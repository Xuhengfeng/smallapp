--2018-06-13
alter table asset alter COLUMN dept_id varchar(20);
--2018-06-20
alter  table  Building  add  last_update_id  bigint;
alter  table  Building  add last_update_time  datetime;

--2018-06-27
CREATE TABLE [dbo].[net_cost] (
[net_cost_id] int NOT NULL IDENTITY(1,1) PRIMARY Key,
[empl_id] int NOT NULL,
[net_type] varchar(10) NOT NULL ,
[net_account] varchar(11) NULL ,
[cost_prod_type] varchar(10) NULL ,
[cost_prod_name] varchar(50) NULL ,
[cost_prod_start] datetime2(7) NULL ,
[cost_prod_end] datetime2(7) NULL ,
[cost_prod_price] numeric(12,2) NULL ,
[cost_prod_status] varchar(10) NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL,
[modify_time] datetime NULL 
)
GO

CREATE TABLE [dbo].[net_cost_detail] (
[net_cost_detail_id] int NOT NULL IDENTITY(1,1) PRIMARY Key,
[net_cost_id] int NOT NULL,
[group_id] int NOT NULL,
[shop_id] int NOT NULL,
[area_id] int NOT NULL,
[big_area_id] int NOT NULL,
[cost_month] varchar(20) NULL ,
[cost_start_date] datetime2(7) NULL ,
[cost_end_date] datetime2(7) NULL ,
[last_remain_money] numeric(12,2) NULL ,
[this_cost_company] numeric(12,2) NULL ,
[this_remain_money] numeric(12,2) NULL ,
[this_cost_money] numeric(12,2) NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL,
[modify_time] datetime NULL 
)
GO
