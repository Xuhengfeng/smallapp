--2018-06-30
IF (select count(param_id) from parameter_all where param_type='网络类型' and param_name='58同城')<=0
  INSERT INTO[parameter_all] ([param_type], [param_name], [param_value], [is_valid], [create_id],[last_update_id]) VALUES ('网络类型', '58同城', '58同城', 'Y', 'jiaxuechao', 'jiaxuechao');
GO

IF (select count(param_id) from parameter_all where param_type='网络类型' and param_name='安居客')<=0
INSERT INTO[parameter_all] ([param_type], [param_name], [param_value], [is_valid], [create_id],[last_update_id]) VALUES ('网络类型', '安居客', '安居客', 'Y', 'jiaxuechao', 'jiaxuechao');
GO

IF (select count(param_id) from parameter_all where param_type='网络类型' and param_name='搜狐')<=0
INSERT INTO[parameter_all] ([param_type], [param_name], [param_value], [is_valid], [create_id],[last_update_id]) VALUES ('网络类型', '搜狐', '搜狐', 'Y', 'jiaxuechao', 'jiaxuechao');
GO

IF (select count(param_id) from parameter_all where param_type='网络类型' and param_name='其他')<=0
INSERT INTO[parameter_all] ([param_type], [param_name], [param_value], [is_valid], [create_id],[last_update_id]) VALUES ('网络类型', '其他', '其他', 'Y', 'jiaxuechao', 'jiaxuechao');
GO

IF (select count(param_id) from parameter_all where param_type='消费类型' and param_name='租房')<=0
INSERT INTO[parameter_all] ([param_type], [param_name], [param_value], [is_valid], [create_id],[last_update_id]) VALUES ('消费类型', '租房', '租房', 'Y', 'jiaxuechao', 'jiaxuechao');
GO

IF (select count(param_id) from parameter_all where param_type='消费类型' and param_name='售房')<=0
INSERT INTO[parameter_all] ([param_type], [param_name], [param_value], [is_valid], [create_id],[last_update_id]) VALUES ('消费类型', '售房', '售房', 'Y', 'jiaxuechao', 'jiaxuechao');
GO

IF (select count(param_id) from parameter_all where param_type='消费类型' and param_name='商铺')<=0
INSERT INTO[parameter_all] ([param_type], [param_name], [param_value], [is_valid], [create_id],[last_update_id]) VALUES ('消费类型', '商铺', '商铺', 'Y', 'jiaxuechao', 'jiaxuechao');
GO

IF (select count(param_id) from parameter_all where param_type='消费类型' and param_name='招聘')<=0
INSERT INTO[parameter_all] ([param_type], [param_name], [param_value], [is_valid], [create_id],[last_update_id]) VALUES ('消费类型', '招聘', '招聘', 'Y', 'jiaxuechao', 'jiaxuechao');
GO

IF (select count(param_id) from parameter_all where param_type='消费类型' and param_name='其他')<=0
INSERT INTO[parameter_all] ([param_type], [param_name], [param_value], [is_valid], [create_id],[last_update_id]) VALUES ('消费类型', '其他', '其他', 'Y', 'jiaxuechao', 'jiaxuechao');
GO