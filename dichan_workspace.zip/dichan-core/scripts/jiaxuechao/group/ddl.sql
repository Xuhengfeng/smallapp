--修改parameter_all表的列类型 ，需要先先清空该字段的数据
--2018-06-09
update parameter_all set modify_time='', create_time = '' ,last_update_time = '';
alter table parameter_all alter COLUMN modify_time datetime;
alter table parameter_all alter COLUMN create_time datetime2(7);
alter table parameter_all alter COLUMN last_update_time datetime2(7);