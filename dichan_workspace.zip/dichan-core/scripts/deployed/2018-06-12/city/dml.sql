update OptionItem set item='组均提成' where OptionItemID=(select OptionItemID from OptionItem where OptionID=(select OptionID from OptionClass o where o.OptionName='提成类别') and item='区均提成');
GO