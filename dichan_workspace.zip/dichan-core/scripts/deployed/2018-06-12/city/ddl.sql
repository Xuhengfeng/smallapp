--------------贾学超---------------
update empl_office set create_time = '' ,last_update_time = '';
alter table empl_office alter COLUMN create_time datetime2(7);
alter table empl_office alter COLUMN last_update_time datetime2(7);

update office set modify_time='', create_time = '' ,last_update_time = '';
alter table office alter COLUMN modify_time datetime;
alter table office alter COLUMN create_time datetime2(7);
alter table office alter COLUMN last_update_time datetime2(7);

update asset set modify_time='', create_time = '' ,last_update_time = '';
alter table asset alter COLUMN modify_time datetime;
alter table asset alter COLUMN create_time datetime2(7);
alter table asset alter COLUMN last_update_time datetime2(7);


-- 添加  底薪表 修改时间  字段
ALTER TABLE basic_salary_info ADD modify_time datetime;