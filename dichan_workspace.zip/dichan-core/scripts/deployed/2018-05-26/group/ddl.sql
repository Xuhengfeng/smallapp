


---贾学超开始018-05-26---------------------------------------------------
--新建参数表
CREATE TABLE [dbo].[parameter_all] (
[param_id] int NOT NULL IDENTITY(1,1) primary key,
[param_type] varchar(10) NOT NULL ,
[param_name] varchar(50) NOT NULL,
[param_value] varchar(20) NULL ,
[is_valid] varchar(10) NOT NULL ,
[create_id] varchar(30) NULL ,
[create_time] varchar(20) NULL ,
[last_update_id] varchar(30) NULL ,
[last_update_time] varchar(20) NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[modify_time] varchar(20) NULL 
)
GO

---贾学超结束018-05-26---------------------------------------------------

-- report daily 表添加唯一约束
alter table report_daily add CONSTRAINT report_daily_un1 UNIQUE (city_name,report_date,group_name)