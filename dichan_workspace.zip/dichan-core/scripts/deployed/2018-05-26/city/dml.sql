--底薪权限配置
IF (select count(PermiID) from Permission where PermissionName='计算底薪' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('计算底薪','底薪表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('查询','底薪表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='删除底薪' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('删除底薪','底薪表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='取消确认' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('取消确认','底薪表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='导出Excel' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('导出Excel','底薪表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='底薪导入' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('底薪导入','底薪表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='拒绝底薪' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('拒绝底薪','底薪表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='提交底薪' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('提交底薪','底薪表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='确认底薪' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('确认底薪','底薪表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='锁定底薪' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('锁定底薪','底薪表','new_erp');
GO