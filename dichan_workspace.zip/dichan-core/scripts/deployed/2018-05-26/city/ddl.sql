---左欢开始2018-05-26----------------------------------
-- ----------------------------
-- Table structure for basic_salary_info
-- ----------------------------
DROP TABLE basic_salary_info
GO
CREATE TABLE basic_salary_info(
[basic_salary_info_id] int NOT NULL IDENTITY(1,1) primary key,
[scity] varchar(30) NULL ,
[sdid] bigint NULL ,
[year_month] varchar(30) NULL ,
[employee_id] int NULL ,
[employee_name] varchar(100) NULL ,
[position_id] int NULL ,
[position_name] varchar(100) NULL ,
[dept_id] int NULL ,
[group_name] varchar(100) NULL ,
[change_position_time] date NULL ,
[change_month_num] int NULL ,
[amount_total] numeric(19,2) NULL ,
[fix_house_num] int NULL ,
[basic_salary] numeric(19,2) NULL ,
[is_new_emp] bit NULL ,
[is_can_change] bit  NULL ,
[board_time] datetime NULL ,
[is_lock] bit NULL ,
[leave_days] numeric(19,2) NULL ,
[incoming_addition] numeric(19,2) NULL ,
[incoming_woking_age] numeric(19,2) NULL ,
[incoming_other] numeric(19,2) NULL ,
[due_income_total] numeric(19,2) NULL ,
[cut_leave] numeric(19,2) NULL ,
[cut_punish] numeric(19,2) NULL ,
[cut_clothes] numeric(19,2) NULL ,
[cut_social_secutiy] numeric(19,2) NULL ,
[cut_fund] numeric(19,2) NULL ,
[cut_borrow] numeric(19,2) NULL ,
[cut_reach_task] numeric(19,2) NULL ,
[cut_rent_house] numeric(19,2) NULL ,
[cut_other] numeric(19,2) NULL ,
[cut_total] numeric(19,2) NULL,
[income_amount] numeric(19,2) NULL ,
[status] varchar(100) NULL ,
[old_status] varchar(100) NULL ,
[create_id] int NULL ,
[create_time] datetime NULL ,
[last_update_id] int NULL ,
[last_update_time] datetime NULL,
[reject_node] varchar(255) NULL
)
GO

--将佣金合同表 分配id改成合同收款B表ID
EXEC sp_rename N'[dbo].[income_contract_info].[distr_id]', N'recpt_bid', 'COLUMN'
GO

---左欢结束2018-05-26----------------------------------


