﻿IF (select count(id) from table_info where table_name='basic_salary_info')<=0
INSERT into table_info 
VALUES('basic_salary_info',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'basic_salary_info_id','number')
GO