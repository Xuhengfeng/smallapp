IF (select count(id) from table_info where table_name='basic_salary_info')<=0
	INSERT into table_info 
	VALUES('basic_salary_info',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'basic_salary_info_id','number')
GO

IF (select count(id) from table_info where table_name='allowance_rule')<=0
	INSERT into table_info 
	VALUES('allowance_rule',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'salary_allowance_rule_id','number')
GO

IF (select count(id) from table_info where table_name='allowance_type')<=0
	INSERT into table_info 
	VALUES('allowance_type',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'allowance_type_id','number')
GO

IF (select count(id) from table_info where table_name='commision_rule')<=0
	INSERT into table_info 
	VALUES('commision_rule',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'commision_rule_id','number')
GO

IF (select count(id) from table_info where table_name='commision_type')<=0
	INSERT into table_info 
	VALUES('commision_type',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'commision_type_id','number')
GO

IF (select count(id) from table_info where table_name='income_contract_info')<=0
	INSERT into table_info 
	VALUES('income_contract_info',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'income_contr_info_id','number')
GO

IF (select count(id) from table_info where table_name='income_emp_info')<=0
	INSERT into table_info 
	VALUES('income_emp_info',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'income_emp_info_id','number')
GO

IF (select count(id) from table_info where table_name='salary_basic_info')<=0
	INSERT into table_info 
	VALUES('salary_basic_info',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'salary_basic_info_id','number')
GO

IF (select count(id) from table_info where table_name='salary_basic_rule')<=0
	INSERT into table_info 
	VALUES('salary_basic_rule',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'salary_basic_rule_id','number')
GO

IF (select count(id) from table_info where table_name='salary_percent_info')<=0
	INSERT into table_info 
	VALUES('salary_percent_info',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'salary_percent_info_id','number')
GO

IF (select count(id) from table_info where table_name='empl_office')<=0
	INSERT into table_info 
	VALUES('empl_office',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'emp_office_id','number')
GO

IF (select count(id) from table_info where table_name='office')<=0
	INSERT into table_info 
	VALUES('office',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'office_id','number')
GO

IF (select count(id) from table_info where table_name='asset')<=0
	INSERT into table_info 
	VALUES('asset',
	(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
	'asset_id','number')
GO