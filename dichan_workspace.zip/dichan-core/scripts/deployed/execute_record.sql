-- 5-24日，运行了城市数据库:集团，湛江，玉林，琼海，梧州，合浦,北海, group

-- 5-26日， 运行了城市数据库:集团，湛江，玉林，琼海，梧州，合浦,北海，group
--   String[] in_city_list = new String[] {"zanjiang","qionghai","wuzhou","hepu","beihai","group","jituan","yulin"};