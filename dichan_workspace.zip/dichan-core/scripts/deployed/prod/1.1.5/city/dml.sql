--审批 2018-09-07 添加，修改，删除权限
IF (select count(PermiID) from Permission where PermissionName='添加' and functionname='普通申请')<=0
  insert Permission(permissionname,functionname,creater) values('添加','普通申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='修改' and functionname='普通申请')<=0
  insert Permission(permissionname,functionname,creater) values('修改','普通申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='删除' and functionname='普通申请')<=0
  insert Permission(permissionname,functionname,creater) values('删除','普通申请','new_erp');
GO


IF (select count(PermiID) from Permission where PermissionName='添加' and functionname='请款申请')<=0
  insert Permission(permissionname,functionname,creater) values('添加','请款申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='修改' and functionname='请款申请')<=0
  insert Permission(permissionname,functionname,creater) values('修改','请款申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='删除' and functionname='请款申请')<=0
  insert Permission(permissionname,functionname,creater) values('删除','请款申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='添加' and functionname='核销申请')<=0
  insert Permission(permissionname,functionname,creater) values('添加','核销申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='修改' and functionname='核销申请')<=0
  insert Permission(permissionname,functionname,creater) values('修改','核销申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='删除' and functionname='核销申请')<=0
  insert Permission(permissionname,functionname,creater) values('删除','核销申请','new_erp');
GO
