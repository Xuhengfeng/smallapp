-----------------------------------左欢----------------------------------------------
--添加 权限表 is_for_group 字段
ALTER TABLE Permission ADD is_for_group varchar(5);
GO
-- 添加  佣金表 ContDistr备注 字段
ALTER TABLE income_contract_info ADD explain varchar(50);
GO

-----------------------------------周乔----------------------------------------------


-----------------------------------韩海飞----------------------------------------------
--通用申请栏目表 增加字段



-----------------------------------贾学超----------------------------------------------

--2018-06-13
alter table asset alter COLUMN dept_id varchar(20);
GO

--2018-06-20
alter  table  Building  add  last_update_id  bigint;
GO

alter  table  Building  add last_update_time  datetime;
GO
