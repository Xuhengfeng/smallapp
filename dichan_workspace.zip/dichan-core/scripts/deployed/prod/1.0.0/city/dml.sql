﻿






-----周桥开始2018-05-23---------------------
--诚意金预订报表
IF (select count(PermiID) from Permission where PermissionName='同步集团员工' and functionname='杂项管理')<=0
  insert Permission(permissionname,functionname,creater) values('同步集团员工','杂项管理','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='妈妈厨房员工导出' and functionname='杂项管理')<=0
  insert Permission(permissionname,functionname,creater) values('妈妈厨房员工导出','杂项管理','new_erp');
GO
IF(select count(id) from table_info where table_name='tysq_details')<=0
INSERT into table_info 
VALUES('tysq_details',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'tysq_details_id','number')
GO

IF(select count(id) from table_info where table_name='field_types')<=0
INSERT into table_info 
VALUES('field_types',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'field_type_id','number')
GO


IF(select count(id) from table_info where table_name='field_chk_rules')<=0
INSERT into table_info 
VALUES('field_chk_rules',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'field_chk_rule_id','number')
GO

IF(select count(id) from table_info where table_name='field_set_values')<=0
INSERT into table_info 
VALUES('field_set_values',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'field_set_value_id','number')
GO

IF(select count(id) from table_info where table_name='Tysq_relation')<=0
INSERT into table_info 
VALUES('Tysq_relation',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'tysq_relation_id','number')
GO
-----左欢结束2018-05-23---------------------

IF (select count(DeptID) from Department where DeptName='集团人员')<=0
	print('新增集团人员...');
	INSERT INTO Department(
						DeptName, 
						Pinyin, 
						HouseTop, 
						CustomerTop, 
						KeyTop,
						is_biz_team
						) VALUES (
						'集团人员', 
						'jtry', 
						'JTRY', 
						'JTRY', 
						'JTRY',
						'N');
GO

IF (select count(PermiID) from Permission where PermissionName='同步集团员工' and functionname='杂项管理')<=0
  insert Permission(permissionname,functionname,creater) values('同步集团员工','杂项管理','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='妈妈厨房员工导出' and functionname='杂项管理')<=0
  insert Permission(permissionname,functionname,creater) values('妈妈厨房员工导出','杂项管理','new_erp');
GO


update Permission set PermissionName = '查询' where FunctionName = '房源报表_查询'
update Permission set PermissionName = '导出Excel' where FunctionName = '房源报表_导出Excel'

