IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='店面报表')<=0
  insert Permission(permissionname,functionname,creater) values('查询','店面报表','new_erp');
GO
IF (select count(PermiID) from Permission where PermissionName='店面信息' and functionname='店面报表')<=0
  insert Permission(permissionname,functionname,creater) values('店面信息','店面报表','new_erp');
GO
IF (select count(PermiID) from Permission where PermissionName='固定资产信息' and functionname='店面报表')<=0
  insert Permission(permissionname,functionname,creater) values('固定资产信息','店面报表','new_erp');
GO

UPDATE office SET create_id  =e.EmplID from Employee e ,office o where e.EmplName=o.create_id;
GO
UPDATE office SET last_update_id  =e.EmplID from Employee e ,office o where e.EmplName=o.last_update_id;
GO

UPDATE asset SET create_id  =e.EmplID from Employee e ,asset a where e.EmplName=a.create_id;
GO
UPDATE asset SET last_update_id  =e.EmplID from Employee e ,asset a where e.EmplName=a.last_update_id;
GO