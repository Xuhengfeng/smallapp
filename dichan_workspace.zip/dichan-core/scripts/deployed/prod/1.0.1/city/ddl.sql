DROP TABLE [dbo].[report_weekly_asset]
GO
CREATE TABLE [dbo].[report_weekly_asset] (
[report_weekly_asset_id] int NOT NULL IDENTITY(1,1) ,
[sdid] bigint NULL ,
[scity] varchar(100) NULL ,
[modify_time] datetime NULL ,
[office_id] int NULL ,
[city_name] varchar(100) NULL ,
[report_date] date NULL ,
[office_name] varchar(255) NULL ,
[start_date] date NULL ,
[rent_money] numeric(19,2) NULL ,
[decorate_money] numeric(19,2) NULL ,
[security_money] numeric(19,2) NULL ,
[transfer_money] numeric(19,2) NULL ,
[office_total_equ_amt] numeric(19,2) NULL ,
[office_total_fur_amt] numeric(19,2) NULL ,
[office_total_sta_amt] numeric(19,2) NULL ,
[office_total_oth_amt] numeric(19,2) NULL ,
[create_id] bigint NULL ,
[create_date_time] datetime2(7) NULL ,
[last_update_id] bigint NULL ,
[update_date_time] datetime2(7) NULL ,
[end_date] date NULL 
)
GO



ALTER TABLE asset ALTER COLUMN dept_id varchar(255) 
GO

EXEC sp_rename N'asset.dept_id', N'dept_name', 'COLUMN'
GO