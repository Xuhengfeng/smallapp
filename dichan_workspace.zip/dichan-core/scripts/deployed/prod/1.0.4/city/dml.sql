--端口管理权限

IF (select count(PermiID) from Permission where PermissionName='端口管理_查询' and functionname='端口管理')<=0
  insert Permission(permissionname,functionname,creater) values('端口管理_查询','端口管理','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='端口管理_新增' and functionname='端口管理')<=0
  insert Permission(permissionname,functionname,creater) values('端口管理_新增','端口管理','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='端口管理_删除' and functionname='端口管理')<=0
  insert Permission(permissionname,functionname,creater) values('端口管理_删除','端口管理','new_erp');
GO