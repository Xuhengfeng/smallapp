----filed_types每个城市源添加一天门店下拉选(追加) 2018-09-11
IF (select count(field_type_id) from field_types where field_type='STOREDROPDOWN' and remark='门店下拉选')<=0
  insert into field_types (field_type,remark) values('STOREDROPDOWN','门店下拉选');
GO
