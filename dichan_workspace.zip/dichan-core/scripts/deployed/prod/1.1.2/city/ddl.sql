--2018-08-31 执行完成
ALTER TABLE tysq_details ADD text20 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text21 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text22 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text23 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text24 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text25 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text26 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text27 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text28 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text29 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD text30 varchar(50) NULL 
GO
ALTER TABLE tysq_details ADD number7 int NULL 
GO
ALTER TABLE tysq_details ADD number8 int NULL 
GO
ALTER TABLE tysq_details ADD number9 int NULL 
GO
ALTER TABLE tysq_details ADD number10 int NULL 
GO
ALTER TABLE tysq_details ADD number11 int NULL 
GO
ALTER TABLE tysq_details ADD number12 int NULL 
GO
ALTER TABLE tysq_details ADD number13 int NULL 
GO
ALTER TABLE tysq_details ADD number14 int NULL 
GO
ALTER TABLE tysq_details ADD amount7 numeric(12,2) NULL 
GO
ALTER TABLE tysq_details ADD amount8 numeric(12,2) NULL 
GO
ALTER TABLE tysq_details ADD amount9 numeric(12,2) NULL 
GO
ALTER TABLE tysq_details ADD amount10 numeric(12,2) NULL 
GO
ALTER TABLE tysq_details ADD amount11 numeric(12,2) NULL 
GO
ALTER TABLE tysq_details ADD amount12 numeric(12,2) NULL 
GO
