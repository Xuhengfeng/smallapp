--2018-09-04 生产已跑批
IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='非业务员工配置表')<=0
	INSERT INTO Permission (PermissionName,FunctionName) VALUES('查询','非业务员工配置表');
GO

IF (select count(PermiID) from Permission where PermissionName='修改' and functionname='非业务员工配置表')<=0
	INSERT INTO Permission (PermissionName,FunctionName) VALUES('修改','非业务员工配置表');
GO

IF (select count(PermiID) from Permission where PermissionName='批量删除' and functionname='非业务员工配置表')<=0
	INSERT INTO Permission (PermissionName,FunctionName) VALUES('批量删除','非业务员工配置表');
GO

IF (select count(PermiID) from Permission where PermissionName='生成提成和底薪' and functionname='非业务员工配置表')<=0
	INSERT INTO Permission (PermissionName,FunctionName) VALUES('生成提成和底薪','非业务员工配置表');
GO