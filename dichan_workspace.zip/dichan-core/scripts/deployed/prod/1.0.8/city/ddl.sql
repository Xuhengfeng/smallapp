--左欢 FjInfo 追加字段  测试环境已跑  2018-08-16
ALTER TABLE FjInfo
ADD function_type varchar(50) NULL 
GO
