--2018-07-25
ALTER TABLE [dbo].[asset] ADD [asset_type_id] int NULL 
GO

ALTER TABLE [dbo].[asset] ADD [asset_name_id] int NULL 
GO

ALTER TABLE [dbo].[asset] ADD [asset_from_id] int NULL 
GO

ALTER TABLE [dbo].[asset] ADD [asset_status_id] int NULL 
GO

ALTER TABLE [dbo].[asset] DROP COLUMN [asset_type]
GO

ALTER TABLE [dbo].[asset] DROP COLUMN [asset_name]
GO

ALTER TABLE [dbo].[asset] DROP COLUMN [asset_from]
GO

ALTER TABLE [dbo].[asset] DROP COLUMN [asset_status]
GO

































