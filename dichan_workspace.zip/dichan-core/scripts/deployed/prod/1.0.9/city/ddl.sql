--周乔 TysqA 修改字段长度  测试环境已跑  2018-08-17

ALTER TABLE TysqA ALTER COLUMN com_req_no varchar(20)
GO

