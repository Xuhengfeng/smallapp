--韩海飞 field_chk_rules 追加字段  测试环境已跑  2018-08-20
ALTER TABLE field_chk_rules ADD field_type varchar(20) NULL 
GO

ALTER TABLE field_chk_rules ALTER COLUMN min_date datetime2 
GO

ALTER TABLE field_chk_rules ALTER COLUMN max_date datetime2 
GO

ALTER TABLE ProceNews ADD is_read varchar(10) NULL 
GO
