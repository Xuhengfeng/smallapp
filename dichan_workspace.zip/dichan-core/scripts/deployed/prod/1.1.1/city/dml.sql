--2018-08-28 
IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='普通申请')<=0
  insert Permission(permissionname,functionname,creater) values('查询','普通申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='请款申请')<=0
  insert Permission(permissionname,functionname,creater) values('查询','请款申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='核销申请')<=0
  insert Permission(permissionname,functionname,creater) values('查询','核销申请','new_erp');
GO