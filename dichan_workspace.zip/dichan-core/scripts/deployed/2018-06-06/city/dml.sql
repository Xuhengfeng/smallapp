﻿






-----周桥开始2018-05-23---------------------
--诚意金预订报表
--房源报表权限
delete from permission where FunctionName ='鎴挎簮鎶ヨ〃' or FunctionName ='鍛樺伐鎶ヨ〃'

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='房源报表')<=0
  insert Permission(permissionname,functionname,creater) values('查询','房源报表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='导出Excel' and functionname='房源报表')<=0
  insert Permission(permissionname,functionname,creater) values('导出Excel','房源报表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='员工报表')<=0
  insert Permission(permissionname,functionname,creater) values('查询','员工报表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='导出Excel' and functionname='员工报表')<=0
  insert Permission(permissionname,functionname,creater) values('导出Excel','员工报表','new_erp');
GO

IF (select count(TaskID) from TaskType where TaskName='资产管理' and TType='业务管理')<=0
  insert TaskType(TaskName,TType,TaskFtp) values('资产管理','业务管理','zcgl');
GO
-----左欢结束2018-05-23---------------------



