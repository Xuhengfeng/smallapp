
----------左欢开始2018-06-06---------------
-------------------------------------------------------底薪表(basic_salary_info)----------------------------------------------

--回滚底薪表  调整底薪 字段
IF COL_LENGTH( 'basic_salary_info','adjust_basic_salary') IS NOT NULL
  alter table basic_salary_info DROP COLUMN adjust_basic_salary
GO

--回滚底薪表  调整底薪说明 字段
IF COL_LENGTH( 'basic_salary_info','adjust_remark') IS NOT NULL
  alter table basic_salary_info DROP COLUMN adjust_remark
GO

--回滚底薪表  离职时间 字段
IF COL_LENGTH( 'basic_salary_info','dimission_time') IS NOT NULL
  alter table basic_salary_info DROP COLUMN dimission_time
GO

--回滚底薪表 是否为当月离职 字段
IF COL_LENGTH( 'basic_salary_info','is_dimission_emp') IS NOT NULL
  alter table basic_salary_info DROP COLUMN is_dimission_emp
GO

--回滚底薪表 网络端口 字段
IF COL_LENGTH( 'basic_salary_info','network_port') IS NOT NULL
  alter table basic_salary_info DROP COLUMN network_port
GO
-------------------------------------------------------提成表(salary_percent_info)----------------------------------------------

--回滚提成表  离职时间 字段
IF COL_LENGTH( 'salary_percent_info','dimission_time') IS NOT NULL
  alter table salary_percent_info DROP COLUMN dimission_time
GO

--回滚提成表  是否为当月离职 字段
IF COL_LENGTH( 'salary_percent_info','is_dimission_emp') IS NOT NULL
  alter table salary_percent_info DROP COLUMN is_dimission_emp
GO


----------周乔开始2018-06-06---------------




----------贾学超开始2018-06-06---------------
--2018-05-28
IF COL_LENGTH( 'office','area_id') IS NOT NULL
  alter table office DROP COLUMN area_id
GO
IF COL_LENGTH( 'office','district_id') IS NOT NULL
  alter table office DROP COLUMN district_id
GO
IF COL_LENGTH( 'office','deptjwd') IS NOT NULL
  alter table office DROP COLUMN deptjwd
GO





----------韩海飞开始2018-06-06---------------