
----------左欢开始2018-06-06---------------
-------------------------------------------------------底薪表(basic_salary_info)----------------------------------------------
--底薪表  调整底薪 字段验证
IF COL_LENGTH( 'basic_salary_info','adjust_basic_salary') IS  NULL
  print '缺少字段：template.basic_salary_info.adjust_basic_salary'
GO

--底薪表  调整底薪说明  字段验证
IF COL_LENGTH( 'basic_salary_info','adjust_remark') IS  NULL
  print '缺少字段：template.basic_salary_info.adjust_remark'
GO


--底薪表  离职时间 字段验证
IF COL_LENGTH( 'basic_salary_info','dimission_time') IS  NULL
  print '缺少字段：template.basic_salary_info.dimission_time'
GO

--底薪表  是否为当月离职  字段验证
IF COL_LENGTH( 'basic_salary_info','is_dimission_emp') IS  NULL
  print '缺少字段：template.basic_salary_info.is_dimission_emp'
GO

--底薪表  网络端口  字段验证
IF COL_LENGTH( 'basic_salary_info','network_port') IS  NULL
  print '缺少字段：template.basic_salary_info.network_port'
GO

-------------------------------------------------------提成表(salary_percent_info)----------------------------------------------

--提成表  离职时间  字段验证
IF COL_LENGTH( 'salary_percent_info','dimission_time') IS  NULL
  print '缺少字段：template.salary_percent_info.dimission_time'
GO

--提成表  是否为当月离职  字段验证
IF COL_LENGTH( 'salary_percent_info','is_dimission_emp') IS  NULL
  print '缺少字段：template.salary_percent_info.is_dimission_emp'
GO



----------周乔开始2018-06-06---------------











----------贾学超开始2018-06-06---------------


--2018-05-28
IF COL_LENGTH( 'office','area_id') IS  NULL
  print '缺少字段：office.area_id'
GO

IF COL_LENGTH( 'office','district_id') IS  NULL
  print '缺少字段：office.district_id'
GO

IF COL_LENGTH( 'office','deptjwd') IS  NULL
  print '缺少字段：office.deptjwd'
GO











----------韩海飞开始2018-06-06---------------