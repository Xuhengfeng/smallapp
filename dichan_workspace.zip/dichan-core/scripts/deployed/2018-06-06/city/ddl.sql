
--------------------------贾学超开始2018-06-06-----------------------------
--2018-05-28 在office表添加3个字段
alter  table  office  add  area_id  int;--区域Id
alter  table  office  add  district_id  int;--片区Id
alter  table  office  add deptjwd  varchar(40);--经纬度（000，000）
alter table FjInfo alter COLUMN Xtwjm VARCHAR(100);


--------------------------左欢开始2018-06-06-----------------------------
-------------------------------------------------------底薪表(basic_salary_info)----------------------------------------------
-- 添加  底薪表 调整底薪 字段
ALTER TABLE basic_salary_info ADD adjust_basic_salary numeric(19,2);

-- 添加  底薪表 调整底薪说明 字段
ALTER TABLE basic_salary_info ADD adjust_remark varchar(255);

-- 添加  底薪表 离职时间 字段
ALTER TABLE basic_salary_info ADD dimission_time date;

-- 添加  底薪表 是否当月离职  字段
ALTER TABLE basic_salary_info ADD is_dimission_emp bit;

-- 添加 底薪表 网络端口 字段
ALTER TABLE basic_salary_info ADD network_port numeric(19,2);
-------------------------------------------------------提成表(salary_percent_info)----------------------------------------------

-- 添加  提成表 离职时间 字段
ALTER TABLE salary_percent_info ADD dimission_time date;

-- 添加  提成表 是否当月离职  字段
ALTER TABLE salary_percent_info ADD is_dimission_emp bit;

--6-7---
--诚意金表添加 代收房款列
alter table sincerity add other_amount numeric(12,2);

--合同表protocol添加预留总费用列
alter table protocol add reserve_fee numeric(12,2);
