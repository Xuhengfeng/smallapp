
-- 添加report_daily表
--CREATE  TABLE  [dbo].[report_daily]  (
--[id]  bigint  NOT  NULL  IDENTITY(1,1)  ,
--[city_name]  varchar(255)  COLLATE  Chinese_PRC_CI_AS  NULL  ,
--[report_date]  date  NULL  ,
--[shop_name]  varchar(255)  COLLATE  Chinese_PRC_CI_AS  NULL  ,
--[members_num]  bigint  NULL  ,
--[join_num]  bigint  NULL  ,
--[dimission_num]  bigint  NULL  ,
--[new_sincerity_num]  bigint  NULL  ,
--[new_sincerity_total]  numeric(19,2)  NULL  ,
--[cancel_sincerity_num]  bigint  NULL  ,
--[cancel_sincerity_amt]  numeric(19,2)  NULL  ,
--[new_dujia_num]  bigint  NULL  ,
--[dujia_total_num]  bigint  NULL  ,
--[new_rent_num]  bigint  NULL  ,
--[new_sale_num]  bigint  NULL  ,
--[new_rent_amt]  numeric(19,2)  NULL  ,
--[new_sale_amt]  numeric(19,2)  NULL  ,
--[rent_due_income_amt]  numeric(19,2)  NULL  ,
--[sale_due_income_amt]  numeric(19,2)  NULL  ,
--[rent_due_other]  numeric(19,2)  NULL  ,
--[sale_due_other]  numeric(19,2)  NULL  ,
--[done_other_amt]  numeric(19,2)  NULL  ,
--[done_income_amt]  numeric(19,2)  NULL  ,
--[create_id]  bigint  NULL  ,
--[create_date_time]  datetime2(7)  NULL  ,
--[update_date_time]  datetime2(7)  NULL  ,
--[sdid]  bigint  NULL  ,
--[scity]  varchar(100)  COLLATE  Chinese_PRC_CI_AS  NULL  ,
--[current_sincerity_num]  bigint  NULL  DEFAULT  NULL  ,
--[current_sincerity_total]  numeric(19,2)  NULL  DEFAULT  NULL  ,
--[sincerity_conv_fix]  numeric(19,2)  NULL  DEFAULT  NULL  ,
--[sincerity_conv_income]  numeric(19,2)  NULL  DEFAULT  NULL  ,
--[group_name]  varchar(255)  COLLATE  Chinese_PRC_CI_AS  NULL  DEFAULT  NULL  
--)
--ON  [PRIMARY]
--GO


--新建report_daily_nonbiz表,人员报表用
CREATE TABLE report_daily_nonbiz (
[id] bigint NOT NULL IDENTITY(1,1) ,
[city_name] varchar(255) COLLATE Chinese_PRC_CI_AS NULL ,
[report_date] date NULL ,
[empl_total_num] bigint NULL ,
[empl_join_num] bigint NULL ,
[empl_dimmision_num] bigint NULL ,
[create_id] bigint null,
[create_date_time] datetime2(7) NULL ,
[last_update_time] datetime2(7) NULL ,
[last_update_id] bigint null,
[sdid] bigint NULL ,
[scity] varchar(100) COLLATE Chinese_PRC_CI_AS NULL ,
)
ON [PRIMARY]
GO



















