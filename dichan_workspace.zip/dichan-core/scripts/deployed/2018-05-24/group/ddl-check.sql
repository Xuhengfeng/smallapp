if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[report_daily]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.report_daily'
GO