if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[report_daily]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[report_daily]
GO

--合同报表,字段回滚
IF COL_LENGTH( 'report_daily','contr_total_num') IS NOT NULL
  alter table report_daily DROP COLUMN contr_total_num
GO

IF COL_LENGTH( 'report_daily','contr_new_num') IS NOT NULL
  alter table report_daily DROP COLUMN contr_total_num
GO

IF COL_LENGTH( 'report_daily','due_income_amt') IS NOT NULL
  alter table report_daily DROP COLUMN due_income_amt
GO

IF COL_LENGTH( 'report_daily','done_income_amt') IS NOT NULL
  alter table report_daily DROP COLUMN done_income_amt
GO

IF COL_LENGTH( 'report_daily','without_income_amt') IS NOT NULL
  alter table report_daily DROP COLUMN without_income_amt
GO
