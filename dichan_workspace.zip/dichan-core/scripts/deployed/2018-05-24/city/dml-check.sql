select * from Permission where functionname = '佣金表' and creater ='new_erp';

select * from Permission where functionname = '诚意金预定' and creater ='new_erp';

select * from Permission where functionname = '诚意金金额' and creater ='new_erp';

select * from Permission where functionname = '审批' and creater ='new_erp';