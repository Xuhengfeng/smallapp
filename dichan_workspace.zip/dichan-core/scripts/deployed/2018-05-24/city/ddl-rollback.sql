﻿

IF COL_LENGTH( 'Employee','last_update_id') IS NOT NULL
  alter table Employee DROP COLUMN last_update_id
GO

IF COL_LENGTH( 'Employee','last_update_time') IS NOT NULL
  alter table Employee DROP COLUMN last_update_time
GO

IF COL_LENGTH( 'department','last_update_id') IS NOT NULL
  alter table department DROP COLUMN last_update_id
GO

IF COL_LENGTH( 'department','last_update_time') IS NOT NULL
  alter table department DROP COLUMN last_update_time
GO

IF COL_LENGTH( 'OptionItem','can_modify') IS NOT NULL
  alter table OptionItem DROP COLUMN can_modify
GO

IF COL_LENGTH( 'OptionItem','remark') IS NOT NULL
  alter table OptionItem DROP COLUMN remark
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[allowance_rule]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[allowance_rule]
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[allowance_type]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[allowance_type];
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[commision_rule]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[commision_rule];
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[commision_type]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[commision_type];
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[income_contract_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[income_contract_info];
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[income_emp_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[income_emp_info];
GO



if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[salary_basic_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[salary_basic_info];
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[salary_basic_rule]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[salary_basic_rule];
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[salary_percent_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[salary_percent_info];
GO

---------左欢开始2018-05-23-----------------------------------------------

IF COL_LENGTH( 'position','last_update_id') IS NOT NULL
  alter table position DROP COLUMN last_update_id
GO

IF COL_LENGTH( 'position','last_update_time') IS NOT NULL
  alter table position DROP COLUMN last_update_time
GO


if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[basic_salary_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[basic_salary_info];
GO

---------左欢结束2018-05-23-----------------------------------------------

---------贾学超开始2018-05-23-----------------------------------------------
if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[empl_office]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[empl_office];
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[office]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[office];
GO

if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[asset]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [dbo].[asset];
GO
---------贾学超结束2018-05-23-----------------------------------------------

