﻿-- employee表做添加一个集团员工,需要在所有分公司数据源中同步,需要添加两个字段
alter  table  Employee  add  last_update_id  bigint;
alter  table  Employee  add last_update_time  datetime;

alter  table  department  add  last_update_id  bigint;
alter  table  department  add last_update_time  datetime;

-- 选项明细表optionItem添加了can_modify,remark
alter  table  OptionItem  add  can_modify  varchar(100);
alter  table  OptionItem  add remark  varchar(500);

-- ----------------------------
-- Table structure for allowance_rule
-- ----------------------------
CREATE TABLE [dbo].[allowance_rule] (
[salary_allowance_rule_id] int NOT NULL IDENTITY(1,1) ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL,
[allowance_amt] numeric(19,2) NULL ,
[allowance_type_id] int NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[incoming_end] numeric(19,2) NULL ,
[incoming_start] numeric(19,2) NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[note] varchar(255) NULL ,
[modify_time] datetime NULL 
)
GO

-- ----------------------------
-- Table structure for allowance_type
-- ----------------------------

CREATE TABLE [dbo].[allowance_type] (
[allowance_type_id] int NOT NULL IDENTITY(1,1) ,
[allowance_type_name] varchar(255) NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[note] varchar(255) NULL ,
[position_id] int NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[modify_time] datetime NULL 
)
GO


-- ----------------------------
-- Table structure for commision_rule
-- ----------------------------

CREATE TABLE [dbo].[commision_rule] (
[commision_rule_id] int NOT NULL IDENTITY(1,1) ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[commin_perct] numeric(19,2) NULL ,
[commision_type_name] varchar(255) NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[incoming_end] numeric(19,2) NULL ,
[incoming_start] numeric(19,2) NULL ,
[is_stage] varchar(255) NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[month_cnt] int NULL ,
[note] varchar(255) NULL ,
[modify_time] datetime NULL 
)
GO

-- ----------------------------
-- Table structure for commision_type
-- ----------------------------
CREATE TABLE [dbo].[commision_type] (
[commision_type_id] int NOT NULL IDENTITY(1,1) ,
[position_id] int NULL ,
[commision_type_name] varchar(255) NULL ,
[note] varchar(255) NULL ,
[create_id] bigint NULL ,
[create_time] datetime NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[modify_time] datetime NULL 
)
GO



CREATE TABLE [dbo].[income_contract_info] (
[income_contr_info_id] int NOT NULL IDENTITY(1,1) ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[cont_id] int NULL ,
[cont_no] varchar(255) NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[deal_date] date NULL ,
[dept_id] int NULL ,
[distr_ratio] numeric(19,2) NULL ,
[due_amount_total] numeric(19,2) NULL ,
[due_income_total] numeric(19,2) NULL ,
[employee_id] int NULL ,
[employee_name] varchar(255) NULL ,
[house_addr] varchar(255) NULL ,
[income_amount] numeric(19,2) NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[old_status] varchar(255) NULL ,
[pay_type] varchar(255) NULL ,
[position_id] int NULL ,
[rece_date] varchar(255) NULL ,
[recpt_no] varchar(255) NULL ,
[reject_node] varchar(255) NULL ,
[status] varchar(255) NULL ,
[trade_type] varchar(255) NULL ,
[year_month] varchar(255) NULL ,
[group_name] varchar(255) NULL ,
[shop_name] varchar(255) NULL ,
[positon_name] varchar(255) NULL ,
[emp_income] numeric(19,2) NULL ,
[old_emp_income] numeric(19,2) NULL ,
[modify_time] datetime NULL 
)
GO


CREATE TABLE [dbo].[income_emp_info] (
[income_emp_info_id] int NOT NULL IDENTITY(1,1) ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[dept_id] int NULL ,
[dimission_date] date NULL ,
[employee_id] int NULL ,
[employee_name] varchar(255) NULL ,
[group_name] varchar(255) NULL ,
[is_new_emp] int NULL ,
[join_date] date NULL ,
[join_month_num] int NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[manager_id] int NULL ,
[manager_name] varchar(255) NULL ,
[position_id] int NULL ,
[positon_name] varchar(255) NULL ,
[shop_name] varchar(255) NULL ,
[year_month] varchar(255) NULL ,
[modify_time] datetime NULL 
)
GO

CREATE TABLE [dbo].[salary_basic_info] (
[salary_basic_info_id] int NOT NULL ,
[position_id] int NULL ,
[is_incoming_rel] varchar(1) NULL ,
[is_dujia_rel] varchar(1) NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL 
)
GO


CREATE TABLE [dbo].[salary_basic_rule] (
[salary_basic_rule_id] int NOT NULL IDENTITY(1,1) NOT FOR REPLICATION ,
[position_name] varchar(100) NULL ,
[is_incoming_rel] varchar(1) NULL,
[is_dujia_rel] varchar(1) NULL,
[incoming_num] numeric(19,2) NULL ,
[dujia_count] int NULL ,
[salary_both_reach] numeric(19,2) NULL ,
[salary_both_unreach] numeric(19,2) NULL ,
[salary_incoming_reach] numeric(19,2) NULL ,
[salary_dujia_reach] numeric(19,2) NULL ,
[without_rel_month_cnt] int NULL ,
[note] varchar(200) NULL,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[create_date_time] datetime2(7) NULL ,
[update_date_time] datetime2(7) NULL ,
[sdid] bigint NULL ,
[scity] varchar(100) NULL ,
[modify_time] datetime NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL 
)
GO

CREATE TABLE [dbo].[salary_percent_info] (
[salary_percent_info_id] int NOT NULL IDENTITY(1,1) ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[income_other] numeric(19,2) NULL ,
[allowance_amt] numeric(19,2) NULL ,
[amount] numeric(19,2) NULL ,
[amount_total] numeric(19,2) NULL ,
[basic_salary] numeric(19,2) NULL ,
[change_month_num] int NULL ,
[change_position_time] date NULL ,
[commi_perct] numeric(19,2) NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[cut_borrow] numeric(19,2) NULL ,
[cut_other] numeric(19,2) NULL ,
[cut_reach_task] numeric(19,2) NULL ,
[cut_total] numeric(19,2) NULL ,
[due_income_total] numeric(19,2) NULL ,
[employee_id] int NULL ,
[income_amount] numeric(19,2) NULL ,
[is_can_change] varchar(255) NULL ,
[is_stage] bit NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[old_status] varchar(255) NULL ,
[position_id] int NULL ,
[status] varchar(255) NULL ,
[trade_type] varchar(255) NULL ,
[type] varchar(255) NULL ,
[year_month] varchar(255) NULL ,
[dept_id] int NULL ,
[employee_name] varchar(255) NULL ,
[group_name] varchar(255) NULL ,
[positon_name] varchar(255) NULL ,
[shop_name] varchar(255) NULL ,
[modify_time] datetime NULL 
)
GO


ALTER TABLE [dbo].[allowance_rule] ADD PRIMARY KEY ([salary_allowance_rule_id])
GO


ALTER TABLE [dbo].[allowance_type] ADD PRIMARY KEY ([allowance_type_id])
GO


ALTER TABLE [dbo].[commision_rule] ADD PRIMARY KEY ([commision_rule_id])
GO

ALTER TABLE [dbo].[commision_type] ADD PRIMARY KEY ([commision_type_id])
GO

-- ----------------------------
-- Indexes structure for table income_contract_info
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table income_contract_info
-- ----------------------------
ALTER TABLE [dbo].[income_contract_info] ADD PRIMARY KEY ([income_contr_info_id])
GO

-- ----------------------------
-- Indexes structure for table income_emp_info
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table income_emp_info
-- ----------------------------
ALTER TABLE [dbo].[income_emp_info] ADD PRIMARY KEY ([income_emp_info_id])
GO

-- ----------------------------
-- Indexes structure for table salary_basic_info
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table salary_basic_info
-- ----------------------------
ALTER TABLE [dbo].[salary_basic_info] ADD PRIMARY KEY ([salary_basic_info_id])
GO

-- ----------------------------
-- Indexes structure for table salary_percent_info
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table salary_percent_info
-- ----------------------------
ALTER TABLE [dbo].[salary_percent_info] ADD PRIMARY KEY ([salary_percent_info_id])
GO

-------左欢开始2018-05-23----------------------------------------------

-- 添加  提成表 业绩类型 字段
ALTER TABLE salary_percent_info ADD amount_type varchar(20);
--添加提成表 提成金额 自动
ALTER TABLE salary_percent_info ADD commision numeric(19,2);
-- 添加  提成表 拒绝原因 字段
ALTER TABLE salary_percent_info ADD reject_node varchar(255);
-- 添加  提成表 是否锁定 字段
ALTER TABLE salary_percent_info ADD is_lock bit;
-- 添加  提成表 调整后提成 字段
ALTER TABLE salary_percent_info ADD adjust_commision numeric(19,2);
-- 添加  提成表 调整说明 字段
ALTER TABLE salary_percent_info ADD adjust_remark varchar(255);

-- 添加  佣金表 是否锁定 字段
ALTER TABLE income_contract_info ADD is_lock bit ;
-- 添加  佣金表 分配ID 字段
ALTER TABLE income_contract_info ADD distr_id int ;

--添加 岗位表 最后修改者ID 字段
ALTER TABLE position ADD last_update_id bigint ;
--添加 岗位表 最后修改时间  字段
ALTER TABLE position ADD last_update_time datetime ;


--添加 佣金表 入职时间  字段
ALTER TABLE income_contract_info ADD change_position_time date ;



-- ----------------------------
-- Table structure for basic_salary_info
-- ----------------------------

CREATE TABLE basic_salary_info(
[basic_salary_info_id] int NOT NULL IDENTITY(1,1) primary key,
[scity] varchar(30) NULL ,
[sdid] bigint NULL ,
[year_month] varchar(30) NULL ,
[employee_id] int NULL ,
[employee_name] varchar(100) NULL ,
[position_id] int NULL ,
[position_name] varchar(100) NULL ,
[dept_id] int NULL ,
[group_name] varchar(1) NULL ,
[change_position_time] date NULL ,
[change_month_num] int NULL ,
[amount_total] numeric(19,2) NULL ,
[fix_house_num] int NULL ,
[basic_salary] numeric(19,2) NULL ,
[is_new_emp] char(1) NULL ,
[is_can_change] char(1) NULL ,
[board_time] datetime NULL ,
[is_lock] bit NULL ,
[leave_days] numeric(19,2) NULL ,
[incoming_addition] numeric(19,2) NULL ,
[incoming_woking_age] numeric(19,2) NULL ,
[incoming_other] numeric(19,2) NULL ,
[dueIncome_total] numeric(19,2) NULL ,
[cut_leave] numeric(19,2) NULL ,
[cut_punish] numeric(19,2) NULL ,
[cut_clothes] numeric(19,2) NULL ,
[cut_social_secutiy] numeric(19,2) NULL ,
[cut_fund] numeric(19,2) NULL ,
[cut_borrow] numeric(19,2) NULL ,
[cut_reach_task] numeric(19,2) NULL ,
[cut_rent_house] numeric(19,2) NULL ,
[cut_other] numeric(19,2) NULL ,
[income_amount] numeric(19,2) NULL ,
[status] varchar(100) NULL ,
[old_status] varchar(100) NULL ,
[create_id] int NULL ,
[create_time] datetime NULL ,
[last_update_id] int NULL ,
[last_update_time] datetime NULL 
)
GO


-------左欢结束2018-05-23----------------------------------------------



-------贾学超开始2018-05-23----------------------------------------------

--新建办公场所权限表， 需要在所有分公司数据源中同步
CREATE TABLE [dbo].[empl_office] (
[emp_office_id] int NOT NULL IDENTITY(1,1) ,
[empl_id] int NOT NULL ,
[office_id] int NOT NULL,
[create_id] bigint NULL ,
[create_time] datetime NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[modify_time] datetime NULL 
)
GO

--新建办公场所权限表， 需要在所有分公司数据源中同步
CREATE TABLE [dbo].[office] (
[office_id] int NOT NULL IDENTITY(1,1) ,
[office_name] varchar(60) NOT NULL ,
[office_area] numeric(12,2) NULL,
[phone_num_pre] varchar(4) NULL ,
[phone_num] varchar(20) NULL ,
[address] varchar(60) NULL,
[start_date] varchar(20) NULL ,
[end_date] varchar(20) NULL,
[days_without_money] varchar(20) NULL ,
[rent_money] numeric(12,2) NULL,
[decorate_money] numeric(12,2) NULL ,
[security_money] numeric(12,2) NULL,
[transfer_money] numeric(12,2) NULL ,
[pay_type] varchar(10) NULL,
[transfer_goods] varchar(400) NULL,
[create_id] varchar(30) NOT NULL ,
[create_time] varchar(20) NOT NULL ,
[last_update_id] varchar(30) NOT NULL ,
[last_update_time] varchar(20) NOT NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[modify_time] varchar(20) NULL 
)
GO

--新建资产明细表， 需要在所有分公司数据源中同步
CREATE TABLE [dbo].[asset] (
[asset_id] int NOT NULL IDENTITY(1,1) ,
[office_id] int NOT NULL ,
[asset_type] varchar(10) NOT NULL,
[asset_name] varchar(30) NOT NULL ,
[asset_no] varchar(30) NOT NULL ,
[asset_unit] varchar(30) NULL,
[asset_price] numeric(12,2) NULL ,
[brand_name] varchar(30) NULL,
[goods_type] varchar(30) NULL ,
[factory_name] varchar(30) NULL,
[goods_color] varchar(30) NULL ,
[goods_manu_date] varchar(30) NULL,
[asset_from] varchar(30) NULL ,
[asset_status] varchar(10) NULL,
[setup_position] varchar(30) NULL,
[receipt_no] varchar(30) NULL ,
[dept_id] int NULL,
[create_id] varchar(30) NOT NULL ,
[create_time] varchar(20) NOT NULL ,
[last_update_id] varchar(30) NOT NULL ,
[last_update_time] varchar(20) NOT NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[modify_time] varchar(20) NULL 
)
GO

-------贾学超结束2018-05-23----------------------------------------------
















