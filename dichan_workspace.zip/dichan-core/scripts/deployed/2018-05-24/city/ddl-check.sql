
IF COL_LENGTH( 'Employee','last_update_id') IS  NULL
  print '缺少字段：template.employee.last_update_id'
GO

IF COL_LENGTH( 'Employee','last_update_time') IS  NULL
  print '缺少字段：template.employee.last_update_time'
GO

IF COL_LENGTH( 'department','last_update_id') IS  NULL
  print '缺少字段：template.department.last_update_id'
GO

IF COL_LENGTH( 'department','last_update_time') IS  NULL
  print '缺少字段：template.department.last_update_time'
GO

IF COL_LENGTH( 'OptionItem','can_modify') IS  NULL
  print '缺少字段：template.OptionItem.can_modify'
GO

IF COL_LENGTH( 'OptionItem','remark') IS  NULL
  print '缺少字段：template.OptionItem.remark'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[allowance_rule]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.allowance_rule'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[allowance_type]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.allowance_type'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[commision_rule]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.commision_rule'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[commision_type]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.commision_type'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[income_contract_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.income_contract_info'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[income_emp_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.income_emp_info'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[percent_sub_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.percent_sub_info'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[salary_basic_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.salary_basic_info'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[salary_basic_rule]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.salary_basic_rule'
GO

if not exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[salary_percent_info]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
  print '缺少表：template.salary_percent_info'
GO



