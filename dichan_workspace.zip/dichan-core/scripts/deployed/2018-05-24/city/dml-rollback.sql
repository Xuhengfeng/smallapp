﻿


-----周桥开始2018-05-23---------------------

delete Permission where functionname = '诚意金预定' and creater ='new_erp';

delete Permission where functionname = '诚意金金额' and creater ='new_erp';

delete Permission where functionname = '合同报表' and creater ='new_erp';

-----周桥结束2018-05-23---------------------

-----韩海飞开始2018-05-23---------------------
delete Permission where functionname = '审批' and creater ='new_erp';
-- 定房报表权限

delete Permission where functionname = '定房报表' and creater ='new_erp';
-- 客源报表权限


delete Permission where functionname = '客源报表' and creater ='new_erp';

-----韩海飞结束2018-05-23---------------------

-----贾学超开始2018-05-23---------------------

delete Permission where functionname = '资产管理' and creater ='new_erp';


-----贾学超结束2018-05-23---------------------


-----左欢开始2018-05-23---------------------
-- 佣金表权限字段
delete Permission where functionname = '佣金表' and creater ='new_erp';


delete Permission where functionname = '提成表' and creater ='new_erp';

--底薪权限配置

delete Permission where functionname = '底薪表' and creater ='new_erp';
--工资配置


delete from OptionItem where OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置');
delete from OptionClass where OptionName='工资岗位' and OptionType='工资配置';


delete from OptionItem where OptionID=(select OptionID from OptionClass where OptionType='工资配置' and OptionName='提成类别');
delete from OptionClass where OptionName='提成类别' and OptionType='工资配置';

-----左欢结束2018-05-23---------------------
