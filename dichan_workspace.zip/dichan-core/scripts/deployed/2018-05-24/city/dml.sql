﻿






-----周桥开始2018-05-23---------------------
--诚意金预订报表
IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='诚意金预定')<=0
  insert Permission(permissionname,functionname,creater) values('查询','诚意金预定','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='导出excel' and functionname='诚意金预定')<=0
  insert Permission(permissionname,functionname,creater) values('导出excel','诚意金预定','new_erp');
GO

--诚意金金额报表
IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='诚意金金额')<=0
  insert Permission(permissionname,functionname,creater) values('查询','诚意金金额','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='导出excel' and functionname='诚意金金额')<=0
  insert Permission(permissionname,functionname,creater) values('导出excel','诚意金金额','new_erp');
GO

--合同报表
IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='合同报表')<=0
  insert Permission(permissionname,functionname,creater) values('查询','合同报表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='导出excel' and functionname='合同报表')<=0
  insert Permission(permissionname,functionname,creater) values('导出excel','合同报表','new_erp');
GO

-----周桥结束2018-05-23---------------------

-----贾学超开始2018-05-23---------------------
IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='资产管理')<=0
  insert Permission(permissionname,functionname,creater) values('查询','资产管理','new_erp');
GO
IF (select count(PermiID) from Permission where PermissionName='新增' and functionname='资产管理')<=0
  insert Permission(permissionname,functionname,creater) values('新增','资产管理','new_erp');
GO
IF (select count(PermiID) from Permission where PermissionName='删除' and functionname='资产管理')<=0
  insert Permission(permissionname,functionname,creater) values('删除','资产管理','new_erp');
GO
IF (select count(PermiID) from Permission where PermissionName='修改' and functionname='资产管理')<=0
  insert Permission(permissionname,functionname,creater) values('修改','资产管理','new_erp');
GO

-----贾学超结束2018-05-23---------------------

-----韩海飞开始2018-05-23---------------------
IF (select count(PermiID) from Permission where PermissionName='查询审批' and functionname='审批')<=0
insert Permission(permissionname,functionname,creater) values('查询审批','审批','new_erp');
GO

-- 定房报表权限
IF (select count(PermiID) from Permission where PermissionName='导出Excel' and functionname='定房报表')<=0
insert Permission(permissionname,functionname,creater) values('导出Excel','定房报表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='定房报表')<=0
insert Permission(permissionname,functionname,creater) values('查询','定房报表','new_erp');
GO

-- 客源报表权限
IF (select count(PermiID) from Permission where PermissionName='导出Excel' and functionname='客源报表')<=0
insert Permission(permissionname,functionname,creater) values('导出Excel','客源报表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='客源报表')<=0
insert Permission(permissionname,functionname,creater) values('查询','客源报表','new_erp');
GO



-----韩海飞结束2018-05-23---------------------


-----左欢开始2018-05-23---------------------
-- 佣金表权限字段
IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='佣金表')<=0
  insert Permission(permissionname,functionname,creater) values('查询','佣金表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='计算员工' and functionname='佣金表')<=0
  insert Permission(permissionname,functionname,creater) values('计算员工','佣金表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='计算佣金' and functionname='佣金表')<=0
  insert Permission(permissionname,functionname,creater) values('计算佣金','佣金表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='提交佣金' and functionname='佣金表')<=0
  insert Permission(permissionname,functionname,creater) values('提交佣金','佣金表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='确认佣金' and functionname='佣金表')<=0
  insert Permission(permissionname,functionname,creater) values('确认佣金','佣金表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='拒绝佣金' and functionname='佣金表')<=0
  insert Permission(permissionname,functionname,creater) values('拒绝佣金','佣金表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='导出excel' and functionname='佣金表')<=0
  insert Permission(permissionname,functionname,creater) values('导出excel','佣金表','new_erp');
GO


--提成权限
IF (select count(PermiID) from Permission where PermissionName='计算提成' and functionname='提成表')<=0
  insert Permission(permissionname,functionname,creater) values('计算提成','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='提成表')<=0
  insert Permission(permissionname,functionname,creater) values('查询','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='导出Excel' and functionname='提成表')<=0
  insert Permission(permissionname,functionname,creater) values('导出Excel','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='提交提成' and functionname='提成表')<=0
  insert Permission(permissionname,functionname,creater) values('提交提成','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='确认提成' and functionname='提成表')<=0
  insert Permission(permissionname,functionname,creater) values('确认提成','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='拒绝提成' and functionname='提成表')<=0
  insert Permission(permissionname,functionname,creater) values('拒绝提成','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='取消确认' and functionname='提成表')<=0
  insert Permission(permissionname,functionname,creater) values('取消确认','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='锁定提成' and functionname='提成表')<=0
  insert Permission(permissionname,functionname,creater) values('锁定提成','提成表','new_erp');
GO

--区均总均查询权限
IF (select count(PermiID) from Permission where PermissionName='查询区经提成' and functionname='提成表')<=0
insert Permission(permissionname,functionname,creater) values('查询区经提成','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询总经提成' and functionname='提成表')<=0
insert Permission(permissionname,functionname,creater) values('查询总经提成','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='提成导入' and functionname='提成表')<=0
insert Permission(permissionname,functionname,creater) values('提成导入','提成表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='删除提成' and functionname='提成表')<=0
insert Permission(permissionname,functionname,creater) values('删除提成','提成表','new_erp');
GO

--底薪权限配置
IF (select count(PermiID) from Permission where PermissionName='计算底薪' and functionname='底薪表')<=0
  insert Permission(permissionname,functionname,creater) values('计算底薪','底薪表','new_erp');
GO

--工资配置
IF(select count(OptionID) from OptionClass where OptionType='工资配置' and OptionName='工资岗位')<=0
  INSERT INTO OptionClass ([OptionType], [OptionName]) VALUES ('工资配置','工资岗位');
GO

--工资岗位字段
IF (select count(OptionItemID) from OptionItem where Item='见习置业顾问' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '见习置业顾问', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem where Item='置业顾问' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '置业顾问', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem where Item='高级置业顾问' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
	INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '高级置业顾问', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem where Item='业务主任' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '业务主任', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem where Item='见习营业经理' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '见习营业经理', '0', '系统管理员','2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem where Item='营业经理' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '营业经理', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem where Item='高级营业经理' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '高级营业经理', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem where Item='区域经理' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '区域经理', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem where Item='高级区域经理' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '高级区域经理', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem where Item='总经理' and OptionID=(select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'))<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from OptionClass where OptionName='工资岗位' and OptionType='工资配置'), '总经理', '0', '系统管理员', '2018-03-27');
GO





--增加提成配置
IF(select count(OptionID) from OptionClass where OptionType='工资配置' and OptionName='提成类别')<=0
  INSERT INTO OptionClass ([OptionType], [OptionName]) VALUES ('工资配置','提成类别');
GO
--添加提成配置字段
IF (select count(OptionItemID) from OptionItem oi inner join OptionClass oc on oi.OptionID=oc.OptionID  where Item='个人提成' and OptionType='工资配置' and OptionName='提成类别')<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from  OptionClass where OptionType='工资配置' and OptionName='提成类别'), '个人提成', '0', '系统管理员', '2018-03-27');
GO
IF (select count(OptionItemID) from OptionItem oi inner join OptionClass oc on oi.OptionID=oc.OptionID  where Item='营业经理提成' and OptionType='工资配置' and OptionName='提成类别')<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from  OptionClass where OptionType='工资配置' and OptionName='提成类别'), '营业经理提成', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem oi inner join OptionClass oc on oi.OptionID=oc.OptionID  where Item='组均提成' and OptionType='工资配置' and OptionName='提成类别')<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from  OptionClass where OptionType='工资配置' and OptionName='提成类别'), '区均提成', '0', '系统管理员', '2018-03-27');
GO

IF (select count(OptionItemID) from OptionItem oi inner join OptionClass oc on oi.OptionID=oc.OptionID  where Item='店均提成' and OptionType='工资配置' and OptionName='提成类别')<=0
  INSERT INTO OptionItem ([OptionID], [Item], [Xh], [Creater], [CreateTime]) VALUES ((select OptionID from  OptionClass where OptionType='工资配置' and OptionName='提成类别'), '店均提成', '0', '系统管理员', '2018-03-27');
GO




--提成类别字段修改 区经提成-》区均提成   总经理提成-》店均提成
--IF (select count(OptionItemID) from OptionItem oi inner join OptionClass oc on oi.OptionID=oc.OptionID  where Item='区经提成' and OptionType='工资配置' and OptionName='提成类别')>0
--	update OptionItem set item='区均提成' where OptionID=(select OptionID from  OptionClass  where OptionType='工资配置' and OptionName='提成类别') and Item='区经提成'
--GO
--IF (select count(OptionItemID) from OptionItem oi inner join OptionClass oc on oi.OptionID=oc.OptionID  where Item='总经理提成' and OptionType='工资配置' and OptionName='提成类别')>0
--	update OptionItem set item='店均提成' where OptionID=(select OptionID from  OptionClass where OptionType='工资配置' and OptionName='提成类别') and Item='总经理提成';
--GO






-----左欢结束2018-05-23---------------------



