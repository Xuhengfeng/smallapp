IF(select count(id) from table_info where table_name='tysq_details')<=0
INSERT into table_info 
VALUES('tysq_details',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'tysq_details_id','number')
GO

IF(select count(id) from table_info where table_name='field_types')<=0
INSERT into table_info 
VALUES('field_types',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'field_type_id','number')
GO


IF(select count(id) from table_info where table_name='field_chk_rules')<=0
INSERT into table_info 
VALUES('field_chk_rules',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'field_chk_rule_id','number')
GO

IF(select count(id) from table_info where table_name='field_set_values')<=0
INSERT into table_info 
VALUES('field_set_values',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'field_set_value_id','number')
GO

IF(select count(id) from table_info where table_name='Tysq_relation')<=0
INSERT into table_info 
VALUES('Tysq_relation',
(select (CASE when 4-LEN((MAX(order_num)+1))=2 THEN '00'+LTRIM((MAX(order_num)+1)) WHEN 4-LEN((MAX(order_num)+1))=1 THEN '0'+LTRIM((MAX(order_num)+1)) ELSE MAX(order_num) END) from table_info),
'tysq_relation_id','number')
GO

