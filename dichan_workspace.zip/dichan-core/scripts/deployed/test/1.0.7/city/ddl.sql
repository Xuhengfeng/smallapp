--韩海飞 field_chk_rules 追加字段  测试环境已跑  2018-08-15
ALTER TABLE field_chk_rules ADD field_type varchar(20) NULL 
GO