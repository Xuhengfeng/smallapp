DROP TABLE [dbo].[non_buzi_employee]
GO
CREATE TABLE [dbo].[non_buzi_employee] (
[non_buzi_employee_id] int NOT NULL IDENTITY(1,1) ,
[employee_id] int NULL ,
[gen_type] varchar(50) NULL ,
[basic_salary] numeric(19,2) NULL ,
[percent_salary] numeric(19,2) NULL ,
[cut_social_secutiy] numeric(19,2) NULL ,
[cut_fund] numeric(19,2) NULL ,
[cut_rent_house] numeric(19,2) NULL ,
[note] varchar(225) NULL ,
[scity] varchar(255) NULL ,
[sdid] bigint NULL ,
[create_id] bigint NULL ,
[create_time] datetime2(7) NULL ,
[last_update_id] bigint NULL ,
[last_update_time] datetime2(7) NULL ,
[modify_time] datetime NULL 
)


GO

-- ----------------------------
-- Indexes structure for table non_buzi_employee
-- ----------------------------

-- ----------------------------
-- Primary Key structure for table non_buzi_employee
-- ----------------------------
ALTER TABLE [dbo].[non_buzi_employee] ADD PRIMARY KEY ([non_buzi_employee_id])
GO