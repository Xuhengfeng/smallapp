--韩海飞 net_cost 追加字段  测试环境已跑  2018-08-13
ALTER TABLE net_cost ADD cost_prod_pay varchar(10) NULL 
GO