
ALTER TABLE [dbo].[asset] ADD [asset_type_id] int NULL 
GO

ALTER TABLE [dbo].[asset] ADD [asset_name_id] int NULL 
GO

ALTER TABLE [dbo].[asset] ADD [asset_from_id] int NULL 
GO

ALTER TABLE [dbo].[asset] ADD [asset_status_id] int NULL 
GO

ALTER TABLE [dbo].[asset] DROP COLUMN [asset_type]
GO

ALTER TABLE [dbo].[asset] DROP COLUMN [asset_name]
GO

ALTER TABLE [dbo].[asset] DROP COLUMN [asset_from]
GO

ALTER TABLE [dbo].[asset] DROP COLUMN [asset_status]

GO

CREATE TABLE [dbo].[fin_loan] (
[fin_loan_id] int NOT NULL ,
[fin_loan_no] varchar(9) NOT NULL ,
[fin_house_id] int NOT NULL ,
[fin_loan_type] varchar(30) NULL ,
[loan_amt] numeric(10,2) NULL ,
[loan_limit_time] numeric(10,2) NULL ,
[inte_pay_type] varchar(30) NULL ,
[inte_rate] numeric(10,2) NULL ,
[has_loan_contr_no] varchar(1) NULL ,
[loan_contr_no] varchar(30) NULL ,
[biz_progress] varchar(30) NULL ,
[pay_status] varchar(10) NULL ,
[return_status] varchar(10) NULL ,
[verify_status] varchar(10) NULL ,
[process_path_id] int NULL ,
[process_name] varchar(30) NULL ,
[process_status] varchar(10) NULL ,
[approve_id] int NULL ,
[approve_name] varchar(30) NULL ,
[create_id] int NOT NULL ,
[create_name] varchar(30) NOT NULL ,
[create_time] datetime2(7) NOT NULL ,
[last_update_id] int NOT NULL ,
[last_update_name] varchar(30) NOT NULL ,
[last_update_time] datetime2(7) NOT NULL ,
[modify_time] datetime NULL ,
[sdid] bigint NULL ,
[scity] varchar(100) NULL ,
PRIMARY KEY ([fin_loan_id])
)

GO


CREATE TABLE [dbo].[fin_follow] (
[fin_follow_id] int NOT NULL ,
[fin_house_id] int NOT NULL ,
[follow_date] varchar(10) NOT NULL ,
[cur_follow_type_id] nvarchar(30) NULL ,
[remark] varchar(200) NULL ,
[create_id] int NOT NULL ,
[create_time] datetime2(7) NOT NULL ,
[last_update_id] int NOT NULL ,
[last_update_time] datetime2(7) NOT NULL ,
[modify_time] datetime NULL ,
[sdid] bigint NULL ,
[scity] varchar(100) NULL ,
PRIMARY KEY ([fin_follow_id])
)

GO



ALTER TABLE [dbo].[field_chk_rules] ADD [field_type] varchar(20) NULL 
GO

ALTER TABLE [dbo].[field_chk_rules] ALTER COLUMN [min_date] datetime2 
GO

ALTER TABLE [dbo].[field_chk_rules] ALTER COLUMN [max_date] datetime2 
GO

ALTER TABLE [dbo].[ProceNews] ADD [is_read] varchar(10) NULL 
GO


--2018-09-08 去除掉proceNews中的未读，在procePath中加入is_read
ALTER TABLE [dbo].[ProceNews] DROP COLUMN [is_read]
GO

ALTER TABLE [dbo].[ProcePath] ADD [is_read] varchar(30) NULL 
GO




























