--通用申请栏目表 增加字段
alter table TysqItem add field_chk_rule_id int NULL;
GO
alter table TysqItem add field_type_id int NULL;
GO
alter table TysqItem add is_mandatory varchar(1);
GO
alter table TysqItem add rel_column_name varchar(30);
GO
--通用申请类型表 增加字段
alter table TysqType add sub_manage_type varchar(20);
GO
alter table TysqType add is_new_sys varchar(1);
GO
alter table TysqType add tysq_scope varchar(10);
GO
alter table TysqType add need_verify varchar(1);
GO
alter table TysqType add is_shop_type varchar(1);
GO
alter table TysqType add rel_tysqtypeid int NULL;
GO


--通用申请主表 增加字段
alter table TysqA add com_req_no varchar(10);
GO
alter table TysqA add is_shop_type varchar(1);
GO
alter table TysqA add status varchar(10);
GO
alter table TysqA add ori_tysqa_id int NULL;
GO
alter table TysqA add tysq_type varchar(20);
GO

-- ----------------------------
-- Table field_types
-- ----------------------------
DROP table field_types 
GO
CREATE TABLE [dbo].[field_types] (
[field_type_id] int NOT NULL IDENTITY(1,1) PRIMARY Key,
[field_type] varchar(20) NULL ,
[remark] varchar(200) NULL ,
[sdid] bigint NULL ,
[scity] varchar(100) NULL ,
[modify_time] datetime NULL 
)
GO

-- ----------------------------
-- Table field_chk_rules
-- ----------------------------
DROP table field_chk_rules 
GO
CREATE TABLE [dbo].[field_chk_rules] (
[field_chk_rule_id] int NOT NULL IDENTITY(1,1) PRIMARY Key,
[field_chk_rule_name] varchar(30) NULL ,
[field_type_id] int NULL ,
[min_len] int NULL ,
[max_len] int NULL ,
[min_value] int NULL ,
[max_value] int NULL ,
[min_date] date NULL ,
[max_date] date NULL ,
[float_len] int NULL ,
[reg_express] varchar(100) NULL ,
[remark] varchar(200) NULL ,
[sdid] bigint NULL ,
[scity] varchar(100) NULL ,
[modify_time] datetime NULL 
)
GO

-- ----------------------------
-- Table field_set_values
-- ----------------------------
DROP table field_set_values 
GO
CREATE TABLE [dbo].[field_set_values] (
[field_set_value_id] int NOT NULL IDENTITY(1,1) PRIMARY Key,
[field_chk_rule_id] int NULL ,
[set_value] varchar(30) NULL ,
[order_num] int NULL ,
[sdid] bigint NULL ,
[scity] varchar(100) NULL ,
[modify_time] datetime NULL 
)
GO

-- ----------------------------
-- Table Tysq_relation
-- ----------------------------
DROP table Tysq_relation 
GO
CREATE TABLE [dbo].[Tysq_relation] (
[tysq_relation_id] int NOT NULL IDENTITY(1,1) PRIMARY Key,
[tysqa_id] int NULL ,
[req_dtl_id] int NULL ,
[ori_req_dtl_id] int NULL ,
[amount] numeric(10,2) NULL ,
[tysq_type] varchar(20) NULL ,
[sdid] bigint NULL ,
[scity] varchar(100) NULL ,
[modify_time] datetime NULL 
)
GO

