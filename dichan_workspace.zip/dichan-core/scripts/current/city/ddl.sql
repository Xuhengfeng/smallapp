ALTER TABLE [dbo].[ProceNews] DROP COLUMN [is_read]
GO

ALTER TABLE [dbo].[ProcePath] ADD [is_read] varchar(30) NULL 
GO