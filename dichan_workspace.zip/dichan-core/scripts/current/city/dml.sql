﻿






-----周桥开始2018-05-23---------------------
--诚意金预订报表
--审批
print '开始导入。。。。'
IF (select count(field_type_id) from field_types where field_type='STOREDROPDOWN' and remark='门店下拉选')<=0
  insert into field_types (field_type,remark) values('STOREDROPDOWN','门店下拉选');
GO
