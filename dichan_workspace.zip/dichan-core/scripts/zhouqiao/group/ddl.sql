
--2018-05-28 测试环境添加房源报表相关字段
alter table report_daily add house_total_num bigint NULL
alter table report_daily add house_new_num bigint NULL
alter table report_daily add house_mine_num bigint NULL
alter table report_daily add house_other_num bigint NULL
alter table report_daily add house_hang_num bigint NULL