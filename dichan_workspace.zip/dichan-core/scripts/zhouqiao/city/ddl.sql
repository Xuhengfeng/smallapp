--诚意金表添加 代收房款列
alter table sincerity add other_amount numeric(12,2);
GO
--合同表protocol添加预留总费用列
alter table protocol add reserve_fee numeric(12,2)
GO
---------------------------------------------------------------------------------------审批相关
--新建通用申请明细表

DROP table tysq_details 
GO
CREATE TABLE tysq_details
(
tysq_details_id int NOT NULL IDENTITY(1,1) ,
tysq_a_id int NOT NULL,
tysq_type_id int NOT NULL,
text1 varchar(30),
text2 varchar(30),
text3  varchar(30),
text4 varchar(30),
text5 varchar(30),
text6 varchar(50),
text7 varchar(50),
text8 varchar(50),
text9 varchar(50),
text10 varchar(50),
text11 varchar(400),
text12 varchar(400),
text13 varchar(400),
text14 varchar(400),
date1 date NULL,
date2 date NULL,
date3 date NULL,
date4 date NULL,
datetime1 datetime NULL,
datetime2 datetime NULL,
datetime3 datetime NULL,
datetime4 datetime NULL,
number1 bigint NULL,
number2 bigint NULL,
number3 bigint NULL,
number4 bigint NULL,
number5 bigint NULL,
number6 bigint NULL,
amount1 numeric(12,2) NULL,
amount2 numeric(12,2) NULL,
amount3 numeric(12,2) NULL,
amount4 numeric(12,2) NULL,
amount numeric(19,2) NULL,
amount5 numeric(12,2) NULL,
amount6 numeric(12,2) NULL,
create_id int NULL,
create_time datetime NULL,
last_update_id int NULL,
last_update_time datetime NULL,
sdid bigint NULL ,
scity varchar(100),
modify_time datetime NULL
)
ON [PRIMARY]
GO


















































































>>>>>>> develop
