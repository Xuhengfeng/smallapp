
IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='员工报表')<=0
  insert Permission(permissionname,functionname,creater) values('查询','员工报表','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='导出Excel' and functionname='员工报表')<=0
  insert Permission(permissionname,functionname,creater) values('导出Excel','员工报表','new_erp');
GO


--审批
print '开始导入。。。。'
GO
IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='普通申请')<=0
  insert Permission(permissionname,functionname,creater) values('查询','普通申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='请款申请')<=0
  insert Permission(permissionname,functionname,creater) values('查询','请款申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='查询' and functionname='核销申请')<=0
  insert Permission(permissionname,functionname,creater) values('查询','核销申请','new_erp');
GO

--审批 2018-09-07 添加，修改，删除权限
IF (select count(PermiID) from Permission where PermissionName='添加' and functionname='普通申请')<=0
  insert Permission(permissionname,functionname,creater) values('添加','普通申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='修改' and functionname='普通申请')<=0
  insert Permission(permissionname,functionname,creater) values('修改','普通申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='删除' and functionname='普通申请')<=0
  insert Permission(permissionname,functionname,creater) values('删除','普通申请','new_erp');
GO


IF (select count(PermiID) from Permission where PermissionName='添加' and functionname='请款申请')<=0
  insert Permission(permissionname,functionname,creater) values('添加','请款申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='修改' and functionname='请款申请')<=0
  insert Permission(permissionname,functionname,creater) values('修改','请款申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='删除' and functionname='请款申请')<=0
  insert Permission(permissionname,functionname,creater) values('删除','请款申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='添加' and functionname='核销申请')<=0
  insert Permission(permissionname,functionname,creater) values('添加','核销申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='修改' and functionname='核销申请')<=0
  insert Permission(permissionname,functionname,creater) values('修改','核销申请','new_erp');
GO

IF (select count(PermiID) from Permission where PermissionName='删除' and functionname='核销申请')<=0
  insert Permission(permissionname,functionname,creater) values('删除','核销申请','new_erp');
GO



--filed_types每个城市源添加一天门店下拉选(追加)
IF (select count(field_type_id) from field_types where field_type='STOREDROPDOWN' and remark='门店下拉选')<=0
  insert into field_types (field_type,remark) values('STOREDROPDOWN','门店下拉选');
GO




