package com.ztj.dichan.entity;

import java.time.LocalDateTime;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 楼盘栋座表
 */
@Entity
@Table(name = "buildingdz")
@Data
@EqualsAndHashCode(callSuper = true)
public class BuildingDz extends ShardingEntity {
	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="builddzid")
	private Integer id;

	/**
	 * 楼房字典id
	 */
	@Column(name="buildid")
	private Integer buildId;

	/**
	 * 单元名
	 */
	@Column(name="dy")
	private String unitName;

	/**
	 * 单元数
	 */
	@Column(name="dynum")
	private Integer unitNum;

	/**
	 * 栋座名后缀
	 */
	@Column(name="dzback")
	private String blockSuffix;

	/**
	 * 栋座名
	 */
	@Column(name="dzname")
	private String blockName ;

	/**
	 * 户数
	 */
	@Column(name="hs")
	private Integer familyNum;

	/**
	 * 平街下总层数
	 */
	@Column(name="streetbom")
	private Integer streetBelowNum;

	/**
	 * 平街上总层数
	 */
	@Column(name="streettop")
	private Integer streetAboveNum;

	/**
	 * 梯数
	 */
	@Column(name="ts")
	private Integer liftNum;

	/**
	 * 修改人id
	 *//*
	private Long lastUpdateId;
	
	*//**
	 * 最后修改时间
	 *//*
	private LocalDateTime lastUpdateTime;*/
	
}