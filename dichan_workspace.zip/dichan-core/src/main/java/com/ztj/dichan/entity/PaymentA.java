package com.ztj.dichan.entity;

import javax.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;


/**
 *请款表头表
 * 
 */
@Table(name="paymenta")
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@NamedQuery(name="PaymentA.findAll", query="SELECT p FROM PaymentA p")
public class PaymentA extends ShardingEntity  {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="paymentaid")
	private Integer id;

	@Column(name="addr")
	private String addr;

	@Column(name="bank")
	private String bank;

	@Column(name="bankaccount")
	private String bankAccount;

	@Column(name="creater")
	private String creater;

	@Column(name="createrid")
	private Integer createrId;

	@Column(name="createtime")
	private String createTime;

	@Column(name="deptid")
	private Integer deptId;

	/**
	 * 备注
	 */
	@Column(name="explain")
	private String explain;

	/**
	 * 款项来源
	 */
	@Column(name="kxly")
	private String paymentFrom;

	/**
	 * 出款账户
	 */
	@Column(name="payaccount")
	private String payAccount;

	/**
	 * 出款日期
	 */
	@Column(name="paydate")
	private String payDate;

	/**
	 * 收款人
	 */
	@Column(name="payee")
	private String Payeeame;

	/**
	 * 收款人id
	 */
	@Column(name="payeeid")
	private Integer payeeId;

	/**
	 * 出款人
	 */
	@Column(name="payer")
	private String payerName;

	/**
	 * 出款人id
	 */
	@Column(name="payerid")
	private Integer payerId;

	/**
	 * 支付方式
	 */
	@Column(name="paymode")
	private String payMode;

	@Column(name="procename")
	private String proceName;

	@Column(name="procepathid")
	private Integer procePathId;

	@Column(name="processstatu")
	private String processStatus;

	/**
	 * 用款日期
	 */
	@Column(name="requdate")
	private String requDate;

	/**
	 * 审批人id
	 */
	@Column(name="sprid")
	private Integer approveId;

	/**
	 * 审批人名字
	 */
	@Column(name="sprname")
	private String approveName;

	/**
	 * 请款总金额
	 */
	@Column(name="totalamount")
	private BigDecimal totalAmount;

	/**
	 * 核销总金额
	 */
	@Column(name="tusemount")
	private BigDecimal tUseMount;

	/**
	 * 合同id或诚意金id
	 */
	@Column(name="ywid")
	private Integer contSincId;

	/**
	 * 合同编号或诚意金收据编号
	 */
	@Column(name="ywno")
	private String contSincNo;

}