package com.ztj.dichan.entity;

import javax.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 审批记录表
 * 
 */
@Entity
@Table(name="approvereco")
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="ApproveReco.findAll", query="SELECT a FROM ApproveReco a")
public class ApproveReco extends ShardingEntity {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="approverecoid")
	private Integer id;

	@Column(name="emplid")
	private Integer emplId;

	@Column(name="emplname")
	private String emplName;

	/**
	 * 摘要信息
	 */
	@Column(name="info")
	private String info;

	/**
	 * 审批日期
	 */
	@Column(name="procedate")
	private String proceDate;

	/**
	 * 流程名称
	 */
	@Column(name="procename")
	private String proceName;

	/**
	 * 审批意见
	 */
	@Column(name="proceopini")
	private String proceOpinion;

	/**
	 * 审批路径ID
	 */
	@Column(name="procepathid")
	private Integer procePathId;

	@Column(name="proceresult")
	private String proceResult;

	@Column(name="taskid")
	private Integer taskId;

	/**
	 * 具体业务id 
	 */
	@Column(name="workid")
	private Integer workId;
	
	@Transient
	private String taskName;
	@Transient
	private String scityCH;


}