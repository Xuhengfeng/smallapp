package com.ztj.dichan.entity;

import javax.persistence.*;
import com.ztj.dichan.enums.BuildingStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;


/**
 * 楼盘信息
 * 
 */
@Entity
@Table(name = "building")
@Data
@EqualsAndHashCode(callSuper = true)
public class Building extends ShardingEntity {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="buildid")
	private Integer id;
	
	/**
	 * 楼盘接待人员姓名
	 */
	@Column(name="admitname")
	private String admitName;

	/**
	 * 楼盘接待人员电话
	 */
	@Column(name="admittel")
	private String admitTel;

	/**
	 * 楼盘官方地址
	 */
	@Column(name="adreess1")
	private String adreessOfficial;

	/**
	 * 楼盘通俗地址
	 */
	@Column(name="adreess2")
	private String adreessNormal;

	/**
	 * 小区总栋数
	 */
	@Column(name="allbuilds")
	private Integer totalBuildNum;

	/**
	 * 小区总户数
	 */
	@Column(name="allframily")
	private Integer totalHouseNum;

	/**
	 * 小区总建面
	 */
	@Column(name="allmianji")
	private Integer totalCoverArea;

	/**
	 * 区域
	 */
	@Column(name="areaid")
	private Integer areaID;

	/**
	 * 所属区域
	 */
	@Column(name="areaname")
	private String areaName;

	/**
	 * 建筑年代
	 */
	@Column(name="buildage")
	private String buildAge;

	/**
	 * 楼盘便签---只针对新楼盘
	 */
	@Column(name="buildbq")
	private String bulidNote;

	/**
	 * 关联楼盘
	 */
	@Column(name="buildname")
	private String buildName;

	/**
	 * 商业类型
	 * 底商、商铺、写字楼、loft--可选，多选
	 */
	@Column(name="businesstype")
	private String businessType;

	/**
	 * 产权年限
	 */
	@Column(name="cqnx")
	private String buildRightYears;

	/**
	 * 创建人
	 */
	@Column(name="creater")
	private String createName;

	/**
	 * 创建人ID
	 */
	@Column(name="createrid")
	private Integer createrID;

	/**
	 * 创建时间
	 * 创建时间，yyyy-mm-dd hh:mm:ss
	 */
	@Column(name="createtime")
	private String createTime;

	/**
	 * 片区
	 */
	@Column(name="districtid")
	private Integer districtID;

	/**
	 * 所属片区
	 */
	@Column(name="districtname")
	private String districtName;

	/**
	 * 独家补助说明
	 */
	@Column(name="djbt")
	private String allowanceExplain;

	/**
	 * 地下车位数
	 */
	@Column(name="downcar")
	private Integer carDownNum;

	/**
	 * 地下车位租金
	 */
	@Column(name="downprice")
	private String carDownRent;

	/**
	 * 民电/商电/多种--只针对新盘
	 * 默认一个空格
	 */
	@Column(name="electric")
	private String electricType;

	/**
	 * 新增方式
	 */
	@Column(name="fhcreatemode1")
	private Integer createType1;

	/**
	 * 新增方式
	 */
	@Column(name="fhcreatemode2")
	private Integer createType2;

	/**
	 * 民电/商电/多种 ---只针对新楼盘
	 * 默认一个空格
	 */
	@Column(name="gas")
	private String gasType;

	/**
	 * 建筑结构
	 */
	@Column(name="housestru")
	private String houseStruc;

	/**
	 * 住宅类型
	 */
	@Column(name="housetype")
	private String buildType;

	/**
	 * 主推户型，热点户型--只针对新盘
	 * 用英文逗号隔开
	 */
	@Column(name="hxmore")
	private String mainSaleType;

	/*@Column(name="hxupdTime")
	private String hxupdTime;*/

	/**
	 * 是否拼盘开发商
	 * 0 不是 , 1是
	 */
	@Column(name="isbrand")
	private Integer isBrand;
	
	/**
	 * 是否删除
	 * 0 正常
	 * 1已删除
	 */
	@Column(name="isdeleted")
	private Integer isDeleted;
	
	/**
	 * 隐藏该楼盘，不显示该楼盘的房源
	 * 0未隐藏 1 隐藏
	 */
	@Column(name="ishide")
	private Integer isHide;
	
	/**
	 * 是否是热盘（推荐盘）--只针对新楼
	 * 0 不是  1是
	 */
	@Column(name="ishot")
	private Integer isHot;
	
	/**
	 * 锁定该楼盘，不可新增
	 * 0 未锁定
	 * 1锁定
	 */
	@Column(name="islock")
	private Integer isLock;
	
	/**
	 * 是否匹配
	 * 0，表示未匹配 1，为有匹配 2，为无匹配
	 */
	@Column(name="ismatch")
	private Integer isMatch;

	/**
	 * 是否是新盘
	 * 0 不是 
	 * 1是
	 */
	@Column(name="isnew")
	private Integer isNew;

	/**
	 * 信息专员是否处理好了图片
	 */
	@Column(name="isover")
	private Integer isOver;

	
	@Column(name="issale")
	private Integer isSale;

	/**
	 * 1，展示  2，不展示--针对新房商业用查看驻场用
	 */
	@Column(name="isseeall")
	private Integer isSeeAll;
	
	/**
	 * 默认是0，不是装修---只针对新楼盘
	 * 0 不是 1 是
	 */
	@Column(name="iszx")
	private Integer isDecorate;

	/***
	 * 交通情况
	 */
	@Column(name="jtqk")
	private String transport;

	/**
	 * 开发商名称
	 */
	@Column(name="kfsname")
	private String developerName;

	/**
	 * 土地性质（出让/划拨）
	 */
	@Column(name="landtype")
	private String landType;

	/**
	 * 土地用途（商业/住宅/商住两用）
	 */
	@Column(name="landuse")
	private String landUse;

	/**
	 * 绿化率
	 */
	@Column(name="lhrate")
	private BigDecimal greenRatio;

	/**
	 * 楼盘简介
	 */
	@Column(name="lpjj")
	private String buildSynop;

	/**
	 * 最近线路的距离(米)
	 */
	@Column(name="metrdistance")
	private BigDecimal nearestMetroDist;

	/**
	 * 附近的地铁站名  
	 * 逗号分开
	 */
	@Column(name="metrname")
	private String metroNames;

	/**
	 * 附近的地铁站线
	 * 地铁站名，逗号分开
	 */
	@Column(name="metrnear")
	private String metroInfo;

	/**
	 * 最近的一条线路
	 * 一号线
	 */
	@Column(name="metrstation")
	private String nearestMetroNo;

	/**
	 * m配比
	 */
	@Column(name="pb")
	private String matchRatio;

	/**
	 * 有无照片
	 * 0 无
	 * 1有
	 */
	@Column(name="pic")
	private Integer has_pic;

	/**
	 * 房源照片 
	 * 默认40个0 
	 */
	@Column(name="picmore")
	private String housePic;

	/**
	 * 全景图标志
	 * 默认字段：000000000000000000000000000000
	 */
	@Column(name="picmoreqj")
	private String fullPic;

	
	@Column(name="picupdtime")
	private String picupdTime;

	/**
	 * 拼音
	 */
	@Column(name="pinyin")
	private String pinYin;

	/**
	 * 楼盘优惠信息--只针对新盘
	 */
	@Column(name="preinfo")
	private String preferInfo;

	/**
	 * 配套设置
	 */
	@Column(name="ptss")
	private String matchSetup;

	/**
	 * 东经
	 */
	@Column(name="px")
	private BigDecimal px;

	/**
	 * 西纬
	 */
	@Column(name="py")
	private BigDecimal py;

	/**
	 * 红线范围--新房和商业用
	 */
	@Column(name="redpoint")
	private String redPoint;

	/**
	 * 在租数量
	 */
	@Column(name="rentcount")
	private Integer rentCount;

	/**
	 * 容积率
	 */
	@Column(name="rjrate")
	private BigDecimal volumnRatio;

	/**
	 * 在售数量
	 */
	@Column(name="salecount")
	private Integer saleCount;

	/**
	 * 卖点描述--新房和商业用
	 */
	@Column(name="saledesc")
	private String salePoIntegerDesc;

	/**
	 * 楼盘状态（未审批/已审批）
	 */
	@Column(name="statu")
	private String buildStatus;

	/**
	 * 商业均租价
	 */
	@Column(name="syprice")
	private BigDecimal avgSaleRentBuzi;

	/**
	 * 商业均售价
	 */
	@Column(name="sysaleprice")
	private BigDecimal avgSalePriceBuzi;

	/**
	 * 停车
	 */
	@Column(name="tc")
	private String carPark;

	/**
	 * 地上车位数
	 */
	@Column(name="upcar")
	private Integer carUpNum;

	/**
	 * 地上车位租金
	 */
	@Column(name="upprice")
	private String carUpRent;

	/**
	 * 责任人id 关联
	 */
	@Column(name="userid")
	private Integer userid;

	/**
	 * 责任人
	 */
	@Column(name="username")
	private String userName;

	/**
	 * 使用年限（仅出让有）
	 */
	@Column(name="useyear")
	private String useYear;

	/**
	 * 民水/商水/多种--只针对新盘
	 */
	@Column(name="water")
	private String waterYpe;

	/**
	 * 物管费
	 */
	@Column(name="wgf")
	private BigDecimal manageFee;

	/**
	 * 0表示（元/月），1表示（元/月/平方)
	 */
	@Column(name="wgftype")
	private Integer managerFeeType;

	/**
	 * 物业
	 */
	@Column(name="wy")
	private String manage;

	/**
	 * 物业公司
	 */
	@Column(name="wycotl")
	private String managementCompany;

	/**
	 * 外网小区列表指定顺序
	 */
	@Column(name="xh")
	private Integer xh;

	/**
	 * 周边超市
	 */
	@Column(name="zbcs")
	private String supermarketInfo;

	/**
	 * 周边交通
	 */
	@Column(name="zbjt")
	private String transportInfo;
	
	/**
	 * 周边学校
	 */
	@Column(name="zbxx")
	private String schoolInfo;

	/**
	 * 周边银行
	 */
	@Column(name="zbyh")
	private String bankInfo;

	/**
	 * 周边医院
	 */
	@Column(name ="zbyy")
	private String hospitalInfo;

	/**
	 * 驻场ID
	 */
	@Column(name="zcid")
	private Integer zcId;

	/**
	 * 占地面积---只针对新盘
	 */
	@Column(name="zdmj")
	private BigDecimal coverRatio;

	/**
	 * 最新开盘---只针对新楼盘
	 * 默认1个空格
	 */
	@Column(name="zxkp")
	private String newestOpen;

	/**
	 * 最早交房---只针对新楼盘
	 * 默认一个空格
	 */
	@Column(name="zzjf")
	private String earliestDeliver;

	/**
	 * 住宅均租价
	 */
	@Column(name="zzprice")
	private BigDecimal avgRentPrice;

	/**
	 * 住宅均售价
	 */
	@Column(name="zzsaleprice")
	private BigDecimal avgSalePrice;

	/**
	 * 修改人id
	 */
	@Column(name="last_update_id")
	private Long lastUpdateId;
	
	/**
	 * 最后修改时间
	 */
	@Column(name="last_update_time")
	private LocalDateTime lastUpdateTime;
	
	@Column(name="average_price")
	private BigDecimal averagePrice;
}