package com.ztj.dichan.repository.approve;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.FieldChkRules;
import com.ztj.dichan.entity.FieldTypes;
import com.ztj.dichan.entity.TysqDetails;
import com.ztj.dichan.entity.TysqItem;
import com.ztj.dichan.vo.SinceritySubDetailVo;
import com.ztj.dichan.vo.approve.TysqItemVo;

@Repository
public class TysqDetailsRepositoryImpl {
	
	@PersistenceContext
	private EntityManager em;
	
	
	List<TysqDetails> findTysqDetailList(Integer id,Integer comReqTypeId){
		StringBuffer sql = new StringBuffer();
		sql.append("select * ");
	    sql.append(" from tysq_details ");
	    sql.append(" where tysq_a_id = "+id);
	    sql.append(" and tysq_type_id ="+comReqTypeId);
	    Query query = em.createNativeQuery(sql.toString());
	    query.unwrap(SQLQuery.class).addEntity(TysqDetails.class).list();
		List<TysqDetails> tysqDetailsList= query.getResultList();
		return tysqDetailsList;
	}


	public void deleteTysqDetailsByIds(String ids){
		StringBuffer sql = new StringBuffer();
		sql.append(" delete tysq_details where tysq_details_id in ("+ids+")");
		Query query = em.createNativeQuery(sql.toString());
		query.executeUpdate();
	}
	
	public List<TysqDetails> calculateTysqDetails(String field,List<Integer> ids){
		StringBuffer sql = new StringBuffer();
		sql.append("select r.ori_req_dtl_id as id,sum("+field+") as amount1 ");
	    sql.append(" from tysq_details d join Tysq_relation r on d.tysq_details_id = r.req_dtl_id ");
	    sql.append(" where tysq_a_id in ("+concatIds(ids)+")");
	    sql.append(" group by r.ori_req_dtl_id ");
	    Query query = em.createNativeQuery(sql.toString());
	    query.unwrap(SQLQuery.class).addScalar("id",IntegerType.INSTANCE).addScalar("amount1",BigDecimalType.INSTANCE)
	    .setResultTransformer(Transformers.aliasToBean(TysqDetails.class));
		List<TysqDetails> tysqDetailsList= query.getResultList();
		return tysqDetailsList;
	}
	
	public String concatIds(List<Integer> ids) {
		StringBuffer sb =new StringBuffer();
		for(int i=0;i<ids.size();i++) {
			sb.append(ids.get(i));
			if(i<ids.size()-1) {
				sb.append(",");
			}
		}
		return sb.toString();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
