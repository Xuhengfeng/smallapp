package com.ztj.dichan.repository.assets;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.assets.Asset;
import com.ztj.dichan.vo.asset.AssetDetailVo;
import com.ztj.dichan.vo.asset.OfficeDetailVo;
import com.ztj.dichan.vo.asset.TotalAssetVo;
import com.ztj.dichan.vo.request.asset.OfficeInfoRequest;

@Repository
public interface AssetRespository extends PagingAndSortingRepository<Asset, Integer> {

	Integer assetTotalRecords(String scity, Asset asset);

	List<Asset> queryAssetListPage(String scity, Asset asset, Pageable pageable);
	
	List<Asset> findByOfficeId(Integer officeId);

	List<Asset> findByAssetNoAndOfficeId(String assetNo,Integer officeId);

	BigDecimal totalAmount(OfficeInfoRequest officeInfoRequest);

	Integer assetInfoTotalRecords(OfficeInfoRequest officeInfoRequest);

	List<AssetDetailVo> assetInfoPage(OfficeInfoRequest officeInfoRequest, Pageable pageable);

	TotalAssetVo totalAsset(OfficeInfoRequest officeInfoRequest,Map<String, Integer> typeMap);

}
