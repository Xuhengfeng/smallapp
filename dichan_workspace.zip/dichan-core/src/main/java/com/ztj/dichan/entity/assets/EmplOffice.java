package com.ztj.dichan.entity.assets;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "emplOffice")
@Data
@EqualsAndHashCode(callSuper = true)
public class EmplOffice extends ShardingEntity{
	
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="emp_office_id")
	private Integer id  ;//员工和办公绑定
	
	@Column(name="empl_id")
	private Integer emplID;//员工Id
	
	@Column(name="office_id")
	private Integer officeId  ;//部门Id
	
	@Column(name="create_id")
	private Integer createId;//创建人
	
	@Column(name="create_time")
	private LocalDateTime CreateTime;//创建时间
	
	@Column(name="last_update_id")
	private Integer lastUpdateId;//最后修改人
	
	@Column(name="last_update_time")
	private LocalDateTime lastUpdateTime;//最后修改时间
	
	@Column(name="scity")
	private String scity;//所属城市
}
