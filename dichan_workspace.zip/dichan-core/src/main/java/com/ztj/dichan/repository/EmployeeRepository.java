package com.ztj.dichan.repository;
import java.util.List;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.Employee;
import com.ztj.dichan.vo.DeptVo;
import com.ztj.dichan.vo.EmployeeDetailVo;
import com.ztj.dichan.vo.employee.EmployeeCsvVo;
import com.ztj.dichan.vo.employee.TreeVo;
import com.ztj.dichan.vo.employee.YouZanImportParams;
import com.ztj.dichan.vo.finance.EmplBasicInfoVo;
import com.ztj.dichan.vo.finance.FinEmployeeVo;

@Repository
public interface EmployeeRepository extends PagingAndSortingRepository<Employee, Integer>{
	
	List<Employee> findTop100ByOrderById();
	
	List<Employee> findBySdidIsNull();
	
	@Query(value="select * from Employee where emplacco = ?1",nativeQuery = true)
	Employee findByEmplAccNo(String emplAcco);

	@Query(value="select * from Employee where emplacco = ?1 and scity = ?2",nativeQuery = true)
	Employee findByEmplAccNoAndScity(String emplacco, String scity);

	//获取老员工+入职员工  入职时间不为空，入职时间小于当前月份 状态为空，离职时间为空 and statu = ''
	@Query(value="select * from employee where deptId in :newDeptIdSet AND rztime!='' AND rztime is not null  and SUBSTRING (rztime, 0, 8)<=:yearMonth and (Statu='' or SUBSTRING (lztime, 0, 8)>:yearMonth) and scity = :scity",nativeQuery=true)
	List<Employee> findByDeptIdInAndScityAndStatusIsEmpty(@Param("newDeptIdSet") Set<Integer> newDeptIdSet,@Param("yearMonth") String yearMonth,@Param("scity") String scity);
	
	//获取离职员工，当前月份离职
	@Query(value="select * from employee where deptId in ?1 and statu = '离职' and scity = ?2  and SUBSTRING (lztime, 0, 8) =?3",nativeQuery=true)
	List<Employee> findByDeptIdInAndScityAndStatusAndDimission(Set<Integer> newDeptIdSet, String scity,
			String yearMonth);
	@Query(value="select e.emplname as emplName from Employee e where e.emplid = ?1 and e.scity =?2",nativeQuery=true)
	String getEmplNameById(Integer leaderId, String scity);
	
	@Query(value="select * from Employee e where e.emplid = ?1 and e.scity =?2",nativeQuery=true)
	Employee findByIdAndScity(Integer employeeId, String scity);
	
	@Query(value="select e.DeptID  from Employee e where e.emplid = ?1 and e.scity =?2",nativeQuery=true)
	Integer findDeptIdByIdAndScity(Integer emplId, String scity);
	
	
	@Query(value="select count(*) from employee",nativeQuery=true)
	Integer testCount();
	
	@Query(value="select e.rztime  from Employee e where e.emplid = ?1 and e.scity =?2",nativeQuery=true)
	String findJoinDateById(Integer emplId, String scity);
	
	//获取所有在职员工
	@Query(value="select *  from Employee e where e.statu in('','见习') ",nativeQuery=true)
	List<Employee> getActiveEmplList();
	
	//根据部门id,获取所有的员工详情
	List<EmployeeDetailVo> dynamicQuery(DeptVo deptVo,Pageable pageable);
	
	//根据部门id,获取所有的员工详情总记录数
	Integer dynamicQueryTotalSize(DeptVo deptVo);

	List<EmployeeCsvVo> queryYouZanByScity(Set<Integer> deptParentIds,List<String> excludePositionnames,YouZanImportParams youZanImportParams);
	
	/**
	 * 
	 * @param emplId
	 * @param scity
	 * @return
	 */
	@Query(value="select * from Employee e where e.positionname in ?1 and scity =?2 and accostatu != '停用' and statu != '离职'",nativeQuery=true)
	List<Employee> findByPositionnameAndScity(List<String> positionName, String scity);
	
	@Query(value="select e.emplid  from Employee e where e.emplname = ?1 and e.scity =?2",nativeQuery=true)
	Integer findEmplId(String emplName, String scity);

	List<TreeVo> employeeTreesByCity();
	/*@Query(value="select e.emplname as emplName from Employee e where e.positionname in ?1 and e.scity =?2 and AccoStatu != '停用'",nativeQuery=true)
	List<String> findByPositionnameAndScity(List<String> positionName, String scity);*/

	Integer findCountByNameOrAccoOrIdNo(FinEmployeeVo finEmployee);

	EmplBasicInfoVo findEmplBasicInfoById(Integer emplId);
	
}



































