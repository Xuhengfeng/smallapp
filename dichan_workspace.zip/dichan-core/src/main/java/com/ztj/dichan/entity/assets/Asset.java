package com.ztj.dichan.entity.assets;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "asset")
@Data
@EqualsAndHashCode(callSuper = true)
public class Asset extends ShardingEntity {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="asset_id")
	private Integer id;//资产明细ID
	
	@Column(name="office_id")
	private Integer officeId;//办公室Id
	
	@Column(name="asset_no")
	private String assetNo;//资产编号
	
	@Column(name="asset_unit")
	private String assetUnit;//单位
	
	@Column(name="asset_price")
	private BigDecimal assetPrice;//价格
	
	@Column(name="brand_name")
	private String brandName;//品牌名称
	
	@Column(name="goods_type")
	private String goodsType;//型号
	
	@Column(name="factory_name")
	private String factoryName;//厂家
	
	@Column(name="goods_color")
	private String goodsColor;//颜色
	
	@Column(name="goods_manu_date")
	private String goodsManuDate;//生产日期
	
	@Column(name="setup_position")
	private String setupPosition;//安装位置
	
	@Column(name="receipt_no")
	private String receiptNo;//发票号码
	
	@Column(name="dept_name")
	private String deptName;//使用部门
	
	@Column(name="create_id")
	private Integer creater;//创建人
	
	@Column(name="create_time")
	private LocalDateTime CreateTime;//创建时间
	
	@Column(name="last_update_id")
	private Integer lastUpdater;//最后修改人
	
	@Column(name="last_update_time")
	private LocalDateTime lastUpdateTime;//最后修改时间
	
	@Column(name="asset_type_id")
	private Integer assetTypeId;
	
	@Column(name="asset_name_id")
	private Integer assetNameId;
	
	@Column(name="asset_from_id")
	private Integer assetFromId;
	
	@Column(name="asset_status_id")
	private Integer assetStatusId;
}
