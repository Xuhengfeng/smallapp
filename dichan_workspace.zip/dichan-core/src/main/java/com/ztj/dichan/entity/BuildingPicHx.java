package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;
 

/**
 * 楼盘户型照片
 */
@Entity
@Table(name = "buildingpichx")
@Data
@EqualsAndHashCode(callSuper = true)
public class BuildingPicHx extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="buildhxid")
	private Integer id;

	
	@Column(name="buildid")
	private Integer buildId;

	/**
	 * 朝向
	 */
	@Column(name="cx")
	private String houseDirection;

	/**
	 * 房
	 */
	@Column(name="fang")
	private Integer roomsNum;

	/**
	 * 栋座单元房号
	 */
	@Column(name="fangno")
	private String blockUnitRoomNo;

	/**
	 * 户型类型
	 */
	@Column(name="htype")
	private String  houseType;

	/**
	 * 照片路径
	 */
	@Column(name="hx")
	private String picPathName;

	/**
	 * 户型名称
	 */
	@Column(name="hxname")
	private String houseTypeName;

	/**
	 * 每个户型的特点，类似于房源标签，以/隔开
	 */
	@Column(name="hxspecial")
	private String houseTypeSpecial;

	/**
	 * 是否是主力户型 
	 * 0不是，1是
	 */
	@Column(name="ishot")
	private Integer isHot;
	
	/**
	 * 建筑面积
	 */
	@Column(name="jzmj")
	private BigDecimal buildArea;

	/**
	 * 建筑最大面积
	 */
	@Column(name="jzmj_max")
	private BigDecimal highestArea;

	/**
	 * 备注
	 */
	@Column(name="memo")
	private String remark;

	@Column(name="piccount")
	private Integer picCount;

	/**
	 * 在售状态
	 */
	@Column(name="salestatu")
	private String saleStatus;

	/**
	 * 售总价
	 */
	@Column(name="saletotal")
	private BigDecimal saleTotal;

	/**
	 * 价格最大值
	 */
	@Column(name="saletotal_max")
	private BigDecimal salePriceMax;

	/**
	 * 厅
	 */
	@Column(name="ting")
	private Integer livingRoomNum ;

	/**
	 * 套内面积
	 */
	@Column(name="tnmj")
	private BigDecimal innerArea;

	/**
	 * 套内面积最大值
	 */
	@Column(name="tnmj_max")
	private BigDecimal highestInnerArea;

	/**
	 * 卫生
	 */
	@Column(name="wei")
	private Integer washRoomNum;

	/**
	 * 阳台
	 */
	@Column(name="yangtai")
	private Integer balconyNum ;
	
	
	/**
	 * 修改人id
	 */
	private Long lastUpdateId;
	
	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime;
	
	
	
}