package com.ztj.dichan.entity.salary;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 佣金员工信息
 * 
 * @author test01
 */
@Entity
@Table(name = "income_emp_Info")
@Data
@EqualsAndHashCode(callSuper = true)
public class IncomeEmpInfo extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "income_emp_Info_id")
	private Integer id;

	/**
	 * 佣金月份
	 */
	private String yearMonth;

	/**
	 * 员工id
	 */
	private Integer employeeId;

	/**
	 * 员工名称
	 */
	private String employeeName;

	/**
	 * 部門id
	 */
	private Integer deptId;

	/**
	 * 店名
	 */
	private String shopName;

	/**
	 * 組名
	 */
	private String groupName;

	/**
	 * 岗位id
	 */
	private Integer positionId;

	/**
	 * 崗位名称
	 */
	private String positonName;

	/**
	 * 经理id
	 */
	private Integer managerId;

	/**
	 * 经理名称
	 */
	private String managerName;

	/**
	 * 是否新入职员工
	 */
	private Integer isNewEmp;

	/**
	 * 入职月数
	 */
	private Integer joinMonthNum;

	/**
	 * 入职时间
	 */
	private LocalDate joinDate;

	/**
	 * 离职时间
	 */
	private LocalDate dimissionDate;

	/**
	 * 创建人
	 */
	private Long createId;

	/**
	 * 创建时间
	 */
	@Column(name="create_time")
	private LocalDateTime createTime;

	/**
	 * 最后修改员工id
	 */
	private Long lastUpdateId;

	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime;
}