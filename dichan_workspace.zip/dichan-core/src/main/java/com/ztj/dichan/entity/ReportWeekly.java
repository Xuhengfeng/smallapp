package com.ztj.dichan.entity;


import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 集团数据库
 * 周报表
 * @author zhouqiao
 *
 */

@Entity
@Table(name="report_weekly")
@Data
@EqualsAndHashCode(callSuper=true)
public class ReportWeekly  extends ShardingEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
	
	private String cityName;
	
	/**
	 * 年月
	 */
	private String yearMonth;
	
	/**
	 * 第几周
	 * 第一周,第二周,第三周,第四周,第五周
	 */
	private String weekNo;
	
	/**
	 * 门店数量
	 */
	private Long shopNum;
	
	/**
	 * 人数
	 */
	private Long membersNum;
	
	/**
	 * 租单成交额
	 * 合同房子出租价格
	 */
	private BigDecimal newRentAmt;
	
	/**
	 * 售单成交额
	 * 合同房子售出价格
	 */
	private BigDecimal newSaleAmt;
	
	/**
	 * 创收
	 * 应收收入+应收代收
	 */
	private BigDecimal dueAllAmt;
	
	/**
	 * 实收
	 * 应收收入
	 */
	private BigDecimal dueIncomeAmt;
	
	/**
	 * 已收
	 * 已收收入
	 */
	private BigDecimal doneIncomeAmt;
	
	/**
	 * 应付
	 *  应收代收
	 */
	private BigDecimal  dueOtherAmt;
	
	/**
	 * 已付
	 * 已收代收
	 */
	private BigDecimal doneOtherAmt;
	
	/**
	 * 创建人
	 * 第一次自动跑:AUTO_JOB
	 *自动重跑：RETRY_JOB
	 *人工重跑：操作员工
	 */
	private Long createId;
	
	
	/**
	 * 周起始时间
	 */
	private Date startDate;
	
	/**
	 * 周结束时间
	 */
	private Date endDate;
	
	  /**
     * 创建时间
     */
    protected LocalDateTime createDateTime = LocalDateTime.now();

    /**
     * 修改时间
     */
    protected LocalDateTime updateDateTime;
}
