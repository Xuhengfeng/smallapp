package com.ztj.dichan.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 楼盘周边配置
 * @author admin
 *
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class BuildAround extends BaseDateTimeEntity{
	
	private static final long serialVersionUID = 1L;	

	/**
	 *楼盘id 
	 */
	private Integer buildId;
	
	/**
	 * 类型：S->school   M->metro  B->bank  H->hospital, M->supermarket
	 */
	private String blockName;
	
	/**
	 * 配置名称
	 */
	private String blockSuffix;
	 
	/**
	 * 距离多少米
	 */
	private Long streetAboveNum;
	
	/**
	 * 最后修改员工id
	 */
	private Long lastUpdateId;
	
	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime;
	
}
