package com.ztj.dichan.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 字段类型定义表
 * 
 */
@Entity
@Table(name="tysq_relation")
@Data
@EqualsAndHashCode(callSuper=true)
public class TysqRelation extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	/**
	 * 主键id
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tysq_relation_ID")
	private Integer tysqRelationId;

	/**
	 * TysqA表的id
	 */
	@Column(name="tysqa_id")
	private Integer tysqaId;
	
	/**
	 * (明细表id)mongo db表的id
	 */
	@Column(name="req_dtl_id")
	private Integer reqDtlId;
	
	/**
	 * (对应请款说明id)mongo db表的id
	 */
	@Column(name="ori_req_dtl_id")
	private Integer oriReqDtlId;
	
	/**
	 * 金额
	 */
	@Column(name="amount")
	private BigDecimal amount;
	
	/**
	 * 请款类型
	 */
	@Column(name="tysq_type")
	private String tysqType;

}