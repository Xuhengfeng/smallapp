package com.ztj.dichan.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 记录所有的城市数据源名称和拼音
 * @author admin
 *
 */
@Data
@Table(name="city_db")
@Entity
@EqualsAndHashCode(callSuper=true)
public class CityDb extends ShardingEntity {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	
	
	/**
	 * 城市名拼音
	 */
	private String cityNamePy;
	
	
	/**
	 * 城市名中文
	 */
	private String cityNameCh;
	
	
	/**
	 * 序号
	 * 保留字段
	 */
	
	private Long orderNum;
	
	
}
