package com.ztj.dichan.repository;



import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.Area;



@Repository
public interface AreaRepository extends PagingAndSortingRepository<Area, Integer>{
	
	Area findByName(String name);
	
	List<Area> findBySdidIsNull();

	List<Area> findAll();

}
