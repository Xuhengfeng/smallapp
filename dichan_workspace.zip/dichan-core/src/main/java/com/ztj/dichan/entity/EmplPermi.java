package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 员工权限表
 */
@Data
@Entity
@Table(name="emplpermi")
@EqualsAndHashCode(callSuper = true)
public class EmplPermi  extends ShardingEntity{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="emplpermiid")
	private Long id;

	@Column(name="creater")
	private String creater;

	@Column(name="createtime")
	private String createTime;

	//@Column(name="emplid")
	//private Integer emplId;
	
	@JoinColumn(name="emplid")
	@ManyToOne(optional = false)
	private Employee employee;

//	@Column(name="permiid")
//	private Integer permiId;
	
	@JoinColumn(name="permiid")
	@ManyToOne(optional = false)
	private Permission permission;
	
	private String scity;

}