package com.ztj.dichan.entity.salary;

import com.ztj.dichan.entity.ShardingEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 提成规则信息
 * 
 * @author test01
 */
 @Entity
 @Table(name = "commision_rule")
@Data
@EqualsAndHashCode(callSuper = true)
public class CommisionRule extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "commision_rule_id")
	private Integer id;

	/**
	 * 提成类别Name
	 */
	private String commisionTypeName;

	/**
	 * 业绩起始
	 */
	private BigDecimal incomingStart;

	/**
	 * 业绩结束
	 */
	private BigDecimal incomingEnd;

	/**
	 * 是否分段提成
	 */
	private String isStage;
	
	/**
	 * 提成百分比
	 */
	private BigDecimal comminPerct;
	
	/**
	 * 提成与晋升时间月数有关
	 */
	private Integer monthCnt;
	
	/**
	 * 备注
	 */
	private String note;

	/**
	 * 创建人
	 */
	private Long createId;

	/**
	 * 创建时间
	 */
	private LocalDateTime createTime;

	/**
	 * 最后修改员工id
	 */
	private Long lastUpdateId;

	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime;
}