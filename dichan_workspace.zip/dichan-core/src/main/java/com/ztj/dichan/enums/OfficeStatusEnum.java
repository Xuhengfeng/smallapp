package com.ztj.dichan.enums;

import java.io.Serializable;

public enum OfficeStatusEnum implements Serializable{
	ALL("all", "全部", ""),
    VALID("valid", "有效", ""),
    OVERDUE("overdue", "过期", "");

    private String code;

    private String name;
    
    private String desc;

    private OfficeStatusEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    
    public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}

}
