package com.ztj.dichan.repository.approve;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.SQLQuery;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.FieldChkRules;
import com.ztj.dichan.entity.FieldTypes;
import com.ztj.dichan.entity.TysqItem;
import com.ztj.dichan.vo.approve.TysqItemVo;

@Repository
public class TysqItemRepositoryImpl {

	
	@PersistenceContext
	private EntityManager em;
	
	
	List<TysqItemVo> findTysqItemVoByComReqTypeId(Integer comReqTypeId){
		List<TysqItemVo> tysqItemList = new ArrayList<>();
		StringBuffer sql = new StringBuffer();
		sql.append(" select i.*,t.*,r.* from TysqItem i join field_types t on i.field_type_id = t.field_type_id ");
		sql.append("left join field_chk_rules r on i.field_chk_rule_id = r.field_chk_rule_id ");
		sql.append(" where i.TysqTypeID = "+comReqTypeId);
		Query query = em.createNativeQuery(sql.toString());
		query.unwrap(SQLQuery.class).addEntity(TysqItem.class).addEntity(FieldTypes.class).addEntity(FieldChkRules.class).list();
		List<Object[]> list= query.getResultList();
		for(Object[] e : list) {
			TysqItemVo o = new TysqItemVo();
			FieldChkRules temp = new FieldChkRules();
			FieldTypes temp2 = new FieldTypes();
			BeanUtils.copyProperties(e[0], o);
			BeanUtils.copyProperties(e[1], temp2);
			if(e[2]!=null) {
				BeanUtils.copyProperties(e[2], temp);
			}
			o.setFieldChkRules(temp);
			o.setFieldTypes(temp2);
			tysqItemList.add(o);
		}
		return tysqItemList;
	}
	
}
