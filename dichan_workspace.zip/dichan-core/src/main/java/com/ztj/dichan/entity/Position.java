package com.ztj.dichan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name="position")
@Data
@EqualsAndHashCode(callSuper=true)
public class Position extends ShardingEntity {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 岗位表
	 * id 自增长
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="positiid")
	private Integer id;
	
	/**
	 * 岗位名称
	 */
	@Column(name="positionname")
	private String positionName;
	
	/**
	 * 岗位类型
	 */
	@Column(name="positiontype")
	private String positionType;
	
	
	/**
	 * 岗位等级
	 */
	@Column(name="positionlevel")
	private Integer positionLevel;
	
	/**
	 * 岗位信息
	 */
	@Column(name="positioninfo")
	private String positionInfo;
	
	/**
	 * 创建人
	 */
	@Column(name="creater")
	private  String creater;
	
	/**
	 * 创建时间
	 */
	@Column(name="createtime")
	private String createTime;
	
	/**
	 * 
	 */
	@Column(name="bzpositionname")
	private String bzPositionName;
	
	/**
	 * 修改人id
	 */
	//private Long lastUpdateId;
	
	/**
	 * 最后修改时间
	 */
	//private LocalDateTime lastUpdateTime;
	
	
}
