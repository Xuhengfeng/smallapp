package com.ztj.dichan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Entity
@Table(name = "parameter")
@Data
@EqualsAndHashCode(callSuper = true)
public class ParameterOld extends ShardingEntity{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="pid")
	private Integer id;//
	
	@Column(name="ptype")
	private String paramType;//参数类型
	
	@Column(name="pname")
	private String paramName;//参数名称
	
	@Column(name="pvalue")
	private String paramValue;//参数值
	
	@Column(name="pmode")
	private String pMode;
	
}
