package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;


/**
 *离职
 * 
 */
@Data
@Entity
@Table(name ="dimission")
@EqualsAndHashCode(callSuper=true)
public class Dimission extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="dimiid")
	private Integer id;

	/**
	 * 办理人
	 */
	@Column(name="blr")
	private String handleName;

	/**
	 * 办理人id
	 */
	@Column(name="blrid")
	private Integer handleId;

	/**
	 * 办理说明
	 */
	@Column(name="blsm")
	private String handleMemo;
	
	/**
	 * 办理日期
	 */
	@Column(name="bltime")
	private String handleTime;

	
	@Column(name="creater")
	private String creater;

	@Column(name="createrid")
	private Integer createId;

	@Column(name="createtime")
	private String createTime;

	/**
	 * 离职扣款
	 */
	@Column(name="debit")
	private BigDecimal dimissionDebt;

	@Column(name="deptid")
	private Integer deptId;

	/**
	 * 变动前大区部门ID
	 */
	@Column(name="dqdeptid")
	private Integer bfBigDeptId;

	/**
	 * 职务
	 */
	@Column(name="dutyname")
	private String dutyName;

	@Column(name="emplid")
	private Integer emplId;

	/**
	 *工作交接人姓名
	 */
	@Column(name="gzjjr")
	private String handToName;

	/**
	 *工作交接人id
	 */
	@Column(name="gzjjrid")
	private Integer handToId;

	/**
	 * 黑名单违反事项
	 */
	@Column(name="hmdwfsx")
	private String blackListItem;

	/**
	 * 离职黑名单
	 */
	@Column(name="lzhmd")
	private String blackList;

	/**
	 * 离职说明
	 */
	@Column(name="lzsm")
	private String dimissionMemo;

	/**
	 * 离职日期
	 */
	@Column(name="lztime")
	private String dimissionDate;

	/**
	 *离职类型
	 */
	@Column(name="lztype")
	private String dimissionType;

	/**
	 * 离职原因
	 */
	@Column(name="lzyy")
	private String dimissionReason;

	/**
	 * 变动前门店部门ID
	 */
	@Column(name="mddeptid")
	private Integer bfShopId;

	/**
	 *岗位
	 */
	@Column(name="positionname")
	private String positonName;

	/**
	 * 流程路径名称
	 */
	@Column(name="procename")
	private String processName;
	
	/**
	 * 流程路径ID
	 */
	@Column(name="procepathid")
	private Integer processPathId;

	/**
	 * 流程状态
	 */
	@Column(name="processstatu")
	private String processStatus;

	/**
	 * 变动前区域部门ID
	 */
	@Column(name="qydeptid")
	private Integer bfDeptId;

	/**
	 * 扣款说明
	 */
	@Column(name="remark")
	private String debtRemark;

	/**
	 * 社会保险
	 */
	@Column(name="shbx")
	private String societyExperience;

	/**
	 * 审批人id
	 */
	@Column(name="sprid")
	private Integer approverId;

	/**
	 * 审批人姓名
	 */
	@Column(name="sprname")
	private String approverName;

	/**
	 * 银行卡号
	 */
	@Column(name="yhkh")
	private String bankAccount;

	/**
	 * 转盘
	 */
	@Column(name="zp")
	private String isTransfer;

	/**
	 * 变动前战区部门ID
	 */
	@Column(name="zqdeptid")
	private Integer bfCompDeptId;

}