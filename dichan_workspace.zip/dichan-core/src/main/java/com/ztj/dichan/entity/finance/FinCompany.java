package com.ztj.dichan.entity.finance;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;
import com.ztj.dichan.enums.BasicSalaryStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 公司信息
 * 
 * @author zuohuan
 *
 */
@Entity
@Table(name = "fin_company")
@Data
@EqualsAndHashCode(callSuper = true)
public class FinCompany extends ShardingEntity {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4083479440457215104L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fin_company_id")
	private Integer id;

	// 公司名称
	private String finCompanyName;

	//是否世华集团
	private Boolean isGroup;
	
	//子公司
	private String subCompany;
	
	//公司地址
	private String companyAddr;
	
	//电话号码
	private String phoneNum;
	
	//状态
	private Boolean status;
	
	//数据源名称
	private String dbName;
	
	//公司首字母
	private String initial;
	
	//创建人
	private Integer createId;
	
	//创建时间
	private LocalDateTime createTime;
	
	//修改人
	private Integer lastUpdateId;
	
	//修改时间
	private LocalDateTime lastUpdateTime;
	
}
