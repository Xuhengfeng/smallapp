package com.ztj.dichan.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name="DELETE_LOG")
@Data
@EqualsAndHashCode(callSuper=true)
public class DeleteLog extends ShardingEntity{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Integer id;
	/**
	 * 要删除的表名
	 */
	private String tableName;
	/**
	 * 记录删除的时间
	 */
	private LocalDateTime deleteTime;
	/**
	 * 记录删除的主键值
	 */
	private Integer pkValue;
	
	private Long  deletedSdid;
	private String deletedScity;
	/**
	 * 删除记录中关键的重新跑批时间
	 */
	private String columnValue;
	/**
	 * 删除记录中关键的重新跑批时间字段名
	 */
	private String columnName;
	
	
}
