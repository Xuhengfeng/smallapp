package com.ztj.dichan.entity.finance;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 房产信息
 * 
 * @author zuohuan
 *
 */
@Entity
@Table(name = "fin_house")
@Data
@EqualsAndHashCode(callSuper = true)
public class FinHouse extends ShardingEntity {

	private static final long serialVersionUID = 6765945216094991604L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fin_house_id")
	private Integer id;

	//公司id
	private Integer companyId;
	
	// 房屋编号    编号程序自动生成， H18050001:H+年份+月份+4位数
	private String finHouseNo;

	//erp系统合同编号
	private String erpContrNo;
	
	//签约时间
	private Date dealDate;
	
	//物业地址
	private String houseAddr;
	
	//面积
	private BigDecimal areaSize;
	
	//房产权证编号
	private String houseAuthNo;
	
	//户型
	private String houseStyleId;
	
	//房屋性质
	private String houseTypeId;
	
	//业主售价
	private BigDecimal salePrice;
	
	//实际成交价
	private BigDecimal finalPrice;
	
	//评估价格
	private BigDecimal evaluPrice;
	
	//买房付款类型
	private String clientPayTypeId;
	
	//合同约定付款方式
	private String contrPayTypeId;
	
	//定金
	private BigDecimal orderAmt;
	
	//首付款
	private BigDecimal firstPayAmt;
	
	//尾款、贷款
	private BigDecimal lastPayAmt;
	
	//贷款银行
	private String loanBank;
	
	//买房贷款信息
	private String clientLoanInfo;
	
	//业主是否留卡
	private Boolean hasOwnerCard;
	
	//是否留密码
	private Boolean hasOwnerPwd;
	
	//公证委托情况
	private String notarialInfo;
	
	//是否查档
	private Boolean hasCheck;
	
	//创建人
	private Integer createId;
	
	//创建时间
	private LocalDateTime createTime;
	
	//修改人
	private Integer lastUpdateId;
	
	//修改时间
	private LocalDateTime lastUpdateTime;
	
}
