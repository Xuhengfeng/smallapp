package com.ztj.dichan.entity.port;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "net_cost_detail")
@Data
@EqualsAndHashCode(callSuper = true)
public class PortDetail extends ShardingEntity {

	private static final long serialVersionUID = 643226609123963375L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "net_cost_detail_id")
	private Integer id;
	
	/**
	 *  端口Id  
	 */  
	@Column(name = "net_cost_id")
	private Integer netCostId;
	

	/**
	 * 组别Id
	 */
	@Column(name = "group_id")
	private Integer groupId;
	
	/**
	 * 门店Id
	 */
	@Column(name = "shop_id")
	private Integer shopId;
	
	/**
	 * 区域Id
	 */
	@Column(name = "area_id")
	private Integer areaId;
	
	/**
	 * 大区Id
	 */
	@Column(name = "big_area_id")
	private Integer bigAreaId;
	
	/**
	 * 扣费月份
	 */
	@Column(name = "cost_month")
	private String costMonth;
	
	/**
	 * 扣费开始日期
	 */
	@Column(name = "cost_start_date")
	private LocalDateTime costStartDate;
	
	/**
	 * 扣费结束日期
	 */
	@Column(name = "cost_end_date")
	private LocalDateTime costEndDate;
	
	/**
	 * 上月结余
	 */
	@Column(name = "last_remain_money")
	private BigDecimal lastRemainMoney;
	
	/**
	 * 本月扣除
	 */
	@Column(name = "this_cost_company")
	private BigDecimal thisCostCompany;
	
	/**
	 * 本月结余
	 */
	@Column(name = "this_remain_money")
	private BigDecimal thisRemainMoney;
	
	/**
	 * 公司报销
	 */
	@Column(name = "this_cost_money")
	private BigDecimal thisCostMoney;
	
	/**
	 * 创建人
	 */
	@Column(name = "create_id")
	private Integer createId;
	
	/**
	 * 创建时间
	 */
	@Column(name = "create_time")
	private LocalDateTime createTime;
	
	/**
	 * 最后修改人
	 */
	@Column(name="last_update_id")
	private Integer lastUpdater;
	
	/**
	 * 最后修改时间
	 */
	@Column(name="last_update_time")
	private LocalDateTime lastUpdateTime;
}
