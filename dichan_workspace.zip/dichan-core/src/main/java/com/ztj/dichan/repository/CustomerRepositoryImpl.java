package com.ztj.dichan.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.LocalDateTimeType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.ztj.common.util.DateUtil;
import com.ztj.dichan.vo.CustomerSubDetailVo;
import com.ztj.dichan.vo.ReportDetailParams;

@Repository
public class CustomerRepositoryImpl{
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@PersistenceContext
	private EntityManager em;
	
	/**
	 * 客源报表
	 * 当前库存客源/新增客源
	 */
	public List<CustomerSubDetailVo> findCustTotalAndNewNum(ReportDetailParams reportDetailParams,Pageable pageable){
		List<CustomerSubDetailVo> list = new ArrayList<>();
		StringBuilder sql = new StringBuilder();	   
	      sql.append("SELECT top (?1) * FROM( ");
	      sql.append("SELECT  ROW_NUMBER() OVER ( ");
	      //动态排序
		   if(pageable.getSort()!=null) {
			   Sort s = pageable.getSort();
			   s.forEach(v ->{
				   if(v.getProperty().equalsIgnoreCase("deptName")) {
					 sql.append("ORDER BY (select case when charindex('区',o.deptName)>0 then substring(o.deptName,charindex('区',o.deptName)+1,len(o.deptName)- charindex('区',o.deptName)) ELSE o.deptName end) "+v.getDirection());
				   }else {
					 sql.append("ORDER BY o."+v.getProperty()+" "+v.getDirection());
				   }
			   });
	    	}else {
	    		sql.append(" ORDER BY o.createTime DESC");
	    	} 
	       sql.append(" ) AS rownum, * from ( ");
	       sql.append(" select c.customerNo customerNo,c.customerName customerName,c.customerTel1 customerTel,c.emplName1 emplName,c.deptName1 deptName,c.customertype custType,c.createTime createTime,c.modify_time modifyTime from customer c,Department d");
	       sql.append(" where c.DeptID1 = d.DeptID and d.deptlevel='组别' and d.is_biz_team = 'Y' and d.scity =c.scity and customerstatu = '有效' and ProcessStatu = '审批完成'");
	       sql.append(" and d.deptname in ("+concatGroupArrys(reportDetailParams)+") ");
	       if(reportDetailParams.getBeginDate()!=null) {
 			   sql.append(" and convert(datetime, substring(c.CreateTime,0,11),20)>= '"+DateUtil.formatDate(reportDetailParams.getBeginDate(),DateUtil.DATEFORMAT_DATE10)+"'");
 		   }
 		   if(reportDetailParams.getEndDate()!=null){
 			   sql.append(" and convert(datetime, substring(c.CreateTime,0,11),20)<= '"+DateUtil.formatDate(reportDetailParams.getEndDate(),DateUtil.DATEFORMAT_DATE10)+"'");
 		   }
 		   if(StringUtils.isNotEmpty(reportDetailParams.getReceptNoDetail())) {
 			   String str = reportDetailParams.getReceptNoDetail();
 			   boolean isDigit = str.trim().matches("^[A-Za-z0-9]*$");
			   if(!isDigit) {
				   sql.append(" and c.customerName like '%"+str.trim()+"%'");
			   }else {
				   sql.append(" and c.customerNo like '%"+str.trim()+"%'");
			   }
 		   }
 		  sql.append(") as o ) A WHERE rownum >?2 ");
		   Query query = em.createNativeQuery(sql.toString());
		   List<Object> paramList = new ArrayList<>();
		   paramList.add(pageable.getPageSize());
		   paramList.add(pageable.getPageNumber()*pageable.getPageSize());
		   int i = 1;
			for (Object param : paramList) {
				query.setParameter(i, param);
				i++;
			}
			query.unwrap(SQLQuery.class).
			    addScalar("customerNo", StringType.INSTANCE)
			   .addScalar("customerName", StringType.INSTANCE)
			   .addScalar("customerTel", StringType.INSTANCE)
			   .addScalar("emplName", StringType.INSTANCE)		
			   .addScalar("deptName", StringType.INSTANCE)
			   .addScalar("custType", StringType.INSTANCE)
			   .addScalar("createTime", StringType.INSTANCE)
			   .addScalar("modifyTime", LocalDateTimeType.INSTANCE)
			   .setResultTransformer(Transformers.aliasToBean(CustomerSubDetailVo.class));
	 		  list = query.getResultList();
	 		  return list;
	}
	
	
	/**
	 * 客源报表
	 * 当前库存客源的数量/当前新增客源的数量
	 */
	public Integer findCustTotalAndNewNumRow(ReportDetailParams reportDetailParams) {
		Integer totalSize =0;
	    StringBuilder sql = new StringBuilder();
	    
	    sql.append(" select count(*) from customer c,Department d");
	       sql.append(" where c.DeptID1 = d.DeptID and d.deptlevel='组别' and d.is_biz_team = 'Y' and d.scity =c.scity and customerstatu = '有效' and ProcessStatu = '审批完成'");
	       sql.append(" and d.deptname in ("+concatGroupArrys(reportDetailParams)+") ");
	       if(reportDetailParams.getBeginDate()!=null) {
			   sql.append(" and convert(datetime, substring(c.CreateTime,0,11),20)>= '"+DateUtil.formatDate(reportDetailParams.getBeginDate(),DateUtil.DATEFORMAT_DATE10)+"'");
		   }
		   if(reportDetailParams.getEndDate()!=null){
			   sql.append(" and convert(datetime, substring(c.CreateTime,0,11),20)<= '"+DateUtil.formatDate(reportDetailParams.getEndDate(),DateUtil.DATEFORMAT_DATE10)+"'");
		   }
		   if(StringUtils.isNotEmpty(reportDetailParams.getReceptNoDetail())) {
			   String str = reportDetailParams.getReceptNoDetail();
			   boolean isDigit = str.trim().matches("^[A-Za-z0-9]*$");
			   if(!isDigit) {
				   sql.append(" and c.customerName like '%"+str.trim()+"%'");
			   }else {
				   sql.append(" and c.customerNo like '%"+str.trim()+"%'");
			   }
		   }
		   Query query = em.createNativeQuery(sql.toString());
		   totalSize = (Integer) query.getSingleResult();
	       return totalSize;
	    
	}
	
	/**
	 * 客源报表
	 * 公客/私客
	 */
	public List<CustomerSubDetailVo> findCustDPNum(ReportDetailParams reportDetailParams,Pageable pageable,String custType){
		List<CustomerSubDetailVo> list = new ArrayList<>();
		StringBuilder sql = new StringBuilder();	   
	      sql.append("SELECT top (?1) * FROM( ");
	      sql.append("SELECT  ROW_NUMBER() OVER ( ");
	      //动态排序
		   if(pageable.getSort()!=null) {
			   Sort s = pageable.getSort();
			   s.forEach(v ->{
				   if(v.getProperty().equalsIgnoreCase("deptName")) {
					 sql.append("ORDER BY (select case when charindex('区',o.deptName)>0 then substring(o.deptName,charindex('区',o.deptName)+1,len(o.deptName)- charindex('区',o.deptName)) ELSE o.deptName end) "+v.getDirection());
				   }else {
					 sql.append("ORDER BY o."+v.getProperty()+" "+v.getDirection());
				   }
			   });
	    	}else {
	    		sql.append(" ORDER BY o.createTime DESC");
	    	} 
	       sql.append(" ) AS rownum, * from ( ");
	       sql.append(" select c.customerNo customerNo,c.customerName customerName,c.customerTel1 customerTel,c.emplName1 emplName,c.deptName1 deptName,c.customertype custType,c.createTime createTime,c.modify_time modifyTime from Department d,CustomerTSGJ cus");
	       sql.append(" right join  customer c on c.CustomerID = cus.CustomerID and cus.gjtype='转客' and cus.ProcessStatu = '审批完成'");
	       sql.append(" where c.DeptID1 = d.DeptID and d.deptlevel='组别' and d.is_biz_team = 'Y' and d.scity =c.scity");
	       sql.append(" and d.deptname in ("+concatGroupArrys(reportDetailParams)+") ");
	       sql.append(" and customerstatu = '有效' and c.ProcessStatu = '审批完成' and CustomerType = '"+custType+"'");
	       if(reportDetailParams.getBeginDate()!=null) {
 			   sql.append(" and case when substring(cus.CreateTime,0,11) is null then substring(c.CreateTime,0,11) else convert(datetime, substring(cus.CreateTime,0,11),20) end >= '"+DateUtil.formatDate(reportDetailParams.getBeginDate(),DateUtil.DATEFORMAT_DATE10)+"'");
 		   }
 		   if(reportDetailParams.getEndDate()!=null){
 			   sql.append(" and case when substring(cus.CreateTime,0,11) is null then substring(c.CreateTime,0,11) else convert(datetime, substring(cus.CreateTime,0,11),20) end <= '"+DateUtil.formatDate(reportDetailParams.getEndDate(),DateUtil.DATEFORMAT_DATE10)+"'");
 		   }
 		   if(StringUtils.isNotEmpty(reportDetailParams.getReceptNoDetail())) {
 			   String str = reportDetailParams.getReceptNoDetail();
 			   boolean isDigit = str.trim().matches("^[A-Za-z0-9]*$");
			   if(!isDigit) {
				   sql.append(" and c.customerName like '%"+str.trim()+"%'");
			   }else {
				   sql.append(" and c.customerNo like '%"+str.trim()+"%'");
			   }
 		   }
 		  sql.append(") as o ) A WHERE rownum >?2 ");
		   Query query = em.createNativeQuery(sql.toString());
		   List<Object> paramList = new ArrayList<>();
		   paramList.add(pageable.getPageSize());
		   paramList.add(pageable.getPageNumber()*pageable.getPageSize());
		   int i = 1;
			for (Object param : paramList) {
				query.setParameter(i, param);
				i++;
			}
			query.unwrap(SQLQuery.class).
		    addScalar("customerNo", StringType.INSTANCE)
		   .addScalar("customerName", StringType.INSTANCE)
		   .addScalar("customerTel", StringType.INSTANCE)
		   .addScalar("emplName", StringType.INSTANCE)		
		   .addScalar("deptName", StringType.INSTANCE)
		   .addScalar("custType", StringType.INSTANCE)
		   .addScalar("createTime", StringType.INSTANCE)
		   .addScalar("modifyTime", LocalDateTimeType.INSTANCE)
		   .setResultTransformer(Transformers.aliasToBean(CustomerSubDetailVo.class));
 		  list = query.getResultList();
 		  return list;
	}
	
	/**
	 * 客源报表
	 * 公客客源的数量/私客客源的数量
	 */
	public Integer findCustDPNumRow(ReportDetailParams reportDetailParams,String custType) {
		Integer totalSize =0;
	    StringBuilder sql = new StringBuilder();
	    
	    sql.append(" select count(*) from Department d,CustomerTSGJ cus");
	       sql.append(" right join  customer c on c.CustomerID = cus.CustomerID and cus.gjtype='转客' and cus.ProcessStatu = '审批完成'");
	       sql.append(" where c.DeptID1 = d.DeptID and d.deptlevel='组别' and d.is_biz_team = 'Y' and d.scity =c.scity");
	       sql.append(" and d.deptname in ("+concatGroupArrys(reportDetailParams)+") ");
	       sql.append(" and customerstatu = '有效' and c.ProcessStatu = '审批完成' and CustomerType = '"+custType+"'");
	       if(reportDetailParams.getBeginDate()!=null) {
			   sql.append(" and case when substring(cus.CreateTime,0,11) is null then substring(c.CreateTime,0,11) else convert(datetime, substring(cus.CreateTime,0,11),20) end >= '"+DateUtil.formatDate(reportDetailParams.getBeginDate(),DateUtil.DATEFORMAT_DATE10)+"'");
		   }
		   if(reportDetailParams.getEndDate()!=null){
			   sql.append(" and case when substring(cus.CreateTime,0,11) is null then substring(c.CreateTime,0,11) else convert(datetime, substring(cus.CreateTime,0,11),20) end <= '"+DateUtil.formatDate(reportDetailParams.getEndDate(),DateUtil.DATEFORMAT_DATE10)+"'");
		   }
		   if(StringUtils.isNotEmpty(reportDetailParams.getReceptNoDetail())) {
			   String str = reportDetailParams.getReceptNoDetail();
			   boolean isDigit = str.trim().matches("^[A-Za-z0-9]*$");
			   if(!isDigit) {
				   sql.append(" and c.customerName like '%"+str.trim()+"%'");
			   }else {
				   sql.append(" and c.customerNo like '%"+str.trim()+"%'");
			   }
		   }
		   Query query = em.createNativeQuery(sql.toString());
		   totalSize = (Integer) query.getSingleResult();
	       return totalSize;
	    
	}
	
	
	/**
	 * 客源报表
	 * 无效客源
	 */
	public List<CustomerSubDetailVo> findCustInvalidNum(ReportDetailParams reportDetailParams,Pageable pageable){
		List<CustomerSubDetailVo> list = new ArrayList<>();
		StringBuilder sql = new StringBuilder();	   
	      sql.append("SELECT top (?1) * FROM( ");
	      sql.append("SELECT  ROW_NUMBER() OVER ( ");
	      //动态排序
		   if(pageable.getSort()!=null) {
			   Sort s = pageable.getSort();
			   s.forEach(v ->{
				   if(v.getProperty().equalsIgnoreCase("deptName")) {
					 sql.append("ORDER BY (select case when charindex('区',o.deptName)>0 then substring(o.deptName,charindex('区',o.deptName)+1,len(o.deptName)- charindex('区',o.deptName)) ELSE o.deptName end) "+v.getDirection());
				   }else {
					 sql.append("ORDER BY o."+v.getProperty()+" "+v.getDirection());
				   }
			   });
	    	}else {
	    		sql.append(" ORDER BY o.createTime DESC");
	    	} 
	       sql.append(" ) AS rownum, * from ( ");
	       sql.append(" select c.customerNo customerNo,c.customerName customerName,c.customerTel1 customerTel,c.emplName1 emplName,c.deptName1 deptName,c.customertype custType,c.createTime createTime,c.modify_time modifyTime from Department d, customer c");
	       sql.append(" where c.DeptID1 = d.DeptID and d.deptlevel='组别' and d.is_biz_team = 'Y' and d.scity =c.scity and customerstatu = '无效' and ProcessStatu = '审批完成'");
	       sql.append(" and d.deptname in ("+concatGroupArrys(reportDetailParams)+") ");
	       if(reportDetailParams.getBeginDate()!=null) {
 			   sql.append(" and convert(datetime, substring(c.CreateTime,0,11),20)>= '"+DateUtil.formatDate(reportDetailParams.getBeginDate(),DateUtil.DATEFORMAT_DATE10)+"'");
 		   }
 		   if(reportDetailParams.getEndDate()!=null){
 			   sql.append(" and convert(datetime, substring(c.CreateTime,0,11),20)<= '"+DateUtil.formatDate(reportDetailParams.getEndDate(),DateUtil.DATEFORMAT_DATE10)+"'");
 		   }
 		   if(StringUtils.isNotEmpty(reportDetailParams.getReceptNoDetail())) {
 			   String str = reportDetailParams.getReceptNoDetail();
 			   boolean isDigit = str.trim().matches("^[A-Za-z0-9]*$");
			   if(!isDigit) {
				   sql.append(" and c.customerName like '%"+str.trim()+"%'");
			   }else {
				   sql.append(" and c.customerNo like '%"+str.trim()+"%'");
			   }
 		   }
 		  sql.append(") as o ) A WHERE rownum >?2 ");
		   Query query = em.createNativeQuery(sql.toString());
		   List<Object> paramList = new ArrayList<>();
		   paramList.add(pageable.getPageSize());
		   paramList.add(pageable.getPageNumber()*pageable.getPageSize());
		   int i = 1;
			for (Object param : paramList) {
				query.setParameter(i, param);
				i++;
			}
			query.unwrap(SQLQuery.class).
			    addScalar("customerNo", StringType.INSTANCE)
			   .addScalar("customerName", StringType.INSTANCE)
			   .addScalar("customerTel", StringType.INSTANCE)
			   .addScalar("emplName", StringType.INSTANCE)		
			   .addScalar("deptName", StringType.INSTANCE)
			   .addScalar("custType", StringType.INSTANCE)
			   .addScalar("createTime", StringType.INSTANCE)
			   .addScalar("modifyTime", LocalDateTimeType.INSTANCE)
			   .setResultTransformer(Transformers.aliasToBean(CustomerSubDetailVo.class));
	 		  list = query.getResultList();
	 		  return list;
	}
	
	/**
	 * 客源报表
	 * 无效客源的数量
	 */
	public Integer findCustInvalidNumRow(ReportDetailParams reportDetailParams) {
		Integer totalSize =0;
	    StringBuilder sql = new StringBuilder();
	    
	    sql.append(" select count(*) from Department d, customer c");
	       sql.append(" where c.DeptID1 = d.DeptID and d.deptlevel='组别' and d.is_biz_team = 'Y' and d.scity =c.scity and customerstatu = '无效' and ProcessStatu = '审批完成'");
	       sql.append(" and d.deptname in ("+concatGroupArrys(reportDetailParams)+") ");
	       if(reportDetailParams.getBeginDate()!=null) {
			   sql.append(" and convert(datetime, substring(c.CreateTime,0,11),20)>= '"+DateUtil.formatDate(reportDetailParams.getBeginDate(),DateUtil.DATEFORMAT_DATE10)+"'");
		   }
		   if(reportDetailParams.getEndDate()!=null){
			   sql.append(" and convert(datetime, substring(c.CreateTime,0,11),20)<= '"+DateUtil.formatDate(reportDetailParams.getEndDate(),DateUtil.DATEFORMAT_DATE10)+"'");
		   }
		   if(StringUtils.isNotEmpty(reportDetailParams.getReceptNoDetail())) {
			   String str = reportDetailParams.getReceptNoDetail();
			   boolean isDigit = str.trim().matches("^[A-Za-z0-9]*$");
			   if(!isDigit) {
				   sql.append(" and c.customerName like '%"+str.trim()+"%'");
			   }else {
				   sql.append(" and c.customerNo like '%"+str.trim()+"%'");
			   }
		   }
		   Query query = em.createNativeQuery(sql.toString());
		   totalSize = (Integer) query.getSingleResult();
	       return totalSize;
	    
	}
	
	/**
	 * 拼接groupArrays
	 * @param reportDetailParams
	 * @return
	 */
	public String concatGroupArrys(ReportDetailParams reportDetailParams) {
		StringBuffer sb = new StringBuffer();
	    for (int i = 0 ; i < reportDetailParams.getGroupDetailFilter().size(); i++) {
	      sb.append("'"+reportDetailParams.getGroupDetailFilter().get(i)+"'");
	      if (i < reportDetailParams.getGroupDetailFilter().size()-1 ) {
	        sb.append(",");
	      }
	    } 
	    return sb.toString();
	}
	    
}
