package com.ztj.dichan.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import com.ztj.dichan.enums.DealTypeEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * 顾客带看信息
 * @author admin
 *
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class CustWatch extends BaseDateTimeEntity  {
	private static final long serialVersionUID = 1L;
	/**
	 * 客户No
	 */
	private String customerNo;
	
	/**
	 * 房源id
	 */
	private int houseId;
	
	/**
	 * 楼盘字典ID
	 */
	private int buildId;
	
	/**
	 * 客户名称
	 */
	private String customerName;
	
	/**
	 * 顾客的联系电话
	 */
	private String customerTel;
	
	/**
	 * 顾客性别
	 * 0为男，1为女
	 */
	private Boolean customerSex;

	/**
	 * 租或者买
	 */
	@Enumerated(value = EnumType.STRING)
	private DealTypeEnum dealType;
	
	/**
	 * 房价
	 */
	private BigDecimal saleTotal;
	
	/**
	 * 单价
	 */
	private BigDecimal salePrice;
	
	/**
	 * 其他费用
	 */
	private BigDecimal saleOtherFee;
	
	/**
	 * 租金
	 */
	private BigDecimal rentTotal;
	
	/**
	 * 管理费
	 */
	private BigDecimal rentManageFee;
	
	/**
	 * 满意度
	 */
	private Long score;
	
	/**
	 * 看房时间
	 */
	private LocalDateTime watchDate;
	 
	/**
	 * 业务员id
	 */
	private Long emplId;
    
	
	/**
	 * 配置一对多的关系
	 * 带看客户上传的多张图片
	 */
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name = "custWatchId")
	private List<CustWatchPic> custWatchPicList =new ArrayList<>();
	

		
}
