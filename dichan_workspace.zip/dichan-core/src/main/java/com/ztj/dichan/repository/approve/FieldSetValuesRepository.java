package com.ztj.dichan.repository.approve;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.FieldSetValues;

@Repository
public interface FieldSetValuesRepository extends PagingAndSortingRepository<FieldSetValues,Long>{
		
	List<FieldSetValues> findByFieldChkRuleId(Integer fieldChkRuleId);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
