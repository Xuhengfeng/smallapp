package com.ztj.dichan.entity.assets;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.ztj.dichan.entity.ReportDaily;
import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 集团数据库 店面报表
 * 
 * @author zuohuan
 *
 */
@Entity
@Table(name = "report_weekly_asset")
@Data
@EqualsAndHashCode(callSuper = true)
public class ReportWeeklyAsset extends ShardingEntity {
	/**
	 * 
	 */
	private static final long serialVersionUID = 3573256668123210802L;

	// id主键
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "report_weekly_asset_id")
	private Integer id;

	// 办公室Id
	private Integer officeId;

	// 城市
	private String cityName;

	// 所属日期
	private Date reportDate;

	// 办公室名称
	private String officeName;

	// 起租日期
	private Date startDate;

	// 截止时间
	private Date endDate;

	// 月租金,总租金
	private BigDecimal rentMoney;

	// 装修费用，总装修费用
	private BigDecimal decorateMoney;

	// 押金，总押金
	private BigDecimal securityMoney;

	// 转让费，总转让费
	private BigDecimal transferMoney;

	// IT类
	private BigDecimal officeTotalItAmt;

	// IT类消耗品
	private BigDecimal officeTotalItConsAmt;

	// 电子设备类
	private BigDecimal officeTotalErpEquAmt;

	// 办公家具类
	private BigDecimal officeTotalWorFurAmt;

	// 办公用品类
	private BigDecimal officeTotalWorThiAmt;
	// 企业文化类
	private BigDecimal officeTotalEntCulAmt;
	// 运输交通类
	private BigDecimal officeTotalTraAmt;

	/**
	 * 创建人 第一次自动跑:AUTO_JOB 自动重跑：RETRY_JOB 人工重跑：操作员工
	 */
	private Long createId;

	/**
	 * 创建时间
	 */
	protected LocalDateTime createDateTime;

	/**
	 * 第一次自动跑:AUTO_JOB 自动重跑：RERUN_JOB 人工重跑：操作员工
	 */
	private Long lastUpdateId;

	/**
	 * 修改时间
	 */
	protected LocalDateTime updateDateTime;

	public static ReportWeeklyAsset assembleData(ReportWeeklyAsset existReportWeeklyAsset, ReportWeeklyAsset r) {
		r.setReportDate(existReportWeeklyAsset.getReportDate());
		r.setOfficeName(existReportWeeklyAsset.getOfficeName());
		r.setStartDate(existReportWeeklyAsset.getStartDate());
		r.setEndDate(existReportWeeklyAsset.getEndDate());
		r.setRentMoney(existReportWeeklyAsset.getRentMoney());
		r.setDecorateMoney(existReportWeeklyAsset.getDecorateMoney());
		r.setSecurityMoney(existReportWeeklyAsset.getSecurityMoney());
		r.setTransferMoney(existReportWeeklyAsset.getTransferMoney());
		r.setOfficeTotalItAmt(existReportWeeklyAsset.getOfficeTotalItAmt());
		r.setOfficeTotalItConsAmt(existReportWeeklyAsset.getOfficeTotalItConsAmt());
		r.setOfficeTotalErpEquAmt(existReportWeeklyAsset.getOfficeTotalErpEquAmt());
		r.setOfficeTotalWorFurAmt(existReportWeeklyAsset.getOfficeTotalWorFurAmt());
		
		r.setOfficeTotalWorThiAmt(existReportWeeklyAsset.getOfficeTotalWorThiAmt());
		r.setOfficeTotalEntCulAmt(existReportWeeklyAsset.getOfficeTotalEntCulAmt());
		r.setOfficeTotalTraAmt(existReportWeeklyAsset.getOfficeTotalTraAmt());

		return r;
	}
}
