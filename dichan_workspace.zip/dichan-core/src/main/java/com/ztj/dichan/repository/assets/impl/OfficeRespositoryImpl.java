package com.ztj.dichan.repository.assets.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.ztj.common.util.DateUtil;
import com.ztj.common.util.Verify;
import com.ztj.dichan.entity.Employee;
import com.ztj.dichan.entity.assets.Office;
import com.ztj.dichan.entity.assets.RequestOffice;
import com.ztj.dichan.vo.asset.OfficeDetailVo;
import com.ztj.dichan.vo.asset.TotalOfficeVo;
import com.ztj.dichan.vo.city.GroupVo;
import com.ztj.dichan.vo.request.asset.OfficeInfoRequest;

/**
 *分页查询办公室列表
 * @return
 */
@Repository
public class OfficeRespositoryImpl {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@PersistenceContext
	private EntityManager em;
	
	List<Office> queryOfficeListPage(String scity,Pageable pageable,RequestOffice requestOffice){
		try {
			Map<String, Object> params=new HashMap<>();
			List<Office> offices = new ArrayList<>();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT top (:top) * FROM( ");
			sql.append("SELECT  ROW_NUMBER() OVER (");
			if(pageable.getSort()!=null) {
				pageable.getSort().forEach(s->{
					String orderBy=s.getProperty();
					sql.append("order by o.");
					if(orderBy.equals("isNew"))
						orderBy="isNewEmp";
					else if(orderBy.equals("isCurrentDimission"))
						orderBy="dimissionDate";
					sql.append(orderBy+" ");
					sql.append(s.getDirection());
				});
			}else {
				sql.append(" ORDER BY o.id DESC ");
			}
			sql.append(") AS rownum, * from ( ");
			sql.append("select a.office_id as id,a.office_name as officeName, a.office_area as officeArea,a.phone_num_pre as phoneNumPre, ");
			sql.append("a.phone_num as phoneNum,a.address as address, a.start_date as startDate,a.end_date as endDate, ");
			sql.append("a.days_without_money as daysWithoutMoney,a.rent_money as rentMoney, a.decorate_money as decorateMoney,a.security_money as securityMoney, ");
			sql.append("a.transfer_money as transferMoney,a.pay_type as payType, a.transfer_goods as transferGoods");
			sql.append(" from office a left join empl_office e on e.office_id = a.office_id ");
			sql.append(" where 1=1 ");
			if(StringUtils.isNotEmpty(requestOffice.getEmplId().toString())) {
				sql.append(" and e.empl_id = '"+requestOffice.getEmplId()+"'");
	 		}
			if(StringUtils.isNotEmpty(requestOffice.getEndBeginTime())) {
				sql.append(" and a.end_date >= '"+requestOffice.getEndBeginTime()+"'");
	 		}
			if(StringUtils.isNotEmpty(requestOffice.getEndFinishTime())){
				sql.append(" and a.end_date <= '"+requestOffice.getEndFinishTime()+"'");
			}
			if(StringUtils.isNotEmpty(requestOffice.getStartBeginTime())) {
				sql.append(" and a.start_date >= '"+requestOffice.getStartBeginTime()+"'");
	 		}
			if(StringUtils.isNotEmpty(requestOffice.getStartFinishTime())){
				sql.append(" and a.start_date <= '"+requestOffice.getStartFinishTime()+"'");
			}
			if(StringUtils.isNotEmpty(requestOffice.getRentStatus())){
				if (requestOffice.getRentStatus().equals("有效")) {
					sql.append(" and a.end_date >= '"+DateUtil.plusDays2(0)+"'");
				}else {
					sql.append(" and a.end_date < '"+DateUtil.plusDays2(0)+"'");
				}
			}
			if(StringUtils.isNotEmpty(requestOffice.getStoreName())) {
				sql.append(" and a.office_name like '%"+requestOffice.getStoreName()+"%'");
			}
			if(StringUtils.isNotEmpty(requestOffice.getAddress())) {
				sql.append(" and a.address like '%"+requestOffice.getAddress()+"%'");
			}
			sql.append(") as o ) A WHERE rownum >:rownum ");
			
			Query query = em.createNativeQuery(sql.toString());
			params.put("top",pageable.getPageSize());
			params.put("rownum",pageable.getPageSize()*pageable.getPageNumber());
			
			for (String param : params.keySet()) {
				query.setParameter(param, params.get(param));
			}
			query.unwrap(SQLQuery.class)
			.addScalar("id", IntegerType.INSTANCE)
			.addScalar("officeName", StringType.INSTANCE)
			.addScalar("officeArea", BigDecimalType.INSTANCE)
			.addScalar("phoneNumPre", StringType.INSTANCE)
			.addScalar("phoneNum", StringType.INSTANCE)
			.addScalar("address", StringType.INSTANCE)
			.addScalar("startDate", StringType.INSTANCE)
			.addScalar("endDate", StringType.INSTANCE)
			.addScalar("daysWithoutMoney", StringType.INSTANCE)
			.addScalar("rentMoney", BigDecimalType.INSTANCE)
			.addScalar("decorateMoney", BigDecimalType.INSTANCE)
			.addScalar("securityMoney", BigDecimalType.INSTANCE)
			.addScalar("transferMoney", BigDecimalType.INSTANCE)
			.addScalar("payType", StringType.INSTANCE)
			.addScalar("transferGoods", StringType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(Office.class));
			offices = query.getResultList();
			return offices;
		} catch (Exception e) {
			logger.debug("分页查询办公室列表异常！");
		}
		return null;
	}
	
	public Integer officeTotalRecords(String scity,RequestOffice requestOffice) {
		StringBuffer sb = new StringBuffer();
		sb.append("select count(a.office_id) from office a left join empl_office e on e.office_id = a.office_id ");
		sb.append(" where 1=1 ");
		if(StringUtils.isNotEmpty(requestOffice.getEmplId().toString())) {
			sb.append(" and e.empl_id = '"+requestOffice.getEmplId()+"'");
 		}
		if(StringUtils.isNotEmpty(requestOffice.getEndBeginTime())) {
			sb.append(" and a.end_date >= '"+requestOffice.getEndBeginTime()+"'");
 		}
		if(StringUtils.isNotEmpty(requestOffice.getEndFinishTime())){
			sb.append(" and a.end_date <= '"+requestOffice.getEndFinishTime()+"'");
		}
		if(StringUtils.isNotEmpty(requestOffice.getStartBeginTime())) {
			sb.append(" and a.start_date >= '"+requestOffice.getStartBeginTime()+"'");
 		}
		if(StringUtils.isNotEmpty(requestOffice.getStartFinishTime())){
			sb.append(" and a.start_date <= '"+requestOffice.getStartFinishTime()+"'");
		}
		Map<String, Object> params = new HashMap<>();
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		return (Integer) query.getSingleResult();

	}
	public Integer officeInfoTotalRecords(OfficeInfoRequest officeInfoRequest) {
		StringBuffer sb = new StringBuffer();
		sb.append("SELECT " + 
				"	count(o.office_id) " + 
				"FROM " + 
				"	office o, " + 
				"	empl_office eo " + 
				"WHERE " + 
				"	o.office_id = eo.office_id " + 
				"AND empl_id = :emplId ");
		Map<String, Object> params = new HashMap<>();
		params.put("emplId", officeInfoRequest.getEmplId());
		
		//组装参数
		assembleParams(officeInfoRequest, sb, params);
		
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		return (Integer) query.getSingleResult();

	}
	
	public List<OfficeDetailVo> officeInfo(OfficeInfoRequest officeInfoRequest, Pageable pageable) {
		List<OfficeDetailVo> officeDetailVos = new ArrayList<>();
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		sb.append("SELECT top (:top) * FROM( ");
		sb.append("SELECT  ROW_NUMBER() OVER (");

		if (pageable.getSort() != null) {
			pageable.getSort().forEach(s -> {
				String orderBy = s.getProperty();
				sb.append("order by o.");
				sb.append(orderBy + " ");
				sb.append(s.getDirection());
			});
		} else {
			sb.append(" ORDER BY o.officeId DESC ");
		}
		sb.append(") AS rownum, * from ( ");

		sb.append("SELECT " + 
				"	o.office_id officeId, " + 
				"	o.office_name officeName, " + 
				"	o.start_date startDate, " + 
				"	o.end_date endDate, " + 
				"	o.phone_num phoneNum, " + 
				"	o.address address, " + 
				"	o.rent_money rentMoney, " + 
				" o.decorate_money decorateMoney, " + 
				" o.security_money securityMoney, " + 
				" o.transfer_money transferMoney, " + 
				" CASE " + 
				"WHEN o.end_date < CONVERT (DATE, GETDATE(), 20) THEN " + 
				"	'过期' " + 
				"ELSE " + 
				"	'有效' " + 
				"END status, " + 
				" ( " + 
				"	SELECT " + 
				"		SUM (a.asset_price) " + 
				"	FROM " + 
				"		asset a " + 
				"	WHERE " + 
				"		a.office_id = o.office_id " + 
				") totalAmount " + 
				"FROM " + 
				"	office o, " + 
				"	empl_office eo " + 
				"WHERE " + 
				"	o.office_id = eo.office_id " + 
				"AND empl_id = :emplId " + 
				"");
		params.put("emplId", officeInfoRequest.getEmplId());
		
		assembleParams(officeInfoRequest, sb, params);

		sb.append(") as o ) A WHERE rownum >:rownum ");

		params.put("top", pageable.getPageSize());

		params.put("rownum", pageable.getPageSize() * pageable.getPageNumber());
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		query.unwrap(SQLQuery.class)
		.addScalar("officeId", IntegerType.INSTANCE)
		.addScalar("officeName",StringType.INSTANCE)
		.addScalar("startDate",StringType.INSTANCE)
		.addScalar("endDate",StringType.INSTANCE)
		.addScalar("phoneNum",StringType.INSTANCE)
		.addScalar("address",StringType.INSTANCE)
		.addScalar("rentMoney",BigDecimalType.INSTANCE)
		.addScalar("decorateMoney",BigDecimalType.INSTANCE)
		.addScalar("securityMoney",BigDecimalType.INSTANCE)
		.addScalar("transferMoney",BigDecimalType.INSTANCE)
		.addScalar("totalAmount",BigDecimalType.INSTANCE)
		.addScalar("status",StringType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(OfficeDetailVo.class));
		officeDetailVos = query.getResultList();
		return officeDetailVos;
	}
	
	public TotalOfficeVo totalOffice(OfficeInfoRequest officeInfoRequest) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		sb.append(" " + 
				"SELECT " + 
				"	COUNT (o.office_id) totalCount, " + 
				"	SUM ( " + 
				"		o.rent_money " + 
				"	) totalRentMoney, " + 
				"	SUM (o.decorate_money) totalDecorateMoney, " + 
				"	SUM (o.security_money) totalSecurityMoney, " + 
				"	SUM (o.transfer_money) totalTransferMoney " + 
				"FROM " + 
				"	office o, " + 
				"	empl_office eo " + 
				" " + 
				"WHERE " + 
				"	o.office_id = eo.office_id " + 
				"AND empl_id = :emplId " + 
				"");
		params.put("emplId", officeInfoRequest.getEmplId());
		
		assembleParams(officeInfoRequest, sb, params);

		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		query.unwrap(SQLQuery.class)
		.addScalar("totalCount", LongType.INSTANCE)
		.addScalar("totalRentMoney",BigDecimalType.INSTANCE)
		.addScalar("totalDecorateMoney",BigDecimalType.INSTANCE)
		.addScalar("totalSecurityMoney",BigDecimalType.INSTANCE)
		.addScalar("totalTransferMoney",BigDecimalType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(TotalOfficeVo.class));
		List<TotalOfficeVo> totalOfficeVos = query.getResultList();
		if(Verify.collectionIfValue(totalOfficeVos))
			return totalOfficeVos.get(0);
		return null;
	}

	private void assembleParams(OfficeInfoRequest officeInfoRequest, StringBuffer sb, Map<String, Object> params) {
		if(!Verify.isBlank(officeInfoRequest.getOfficeName())) {
			sb.append(" and o.office_name like :officeName");
			params.put("officeName", "%"+officeInfoRequest.getOfficeName()+"%");
		}
		if(officeInfoRequest.getBeginTimeStart()!=null) {
			sb.append(" and start_date>=:beginTimeStart ");
			params.put("beginTimeStart", DateUtil.formatDate(officeInfoRequest.getBeginTimeStart(), DateUtil.DATEFORMAT_DATE10));
		}
		if(officeInfoRequest.getBeginTimeEnd()!=null) {
			sb.append(" and start_date<=:beginTimeEnd ");
			params.put("beginTimeEnd", DateUtil.formatDate(officeInfoRequest.getBeginTimeEnd(), DateUtil.DATEFORMAT_DATE10));
		}
		//有效
		if(officeInfoRequest.getStatus()!=null && officeInfoRequest.getStatus()==-1) 
			sb.append(" and end_date>=CONVERT (DATE, GETDATE(), 20) ");
		//过期
		else if(officeInfoRequest.getStatus()!=null  && officeInfoRequest.getStatus()==-2)
			sb.append(" and end_date<CONVERT (DATE, GETDATE(), 20) ");
		
		if(officeInfoRequest.getEndTimeStart()!=null) {
			sb.append(" and end_date>=:endTimeStart ");
			params.put("endTimeStart", DateUtil.formatDate(officeInfoRequest.getEndTimeStart(), DateUtil.DATEFORMAT_DATE10));
		}
		if(officeInfoRequest.getEndTimeEnd()!=null) {
			sb.append(" and end_date<=:endTimeEnd ");
			params.put("endTimeEnd", DateUtil.formatDate(officeInfoRequest.getEndTimeEnd(), DateUtil.DATEFORMAT_DATE10));
		}
	}
	
	public List<GroupVo> getOfficeListByType(Employee user,String type){
		String sql = "select DISTINCT o.office_id as deptId,o.office_name as deptName from office o ";
		Map<String, Object> params = new HashMap<>();
		if (type.equals("JURIS")) {
			sql += " join empl_office eo on eo.office_id = o.office_id where eo.empl_id=:emplId";
			params.put("emplId", user.getId());
		}
		Query query = em.createNativeQuery(sql);
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		query.unwrap(SQLQuery.class).addScalar("deptId", IntegerType.INSTANCE)
				.addScalar("deptName", StringType.INSTANCE)
				.setResultTransformer(Transformers.aliasToBean(GroupVo.class));
		List<GroupVo> groupVos = query.getResultList();
		return groupVos;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
