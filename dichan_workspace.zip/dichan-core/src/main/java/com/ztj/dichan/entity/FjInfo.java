package com.ztj.dichan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 附件表
 * 
 */
@Entity
@Table(name="fjinfo")
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="FjInfo.findAll", query="SELECT f FROM FjInfo f")
public class FjInfo extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="fjid")
	private Integer id;

	@Column(name="taskid")
	private Integer taskId;

	/**
	 * 具体业务ID
	 */
	@Column(name="workid")
	private Integer workId;

	/**
	 * 附件名称
	 */
	@Column(name="fjmc")
	private String fjmc;

	/**
	 * 文件名
	 */
	@Column(name="wjm")
	private String wjm;

	/**
	 * 文件类型
	 */
	@Column(name="wjlx")
	private String wjlx;

	/**
	 * 系统文件名
	 */
	@Column(name="xtwjm")
	private String xtwjm;

	/**
	 * 旋转度数
	 */
	@Column(name="degree")
	private String degree;

	@Column(name="createrid")
	private Integer createrId;

	@Column(name="creater")
	private String creater;

	@Column(name="createtime")
	private String createTime;
	

	//附件所属功能类型  如HOUSE,BORROW
	private String functionType;


}