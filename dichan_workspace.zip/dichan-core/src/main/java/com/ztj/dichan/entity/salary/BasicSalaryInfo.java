package com.ztj.dichan.entity.salary;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;
import com.ztj.dichan.enums.BasicSalaryStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 底薪表信息
 * 
 * @author zuohuan
 *
 */
@Entity
@Table(name = "basic_salary_info")
@Data
@EqualsAndHashCode(callSuper = true)
public class BasicSalaryInfo extends ShardingEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3959835194816070971L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "basic_salary_info_id")
	private Integer id;

	// 底薪月份
	private String yearMonth;

	// 员工ID
	private Integer employeeId;

	// 员工名称，数据库字段不存在
	private String employeeName;

	// 岗位ID
	private Integer positionId;

	// 岗位名称，数据库字段不存在
	private String positionName;

	// 部门ID
	private Integer deptId;

	// 组别名称
	private String groupName;

	// 入职时间
	private LocalDate changePositionTime;

	// 入职月数
	private Integer changeMonthNum;

	// 总业绩
	private BigDecimal amountTotal = BigDecimal.ZERO;

	// 定房数
	private Integer fixHouseNum = 0;

	// 底薪
	private BigDecimal basicSalary = BigDecimal.ZERO;

	// 是否为新入职员工
	private Boolean isNewEmp;

	// 是否为当月离职员工
	private Boolean isDimissionEmp;

	// 离职时间
	private LocalDate dimissionTime;

	// 是否手动添加
	private Boolean isCanChange;

	// 转正时间
	private LocalDateTime boardTime;

	// 锁定底薪
	private Boolean isLock;

	// 调整底薪
	private BigDecimal adjustBasicSalary = BigDecimal.ZERO;

	// 调整说明
	private String adjustRemark;

	// 补工资
	private BigDecimal incomingAddition = BigDecimal.ZERO;

	// 工龄工资
	private BigDecimal incomingWokingAge = BigDecimal.ZERO;

	// 其他收入
	private BigDecimal incomingOther = BigDecimal.ZERO;

	// 应发合计
	private BigDecimal dueIncomeTotal = BigDecimal.ZERO;

	// 缺勤天数
	private BigDecimal leaveDays = BigDecimal.ZERO;

	// 缺勤扣款
	private BigDecimal cutLeave = BigDecimal.ZERO;

	// 罚款
	private BigDecimal cutPunish = BigDecimal.ZERO;

	// 工服押金
	private BigDecimal cutClothes = BigDecimal.ZERO;

	// 社保
	private BigDecimal cutSocialSecutiy = BigDecimal.ZERO;

	// 世华基金
	private BigDecimal cutFund = BigDecimal.ZERO;

	// 员工借款
	private BigDecimal cutBorrow = BigDecimal.ZERO;

	// 业绩扣款
	private BigDecimal cutReachTask = BigDecimal.ZERO;

	// 住宿扣款
	private BigDecimal cutRentHouse = BigDecimal.ZERO;
	
	// 网络端口
	private BigDecimal networkPort = BigDecimal.ZERO;
	
	// 其他扣款
	private BigDecimal cutOther = BigDecimal.ZERO;

	// 扣款合计
	private BigDecimal cutTotal = BigDecimal.ZERO;

	// 实发金额
	private BigDecimal incomeAmount = BigDecimal.ZERO;

	// 状态
	@Enumerated(EnumType.STRING)
	private BasicSalaryStatusEnum status;

	// 旧状态
	@Enumerated(EnumType.STRING)
	private BasicSalaryStatusEnum oldStatus;

	// 创建人
	private Integer createId;

	// 创建时间
	private LocalDateTime createTime;

	// 最后修改人
	private Integer lastUpdateId;

	// 最后修改时间
	private LocalDateTime lastUpdateTime;

	// 拒绝理由
	private String rejectNode;

}
