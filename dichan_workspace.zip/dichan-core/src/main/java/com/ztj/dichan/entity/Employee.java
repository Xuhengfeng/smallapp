package com.ztj.dichan.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 员工基本信息
 * 
 */
@Entity
@Table(name = "employee")
@Data
@EqualsAndHashCode(callSuper=true)
public class Employee extends ShardingEntity {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "emplid")
	private Integer id;
	

	
	
	/**
	 * 账号状态
	 */
	@Column(name = "accostatu")
	private String accountStatus;

	/**
	 * 现住地址
	 */
	@Column(name = "addr")
	private String presentAddr;

	/**
	 * 开户银行
	 */
	@Column(name = "bank")
	private String bankName;

	/**
	 * 银行账户
	 */
	@Column(name = "bankaccount")
	private String bankAccount;

	/**
	 * 员工生日
	 */
	@Column(name = "brith")
	private String birthdayDate;

	/**
	 * 毕业时间
	 */
	@Column(name = "bysj")
	private String gratuationDate;

	/**
	 * 毕业学校
	 */
	@Column(name = "byxx")
	private String gratuationSchool;

	/**
	 * 操作人 系统自动生成，来自操作员工
	 */
	@Column(name = "creater")
	private String createId;

	/**
	 * 创建时间
	 */
	@Column(name = "createtime")
	private String createTime;

	/**
	 * 档案编号
	 */
	@Column(name = "dabh")
	private String docNo;

	/**
	 * 部门id
	 */
	@Column(name = "deptid")
	private Integer deptId;

	/**
	 * 到岗日期
	 */
	@Column(name = "dgtime")
	private String positionDate;

	/**
	 * 职务
	 */
	@Column(name = "dutyname")
	private String dutyName;

	/**
	 * 文化程度
	 */
	@Column(name = "education")
	private String educationLevel;

	/**
	 * 电子邮箱
	 */
	@Column(name = "email")
	private String email;

	/**
	 * 员工账号
	 */
	@Column(name = "emplacco")
	private String emplAccNo;

	/**
	 * 员工标签
	 */
	@Column(name = "emplbq")
	private String emplFlag;

	/**
	 * 员工信息
	 */
	@Column(name = "emplinfo")
	private String emplInfo;

	/**
	 * 员工名字
	 */
	@Column(name = "emplname")
	private String emplName;

	/**
	 * 公积金状态
	 */
	@Column(name = "gjjzt")
	private String fundStatus;

	/**
	 * 工作经验
	 */
	@Column(name = "gzjl")
	private String workExperience;

	/**
	 * 户籍地址
	 */
	@Column(name = "hjaddr")
	private String domicileAddr;

	/**
	 * 黑名单违反事项
	 */
	@Column(name = "hmdwfsx")
	private String blackListItem;

	/**
	 * 行业经验说明 有/无
	 */
	@Column(name = "hyjy")
	private String isExperience;

	/**
	 * 行业经验
	 */
	@Column(name = "hyjysm")
	private String experienceNote;

	/**
	 * 身份证号码
	 */
	@Column(name = "idcard")
	private String idNo;

	/**
	 * 籍贯
	 */
	@Column(name = "jg")
	private String nativePlace;

	/**
	 * 紧急联系人
	 */
	@Column(name = "jjcontacts")
	private String urgContactName;

	/**
	 * 紧急联系人关系
	 */
	@Column(name = "jjrrelation")
	private String urgRelation;

	/**
	 * 紧急联系人电话
	 */
	@Column(name = "jjrtel")
	private String urgContactTel;

	/**
	 * 考核标志 选择：1：是， 0：否
	 */
	@Column(name = "khbz")
	private String isAssess;

	/**
	 * 考核日期
	 */
	@Column(name = "khtime")
	private String assessDate;

	/**
	 * 查看客源次数
	 */
	@Column(name = "lccount")
	private Integer checkCustCount;

	/**
	 * pc端查看客源次数
	 */
	@Column(name = "lccountpc")
	private Integer checkCustCountPc;

	/**
	 * 查看业主的次数
	 */
	@Column(name = "lcount")
	private Integer checkOwnerCount;

	/**
	 * pc端查看业主次数
	 */
	@Column(name = "lcountpc")
	private Integer checkOwnerCountPc;

	/**
	 * 劳动合同期
	 */
	@Column(name = "ldhtqx")
	private Integer contractPeriod;

	/**
	 * 查看时间
	 */
	@Column(name = "ltime")
	private String checkOwnerTime;

	/**
	 * 离职办理日期
	 */
	@Column(name = "lzbltime")
	private String dimissionDealDate;

	/**
	 * 离职黑名单
	 */
	@Column(name = "lzhmd")
	private String blackList;

	/**
	 * 离职日期
	 */
	@Column(name = "lztime")
	private String dimissionDate;

	/**
	 * 民族
	 */
	@Column(name = "nation")
	private String nation;

	/**
	 * 手机号码
	 */
	@Column(name = "phone")
	private String phone;

	/**
	 * 照片
	 */
	@Column(name = "photo")
	private String photo;

	/**
	 * 拼音码
	 */
	@Column(name = "pinyin")
	private String pinyin;

	/**
	 * 岗位id
	 */
	@Column(name = "positiid")
	private Integer positiId;

	/**
	 * 岗位名称
	 */
	@Column(name = "positionname")
	private String positionName;

	/**
	 * 岗位说明
	 */
	@Column(name = "postnote")
	private String postNote;

	/**
	 * 密码
	 */
	@Column(name = "pwd")
	private String pwd;

	/**
	 * 拼音首字母
	 */
	@Column(name = "pytop")
	private String pinYinFirst;

	/**
	 * 渠道确认
	 */
	@Column(name = "qdqr")
	private String channelConfirm;

	/**
	 * qq
	 */
	@Column(name = "qq")
	private String qq;

	/**
	 * 入司渠道
	 */
	@Column(name = "rsqd")
	private String joinChannel;

	/**
	 * 入职办理日期
	 */
	@Column(name = "rzbltime")
	private String joinDealDate;

	/**
	 * 入职日期
	 */
	@Column(name = "rztime")
	private String joinDate;

	/**
	 * 性别
	 */
	@Column(name = "sex")
	private String sex;

	/**
	 * 师傅兑奖日期
	 */
	@Column(name = "sfdjdate")
	private String masterPrizeDate;

	/**
	 * 师傅ID
	 */
	@Column(name = "sfid")
	private Integer masterId;

	/**
	 * 师傅姓名
	 */
	@Column(name = "sfname")
	private String masterName;

	/**
	 * 社会保险
	 */
	@Column(name = "shbx")
	private String societyExperience;

	/**
	 * 显示序号
	 */
	@Column(name = "showorder")
	private Integer showOrder;

	/**
	 * 状态
	 */
	@Column(name = "statu")
	private String status;

	/**
	 * 联系电话
	 */
	@Column(name = "tel")
	private String tel;

	/**
	 * 推荐奖
	 */
	@Column(name = "tjj")
	private String refereePrize;

	/**
	 * 推荐奖说明
	 */
	@Column(name = "tjjsm")
	private String refereeNote;

	/**
	 * 推荐人id
	 */
	@Column(name = "tjrid")
	private Integer refereeId;

	/**
	 * 推荐人姓名
	 */
	@Column(name = "tjrname")
	private String refereeName;

	/**
	 * 往返员工
	 */
	@Column(name = "wfyg")
	private String isReturnEmp;

	/**
	 * 资料备注
	 */
	@Column(name = "zlbz")
	private String docNote;

	/**
	 * 资料齐否 是/否
	 */
	@Column(name = "zlqf")
	private String isDocComplete;

	/**
	 * 专业
	 */
	@Column(name = "zy")
	private String major;
	

//	/**
//	 * 修改人id
//	 */
//	private Long lastUpdateId;
//
//	/**
//	 * 最后修改时间
//	 */
//	private LocalDateTime lastUpdateTime;

}