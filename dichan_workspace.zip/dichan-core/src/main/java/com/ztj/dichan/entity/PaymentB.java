package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;


/**
 *请款明细表
 * 
 */
@Data
@Table(name="paymentb")
@Entity
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="PaymentB.findAll", query="SELECT p FROM PaymentB p")
public class PaymentB extends ShardingEntity{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="paymentid")
	private Integer id;

	@Column(name="amount")
	private BigDecimal amount;

	/**
	 * 款项id
	 */
	@Column(name="costitemid")
	private Integer costItemId;

	/**
	 * 请款主表id
	 */
	@Column(name="paymentaid")
	private Integer paymentAId;

	@Column(name="remark")
	private String remark;

	/**
	 * 收款id
	 */
	@Column(name="skid")
	private Integer payeeId;

	/**
	 * 收款类型
	 */
	@Column(name="sklx")
	private String payeeType;

	/**
	 * 收款单号
	 */
	@Column(name="skno")
	private String payeeNo;

	/**
	 * 核销金额
	 */
	@Column(name="useamount")
	private BigDecimal useAmount;

	/**
	 * 核销人名字
	 */
	@Column(name="verify")
	private String verifyName;

	@Column(name="verifyid")
	private Integer verifyId;

	/**
	 * 核销时间
	 */
	@Column(name="verifytime")
	private String verifyTime;

	/**
	 * 核销说明
	 */
	@Column(name="vexplain")
	private String verifyExplain;

}