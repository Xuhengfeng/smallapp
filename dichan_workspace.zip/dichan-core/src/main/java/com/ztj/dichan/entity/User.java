package com.ztj.dichan.entity;


import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 用户信息
 *
 * @author test01
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class User extends BaseDateTimeEntity {
	private static final long serialVersionUID = 1L;

	/**
	 * 用户名
	 */
	private String username;

	/**
	 * 密码
	 */
	private String password;

	/**
	 * 手机号
	 */
	private String mobile;

	/**
	 * 备注信息
	 */
	private String remark;
}
