package com.ztj.dichan.entity.finance;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 房产跟进表
 * 
 * @author HHF
 *
 */
@Entity
@Table(name = "fin_follow")
@Data
@EqualsAndHashCode(callSuper = true)
public class FinFollow extends ShardingEntity {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fin_follow_id")
	private Integer id;

	//公司id
	private Integer finHouseId;
	
	//跟进日期
	private Date followDate;
	
	//当前业务进度
	private String curFollowTypeId;
	
	//备注
	private String remark;
	
	//创建人
	private Integer createId;
	
	//创建时间
	private LocalDateTime createTime;
	
	//修改人
	private Integer lastUpdateId;
	
	//修改时间
	private LocalDateTime lastUpdateTime;
	
}
