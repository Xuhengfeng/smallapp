package com.ztj.dichan.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 多岗位
 * @author admin
 *
 */
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class PositionExtra  extends BaseDateTimeEntity{
    private static final long serialVersionUID = 1L;	
    /**
     * 员工
     */
    @ManyToOne(fetch= FetchType.EAGER)
    private Employee empl;

    /**
     *多岗位
     */
    @ManyToOne(fetch=FetchType.EAGER)
    private Position position;
	
	/**
	 * 创建人id
	 */
	private Long createId;
	
	/**
	 * 修改人
	 */
	private Long lastUpdateId;
	
}
