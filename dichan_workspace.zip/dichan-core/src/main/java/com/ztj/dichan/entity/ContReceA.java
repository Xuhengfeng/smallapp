package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;


/**
 * 合同收款主表
 * 
 */
@Table(name="contrecea")
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
@NamedQuery(name="ContReceA.findAll", query="SELECT c FROM ContReceA c")
public class ContReceA extends ShardingEntity {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="recptid")
	private Integer id;

	/**
	 * 存回未用
	 */
	@Column(name="chwy")
	private String chwy;

	/**
	 * 存款核销金额
	 */
	@Column(name="ckhxje")
	private BigDecimal depositeVerifyAmt;

	/**
	 * 合同表id
	 */
	@Column(name="contid")
	private Integer contId;

	@Column(name="creater")
	private String creater;

	@Column(name="createrid")
	private Integer createId;

	@Column(name="createtime")
	private String createTime;

	/**
	 * 客户关系表id
	 */
	@Column(name="crid")
	private Integer crid;

	/**
	 * 诚意金id
	 */
	@Column(name="cyjid")
	private Integer sincerityId;

	/**
	 * 诚意金转佣金
	 */
	@Column(name="czy")
	private String sincerityToService;

	@Column(name="deptid")
	private Integer deptId;

	@Column(name="explain")
	private String explain;

	/**
	 * 非货币
	 */
	@Column(name="fhb")
	private String nonCash;

	/**
	 * 存款日期
	 */
	@Column(name="paydate")
	private String payDate;

	/**
	 * 存款人
	 */
	@Column(name="payee")
	private String payee;

	@Column(name="payeeaccount")
	private String payeeAccount;

	@Column(name="payeeid")
	private Integer payeeId;

	/**
	 * 存款方式
	 */
	@Column(name="payeemode")
	private String payeeMode;

	@Column(name="procename")
	private String proceName;

	@Column(name="procepathid")
	private Integer procePathId;

	@Column(name="processstatu")
	private String processStatus;

	/**
	 * 收款日期
	 */
	@Column(name="recedate")
	private String receDate;

	/**
	 * 收据编号
	 */
	@Column(name="recptno")
	private String recptNO;

	/**
	 * 审批人id
	 */
	@Column(name="sprid")
	private Integer approverId;

	/**
	 * 审批人名字
	 */
	@Column(name="sprname")
	private String approverName;

	/**
	 * 实收金额
	 */
	@Column(name="ssje")
	private BigDecimal realAmount;

	
	/**
	 * 提交时间
	 */
	@Column(name="tjtime")
	private String approveTime;

	/**
	 * 收款总金额
	 */
	@Column(name="totalamount")
	private BigDecimal totalAmount;

	/**
	 * 调整金额
	 */
	@Column(name="tzje")
	private BigDecimal ajustAmount;

}