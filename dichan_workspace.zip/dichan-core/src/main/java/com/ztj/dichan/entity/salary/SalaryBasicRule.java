package com.ztj.dichan.entity.salary;


import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 底薪规则信息
 * 
 * @author test01
 */
@Entity
@Table(name = "salary_basic_rule")
@Data
@EqualsAndHashCode(callSuper = true)
public class SalaryBasicRule extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "salary_basic_rule_id")
	private Integer id;

	/**
	 * 岗位id
	 */
	//private Integer positionId;
	//岗位名称，从optionItem中取(关联ID为optionClass名称 工资配置)
	private String positionName;
	
	/**
	 * 底薪与业绩有关
	 */
	@Column(name = "is_incoming_rel")
	private String isIncomingRel="N";

	/**
	 * 底薪与定房有关
	 */
	@Column(name = "is_dujia_rel")
	private String isDujiaRel="N";

	/**
	 * 业绩达标 precision=19,scale=2,
	 * 
	 */
	@Column(name = "incoming_num" ,nullable=false,columnDefinition="numeric(19,2) default 0.00")
	private BigDecimal incomingNum;

	/**
	 * 定房达标量
	 */
	@Column(name = "dujia_count",nullable=false, columnDefinition="int default 0")
	private Long dujiaCount;

	/**
	 * 底薪（两者达标）
	 */
	@Column(name = "salary_both_reach",nullable=false, columnDefinition="numeric(19,2) default 0.00")
	private BigDecimal salaryBothReach;

	/**
	 * 底薪（两者未达标）
	 */
	@Column(name = "salary_both_unreach",nullable=false, columnDefinition="numeric(19,2) default 0.00")
	private BigDecimal salaryBothUnreach;

	/**
	 * 底薪（只有业绩达标）
	 */
	@Column(name = "salary_incoming_reach",nullable=false, columnDefinition="numeric(19,2) default 0.00")
	private BigDecimal salaryIncomingReach;

	/**
	 * 底薪（只有定房量达标）
	 */
	@Column(name = "salary_dujia_reach",nullable=false, columnDefinition="numeric(19,2) default 0.00")
	private BigDecimal salaryDujiaReach;

	/**
	 * 底薪与业绩无关的月数
	 */
	@Column(name="without_rel_month_cnt",nullable=false, columnDefinition="int default 0")
	private Integer withoutRelMonthCnt;

	/**
	 * 备注
	 */
	private String note;

	/**
	 * 创建人
	 */
	private Long createId;

	/**
	 * 创建时间
	 */
	private LocalDateTime createTime;

	/**
	 * 最后修改员工id
	 */
	private Long lastUpdateId;

	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime;
}