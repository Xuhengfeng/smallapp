package com.ztj.dichan.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Table(name="syslogin")
@Entity
public class SysLogin implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name="cityname")
	private String cityName;
	
	@Column(name="portnum")
	private String portNum;
	
	@Column(name="dbname")
	private String dbName;
	
	private String pcurl;
	
	private String appurl;
	
	private Integer ismain;
	
	private Integer isenable;
	
	private String px;
	
	private String py;
	
	private String cityNamePy;
	
	private String cityNameCh;
	
	private String orderNum;
	
	/**
	 * 测试,开发,生产环境标识
	 * dev,test,prod
	 */
	private String env;
	
	/**
	 * 数据源类型
	 * city,master,group
	 */
	private String dbType;
	
}
