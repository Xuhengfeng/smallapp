package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 入职信息
 * 
 */
@Data
@Entity
@Table(name="entryinfo")
@EqualsAndHashCode(callSuper = true)
public class EntryInfo extends ShardingEntity {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="entryid")
	private Integer id;

	/**
	 * 联系地址
	 */
	@Column(name="addr")
	private String presentAddr;

	/**
	 * 办理人
	 */
	@Column(name="blr")
	private String handleName;

	/**
	 * 办理人id
	 */
	@Column(name="blrid")
	private Integer handleId;

	/**
	 * 办理日期
	 */
	@Column(name="bltime")
	private String handleTime;

	/**
	 * 员工生日
	 */
	@Column(name="brith")
	private String birthdayDate;

	/**
	 * 毕业时间
	 */
	@Column(name="bysj")
	private String gratuationDate;

	/**
	 * 毕业学校
	 */
	@Column(name="byxx")
	private String gratuationSchool;

	@Column(name="creater")
	private String creater;

	@Column(name="createrid")
	private Integer createrId;

	@Column(name="createtime")
	private String createTime;

	/**
	 * 档案编号
	 */
	@Column(name="dabh")
	private String docNo;

	@Column(name="deptid")
	private Integer deptId;

	/**
	 * 到岗日期
	 */
	@Column(name="dgtime")
	private String positionDate;

	/**
	 * 职务
	 */
	@Column(name="dutyname")
	private String dutyName;

	/**
	 * 文化程度
	 */
	@Column(name="education")
	private String educationLevel;

	@Column(name="email")
	private String email;

	/**
	 * 员工帐号
	 */
	@Column(name="emplacco")
	private String emplAccNo;

	@Column(name="emplid")
	private Integer emplId;

	@Column(name="emplinfo")
	private String emplInfo;

	@Column(name="emplname")
	private String emplName;

	/**
	 * 公积金状态
	 */
	@Column(name="gjjzt")
	private String fundStatus;

	/**
	 * 工作经历
	 */
	@Column(name="gzjl")
	private String workExperience;

	/**
	 * 户籍地址
	 */
	@Column(name="hjaddr")
	private String domicileAddr;

	/**
	 * 行业经验
	 */
	@Column(name="hyjy")
	private String isExperience;

	/**
	 * 行业经验说明
	 */
	@Column(name="hyjysm")
	private String experienceNote;

	/**
	 * 身份证号码
	 */
	@Column(name="idcard")
	private String idNo;

	/**
	 * 籍贯
	 */
	@Column(name="jg")
	private String nativePlace;

	/**
	 * 紧急联系人
	 */
	@Column(name="jjcontacts")
	private String urgContactName;

	/**
	 * 紧急联系人关系
	 */
	@Column(name="jjrrelation")
	private String urgRelation;

	/**
	 * 紧急联系人电话
	 */
	@Column(name="jjrtel")
	private String urgContactTel;

	/**
	 *劳动合同期限
	 */
	@Column(name="ldhtqx")
	private Integer contractPeriod;

	/**
	 * 民族
	 */
	@Column(name="nation")
	private String nation;

	@Column(name="phone")
	private String phoneNum;

	@Column(name="positiid")
	private Integer positiId;

	@Column(name="positionname")
	private String positionName;

	/**
	 * 流程路径名称
	 */
	@Column(name="procename")
	private String processName;

	/**
	 * 流程路径id
	 */
	@Column(name="procepathid")
	private Integer processPathId;

	/**
	 * 流程状态
	 */
	@Column(name="processstatu")
	private String processStatu;

	@Column(name="qq")
	private String qq;

	/**
	 * 入司渠道
	 */
	@Column(name="rsqd")
	private String joinChannel;

	/**
	 * 入职日期
	 */
	@Column(name="rztime")
	private String joinDate;

	@Column(name="sex")
	private String sex;

	/**
	 * 师傅id
	 */
	@Column(name="sfid")
	private Integer masterId;

	/**
	 * 师傅姓名
	 */
	@Column(name="sfname")
	private String masterName;

	/**
	 * 社会保险
	 */
	@Column(name="shbx")
	private String societyExperience;

	/**
	 * 审批人id
	 */
	@Column(name="sprid")
	private Integer approverId;

	/**
	 * 审批人姓名
	 */
	@Column(name="sprname")
	private String approverName;

	@Column(name="statu")
	private String status;

	@Column(name="tel")
	private String tel;

	/**
	 * 推荐人id
	 */
	@Column(name="tjrid")
	private Integer refereeId;

	/**
	 * 推荐人姓名
	 */
	@Column(name="tjrname")
	private String refereeName;

	/**
	 * 往返员工
	 */
	@Column(name="wfyg")
	private String isReturnEmp;

	/**
	 * 资料备注
	 */
	@Column(name="zlbz")
	private String docNote;

	/**
	 * 资料齐否
	 */
	@Column(name="zlqf")
	private String isDocComplete;

	/**
	 * 专业
	 */
	@Column(name="zy")
	private String major;

}