package com.ztj.dichan.entity;

import java.time.LocalDateTime;
import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 	部门信息
 */
@Entity
@Table(name="department")
@Data
@EqualsAndHashCode(callSuper=true)
public class Department extends ShardingEntity {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="deptid")
	private Integer id;

	/**
	 * 地址
	 */
	@Column(name="addr")
	private String addr;

	/**
	 * 区域id
	 */
	@Column(name="areaid")
	private Integer areaId;

	/**
	 * 操作员id
	 */
	@Column(name="creater")
	private String createId;

	/**
	 * 创建时间
	 */
	@Column(name="createtime")
	private String createTime;

	/**
	 * 客源编号前缀
	 */
	@Column(name="customertop")
	private String custNoPrefix;

	/**
	 * 部门信息
	 */
	@Column(name="deptinfo")
	private String deptInfo;

	/**
	 * 部门经纬度
	 */
	@Column(name="deptjwd")
	private String deptjwd;

	/**
	 * 部门层级
	 * 选择：空、店组、区域、大区
	 */
	@Column(name="deptlevel")
	private String deptLevel;

	/**
	 * 部门名字
	 */
	@Column(name="deptname")
	private String deptName;

	/**
	 * 树形路径
	 */
	@Column(name="depttree")
	private String deptTree;

	/**
	 * 部门类型
	 */
	@Column(name="depttype")
	private String deptType;
	
	/**
	 * 部门所在片区ID
	 */
	@Column(name="districtid")
	private Integer districtId;

	/**
	 * 房源编号前缀
	 */
	@Column(name="housetop")
	private String houseNoPrefix;

	/**
	 * 精耕房库存数量
	 */
	@Column(name="jgfkcsl")
	private Integer jgfNum;

	/**
	 * 钥匙编号前缀
	 */
	@Column(name="keytop")
	private String keyNoPrefix;

	/**
	 * 部门负责人ID
	 * 与员工表(employee)的EmplID关联
	 */
	@Column(name="leaderid")
	private Integer leaderId;

	/**
	 * 上级部门ID
	 * 从已有部门选择，不能为空，第一级为0
	 */
//	@JoinColumn(name="parentid")
//	@ManyToOne(fetch = FetchType.LAZY)
//	@NotFound(action = NotFoundAction.IGNORE)
//	@JsonIgnoreProperties
//	private Department parent;

	@Column(name="parentid")
	private Integer parentId = 0;

	/**
	 * 拼音码
	 */
	@Column(name="pinyin")
	private String pinYin;

	/**
	 * 区域直管组
	 */
	@Column(name="qyzgz")
	private String areaChargeGroup;

	/**
	 * 显示序号
	 */
	@Column(name="showorder")
	private String showOrder;

	/**
	 * 子节点数量
	 */
	@Column(name="sonnum")
	private Integer sonNum;

	/**
	 * 状态
	 * 选择：启用/停用
	 */
	@Column(name="statu")
	private String status;

	/**
	 * 电话号码
	 */
	@Column(name="tel")
	private String telNum;

	/**
	 *执照名称
	 */
	@Column(name="zzmc")
	private String licenseName;

	/**
	 * 限制组别不合法的插入
	 */
	@Column(name="is_biz_team")
	private String isBizTeam;
	
	/**
	 * 办公区Id
	 */
	@Column(name="office_id")
	private Integer officeId;
	
	/**
	 * 修改人id
	 */
	//private Long lastUpdateId;
	
	/**
	 * 最后修改时间
	 */
	//private LocalDateTime lastUpdateTime=LocalDateTime.now();
	
}