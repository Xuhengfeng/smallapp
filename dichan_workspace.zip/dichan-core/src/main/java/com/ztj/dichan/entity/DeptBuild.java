package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 部门楼盘表
 * 
 */
@Entity
@Table(name ="deptbuild")
@Data
@EqualsAndHashCode(callSuper=true)
public class DeptBuild extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="dbid")
	private Integer id;

	@Column(name="buildid")
	private Integer buildId;

	/**
	 * 操作员id
	 */
	@Column(name="creater")
	private String createId;

	@Column(name="createtime")
	private String createTime;

	@Column(name="deptid")
	private Integer deptId;

}