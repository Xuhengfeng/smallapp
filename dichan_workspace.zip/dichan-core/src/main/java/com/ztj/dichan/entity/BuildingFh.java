package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;
 

/**
 * 楼盘房号表
 */
@Entity
@Table(name = "buildingfh")
@Data
@EqualsAndHashCode(callSuper = true)
public class BuildingFh extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="buildfhid")
	private Integer id;

	/**
	 * 栋座id
	 */
	@Column(name="builddzid")
	private Integer buildBlockId;

	/**
	 * 楼盘id
	 */
	@Column(name="buildid")
	private Integer buildId;

	/**
	 * 楼盘字典名称
	 */
	@Column(name="buildname")
	private String buildName;

	/**
	 * 朝向
	 */
	@Column(name="cx")
	private String houseDirection;

	/**
	 * 单元名
	 */
	@Column(name="dyname")
	private String unitName;

	/**
	 * 栋座名
	 */
	@Column(name="dzname")
	private String blockName;

	/**
	 * 房
	 */
	@Column(name="fang")
	private Integer roomsNum;

	/**
	 * 房号
	 */
	@Column(name="fhname")
	private String roomNo;

	/**
	 * 建造面积
	 */
	@Column(name="jzmj")
	private BigDecimal buildArea;

	/**
	 * 厅
	 */
	@Column(name="ting")
	private Integer livingRoomNum;

	/**
	 * 套内面积
	 */
	@Column(name="tnmj")
	private BigDecimal innerArea;

	/**
	 * 卫
	 */
	@Column(name="wei")
	private Integer washRoomNum;

	/**
	 * 阳台
	 */
	@Column(name="yangtai")
	private int balconyNum;
	
	/**
	 * 楼层数
	 */
	private Integer floorNo;
	
	/**
	 * 修改人id
	 */
	private Long lastUpdateId;
	
	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}