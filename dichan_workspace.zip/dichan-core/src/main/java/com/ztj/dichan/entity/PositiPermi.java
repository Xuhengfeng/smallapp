
/**
* @Title: PositiPermi.java
* @Package com.ztj.dichan.entity
* @Description: TODO 
* @author zuohuan
* @date 2018年7月20日
* @version V1.0
**/
package com.ztj.dichan.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
* @ClassName: PositiPermi
* @Description: TODO 岗位权限表
* @author zuohuan
* @date 2018年7月20日
*
**/
@Entity
@Table(name="PositiPermi")
@Data
@EqualsAndHashCode(callSuper = true)
public class PositiPermi extends ShardingEntity{
	/**
	* @Fields field:field:{todo}
	**/
	private static final long serialVersionUID = 1773432195202747778L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="positiPermiId")
	private Integer positiPermiId;
	
	private Integer Positid;
	
	private Integer PermiId;
	
	private Integer creater;
	
	private LocalDateTime createTime;
	
}
