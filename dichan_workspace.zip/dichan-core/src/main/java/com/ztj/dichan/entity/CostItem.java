package com.ztj.dichan.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * The persistent class for the CostItem database table.
 * 
 */

@Entity
@Table(name="costitem")
@Data
@EqualsAndHashCode(callSuper = true)
public class CostItem extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="costitemid")
	private Integer id;

	@Column(name="creater")
	private String creater;

	@Column(name="createtime")
	private String createTime;

	@Column(name="itemname")
	private String itemName;

	@Column(name="itemtype")
	private String itemType;

	@Column(name="statu")
	private String status;

	@Column(name="xh")
	private Integer xh;

}