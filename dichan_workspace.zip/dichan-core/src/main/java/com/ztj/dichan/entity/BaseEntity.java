package com.ztj.dichan.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import lombok.Data;
import lombok.EqualsAndHashCode;
 
/**
 * 基本实体对象,只定义所有实体对象公用的属性,非公有的需要在子类中定义
 *
 * @author test01
 */
@MappedSuperclass
@Data
@EqualsAndHashCode(callSuper=true)
public class BaseEntity extends ShardingEntity{
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
      protected Long id;
}
