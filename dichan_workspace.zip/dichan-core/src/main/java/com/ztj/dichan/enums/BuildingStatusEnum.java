package com.ztj.dichan.enums;

import java.io.Serializable;

public enum BuildingStatusEnum implements Serializable{

	N("new_constuct", "新建", ""),
    A("success_approval", "审批成功", ""),
	U("update","修改",""),
	D("delete","删除","");
	
	private String code;

	private String name;
	
	private String desc;
	    
	public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}

	private BuildingStatusEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
}
