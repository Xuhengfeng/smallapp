package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 流程表
 * 
 */
@Entity
@Table(name="process")
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="Process.findAll", query="SELECT p FROM Process p")
public class Process extends ShardingEntity {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="proceid")
	private Integer id;

	@Column(name="creater")
	private String creater;

	@Column(name="createtime")
	private String createTime;

	/**
	 * 操作类型
	 */
	@Column(name="opertype")
	private String operType;

	/**
	 * 流程信息
	 */
	@Column(name="proceinfo")
	private String proceInfo;

	/**
	 * 流程名称
	 */
	@Column(name="procename")
	private String proceName;

	/**
	 * 流程序号
	 */
	@Column(name="proceorder")
	private Integer proceOrder;

	@Column(name="statu")
	private String status;

	@Column(name="taskid")
	private Integer taskId;

	/**
	 * 通用申请默认流程id
	 * 与通用申请默认流程表TysqProc与的TysqProcID关联
	 */
	@Column(name="tysqprocid")
	private Integer taskProcId;

	/**
	 * 通用申请类型ID，与通用申请类型表
	 */
	@Column(name="tysqtypeid")
	private Integer comReqTypeId;
	
	@Transient
	private Integer emplId;
	@Transient
	private String person;


}