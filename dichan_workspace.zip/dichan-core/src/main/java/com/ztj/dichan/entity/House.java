package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.List;


/**
 * 房源信息
 * 
 */
@Entity
@Table(name="House")
@Data
@EqualsAndHashCode(callSuper = true)
public class House extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="houseid")
	private Integer id;

	/**
	 * 楼盘官方地址
	 */
	@Column(name="adress1")
	private String adreessOfficial;

	/**
	 * 楼盘通俗地址
	 */
	@Column(name="adress2")
	private String adreessNormal;

	/**
	 * 区域
	 */
	@Column(name="areaname")
	private String areaName;

	/**
	 * 归属原因
	 */ 
	@Column(name="belongreason1")
	private String belongReason1;

	/**
	 * 归属原因2
	 */
	@Column(name="belongreason2")
	private String belongReason2;

	/**
	 * 归属原因3
	 */
	@Column(name="belongreason3")
	private String belongReason3;

	/**
	 * 归属原因4
	 */
	@Column(name="belongreason4")
	private String belongReason4;

	/**
	 * 归属原因5
	 */
	@Column(name="belongreason5")
	private String belongReason5;
	
	/**
	 * 归属原因6
	 */
	@Column(name="belongreason6")
	private String belongReason6;
	
	/**
	 * 归属原因7
	 */
	@Column(name="belongreason7")
	private String belongReason7;

	/**
	 * 建筑年代
	 */
	@Column(name="buildage")
	private String buildAge;
	
	/**
	 * 楼盘id
	 */
	@Column(name="buildid")
	private Integer buildID;

	/**
	 * 楼盘名称
	 */
	@Column(name="buildname")
	private String buildName;

	/**
	 * 建筑面积
	 */
	@Column(name="builtarea")
	private BigDecimal builtArea;

	/**
	 * 
	 */
	@Column(name="comefrom")
	private String comeFrom;

	/**
	 * 联系人
	 */
	@Column(name="contacts")
	private String relativeName;

	/**
	 * 联系人电话
	 */
	@Column(name="contactstel")
	private String relativeTel;

	/**
	 * 创建人
	 */
	@Column(name="creater")
	private String createUserName;

	/**
	 * 创建人ID
	 */
	@Column(name="createrid")
	private Integer createUserId;

	/**
	 * 创建时间，yyyy-mm-dd hh:mm:ss
	 */
	@Column(name="createtime")
	private String createTime;
	
	/**
	 * 交易类型  出租/出售/租售
	 */
	@Column(name="dealtype")
	private String dealType;

	/**
	 * 部门ID 1
	 * 与部门表(Department)的DeptID关联。
	 */
	@Column(name="deptid1")
	private Integer deptId1;

	/**
	 * 部门ID 2
	 * 与部门表(Department)的DeptID关联。
	 */
	@Column(name="deptid2")
	private Integer deptId2;

	/**
	 * 部门ID 3
	 * 与部门表(Department)的DeptID关联。
	 */
	@Column(name="deptid3")
	private Integer deptId3;

	/**
	 * 部门ID  4
	 * 与部门表(Department)的DeptID关联。
	 */
	@Column(name="deptid4")
	private Integer deptId4;
	
	/**
	 * 部门ID  5
	 * 与部门表(Department)的DeptID关联。
	 */
	@Column(name="deptid5")
	private Integer deptId5;

	/**
	 * 部门ID 6
	 * 与部门表(Department)的DeptID关联。
	 */
	@Column(name="deptid6")
	private Integer deptId6;

	/**
	 * 部门ID 7
	 * 与部门表(Department)的DeptID关联。
	 */
	@Column(name="deptid7")
	private Integer deptId7;

	/**
	 * 部门名称
	 */
	@Column(name="deptname1")
	private String deptName1;

	/**
	 * 部门名称
	 */
	@Column(name="deptname2")
	private String deptName2;

	/**
	 * 部门名称
	 */
	@Column(name="deptname3")
	private String deptName3;

	/**
	 * 部门名称
	 */
	@Column(name="deptname4")
	private String deptName4;

	/**
	 * 部门名称
	 */
	@Column(name="deptname5")
	private String deptName5;

	/**
	 * 部门名称
	 */
	@Column(name="deptname6")
	private String deptName6;

	/**
	 * 部门名称
	 */
	@Column(name="deptname7")
	private String deptName7;

	/**
	 * 委托日期
	 */
	@Column(name="depudate")
	private String deputeDate;

	/**
	 * 委托方式
	 */
	@Column(name="deputype")
	private String deputeType;

	/**
	 * 底价
	 */
	@Column(name ="diprice")
	private BigDecimal lowestPrice;

	/**
	 * 片区
	 */
	@Column(name="districtname")
	private String districtName;

	/**
	 * 三个月内带看量
	 */
	@Column(name="dkcount")
	private Integer watchCounts3month;

	/**
	 * 单元
	 */
	@Column(name="dyname")
	private String unitName;

	/**
	 * 栋座
	 */
	@Column(name="dzname")
	private String blockName;

	@Column(name="emplid1")
	private Integer emplId1;

	@Column(name="emplid2")
	private Integer emplId2;

	@Column(name="emplid3")
	private Integer emplId3;

	@Column(name="emplid4")
	private Integer emplId4;

	@Column(name="emplid5")
	private Integer emplId5;

	@Column(name="emplid6")
	private Integer emplId6;

	@Column(name="emplid7")
	private Integer emplId7;

	/**
	 * 归属人1
	 */
	@Column(name="emplname1")
	private String emplName1;

	/**
	 * 	归属人2
	 */
	@Column(name="emplname2")
	private String emplName2;

	/**
	 * 	归属人3
	 */
	@Column(name="emplname3")
	private String emplName3;

	/**
	 * 	归属人4
	 */
	@Column(name="emplname4")
	private String emplName4;

	/**
	 * 	归属人5
	 */
	@Column(name="emplname5")
	private String emplName5;

	/**
	 * 	归属人6
	 */
	@Column(name="emplname6")
	private String emplName6;

	/**
	 * 	归属人7
	 */
	@Column(name="emplname7")
	private String emplName7;

	/**
	 * 房
	 */
	@Column(name="fang")
	private Integer roomsNum;

	/**
	 * 房号
	 */
	@Column(name="fhname")
	private String roomName;

	/**
	 * 房源标签
	 */
	@Column(name="housebq")
	private String houseTag;

	/**
	 * 朝向
	 */
	@Column(name="housecx")
	private String houseDirection;

	/**
	 * 证件情况
	 */
	@Column(name="housedoc")
	private String houseDoc;
	
	/**
	 * 房屋类型（平层/高层/小高层/错层/跃层/洋房/别墅/四合院）
	 */
	@Column(name="houseform")
	private String houseForm;

	/**
	 * 家具电器
	 */
	@Column(name="housejd")
	private String houseElec;

	/**
	 * 看房
	 */
	@Column(name="housekf")
	private String houseWatch;

	/**
	 * 房源编号
	 * 部门+数字
	 */
	@Column(name="houseno")
	private String houseNo;

	/**
	 * 现状
	 */
	@Column(name="housenow")
	private String houseCurrentStatus;

	/**
	 * 产权
	 */
	@Column(name="houseright")
	private String houseRight;

	/**
	 * 来源
	 */
	@Column(name="housesource")
	private String houseSource;

	/**
	 * 建筑结构
	 */
	@Column(name="housestru")
	private String houseStruc;

	/**
	 * 面朝实物
	 */
	@Column(name="housesw")
	private String objectFace;

	/**
	 * 税费
	 */
	@Column(name="housetax")
	private String houseTax;

	/**
	 * 房源标题
	 * 手动填写，若无，就以片区+楼盘+户型+面积
	 */
	@Column(name="housetitle")
	private String houseTitle;

	/**
	 * 默认公盘
	 * 房源分类（公盘/私盘/封盘）
	 */
	@Column(name="housetype")
	private String houseType;

	/**
	 * 默认普通房
	 * 房源特征（普通房/精耕房/全程房）
	 */
	@Column(name="housetz")
	private String houseFeature;
	
	/**
	 * 用途
	 */
	@Column(name="houseuse")
	private String houseUse;

	/**
	 * 装修（清水/简装/中装/精装/豪装）
	 */
	@Column(name="housezx")
	private String houseDecoration;

	/**
	 * 套内面积
	 */
	@Column(name="innerarea")
	private BigDecimal innerArea;

	/**
	 * 默认1
	 */
	@Column(name="isdis")
	private Integer isDis;

	/**
	 * 是否是热盘（推荐盘）--只针对新楼盘
	 * 0不是，1是
	 */
	@Column(name="ishot")
	private Integer isHot;

	/**
	 * 是否有钥匙
	 * 默认0没有钥匙，1有
	 */
	@Column(name="iskey")
	private Integer isKey;

	/**
	 * 是否有首勘
	 * 默认0是没有首勘，1有
	 */
	@Column(name="issk")
	private Integer isFirstProspect;

	/**
	 * 默认0 
	 * 1 已委托
	 */
	@Column(name="iswt")
	private Integer isDepute;

	/**
	 * 土地性质
	 */
	@Column(name="landtype")
	private String landType;

	/**
	 * 最后更新时间
	 */
	@Column(name="lastdate")
	private String lastUpdateTime;

	/**
	 * 楼层
	 */
	@Column(name="lcname")
	private Integer floorNum;

	/**
	 * 查看业主次数
	 * 当天被看次数
	 */
	@Column(name="lcount")
	private Integer checkOwnerCount;

	/**
	 * PC端查看业主次数
	 */
	@Column(name="lcountpc")
	private Integer checkOwnerCountPc;

	/**
	 * 查看业主时间
	 * 当天时间
	 */
	@Column(name="ltime")
	private String checkOwnerTime;

	/**
	 * 备注
	 */
	@Column(name="memo")
	private String houseMark;

	@Column(name="moveto")
	private String moveTo;

	//TOOD
	@Column(name="orderclick")
	private Integer orderClick;

	/**
	 * 带看次数
	 */
	@Column(name="orderdk")
	private Integer watchCount;

	/**
	 * 勘察次数
	 */
	@Column(name="orderkc")
	private Integer prospectCount;

	@Column(name="ordertotal")
	private BigDecimal orderTotal;

	/**
	 * 业主名称
	 */
	@Column(name="ownername")
	private String ownerName;

	/**
	 * 付佣
	 */
	@Column(name="ownerpay")
	private String ownerPay;

	/**
	 * 电话1
	 */
	@Column(name="ownertel1")
	private String ownerTel1;

	/**
	 * 电话2
	 */
	@Column(name="ownertel2")
	private String ownerTel2;

	/**
	 * 付款方式
	 */
	@Column(name="paytype")
	private String payType;

	/**
	 * 房源照片
	 * 默认40个0
	 */
	@Column(name="picmore")
	private String housePic;

	/**
	 * 流程路径名称
	 * 1个空格
	 */
	@Column(name="procename")
	private String processName;

	/**
	 * 流程路径ID 0
	 */
	@Column(name="procepathid")
	private Integer processPathId;

	/**
	 * 流程状态
	 * 1个空格
	 */
	@Column(name="processstatu")
	private String processStatus;
	
	/**
	 * 同业主关系
	 */
	@Column(name="relation")
	private String relativeRelationship;

	/**
	 * 租赁-付款方式
	 */
	@Column(name="rentpaytype")
	private String rentPayType;

	/**
	 * 租赁-押金
	 */
	@Column(name="rentyj")
	private String rentSecurityPay;

	/**
	 * 租赁-最长租期
	 */
	@Column(name="rentzczq")
	private String rentLongestPeriod;

	/**
	 * 租赁-最短租期
	 */
	@Column(name="rentzdzq")
	private String rentLowestPeriod;

	/**
	 * 非住宅类型属性
	 */
	@Column(name="s1")
	private String nonHouseProp1;
	/**
	 * 非住宅类型属性
	 */
	@Column(name="s2")
	private String nonHouseProp2;

	/**
	 * 非住宅类型属性
	 */
	@Column(name="s3")
	private String nonHouseProp3;

	/**
	 * 非住宅类型属性
	 */
	@Column(name="s4")
	private String nonHouseProp4;

	/**
	 * 售单价
	 */
	@Column(name="saleprice")
	private BigDecimal salePrice;

	/**
	 * 售价
	 */
	@Column(name="saletotal")
	private BigDecimal saleTotal;

	/**
	 * 首付
	 */
	@Column(name="sf")
	private BigDecimal firstPay;

	/**
	 * 首勘照片完善时间
	 */
	@Column(name="skupdtime")
	private String prospectUpdateTime;

	/**
	 * 抢到首勘人ID
	 * 默认0
	 */
	@Column(name="skuserid")
	private Integer firstRobberId;

	/**
	 * 是否提交首勘
	 * 默认0未提交，1提交
	 */
	@Column(name="skuserover")
	private Integer isSubmitFirst;

	/**
	 * 抢到首勘时间
	 */
	@Column(name="skusertime")
	private String firstRobberTime;
	
	/**
	 * 审批人ID
	 */
	@Column(name="sprid")
	private Integer approverId;

	/**
	 * 审批人  
	 */
	@Column(name="sprname")
	private String approverName;

	/**
	 * 楼盘状态（未审批/已审批）
	 */
	@Column(name="statu")
	private String buildStatus;

	/**
	 * 总层数
	 */
	@Column(name="streettop")
	private Integer totalFloorNum;

	/***
	 * 归属时间
	 */
	@Column(name="time1")
	private String belongTime1;

	/***
	 * 归属时间
	 */
	@Column(name="time2")
	private String belongTime2;

	/***
	 * 归属时间
	 */
	@Column(name="time3")
	private String belongTime3;

	/***
	 * 归属时间
	 */
	@Column(name="time4")
	private String belongTime4;

	/***
	 * 归属时间
	 */
	@Column(name="time5")
	private String belongTime5;

	/***
	 * 归属时间
	 */
	@Column(name="time6")
	private String belongTime6;

	/***
	 * 归属时间
	 */
	@Column(name="time7")
	private String belongTime7;

	/**
	 * 厅
	 */
	@Column(name="ting")
	private Integer livingRoomNum;

	/**
	 * 格式：yyyy-mm-dd hh:mm:ss
	 * 归属变更时间
	 */
	@Column(name="updtime")
	private String lastBelongTime;

	/**
	 * 卫
	 */
	@Column(name="wei")
	private Integer washRoomNum;

	/**
	 * 物业费
	 */
	@Column(name="wgf")
	private String houseManageFee;

	/**
	 * 房源和委托表的对照关系
	 */
	@Column(name="wtid")
	private Integer deputeId;

	/***
	 * 委托类型
	 */
	@Column(name="wttype")
	private String deputeStyle;

	/**
	 * 阳台
	 */
	@Column(name="yangtai")
	private Integer balconyNum;

	/**
	 * 月供
	 */
	@Column(name="yg")
	private BigDecimal monthPay;

	/**
	 * 租单间
	 */
	@Column(name="zuprice")
	private BigDecimal rentSinglePrice;

	/**
	 * 租价
	 */
	@Column(name="zutotal")
	private BigDecimal rentPrice;
	
}