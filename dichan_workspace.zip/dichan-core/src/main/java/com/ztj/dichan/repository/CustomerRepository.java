package com.ztj.dichan.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.Building;
import com.ztj.dichan.entity.Customer;
import com.ztj.dichan.vo.CustomerSubDetailVo;
import com.ztj.dichan.vo.ReportDetailParams;
import com.ztj.dichan.vo.ReservationSubDetailVo;


@Repository
public interface CustomerRepository extends PagingAndSortingRepository<Customer, Long>{
	
	@Query(" select c from Customer c where c.customerNo in ?1 ")
	List<Customer> customerListByNo(List<String> customerNos);

	Customer findByCustomerNo(String customerNo);
	
	/**
	 * 模糊查询客户信息
	 */
	 @Query(value="select Top 100 * from Customer a where a.CustomerName like CONCAT('%',:keyName,'%') or a.CustomerTel1 like CONCAT('%',:keyName,'%') ",nativeQuery=true)
	List<Customer> likeByName(@Param("keyName") String keyName);
	 
	 
	List<Customer> findByCustomerName(String customerName);
	List<Customer> findByCustomerTel1(String customerTel1);
	

	@Query("select u from Customer u where u.customerNo in ?1 ")
	List<Customer> findByCustomerNos(List<String> nos);
	
	
	/**
	 * 查询客源报表
	 * 当前库存客源/新增客源
	 */
	public List<CustomerSubDetailVo> findCustTotalAndNewNum(ReportDetailParams reportDetailParams,Pageable pageable);
	
	/**
	 * 查询客源报表
	 * 公客/私客
	 */
	public List<CustomerSubDetailVo> findCustDPNum(ReportDetailParams reportDetailParams,Pageable pageable,String custType);
	
	
	/**
	 * 查询客源报表
	 * 无效
	 */
	public List<CustomerSubDetailVo> findCustInvalidNum(ReportDetailParams reportDetailParams,Pageable pageable);
	
	/**
	 * 查询订房报表
	 * 当前库存客源的数量/新增客源的数量
	 */
	public Integer findCustTotalAndNewNumRow(ReportDetailParams reportDetailParams);
	
	
	/**
	 * 查询订房报表
	 * 公客的数量/私客的数量
	 */
	public Integer findCustDPNumRow(ReportDetailParams reportDetailParams,String custType);
	
	
	/**
	 * 查询订房报表
	 * 无效客源的数量
	 */
	public Integer findCustInvalidNumRow(ReportDetailParams reportDetailParams);
	
	
}
