package com.ztj.dichan.repository;




import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.ztj.dichan.entity.CustWatch;
import com.ztj.dichan.enums.DealTypeEnum;



public interface CustWatchRepository extends PagingAndSortingRepository<CustWatch, Long> , JpaSpecificationExecutor<CustWatch> {
	


	List<CustWatch> findByCustomerNoAndEmplIdAndDealType(String customerNo,Long emplId,DealTypeEnum dealType,Sort sort);
	
	List<CustWatch> findByCustomerNoAndDealType(String customerNo,DealTypeEnum dealType,Sort sort);
}
