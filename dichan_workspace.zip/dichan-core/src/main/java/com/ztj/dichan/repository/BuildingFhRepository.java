package com.ztj.dichan.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.BuildingFh;

@Repository
public interface BuildingFhRepository extends PagingAndSortingRepository<BuildingFh,Integer>{

}
