package com.ztj.dichan.repository.building.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.ztj.common.util.Verify;
import com.ztj.dichan.entity.Building;

/**
 *根据城市/区域/关键字获取楼盘字典表
 * @return
 */
@Repository
public class BuildingRepositoryImpl {
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@PersistenceContext
	private EntityManager em;
	
	List<Building> queryBuildingPage(String scity,String serachMsg,Pageable pageable){
		try {
			Map<String, Object> params=new HashMap<>();
			List<Building> buildings = new ArrayList<>();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT top (:top) * FROM( ");
			sql.append("SELECT  ROW_NUMBER() OVER (");
			if(pageable.getSort()!=null) {
				pageable.getSort().forEach(s->{
					String orderBy=s.getProperty();
					sql.append("order by o.");
					if(orderBy.equals("isNew"))
						orderBy="isNewEmp";
					else if(orderBy.equals("isCurrentDimission"))
						orderBy="dimissionDate";
					sql.append(orderBy+" ");
					sql.append(s.getDirection());
				});
			}else {
				sql.append(" ORDER BY o.id DESC ");
			}
			sql.append(") AS rownum, * from ( ");
			sql.append("select buildid as id,adreess1 as adreessOfficial,buildname as buildName,creater as createName,createtime as createTime,districtid as districtID, ");
			sql.append("districtname as districtName,landuse as landUse,areaid as areaID,areaname as areaName,buildage as buildAge, allbuilds as totalBuildNum, ");
			sql.append("statu as buildStatus ");
			sql.append(" from building where scity = :scity ");
			
			if(!Verify.isBlank(serachMsg)) {
				sql.append(" and (districtname like :serachMsg or areaname like :serachMsg or buildname like :serachMsg or adreess1 like :serachMsg ) ");
				params.put("serachMsg", "%"+serachMsg+"%");
			}
			
			sql.append(") as o ) A WHERE rownum >:rownum ");
			
			Query query = em.createNativeQuery(sql.toString());
			params.put("top",pageable.getPageSize());
			params.put("scity",scity);
			params.put("rownum",pageable.getPageSize()*pageable.getPageNumber());
			
			for (String param : params.keySet()) {
				query.setParameter(param, params.get(param));
			}
			query.unwrap(SQLQuery.class)
			.addScalar("id", IntegerType.INSTANCE).addScalar("adreessOfficial", StringType.INSTANCE)
			.addScalar("districtID", IntegerType.INSTANCE).addScalar("districtName", StringType.INSTANCE)
			.addScalar("buildAge", StringType.INSTANCE).addScalar("createName", StringType.INSTANCE)		
			.addScalar("buildName", StringType.INSTANCE).addScalar("buildStatus", StringType.INSTANCE)
			.addScalar("areaID", IntegerType.INSTANCE).addScalar("areaName", StringType.INSTANCE)
			.addScalar("createTime", StringType.INSTANCE).addScalar("landUse", StringType.INSTANCE)
			.addScalar("totalBuildNum", IntegerType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(Building.class));
			buildings = query.getResultList();
			return buildings;
		} catch (Exception e) {
			logger.debug("分页查询楼盘字典异常！");
		}
		return null;
	}
	
	public Integer buildingTotalRecords(String scity,String serachMsg) {

		StringBuffer sb = new StringBuffer();
		sb.append("select count(buildid) from building where scity=:scity ");
		Map<String, Object> params = new HashMap<>();
		params.put("scity", scity);
		if (!Verify.isBlank(serachMsg)) {
			sb.append(" and (districtname like :serachMsg or areaname like :serachMsg or buildname like :serachMsg or adreess1 like :serachMsg ) ");
			params.put("serachMsg", "%"+serachMsg+"%");
		}
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		return (Integer) query.getSingleResult();

	}
}
