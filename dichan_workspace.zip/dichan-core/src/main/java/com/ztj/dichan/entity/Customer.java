package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;


/**
 * 客户信息表
 */
@Entity
@Table(name="Customer")
@Data
@EqualsAndHashCode(callSuper = true)
public class Customer extends ShardingEntity {
	private static final long serialVersionUID = 1L;
	

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="customerid")
	private Integer id;

	/**
	 * 住址
	 */
	@Column(name="addr")
	private String address;

	/**
	 * 关联区域
	 */
	@Column(name="areaname")
	private String relAreaName;

	/**
	 * 归属原因 
	 */
	@Column(name="belongreason1")
	private String belongReason1;

	/**
	 * 归属原因2
	 */
	@Column(name="belongreason2")
	private String belongReason2;

	/**
	 * 归属原因3
	 */
	@Column(name="belongreason3")
	private String belongReason3;

	/**
	 * 生日
	 */
	@Column(name="birth")
	private String birthdayDate;

	/**
	 * 楼盘id
	 */
	@Column(name="buildid")
	private Integer buildID;

	/**
	 * 关联楼盘
	 */
	@Column(name="buildname")
	private String buildName;

	/**
	 * 客源类型
	 * 新房，二手房，商业
	 */
	@Column(name="cclass")
	private String custFeature;

	/**
	 * 创建人
	 */
	@Column(name="creater")
	private String createName;

	@Column(name="CreaterID")
	private Integer createID;

	/**
	 * 创建时间
	 */
	@Column(name="createtime")
	private String createTime;

	/**
	 * 客源特性
	 * 0普通客，1优质客，2刚需客
	 */
	@Column(name="customercharacter")
	private String custCharacter;

	/**
	 * 客户姓名
	 */
	@Column(name="customername")
	private String customerName;

	/**
	 * 客源（委托）编号
	 * 默认店名+5位数字
	 */
	@Column(name="customerno")
	private String customerNo;

	/**
	 * 性别
	 */
	@Column(name="customersex")
	private String customerSex;

	/**
	 * 客源状态
	 * 0有效，1暂缓，2已购，3已租，4我购，5我租，6待审，7未知
	 */
	@Column(name="customerstatu")
	private String custStatus;

	/**
	 * 客户电话1
	 */
	@Column(name="customertel1")
	private String customerTel1;

	/**
	 * 客户电话2
	 */
	@Column(name="customertel2")
	private String customerTel2;

	/**
	 * 客源分类
	 * 0公客，1私客
	 */
	@Column(name="customertype")
	private String custType;
	
	/**
	 * 客源来源
	 */
	@Column(name="custsoucre")
	private String custSource;
	
	/**
	 * 交易类型
	 */
	@Column(name="dealtype")
	private String dealType;

	/**
	 * 
	 */
	@Column(name="deptid1")
	private Integer deptId1;

	@Column(name="deptid2")
	private Integer deptId2;

	@Column(name="deptid3")
	private Integer deptId3;

	@Column(name="deptname1")
	private String deptName1;

	@Column(name="deptname2")
	private String deptName2;

	@Column(name="deptname3")
	private String deptName3;

	/**
	 * 委托日期
	 */
	@Column(name="depudate")
	private String deputeDate;

	/**
	 * 片区
	 */
	@Column(name="districtname")
	private String districtName;

	/**
	 * 
	 */
	@Column(name="emplid1")
	private Integer emplId1;

	@Column(name="emplid2")
	private Integer emplId2;

	@Column(name="emplid3")
	private Integer emplId3;

	/**
	 * 归属人1
	 */
	@Column(name="emplname1")
	private String emplName1;

	@Column(name="emplname2")
	private String emplName2;

	@Column(name="emplname3")
	private String emplName3;

	/**
	 * 几房
	 */
	@Column(name = "fang")
	private Integer roomNum;

	/**
	 * 0不隐藏，1隐藏
	 * 是否隐藏，默认值0
	 */
	@Column(name="hide")
	private Integer isHide;

	/**
	 * 最高楼层
	 */
	@Column(name="highestfloor")
	private Integer highestFloor;

	/**
	 * 意向最高价格
	 */
	@Column(name="highestprice")
	private BigDecimal highestPrice;

	/**
	 * 朝向
	 */
	@Column(name="housecx")
	private String houseDirection;

	/**
	 * 意向房屋属性
	 * 0小区房，1电梯房，2花园洋房，3单梯房
	 */
	@Column(name="houseproperty")
	private String houseLikeProp;

	/**
	 * 需求类别
	 * 0住宅，1商铺，2商住，3写字楼，4仓库，5厂房，6车位，7地下室，8别墅，9其它
	 */
	@Column(name="housetype")
	private String houseReqType;

	/**
	 * 意向装修
	 * 清水，简装，中装，精装，豪装
	 */
	@Column(name="housezx")
	private String houseLikeDeco;

	/**
	 * 身份证号码
	 */
	@Column(name="idno")
	private String idNo;

	/**
	 * 0非，1是
	 * 非一层
	 */
	@Column(name="isfoot")
	private Integer isFirstFloor;

	/**
	 * 0非，1是
	 * 非顶层
	 */
	@Column(name="istop")
	private Integer isTopFloor;

	/**
	 * 最新跟进日期（最新更新日期）
	 */
	@Column(name="lastdate")
	private String lastUpdateTime;

	/**
	 * 查看业主次数
	 */
	@Column(name="lcount")
	private Integer checkOwnerCount;

	/**
	 * PC端查看业主次数
	 */
	@Column(name="lcountpc")
	private Integer checkOwnerCountPc;

	/**
	 * 最低楼层
	 */
	@Column(name="leastfloor")
	private Integer lowestFloor;

	/**
	 * 意向最低价格
	 */
	@Column(name="leastprice")
	private BigDecimal lowestPrice;

	/**
	 * 看房时间
	 * 随时，预约，上午，下午，周末，节假日，工作日
	 */
	@Column(name="looktime")
	private String watchTime;

	/**
	 * 查看业主时间
	 */
	@Column(name="ltime")
	private String checkOwnerTime;

	/**
	 * 意向最大面积
	 */
	@Column(name="maxacreage")
	private BigDecimal highestArea;

	/**
	 * 备注
	 */
	@Column(name="memo")
	private String houseMark;

	/**
	 * 意向最低面积
	 */
	@Column(name="minacreage")
	private BigDecimal lowestArea;

	/**
	 * 
	 */
	@Column(name="moveto")
	private String moveTo;

	@Column(name="ordertime")
	private String orderTime;

	/**
	 * 付款方式
	 */
	@Column(name="paytype")
	private String payType;

	/**
	 * 流程路径名称
	 */
	@Column(name="procename")
	private String processName;

	/**
	 * 流程路径id
	 */
	@Column(name="procepathid")
	private Integer processPathId;

	/**
	 * 流程状态
	 */
	@Column(name="processstatu")
	private String processStatus;

	/**
	 * qq号
	 */
	@Column(name="qq")
	private String qqNo;

	/**
	 * 付款方式（求租）
	 * 月付，季付，半年付，年付，不限
	 */
	@Column(name="rentpaytype")
	private String rentPayType;
	
	/**
	 * 审批人ID
	 */
	@Column(name="sprid")
	private Integer approverId;

	/**
	 * 审批人
	 */
	@Column(name="sprname")
	private String approverName;

	/**
	 * 归属时间1
	 */
	@Column(name="time1")
	private String belongTime1;


	/**
	 * 归属时间2
	 */
	@Column(name="time2")
	private String belongTime2;

	/**
	 * 归属时间3
	 */
	@Column(name="time3")
	private String belongTime3;

	/**
	 * 归属变更时间
	 */
	@Column(name="updtime")
	private String lastBelongTime;

	/**
	 * 职业
	 */
	@Column(name="vocation")
	private String vocation;

}