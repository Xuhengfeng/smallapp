package com.ztj.dichan.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 员工管辖部门
 */
@Data
@Table(name="empldept")
@Entity
@EqualsAndHashCode(callSuper = true)
public class EmplDept extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="empldeptid")
	private Integer id;

	@Column(name="creater")
	private String creater;

	@Column(name="createtime")
	private String createTime;

	@Column(name="deptid")
	private Integer deptId;

	@Column(name="emplid")
	private Integer emplId;
}