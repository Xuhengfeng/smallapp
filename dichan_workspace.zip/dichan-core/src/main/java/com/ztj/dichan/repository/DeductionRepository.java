package com.ztj.dichan.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.DeductionEntity;

@Repository
public interface DeductionRepository extends PagingAndSortingRepository<DeductionEntity, Integer>{
	

}
