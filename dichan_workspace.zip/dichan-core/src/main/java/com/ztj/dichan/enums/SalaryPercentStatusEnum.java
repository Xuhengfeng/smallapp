package com.ztj.dichan.enums;

import java.io.Serializable;

/**
 * 工资提成信息状态
 * 
 * @author test01
 */
public enum SalaryPercentStatusEnum implements Serializable{
	ALL("all", "所有状态", ""),
	NEW("ics_new", "未提交", ""),
    SUBMIT("ics_submit", "提交", ""),
    CONFIRM("ics_confirm", "确认", ""),
    REJECT("ics_reject","拒绝",""),
    CANCEL("ics_cancel", "取消确认", "");

    private String code;

    private String name;
    
    private String desc;

    private SalaryPercentStatusEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}


}
