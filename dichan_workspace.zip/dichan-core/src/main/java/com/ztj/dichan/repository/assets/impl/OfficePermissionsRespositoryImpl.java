package com.ztj.dichan.repository.assets.impl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LocalDateTimeType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.assets.EmplOffice;

/**
 *根据办公室Id分页查询
 * @return
 */
@Repository
public class OfficePermissionsRespositoryImpl {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@PersistenceContext
	private EntityManager em;
	
	List<EmplOffice> queryEmplOfficeList(String scity,Integer officeId,Pageable pageable){
		try {
			Map<String, Object> params=new HashMap<>();
			List<EmplOffice> emplOffices = new ArrayList<>();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT top (:top) * FROM( ");
			sql.append("SELECT  ROW_NUMBER() OVER (");
			if(pageable.getSort()!=null) {
				pageable.getSort().forEach(s->{
					String orderBy=s.getProperty();
					sql.append("order by o.");
					if(orderBy.equals("isNew"))
						orderBy="isNewEmp";
					else if(orderBy.equals("isCurrentDimission"))
						orderBy="dimissionDate";
					sql.append(orderBy+" ");
					sql.append(s.getDirection());
				});
			}else {
				sql.append(" ORDER BY o.id DESC ");
			}
			sql.append(") AS rownum, * from ( ");
			sql.append("select s.emp_office_id as id,s.empl_id as emplID,f.EmplName as lastUpdateName,e.EmplName as emplName,e.Emplacco as emplAccNo,d.deptName as deptName,s.office_id as officeId,s.last_update_id as lastUpdateId,s.last_update_time as lastUpdateTime ");
			sql.append(" from empl_office s LEFT JOIN Employee e ON e.EmplID = s.empl_id ");
			sql.append(" LEFT JOIN Employee f ON f.EmplID = s.last_update_id");
			sql.append(" LEFT JOIN Department d ON d.DeptID = e.deptId");
			sql.append(" where s.office_id = :officeId ");
			sql.append(") as o ) A WHERE rownum >:rownum ");
			
			Query query = em.createNativeQuery(sql.toString());
			params.put("officeId",officeId);
			params.put("top",pageable.getPageSize());
			params.put("rownum",pageable.getPageSize()*pageable.getPageNumber());
			
			for (String param : params.keySet()) {
				query.setParameter(param, params.get(param));
			}
			query.unwrap(SQLQuery.class)
			.addScalar("id", IntegerType.INSTANCE)
			.addScalar("emplID", IntegerType.INSTANCE)
			.addScalar("officeId", IntegerType.INSTANCE)
			.addScalar("lastUpdateId", IntegerType.INSTANCE)
			.addScalar("lastUpdateTime", LocalDateTimeType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(EmplOffice.class));
			emplOffices = query.getResultList();
			return emplOffices;
		} catch (Exception e) {
			logger.debug("分页查询资产管理员工列表异常！");
		}
		return null;
	}
	
	public Integer emplTotalRecords(String scity,Integer officeId) {

		StringBuffer sb = new StringBuffer();
		sb.append("select count(emp_office_id) from empl_office where office_id = :officeId ");
		Map<String, Object> params = new HashMap<>();
		params.put("officeId", officeId);
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		return (Integer) query.getSingleResult();

	}
}
