
/**
* @Title: FinEmployeeStatusEnum.java
* @Package com.ztj.dichan.enums.finance
* @Description: TODO 
* @author zuohuan
* @date 2018年7月18日
* @version V1.0
**/
package com.ztj.dichan.enums.finance;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import com.ztj.dichan.enums.AssetRequestParamEnum;

/**
* @ClassName: FinEmployeeStatusEnum
* @Description: TODO 
* @author zuohuan
* @date 2018年7月18日
*
**/
public enum FinEmployeeStatusEnum implements Serializable{
	ALL("all", "全部", ""),
	VALID("valid", "有效的", ""),
    FORBIDDEN("forbidden", "失效的", "");

    private String code;

    private String name;
    
    private String desc;

    private FinEmployeeStatusEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}

	public static FinEmployeeStatusEnum queryEnumByName(String name) {
		List<FinEmployeeStatusEnum> finEmployeeStatusEnums=Arrays.asList(FinEmployeeStatusEnum.values());
		for (FinEmployeeStatusEnum finEmployeeStatusEnum : finEmployeeStatusEnums) {
			if(name.equals(finEmployeeStatusEnum.getName())) 
				return finEmployeeStatusEnum;
		}
		return null;
	}
}
