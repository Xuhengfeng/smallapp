package com.ztj.dichan.enums;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * 用户佣金信息状态
 * 
 * @author test01
 */
public enum IncomeContractStatusEnum implements Serializable{
	ALL("all", "所有状态", ""),
	NEW("ics_new", "未提交", ""),
    SUBMIT("ics_submit", "提交", ""),
    CONFIRM("ics_confirm", "确认", ""),
    REJECT("ics_reject", "拒绝", ""),
    RECALCULATE("ics_recalculate", "重新计算", ""),
    DELETE("ics_delete", "无效", ""),
    WRONG("ics_wrong", "错误", ""),
    CANCEL_SUBMIT("ics_cancel_submit", "取消提交", ""),
    CANCEL_CONFIRM("ics_cancel_confirm", "取消确认", "");

    private String code;

    private String name;
    
    private String desc;

    private IncomeContractStatusEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}

	public static IncomeContractStatusEnum queryEnumByName(String name) {
		List<IncomeContractStatusEnum> incomeContractStatusEnums=Arrays.asList(IncomeContractStatusEnum.values());
		for (IncomeContractStatusEnum incomeContractStatusEnum : incomeContractStatusEnums) {
			if(name.equals(incomeContractStatusEnum.getName())) 
				return incomeContractStatusEnum;
		}
		return null;
	}

}
