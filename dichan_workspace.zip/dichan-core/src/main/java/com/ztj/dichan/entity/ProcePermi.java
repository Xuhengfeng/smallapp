package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 流程岗位表
 * 
 */
@Entity
@Table(name="procepermi")
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="ProcePermi.findAll", query="SELECT p FROM ProcePermi p")
public class ProcePermi extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ppid")
	private Integer id;

	@Column(name="creater")
	private String createId;

	@Column(name="createtime")
	private String createTime;

	@Column(name="positiid")
	private Integer positionId;

	/**
	 * 流程id
	 */
	@Column(name="proceid")
	private Integer proceId;

}