package com.ztj.dichan.entity;

import java.security.Principal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Cleanup;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@Table(name = "Net_Cost_detail")
@EqualsAndHashCode(callSuper=true)
public class DeductionEntity extends ShardingEntity {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4354040825007101210L;

	/**
	 * 网络消费字表主键Id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="Net_Cost_detail_id")
	private int Net_Cost_detail_id;
	
	/**
	 * 网络端口Id
	 */
	@Column(name = "Net_Cost_id")
	private int Net_Cost_id;
	
	/**
	 * 组别ID
	 */
	@Column(name = "group_id")
	private int group_id;
	
	/**
	 * 门店ID
	 */
	@Column(name = "shop_id")
	private int shop_id;
	
	
	/**
	 * 区域id
	 */
	@Column(name= "area_id")
	private int area_id;
	
	/**
	 * 大区ID
	 */
	@Column(name = "big_area_id")
	private int big_area_id;
	
	/**
	 * 扣费月份
	 */
	@Column(name = "cost_month")
	private String cost_month;
	
	/**
	 * 扣费开始时间
	 */
	@Column(name = "cost_start_date")
	private String cost_start_date;
	
	/**
	 * 扣费结束时间
	 */
	@Column(name = "cost_end_date")
	private String cost_end_date;
	
	/**
	 * 上月结余
	 */
	@Column(name = "last_remain_money")
	private Double last_remain_money;
	
	/**
	 * 本月扣除
	 */
	@Column(name = "this_cost_money")
	private Double this_cost_money;
	
	/**
	 *本月结余
	 */
	@Column(name = "this_remain_money")
	private Double this_remain_money;
	
	/**
	 * 公司报销
	 */
	@Column(name = "this_cost_company")
	private Double this_cost_company;
	
	/**
	 * 修改时间
	 */
	private LocalDateTime modifyTime=LocalDateTime.now();
}
