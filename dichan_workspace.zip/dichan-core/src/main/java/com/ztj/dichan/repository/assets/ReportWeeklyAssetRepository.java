package com.ztj.dichan.repository.assets;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.assets.ReportWeeklyAsset;
import com.ztj.dichan.vo.asset.ReportWeeklyAssetVo;
import com.ztj.dichan.vo.request.asset.ReportWeeklyAssetRequest;

@Repository
public interface ReportWeeklyAssetRepository extends PagingAndSortingRepository<ReportWeeklyAsset,Integer>{

	Integer reportAssetTotalRecords(ReportWeeklyAssetRequest reportWeeklyAssetRequest);

	List<ReportWeeklyAssetVo> assetPage(ReportWeeklyAssetRequest reportWeeklyAssetRequest, Pageable pageable);

	@Modifying
    @Query(value="delete from report_weekly_asset where office_id in(?1) and city_name=?2",nativeQuery=true)
	void deleteByOfficeIdsAndScity(List<String> officeIds, String scity);

}
