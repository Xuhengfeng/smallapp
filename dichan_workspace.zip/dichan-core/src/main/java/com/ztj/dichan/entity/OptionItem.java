package com.ztj.dichan.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * 输入选项明细
 * @author admin
 *
 */

@Data
@Entity
@Table(name ="optionitem")
@EqualsAndHashCode(callSuper = true)
public class OptionItem extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="optionitemid")
	private Integer id;

	/**
	 * 是否可以修改
	 */
	private String canModify;

	
	@Column(name="creater")
	private String creater;

	@Column(name="createtime")
	private String createTime;

	/**
	 * 栏目内容
	 */
	@Column(name="item")
	private String item;

	/**
	 * 选项id
	 */
	@Column(name="optionid")
	private Integer optionId;

	/**
	 * 说明
	 */
	private String remark;

	/**
	 * 显示序号
	 */
	@Column(name="xh")
	private Integer showOrder;

}