package com.ztj.dichan.enums;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * 店面报表类型
 * 
 * @author test01
 */
public enum AssetRequestParamEnum implements Serializable{
	
	TOTAL_ASSET("total_asset", "总店面", ""),
    NEW_ASSET("new_asset", "新增店面", "");

    private String code;

    private String name;
    
    private String desc;

    private AssetRequestParamEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}

	public static AssetRequestParamEnum queryEnumByName(String name) {
		List<AssetRequestParamEnum> assetRequestParamEnums=Arrays.asList(AssetRequestParamEnum.values());
		for (AssetRequestParamEnum assetRequestParamEnum : assetRequestParamEnums) {
			if(name.equals(assetRequestParamEnum.getName())) 
				return assetRequestParamEnum;
		}
		return null;
	}

}
