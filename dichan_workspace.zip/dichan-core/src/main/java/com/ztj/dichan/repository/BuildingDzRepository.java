package com.ztj.dichan.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.BuildingDz;

@Repository
public interface BuildingDzRepository extends PagingAndSortingRepository<BuildingDz,Integer>{
	
	/**
	 * 分页查询栋座列表
	 * @param buildId
	 * @param pageable
	 * @return
	 */
	List<BuildingDz> findByBuildId(Integer buildId);

}
