package com.ztj.dichan.repository.approve;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.TysqRelation;

@Repository
public interface TysqRelationRepository extends PagingAndSortingRepository<TysqRelation,Integer>{
		List<TysqRelation> findByTysqaId(Integer tysqAid);
		
		
		@Query(value ="select * from tysq_relation  where ori_req_dtl_id = ?1  and tysqa_id in (?2)",nativeQuery =true)
		List<TysqRelation> searchAprovalVerifyDetails(Integer oriReqDtlId,Integer[] tysqaIds);
		
		
		List<TysqRelation> findByOriReqDtlId(Integer oriReqDtlId);
		
	}
