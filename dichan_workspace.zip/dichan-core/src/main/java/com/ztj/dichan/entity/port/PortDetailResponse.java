package com.ztj.dichan.entity.port;

import java.util.List;

import com.ztj.dichan.vo.PortDetailVo;

import lombok.Data;

@Data
public class PortDetailResponse {

	private String cityName;

	private Integer totalRecords;
	
	private List<PortDetailVo> portDetailVos;
}
