package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 作业类型表
 * 
 */
@Entity
@Table(name="TaskType")
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="TaskType.findAll", query="SELECT t FROM TaskType t")
public class TaskType extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="taskid")
	private Integer id;

	@Column(name="creater")
	private String creater;

	@Column(name="createtime")
	private String createTime;

	/**
	 * 作业附件文件夹名称(ftp)
	 */
	@Column(name="taskftp")
	private String taskFtp;

	/**
	 * 作业名称
	 */
	@Column(name="taskname")
	private String taskName;

	/**
	 * 填报说明
	 */
	@Column(name="tbsm")
	private String taskNote;

	/**
	 * 作业类别
	 */
	@Column(name="ttype")
	private String taskType;

}