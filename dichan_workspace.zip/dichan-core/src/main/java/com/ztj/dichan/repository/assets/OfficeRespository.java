package com.ztj.dichan.repository.assets;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.Employee;
import com.ztj.dichan.entity.assets.Office;
import com.ztj.dichan.entity.assets.RequestOffice;
import com.ztj.dichan.vo.asset.OfficeDetailVo;
import com.ztj.dichan.vo.asset.TotalOfficeVo;
import com.ztj.dichan.vo.city.GroupVo;
import com.ztj.dichan.vo.request.asset.OfficeInfoRequest;

@Repository
public interface OfficeRespository extends PagingAndSortingRepository<Office, Integer> {

	List<Office> queryOfficeListPage(String scity, Pageable pageable, RequestOffice requestOffice);

	Integer officeTotalRecords(String scity, RequestOffice requestOffice);

	List<Office> findByOfficeName(String officeName);

	Integer officeInfoTotalRecords(OfficeInfoRequest officeInfoRequest);

	List<OfficeDetailVo> officeInfo(OfficeInfoRequest officeInfoRequest, Pageable pageable);

	TotalOfficeVo totalOffice(OfficeInfoRequest officeInfoRequest);
	
    @Query(value="select * from office where end_date >= ?1",nativeQuery=true)
	List<Office> findByExpireType(String date);
   
   
   List<GroupVo> getOfficeListByType(Employee user,String type);
}
