package com.ztj.dichan.config;

import ch.qos.logback.core.rolling.FixedWindowRollingPolicy;

/**
 * logback默认生成的最大文件数量为20,这里进行相应的修改
 * 
 * @author test01
 */
public class CustomFixedWindowRollingPolicy extends FixedWindowRollingPolicy {
	private static int MAX_WINDOW_SIZE = 100000;

	@Override
	protected int getMaxWindowSize() {
		return MAX_WINDOW_SIZE;
	}
}
