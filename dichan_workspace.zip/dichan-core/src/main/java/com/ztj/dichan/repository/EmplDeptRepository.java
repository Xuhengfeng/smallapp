package com.ztj.dichan.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.Department;
import com.ztj.dichan.entity.EmplDept;

@Repository
public interface EmplDeptRepository extends PagingAndSortingRepository<EmplDept, Integer>{
	
	@Query("select d.deptName from EmplDept eml,Department d where eml.deptId=d.id and eml.emplId =?1 and d.deptLevel ='组别'")
	List<String> getShopListByEmpl(Integer emplId);
	
	@Query("select d.deptName from EmplDept eml,Department d where eml.deptId=d.id and eml.emplId =?1 and  d.deptLevel='门店'")
	List<String> getShopListByEmpl2(Integer emplId);
	
	@Query("select DISTINCT d.deptName from EmplDept eml,Department d,Department d2 where eml.deptId=d.id and eml.emplId =?1 and d.deptLevel ='组别' and d.isBizTeam='Y'  and d2.id = d.parentId and d2.deptLevel ='门店'")
	List<String> getGroupListByEmpl(Integer emplId);
	
	
	List<Department> queryAuthDept(Integer emplId);
	
	
}
