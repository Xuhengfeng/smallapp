package com.ztj.dichan.repository.assets.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.ztj.common.util.DateUtil;
import com.ztj.common.util.Verify;
import com.ztj.dichan.entity.assets.Asset;
import com.ztj.dichan.enums.OfficeStatusEnum;
import com.ztj.dichan.vo.asset.AssetDetailVo;
import com.ztj.dichan.vo.asset.OfficeDetailVo;
import com.ztj.dichan.vo.asset.TotalAssetVo;
import com.ztj.dichan.vo.asset.TotalOfficeVo;
import com.ztj.dichan.vo.request.asset.OfficeInfoRequest;

/**
 *分页查询办公室列表
 * @return
 */
@Repository
public class AssetRespositoryImpl {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@PersistenceContext
	private EntityManager em;
	
	List<Asset> queryAssetListPage(String scity, Asset asset,Pageable pageable){
		try {
			Map<String, Object> params=new HashMap<>();
			List<Asset> assets = new ArrayList<>();
			StringBuilder sql = new StringBuilder();
			sql.append("SELECT top (:top) * FROM( ");
			sql.append("SELECT  ROW_NUMBER() OVER (");
			if(pageable.getSort()!=null) {
				pageable.getSort().forEach(s->{
					String orderBy=s.getProperty();
					sql.append("order by o.");
					if(orderBy.equals("isNew"))
						orderBy="isNewEmp";
					else if(orderBy.equals("isCurrentDimission"))
						orderBy="dimissionDate";
					sql.append(orderBy+" ");
					sql.append(s.getDirection());
				});
			}else {
				sql.append(" ORDER BY o.id DESC ");
			}
			sql.append(") AS rownum, * from ( ");
			sql.append("select asset_id as id,office_id as officeId,asset_type_id as assetTypeId, ");
			sql.append("asset_no as assetNo,asset_unit as assetUnit,asset_price as assetPrice,brand_name as brandName,asset_name_id as assetNameId, ");
			sql.append("goods_type as goodsType,factory_name as factoryName, goods_manu_date as goodsManuDate,asset_from_id as assetFromId, ");
			sql.append("goods_color as goodsColor,asset_status_id as assetStatusId, ");
			sql.append("setup_position as setupPosition,receipt_no as receiptNo,dept_name as deptName ");
			sql.append(" from asset where office_id = :officeId");
			if (StringUtils.isNotEmpty(asset.getAssetNo())) {
				sql.append(" and asset_no like '%"+asset.getAssetNo()+"%'");
			}
			if (asset.getAssetTypeId() != null) {
				sql.append(" and asset_type_id = "+asset.getAssetTypeId());
			}
			if (asset.getAssetNameId() != null) {
				sql.append(" and asset_name_id = "+asset.getAssetNameId());
			}
			sql.append(") as o ) A WHERE rownum >:rownum ");
			
			Query query = em.createNativeQuery(sql.toString());
			params.put("top",pageable.getPageSize());
			params.put("officeId",asset.getOfficeId());
			params.put("rownum",pageable.getPageSize()*pageable.getPageNumber());
			
			for (String param : params.keySet()) {
				query.setParameter(param, params.get(param));
			}
			query.unwrap(SQLQuery.class)
			.addScalar("id", IntegerType.INSTANCE)
			.addScalar("officeId", IntegerType.INSTANCE)
			.addScalar("assetNo", StringType.INSTANCE)
			.addScalar("assetUnit", StringType.INSTANCE)
			.addScalar("assetPrice", BigDecimalType.INSTANCE)
			.addScalar("brandName", StringType.INSTANCE)
			.addScalar("goodsType", StringType.INSTANCE)
			.addScalar("factoryName", StringType.INSTANCE)
			.addScalar("goodsColor", StringType.INSTANCE)
			.addScalar("goodsManuDate", StringType.INSTANCE)
			.addScalar("setupPosition", StringType.INSTANCE)
			.addScalar("receiptNo", StringType.INSTANCE)
			.addScalar("deptName", StringType.INSTANCE)
			.addScalar("assetTypeId", IntegerType.INSTANCE)
			.addScalar("assetNameId", IntegerType.INSTANCE)
			.addScalar("assetFromId", IntegerType.INSTANCE)
			.addScalar("assetStatusId", IntegerType.INSTANCE)
			.setResultTransformer(Transformers.aliasToBean(Asset.class));
			assets = query.getResultList();
			return assets;
		} catch (Exception e) {
			logger.debug("分页查询资产明细列表异常！");
		}
		return null;
	}
	
	public Integer assetTotalRecords(String scity, Asset asset) {
		StringBuffer sb = new StringBuffer();
		sb.append("select count(asset_id) from asset where office_id = :officeId ");
		if (StringUtils.isNotEmpty(asset.getAssetNo())) {
			sb.append(" and asset_no = '%"+asset.getAssetNo()+"%'");
		}
		if (asset.getAssetTypeId() != null) {
			sb.append(" and asset_type_id = "+asset.getAssetTypeId());
		}
		if (asset.getAssetNameId() != null) {
			sb.append(" and asset_name_id = "+asset.getAssetNameId());
		}
		Map<String, Object> params = new HashMap<>();
		params.put("officeId", asset.getOfficeId());
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		return (Integer) query.getSingleResult();
	}
	public BigDecimal totalAmount(OfficeInfoRequest officeInfoRequest) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		sb.append("select sum(asset_price) totalAmount from asset a where office_id in (SELECT " + 
				"	o.office_id " + 
				"FROM " + 
				"	office o, " + 
				"	empl_office eo " + 
				"WHERE " + 
				"	o.office_id = eo.office_id " + 
				"AND empl_id = :emplId "
				);
		
		
		params.put("emplId", officeInfoRequest.getEmplId());
		
		if(!Verify.isBlank(officeInfoRequest.getOfficeName())) {
			sb.append(" and o.office_name like :officeName");
			params.put("officeName", "%"+officeInfoRequest.getOfficeName()+"%");
		}
		if(officeInfoRequest.getBeginTimeStart()!=null) {
			sb.append(" and start_date>=:beginTimeStart ");
			params.put("beginTimeStart", DateUtil.formatDate(officeInfoRequest.getBeginTimeStart(), DateUtil.DATEFORMAT_DATE10));
		}
		if(officeInfoRequest.getBeginTimeEnd()!=null) {
			sb.append(" and start_date>=:beginTimeEnd ");
			params.put("beginTimeEnd", DateUtil.formatDate(officeInfoRequest.getBeginTimeEnd(), DateUtil.DATEFORMAT_DATE10));
		}
		/*//有效
		if(officeInfoRequest.getStatus()!=null && officeInfoRequest.getStatus()==OfficeStatusEnum.VALID) 
			sb.append(" and end_date>=CONVERT (DATE, GETDATE(), 20) ");
		//过期
		else if(officeInfoRequest.getStatus()!=null && officeInfoRequest.getStatus()==OfficeStatusEnum.OVERDUE)
			sb.append(" and end_date<CONVERT (DATE, GETDATE(), 20) ");*/
		if(Verify.isIntegerGtZero(officeInfoRequest.getStatus())) { 
			sb.append(" and a.asset_status_id=:status ");
			params.put("status", officeInfoRequest.getStatus());
		}else if(officeInfoRequest.getStatus()!=null && officeInfoRequest.getStatus()==-1) {//有效
			sb.append(" and end_date>=CONVERT (DATE, GETDATE(), 20) ");
		}else if(officeInfoRequest.getStatus()!=null && officeInfoRequest.getStatus()==-2) {//过期
			sb.append(" and end_date<CONVERT (DATE, GETDATE(), 20) ");
		}
		if(officeInfoRequest.getEndTimeStart()!=null) {
			sb.append(" and end_date>=:endTimeStart ");
			params.put("endTimeStart", DateUtil.formatDate(officeInfoRequest.getEndTimeStart(), DateUtil.DATEFORMAT_DATE10));
		}
		if(officeInfoRequest.getEndTimeEnd()!=null) {
			sb.append(" and end_date>=:endTimeEnd ");
			params.put("endTimeEnd", DateUtil.formatDate(officeInfoRequest.getEndTimeEnd(), DateUtil.DATEFORMAT_DATE10));
		}
		sb.append(" ) ");
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		BigDecimal totalOfficeVo = (BigDecimal) query.getSingleResult();
		return totalOfficeVo;
	}
	
	public Integer assetInfoTotalRecords(OfficeInfoRequest officeInfoRequest) {
		StringBuffer sb = new StringBuffer();
		
		sb.append("SELECT " + 
				"	count(a.office_id) " + 
				"FROM " + 
				"	asset a,  " + 
				"	office o, " + 
				"	empl_office eo  " + 
				"WHERE " + 
				"	a.office_id = o.office_id " + 
				"AND o.office_id = eo.office_id " + 
				"AND eo.empl_id = :emplId ");
		Map<String, Object> params = new HashMap<>();
		params.put("emplId", officeInfoRequest.getEmplId());
		
		//组装查询条件
		assembleParams(officeInfoRequest, sb, params,true);
		
		
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		return (Integer) query.getSingleResult();

	}
	
	public List<AssetDetailVo> assetInfoPage(OfficeInfoRequest officeInfoRequest, Pageable pageable) {
		List<AssetDetailVo> assetDetailVos = new ArrayList<>();
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		sb.append("SELECT top (:top) * FROM( ");
		sb.append("SELECT  ROW_NUMBER() OVER (");

		if (pageable.getSort() != null) {
			pageable.getSort().forEach(s -> {
				String orderBy = s.getProperty();
				sb.append("order by o.");
				if(orderBy.equals("assetType")) 
					orderBy="assetTypeId";
				else if(orderBy.equals("assetName"))
					orderBy="assetNameId";
				else if(orderBy.equals("assetFrom"))
					orderBy="assetFromId";
				else if(orderBy.equals("assetStatus"))
					orderBy="assetStatusId";
				sb.append(orderBy + " ");
				sb.append(s.getDirection());
			});
		} else {
			sb.append(" ORDER BY o.assetId DESC ");
		}
		sb.append(") AS rownum, * from ( ");

		sb.append("SELECT " + 
				"	a.asset_id assetId, " + 
				"	o.office_name officeName, " + 
				"	a.asset_no assetNo, " + 
				"  a.asset_unit assetUnit, " + 
				"  a.asset_price assetPrice, " + 
				"  a.brand_name brandName, " + 
				"  a.goods_type goodsType, " + 
				"  a.factory_name factoryName, " + 
				"  a.goods_color goodsColor, " + 
				"  a.goods_manu_date goodsManuDate, " + 
				"  a.setup_position setupPosition, " + 
				"  a.dept_name deptName, "+ 
				"  a.asset_type_id as assetTypeId," + 
				"  a.asset_name_id as assetNameId," + 
				"  a.asset_from_id as assetFromId," + 
				"  a.asset_status_id as assetStatusId " + 
				" FROM " + 
				"	asset a,  " + 
				"	office o, " + 
				"	empl_office eo  " + 
				"WHERE " + 
				"	a.office_id = o.office_id " + 
				"AND o.office_id = eo.office_id " + 
				"AND eo.empl_id = :emplId ");
		params.put("emplId", officeInfoRequest.getEmplId());
		assembleParams(officeInfoRequest, sb, params,true);
		
		sb.append(") as o ) A WHERE rownum >:rownum ");

		params.put("top", pageable.getPageSize());

		params.put("rownum", pageable.getPageSize() * pageable.getPageNumber());
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		query.unwrap(SQLQuery.class)
		.addScalar("assetId", IntegerType.INSTANCE)
		.addScalar("officeName",StringType.INSTANCE)
		.addScalar("assetNo",StringType.INSTANCE)
		.addScalar("assetUnit",StringType.INSTANCE)
		.addScalar("assetPrice",BigDecimalType.INSTANCE)
		.addScalar("brandName",StringType.INSTANCE)
		.addScalar("goodsType",StringType.INSTANCE)
		.addScalar("factoryName",StringType.INSTANCE)
		.addScalar("goodsColor",StringType.INSTANCE)
		.addScalar("goodsManuDate",StringType.INSTANCE)
		.addScalar("setupPosition",StringType.INSTANCE)
		.addScalar("deptName",StringType.INSTANCE)
		.addScalar("assetTypeId",IntegerType.INSTANCE)
		.addScalar("assetNameId",IntegerType.INSTANCE)
		.addScalar("assetFromId",IntegerType.INSTANCE)
		.addScalar("assetStatusId",IntegerType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(AssetDetailVo.class));
		assetDetailVos = query.getResultList();
		return assetDetailVos;
	}
	public TotalAssetVo totalAsset(OfficeInfoRequest officeInfoRequest,Map<String, Integer> typeMap) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		sb.append("SELECT " + 
				"	SUM (a.asset_price) totalAssetPrice, " + 
			/*	"	( " + 
				"		SELECT " + 
				"			COUNT (o.office_id) " + 
				"		FROM "+
				"			office o, " + 
				"			empl_office eo " + 
				"		WHERE " + 
				"			o.office_id = eo.office_id " + 
				"		AND empl_id = :emplId ");
		assembleParams(officeInfoRequest, sb, params,false);
		sb.append("	) totalCount, " +*/ 
				"	( " + //IT类
				"		SELECT " + 
				"			SUM (asset_price) " + 
				"		FROM " + 
				"			asset a, " + 
				"			office o, " + 
				"			empl_office eo " + 
				"		WHERE " + 
				"			a.office_id = o.office_id " + 
				"		AND o.office_id = eo.office_id " + 
				"		AND asset_type_id =" + typeMap.get("officeTotalItAmt")+
				"		AND eo.empl_id = :emplId ");
		assembleParams(officeInfoRequest, sb, params,true);
		sb.append("	) officeTotalItAmt, " + 
				"	( " + //IT类消耗品
				"		SELECT " + 
				"			SUM (asset_price) " + 
				"		FROM " + 
				"			asset a, " + 
				"			office o, " + 
				"			empl_office eo " + 
				"		WHERE " + 
				"			a.office_id = o.office_id " + 
				"		AND o.office_id = eo.office_id " + 
				"		AND asset_type_id =" +typeMap.get("officeTotalItConsAmt")+ 
				"		AND eo.empl_id = :emplId ");
		assembleParams(officeInfoRequest, sb, params,true);
		sb.append("	) officeTotalItConsAmt, " + 
				"	( " + 
				"		SELECT " + 
				"			SUM (asset_price) " + 
				"		FROM " + 
				"			asset a, " + 
				"			office o, " + 
				"			empl_office eo " + 
				"		WHERE " + 
				"			a.office_id = o.office_id " + 
				"		AND o.office_id = eo.office_id " + 
				"		AND asset_type_id =  " + typeMap.get("officeTotalErpEquAmt")+ 
				"		AND eo.empl_id = :emplId ");
		assembleParams(officeInfoRequest, sb, params,true);		
		sb.append("	) officeTotalErpEquAmt, " + 
				"	( " + 
				"		SELECT " + 
				"			SUM (asset_price) " + 
				"		FROM " + 
				"			asset a, " + 
				"			office o, " + 
				"			empl_office eo " + 
				"		WHERE " + 
				"			a.office_id = o.office_id " + 
				"		AND o.office_id = eo.office_id " + 
				"		AND asset_type_id =" +  typeMap.get("officeTotalWorFurAmt")+ 
				"		AND eo.empl_id = :emplId " );
		assembleParams(officeInfoRequest, sb, params,true);		
		sb.append("	) officeTotalWorFurAmt, ");
		sb.append("	( " + 
				"		SELECT " + 
				"			SUM (asset_price) " + 
				"		FROM " + 
				"			asset a, " + 
				"			office o, " + 
				"			empl_office eo " + 
				"		WHERE " + 
				"			a.office_id = o.office_id " + 
				"		AND o.office_id = eo.office_id " + 
				"		AND asset_type_id =" +  typeMap.get("officeTotalWorThiAmt")+ 
				"		AND eo.empl_id = :emplId " );
		assembleParams(officeInfoRequest, sb, params,true);		
		sb.append("	) officeTotalWorThiAmt, ");
		
		sb.append("	( " + 
				"		SELECT " + 
				"			SUM (asset_price) " + 
				"		FROM " + 
				"			asset a, " + 
				"			office o, " + 
				"			empl_office eo " + 
				"		WHERE " + 
				"			a.office_id = o.office_id " + 
				"		AND o.office_id = eo.office_id " + 
				"		AND asset_type_id =" +  typeMap.get("officeTotalEntCulAmt")+ 
				"		AND eo.empl_id = :emplId " );
		assembleParams(officeInfoRequest, sb, params,true);		
		sb.append("	) officeTotalEntCulAmt, ");
		
		sb.append("	( " + 
				"		SELECT " + 
				"			SUM (asset_price) " + 
				"		FROM " + 
				"			asset a, " + 
				"			office o, " + 
				"			empl_office eo " + 
				"		WHERE " + 
				"			a.office_id = o.office_id " + 
				"		AND o.office_id = eo.office_id " + 
				"		AND asset_type_id =" +  typeMap.get("officeTotalTraAmt")+ 
				"		AND eo.empl_id = :emplId " );
		assembleParams(officeInfoRequest, sb, params,true);		
		sb.append("	) officeTotalTraAmt ");
		sb.append(		"FROM " + 
				"	asset a, " + 
				"	office o, " + 
				"	empl_office eo " + 
				"WHERE " + 
				"	a.office_id = o.office_id " + 
				"AND o.office_id = eo.office_id " + 
				"AND eo.empl_id = :emplId " );
		params.put("emplId", officeInfoRequest.getEmplId());
		
		assembleParams(officeInfoRequest, sb, params,true);

		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		query.unwrap(SQLQuery.class)
/*		.addScalar("totalCount", IntegerType.INSTANCE)*/
		.addScalar("totalAssetPrice",BigDecimalType.INSTANCE)
		.addScalar("officeTotalItAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalItConsAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalErpEquAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalWorFurAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalWorThiAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalEntCulAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalTraAmt",BigDecimalType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(TotalAssetVo.class));
		List<TotalAssetVo> totalAssetVos = query.getResultList();
		if(Verify.collectionIfValue(totalAssetVos))
			return totalAssetVos.get(0);
		return null;
	}

	private void assembleParams(OfficeInfoRequest officeInfoRequest, StringBuffer sb, Map<String, Object> params,Boolean isAssetType) {
		if(!Verify.isBlank(officeInfoRequest.getOfficeName())) {
			sb.append(" and o.office_name like :officeName");
			params.put("officeName", "%"+officeInfoRequest.getOfficeName()+"%");
		}
		if(officeInfoRequest.getBeginTimeStart()!=null) {
			sb.append(" and o.start_date>=:beginTimeStart ");
			params.put("beginTimeStart", DateUtil.formatDate(officeInfoRequest.getBeginTimeStart(), DateUtil.DATEFORMAT_DATE10));
		}
		if(officeInfoRequest.getBeginTimeEnd()!=null) {
			sb.append(" and o.start_date<=:beginTimeEnd ");
			params.put("beginTimeEnd", DateUtil.formatDate(officeInfoRequest.getBeginTimeEnd(), DateUtil.DATEFORMAT_DATE10));
		}
		/*//有效
		if(officeInfoRequest.getStatus()!=null && officeInfoRequest.getStatus()==OfficeStatusEnum.VALID) 
			sb.append(" and o.end_date>=CONVERT (DATE, GETDATE(), 20) ");
		//过期
		else if(officeInfoRequest.getStatus()!=null && officeInfoRequest.getStatus()==OfficeStatusEnum.OVERDUE)
			sb.append(" and o.end_date<CONVERT (DATE, GETDATE(), 20) ");*/
		if(Verify.isIntegerGtZero(officeInfoRequest.getStatus())) { 
			sb.append(" and a.asset_status_id=:status ");
			params.put("status", officeInfoRequest.getStatus());
		}else if(officeInfoRequest.getStatus()!=null && officeInfoRequest.getStatus()==-1) {//有效
			sb.append(" and end_date>=CONVERT (DATE, GETDATE(), 20) ");
		}else if(officeInfoRequest.getStatus()!=null && officeInfoRequest.getStatus()==-2) {//过期
			sb.append(" and end_date<CONVERT (DATE, GETDATE(), 20) ");
		}
		if(officeInfoRequest.getEndTimeStart()!=null) {
			sb.append(" and o.end_date>=:endTimeStart ");
			params.put("endTimeStart", DateUtil.formatDate(officeInfoRequest.getEndTimeStart(), DateUtil.DATEFORMAT_DATE10));
		}
		if(officeInfoRequest.getEndTimeEnd()!=null) {
			sb.append(" and o.end_date<=:endTimeEnd ");
			params.put("endTimeEnd", DateUtil.formatDate(officeInfoRequest.getEndTimeEnd(), DateUtil.DATEFORMAT_DATE10));
		}
		
		if(isAssetType && Verify.isIntegerGtZero(officeInfoRequest.getAssetType())) { 
			sb.append(" and a.asset_type_id=:assetType ");
			params.put("assetType", officeInfoRequest.getAssetType());
		}
	}
}
