package com.ztj.dichan.entity;

import javax.persistence.*;

/**
 * 房屋销售跟进表
 */
@Entity
@Table(name = "housesalegj")
@NamedQuery(name = "HouseSaleGJ.findAll", query = "SELECT h FROM HouseSaleGJ h")
public class HouseSaleGJ extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "housesalegjid")
	private int id;

	@Column(name = "createtime")
	private String createTime;

	@Column(name = "deptid")
	private int deptId;

	@Column(name = "deptname")
	private String deptName;

	@Column(name = "emplid")
	private int emplId;

	@Column(name = "emplname")
	private String emplName;

	@Column(name = "fenshu")
	private int grade;

	private int gjid;

	/**
	 * 跟进内容
	 */
	@Column(name = "gjinfo")
	private String gjInfo;

	/**
	 * 跟进备注
	 */
	@Column(name = "gjmemo")
	private String gjMemo;

	/**
	 * 跟进图片
	 */
	@Column(name = "gjpic")
	private String gjPic;

	@Column(name = "gjrenwumemo")
	private String gjRenWuMemo;

	@Column(name = "gjtype")
	private String gjType;

	@Column(name = "housegjrenwuid")
	private int houseGJRenwuID;

	@Column(name = "houseid")
	private int houseId;

	@Column(name = "ismastergj")
	private int ismastergj;

	@Column(name = "mode")
	private String mode;

	@Column(name = "procename")
	private String proceName;

	@Column(name = "procepathid")
	private int procePathID;

	@Column(name = "processstatu")
	private String processStatu;

	@Column(name = "sprid")
	private int approverId;

	@Column(name = "sprname")
	private String approverName;

	@Column(name = "sysmemo")
	private String sysMemo;

}