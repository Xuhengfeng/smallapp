package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 审批消息表
 * 
 */
@Entity
@Table(name="procenews")
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="ProceNews.findAll", query="SELECT p FROM ProceNews p")
public class ProceNews extends ShardingEntity implements Comparable<String>{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="procenewsid")
	private Integer id;

	@Column(name="emplid")
	private Integer emplId;

	/**
	 * 消息类型
	 * 空：审批消息；'通知'：通知消息，第一次点击后自动消失
	 */
	@Column(name="newstype")
	private String newsType;

	/**
	 * 审批路径ID
	 */
	@Column(name="procepathid")
	private Integer procePathId;

	/**
	 * 提交人员工ID
	 */
	@Column(name="sendemplid")
	private Integer sendEmplId;

	/**
	 * 摘要信息
	 */
	@Column(name="sendinfo")
	private String sendInfo;

	@Column(name="sendtime")
	private String sendTime;

	@Column(name="taskid")
	private Integer taskId;

	@Column(name="workid")
	private Integer workId;
	
	@Transient
	private String emplName;
	@Transient
	private String taskName;
	@Transient
	private String sendEmplName;
	@Transient
	private String scityCH;
	
	@Override
	public int compareTo(String o) {
		// TODO Auto-generated method stub
		return 0;
	}

}