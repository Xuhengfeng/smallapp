package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 通用申请子表
 * 
 */
@Data
@Entity
@Table(name="tysqb")
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="TysqB.findAll", query="SELECT t FROM TysqB t")
public class TysqB extends ShardingEntity{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tysqbid")
	private Integer id;

	/**
	 * 显示宽度
	 */
	@Column(name="colwidth")
	private Integer colWidth;

	/**
	 * 栏目名称
	 */
	@Column(name="itemname")
	private String itemName;

	/**
	 * 栏目内容
	 */
	@Column(name="itemvalue")
	private String itemValue;

	/**
	 * 行号
	 */
	@Column(name="rownum")
	private Integer rowNum;

	/**
	 * 通用申请主表id
	 */
	@Column(name="tysqaid")
	private Integer comReqDetailId;


}