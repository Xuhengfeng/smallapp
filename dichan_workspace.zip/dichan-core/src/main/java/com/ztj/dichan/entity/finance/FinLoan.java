package com.ztj.dichan.entity.finance;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;
import com.ztj.dichan.enums.BasicSalaryStatusEnum;
import com.ztj.dichan.vo.request.finance.FinLoanInfoAddVo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * 借款申请表
 * 
 * @author zuohuan
 *
 */
@Entity
@Table(name = "fin_loan")
@Data
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
public class FinLoan extends ShardingEntity {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4083479440457215104L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fin_loan_id")
	private Integer id;

	//借款编号
	private String finLoanNo;
	
	//借款合同编号
	//private String finLoanContrNo;
	
	//买卖方类型
	private String clientType;
	
	//房产信息ID
	private Integer finHouseId;
	
	//借款类型
	private Integer finLoanTypeId;
	
	//借款金额
	private BigDecimal loanAmt;
	
	//借款期限
	private BigDecimal loanLimitTime;
	
	//利息支付类型
	private Integer intePayTypeId;
	
	//借款利率
	private BigDecimal inteRate;
	
	//是否有贷款合同
	private Boolean hasLoanContrNo;
	
	//贷款合同号
	private String loanContrNo;
	
	//当前业务进度
	private Integer bizProgressId;
	
	//出款状态
	private String payStatus;
	
	//已出款金额
	private BigDecimal payMoney;
	
	//还款状态
	private String returnStatus;
	
	//未还款金额
	private BigDecimal returnMoney;
	
	//核销状态
	private String verifyStatus;
	
	//流程路径ID
	private Integer processPathId;
	
	//流程路径名称
	private String processName;
	
	//流程状态
	private String processStatus;
	
	//起始时间
	private Date beginTime;
	
	//结束时间
	private Date endTime;
	
	//审批人ID
	private Integer approveId;
	
	//审批人
	private String approveName;
	
	//创建人
	private Integer createId;
	
	//创建时间
	private LocalDateTime createTime;
	
	//修改人
	private Integer lastUpdateId;
	
	//修改时间
	private LocalDateTime lastUpdateTime;
	
	
	public FinLoan(FinLoanInfoAddVo finLoanInfoAddVo) {
		this.id=finLoanInfoAddVo.getFinLoanId();
		this.finHouseId=finLoanInfoAddVo.getFinHouseId();
		this.clientType=finLoanInfoAddVo.getClientType().name();
		this.finLoanNo=finLoanInfoAddVo.getFinLoanNo();
		this.hasLoanContrNo=finLoanInfoAddVo.getHasLoanContrNo();
		this.loanContrNo=finLoanInfoAddVo.getLoanContrNo();
		this.loanAmt=finLoanInfoAddVo.getLoanAmt();
		this.finLoanTypeId=finLoanInfoAddVo.getFinLoanTypeId();
		this.loanLimitTime=finLoanInfoAddVo.getLoanLimitTime();
		this.intePayTypeId=finLoanInfoAddVo.getIntePayTypeId();
		this.inteRate=finLoanInfoAddVo.getInteRate();
		this.beginTime=finLoanInfoAddVo.getBeginTime();
		this.endTime=finLoanInfoAddVo.getEndTime();
		this.bizProgressId=finLoanInfoAddVo.getBizProgressId();
	}
}
