package com.ztj.dichan.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 集团数据库
 * 日报表
 * @author zhouqiao
 *
 */

@Entity
@Table(name="report_daily")
@Data
@EqualsAndHashCode(callSuper=true)
public class ReportDaily extends ShardingEntity implements Serializable {
	private static final long serialVersionUID = 1L;
	 
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
	
    
    /**
     * 城市拼音
     */
	private String cityName;
	
	
	/**
	 * 冗余字段,城市中文名
	 */
	@Transient
	private String cityNameCh;
	
	/**
	 * 获取数据的所属日期
	 */
	private java.sql.Date reportDate;
	
	/**
	 * 店名
	 */
	private String shopName;
	
	
	/**
	 * 组别
	 */
	private String groupName;
	
	/**
	 * 店面人数
	 */
	private Long membersNum;
	
	/**
	 * 入职人数
	 */
	private Long joinNum;
	
	/**
	 * 离职人数
	 */
	private Long dimissionNum;
	
	/**
	 * 新增诚意金数
	 */
	private Long newSincerityNum;
	
	/**
	 * 新增诚意金金额
	 */
	private BigDecimal newSincerityTotal;
	
	/**
	 * 退诚意金数
	 */
	private Long cancelSincerityNum;
	
	/**
	 * 退诚意金金额
	 */
	private BigDecimal cancelSincerityAmt;
	
	/**------------------------定房
	 * 新增订房数
	 */
	private Long newDujiaNum;
	
	/**
	 * 订房库存
	 */
	private Long dujiaTotalNum;
	
	/**
	 * 一周后过期
	 */
	private Long weekOutNum;
	
	/**
	 * 一个月后过期
	 */
	private Long monthOutNum;
	
	/**------------------------客源
	 * 	新增客源数
	 */
	private Long custNewNum;
	
	/**
	 * 当前库存
	 */
	private Long custTotalNum;
	
	/**
	 * 公客
	 */
	private Long custPublicNum;
	
	/**
	 * 私客
	 */
	private Long custPrivateNum;
	
	/**
	 * 无效
	 */
	private Long custInvalidNum;
	
	/**------------------------房源
	 * 当前库存房源
	 */
	private Long houseTotalNum;
	
	/**
	 * 新增房源数
	 */
	private Long houseNewNum;
	
	/**
	 * 我租我售
	 */
	private Long houseMineNum;
	
	/**
	 * 已租已售
	 */
	private Long houseOtherNum;
	
	/**
	 * 暂缓
	 */
	private Long houseHangNum;
	
	/**------------------------
	 * 租单成交量
	 */
	private Long newRentNum;
	
	/**
	 * 售单成交量
	 */
	private Long  newSaleNum;
	
	/**
	 *  租单成交额
	 *  合同房子出租价格
	 */
	private BigDecimal newRentAmt;

	/**
	 *  售单成交额
	 *  合同房子出售价格
	 */
	private BigDecimal newSaleAmt;
	
	/**
	 * 租单业绩
	 * 租单应收收入
	 */
	private BigDecimal rentDueIncomeAmt;
	
	/**
	 * 售单业绩
	 * 售单应收收入
	 */
	private BigDecimal saleDueIncomeAmt;
	
	/**
	 * 租单应收代收
	 */
	private BigDecimal rentDueOther;
	
	/**
	 * 售单应收代收
	 */
	private BigDecimal  saleDueOther;
	
	/**
	 * 已收代收
	 */
	private BigDecimal doneOtherAmt;
	

	
	/**
	 * 创建人
	 * 第一次自动跑:AUTO_JOB
	 *自动重跑：RETRY_JOB
	 *人工重跑：操作员工
	 */
	private Long createId;
	
    /**
     * 创建时间
     */
    protected LocalDateTime createDateTime;

    /**
     * 修改时间
     */
    protected LocalDateTime updateDateTime;
    
    @Transient
    private Date beginDate;
    
    @Transient
    private Date endDate;
    
    
    /**
     * 当前诚意金库存数量
     */
    private Long currentSincerityNum;
    
    /**
     * 当前诚意金库存金额
     */
    private BigDecimal currentSincerityTotal;
    
    
    /**
     * 诚意金转定金
     */
    private BigDecimal sincerityConvFix;
    
    /**
     * 诚意金转佣金
     */
    private BigDecimal sincerityConvIncome;
    
    /**
     * 合同库存数量
     */
    private Long contrTotalNum;
    
    /**
     * 合同新增数量
     */
    private Long contrNewNum;
    
    /**
     * 合同应收收入
     */
    private BigDecimal dueIncomeAmt;
    
	/**
	 * 合同已收收入
	 */
	private BigDecimal doneIncomeAmt;
    
    /**
     * 合同未收收入
     */
    private BigDecimal  withoutIncomeAmt;
    
    
    
}
