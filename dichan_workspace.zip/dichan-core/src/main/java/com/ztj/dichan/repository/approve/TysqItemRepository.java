package com.ztj.dichan.repository.approve;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import com.ztj.dichan.entity.TysqItem;
import com.ztj.dichan.vo.approve.TysqItemVo;

@Repository
public interface TysqItemRepository extends PagingAndSortingRepository<TysqItem,Long>{
	List<TysqItemVo> findTysqItemVoByComReqTypeId(Integer comReqTypeId);
	
	List<TysqItem> findByComReqTypeId(Integer comReqTypeId);
}
