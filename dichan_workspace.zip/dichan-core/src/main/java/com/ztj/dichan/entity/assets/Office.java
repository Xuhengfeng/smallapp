package com.ztj.dichan.entity.assets;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Entity
@Table(name = "office")
@Data
@EqualsAndHashCode(callSuper = true)
public class Office extends ShardingEntity{

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="office_id")
	private Integer id;//办公室Id
	
	@Column(name="office_name")
	private String officeName;//办公区名称
	
	@Column(name="office_area")
	private BigDecimal officeArea;//面积
	
	@Column(name="phone_num_pre")
	private String phoneNumPre;//电话区号
	
	@Column(name="phone_num")
	private String phoneNum;//电话号码
	
	@Column(name="address")
	private String address;//地址
	
	@Column(name="start_date")
	private String startDate;//起租日期
	
	@Column(name="end_date")
	private String endDate;//截止日期
	
	@Column(name="days_without_money")
	private String daysWithoutMoney;//免租期
	
	@Column(name="rent_money")
	private BigDecimal rentMoney;//月租金
	
	@Column(name="decorate_money")
	private BigDecimal decorateMoney;//装修费用
	
	@Column(name="security_money")
	private BigDecimal securityMoney;//押金
	
	@Column(name="transfer_money")
	private BigDecimal transferMoney;//转让费
	
	@Column(name="pay_type")
	private String payType;//付款方式
	
	@Column(name="transfer_goods")
	private String transferGoods;//转让物品
	
	@Column(name="area_id")
	private Integer areaId;//区域
	
	@Column(name="district_id")
	private Integer districtId;//片区
	
	@Column(name="deptjwd")
	private String deptJwd; //经纬度
	
	@Column(name="create_id")
	private Integer creater;//创建人
	
	@Column(name="create_time")
	private LocalDateTime CreateTime;//创建时间
	
	@Column(name="last_update_id")
	private Integer lastUpdater;//最后修改人
	
	@Column(name="last_update_time")
	private LocalDateTime lastUpdateTime;//最后修改时间
	
}
