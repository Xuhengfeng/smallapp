package com.ztj.dichan.repository;



import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.ApproveReco;



@Repository
public interface ApproveRecoRepository extends PagingAndSortingRepository<ApproveReco, Integer>{
	
	@Query("select a from ApproveReco a where a.workId = ?1 and a.scity = ?2 and a.taskId = ?3 order by proceDate asc")
	List<ApproveReco> findByWorkIdAndScity(Integer workId,String scity,Integer taskId);

}
