package com.ztj.dichan.entity.salary;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.ztj.dichan.entity.ShardingEntity;
import com.ztj.dichan.enums.PercentTypeEnum;
import com.ztj.dichan.enums.SalaryPercentStatusEnum;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 提成信息
 * 
 * @author test01
 */
@Entity
@Table(name = "salary_percent_info")
@Data
@EqualsAndHashCode(callSuper = true)
public class SalaryPercentInfo extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "salary_percent_info_id")
	private Integer id;

	/**
	 * 提成月份
	 */
	private String yearMonth;

	/**
	 * 员工id
	 */
	private Integer employeeId;

	/**
	 * 员工名称
	 */
	private String employeeName;

	/**
	 * 部門id
	 */
	private Integer deptId;

	/**
	 * 店名
	 */
	private String shopName;

	/**
	 * 組名
	 */
	private String groupName;

	/**
	 * 岗位id
	 */
	private Integer positionId;

	/**
	 * 崗位名称
	 */
	private String positonName;

	/**
	 * 交易类别
	 */
	private String tradeType;

	/**
	 * 总业绩 租单总业绩或者售单总业绩
	 */
	private BigDecimal amountTotal = BigDecimal.ZERO;

	/**
	 * 业绩类型，个人业绩，团队业绩，区均业绩，其他业绩
	 */
	private String amountType;
	/**
	 * 段业绩
	 */
	private BigDecimal amount = BigDecimal.ZERO;

	/**
	 * 是否分段提成
	 */
	private Boolean isStage = false;

	/**
	 * 提成百分比
	 */
	private BigDecimal commiPerct = BigDecimal.ZERO;

	/**
	 * 晋升/入职时间
	 */
	private LocalDate changePositionTime;

	/**
	 * 晋升/入职月数
	 */
	private Integer changeMonthNum = 0;
	
	/**
	 * 是否为当月离职员工
	 */
	private Boolean isDimissionEmp;

	/**
	 * 离职时间
	 */
	private LocalDate dimissionTime;
	
	/**
	 * 业务津贴
	 */
	private BigDecimal allowanceAmt = BigDecimal.ZERO;

	/**
	 * 其它收入
	 */
	private BigDecimal incomeOther = BigDecimal.ZERO;

	/**
	 * 应发合计
	 */
	private BigDecimal dueIncomeTotal = BigDecimal.ZERO;

	/**
	 * 员工借款
	 */
	private BigDecimal cutBorrow = BigDecimal.ZERO;

	/**
	 * 业绩扣款
	 */
	private BigDecimal cutReachTask = BigDecimal.ZERO;

	/**
	 * 其它扣款
	 */
	private BigDecimal cutOther = BigDecimal.ZERO;

	/**
	 * 扣款合计
	 */
	private BigDecimal cutTotal = BigDecimal.ZERO;

	/**
	 * 实发金额
	 */
	private BigDecimal incomeAmount = BigDecimal.ZERO;

	/**
	 * 底薪
	 */
	private BigDecimal basicSalary = BigDecimal.ZERO;

	/**
	 * 提成类型:个人或团队(person/group)
	 */
	@Enumerated(EnumType.STRING)
	private PercentTypeEnum type = PercentTypeEnum.PERSON;

	/**
	 * 是否手动加入
	 */
	private String isCanChange = "N";

	/**
	 * 状态
	 */
	@Enumerated(EnumType.STRING)
	private SalaryPercentStatusEnum status = SalaryPercentStatusEnum.NEW;

	/**
	 * 旧状态
	 */
	@Enumerated(EnumType.STRING)
	private SalaryPercentStatusEnum oldStatus;

	/**
	 * 创建人
	 */
	private Long createId;

	/**
	 * 创建时间
	 */
	private LocalDateTime createTime = LocalDateTime.now();

	/**
	 * 最后修改员工id
	 */
	private Long lastUpdateId;

	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime = LocalDateTime.now();

	/**
	 * 提成金额
	 */
	private BigDecimal commision = BigDecimal.ZERO;

	/**
	 * 调整后提成
	 */
	private BigDecimal adjustCommision;

	/**
	 * 调整说明
	 */
	private String adjustRemark;

	/**
	 * 是否锁定
	 */

	private Boolean isLock;
	/**
	 * 拒绝理由
	 */
	private String rejectNode;

}
