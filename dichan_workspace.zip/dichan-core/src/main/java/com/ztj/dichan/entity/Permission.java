package com.ztj.dichan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * The persistent class for the Permission database table.
 * 
 */
@Entity
@Table(name = "Permission")
@Data
@EqualsAndHashCode(callSuper = true)
@NamedQuery(name="Permission.findAll", query="SELECT p FROM Permission p")
public class Permission extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="permiid")
	private Long permiID;

	@Column(name="creater")
	private String creater;

	@Column(name="createtime")
	private String createTime;

	@Column(name="functionname")
	private String functionName;

	@Column(name="permissionname")
	private String permissionName;

	@Column(name="statu")
	private String statu;
	
	/**
	 * isForGroup 不等于Y，同步
	 */
	@Column(name="is_for_group")
	private String isForGroup;
	

}