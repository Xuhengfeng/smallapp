package com.ztj.dichan.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name="netbuildprice")
@Data
@EqualsAndHashCode(callSuper = true)
public class NetBuildPrice extends ShardingEntity  {

	private static final long serialVersionUID = 1L;

	/**
	 * 主键 
	 * 
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="netbuildpriceid")
	private Integer id;
	
	
	/**
	 * 楼盘id
	 */
	@Column(name="buildid")
	private String buildId;
	
	/**
	 * 所属区域
	 */
	@Column(name="areaname")
	private String areaName;
	
	/**
	 * 所属片区
	 */
	@Column(name="districtname")
	private String districtName;
	
	/**
	 * 年
	 */
	@Column(name="byear")
	private Integer year;
	
	/**
	 * 月
	 */
	@Column(name="bmonth")
	private Integer month;
	
	/**
	 * 成交数量
	 */
	@Column(name="dealcount")
	private Integer dealCount;
	
	/**
	 * 在售数量
	 */
	@Column(name="salecount")
	private Integer saleCount;
	
	/**
	 * 出租数量
	 */
	@Column(name="rentcount")
	private Integer rentCount;
	
	/**
	 * 住宅售价
	 */
	@Column(name="rreprice")
	private BigDecimal housingPrice;
	
	/**
	 * 商业售价
	 */
	@Column(name="creprice")
	private BigDecimal businessPrice;
	
	/**
	 * 住宅租金
	 */
	@Column(name="rrerent")
	private BigDecimal housingRentPrice;
	
	/**
	 * 商业租金
	 */
	@Column(name="crerent")
	private BigDecimal businessRentPrice;
	
	/**
	 * 创建人
	 */
	@Column(name="creater")
	private String createName;
	
	/**
	 * 创建时间
	 */
	@Column(name="createtime")
	private String createTime;
	
	/**
	 * 最后修改员工id
	 */
	private Long LastUpdateId;
	
	/**
	 * 最后修改时间
	 */
	private LocalDateTime LastUpdateTime;
	
}
