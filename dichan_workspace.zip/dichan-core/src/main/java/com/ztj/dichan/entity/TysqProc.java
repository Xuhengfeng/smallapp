package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 通用申请默认流程表
 * 
 */
@Entity
@Table(name="tysqproc")
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="TysqProc.findAll", query="SELECT t FROM TysqProc t")
public class TysqProc extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tysqprocid")
	private Integer id;

	/**
	 * 默认流程名称
	 */
	@Column(name="tysqpname")
	private String comReqProcName;

	@Column(name="tysqtypeid")
	private Integer comReqTypeId;

}