package com.ztj.dichan.enums;

import java.io.Serializable;


/**
 * 报表详情切换枚举类型
 * @author zhouqiao
 *
 */
public enum TabDetailTypeEnum implements Serializable{

	
	NEWSINCERITY("newSincerity","诚意金新增详情",""),
	CANCELSINCERITY("cancelSincerity","诚意金退款详情",""),
	CURRENTSINCERITY("currentSincerity","诚意金库存详情",""),
	SINCERITYCONVFIX("sincerityConvfix","诚意金转定详情",""),
	SINCERITYCONVINCOME("sincerityConvIncome","诚意金转佣详情",""),
	CONTRTOTAL("contrTotalNum","合同库存详情",""),
	CONTRNEW("contrNewNum","合同新增详情",""),
	DUEINCOME("dueIncomeAmt","合同所有应收详情",""),
	DONEINCOME("doneIncomeAmt","合同所有已收详情",""),
	WITHOUTINCOME("withoutIncome","合同所有未收详情","");

    private String code;

    private String name;
    
    private String desc;

    private TabDetailTypeEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}
	
}
