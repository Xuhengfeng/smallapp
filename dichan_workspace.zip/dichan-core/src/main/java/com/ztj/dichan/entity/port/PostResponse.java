package com.ztj.dichan.entity.port;

import java.util.List;

import com.ztj.dichan.vo.PostVo;

import lombok.Data;

@Data
public class PostResponse {
	
	private String cityName;

	private Integer totalRecords;
	
	private List<PostVo> postVos;

}
