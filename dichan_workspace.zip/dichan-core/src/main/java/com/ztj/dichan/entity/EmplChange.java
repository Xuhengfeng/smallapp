package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 员工人事变动
 * 
 */
@Data
@Table(name="emplchange")
@Entity
@EqualsAndHashCode(callSuper = true)
public class EmplChange extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="emplchangeid")
	private Integer id;

	/**
	 * 办理人
	 */
	@Column(name="blr")
	private String handleName;

	/**
	 * 办理人id
	 */
	@Column(name="blrID")
	private Integer handleId;

	/**
	 * 办理日期
	 */
	@Column(name="blTime")
	private String handleTime ;

	/**
	 * 变动说明
	 */
	@Column(name="changememo")
	private String changeMemo;

	/**
	 * 变动日期
	 */
	@Column(name="changetime")
	private String changeTime;

	@Column(name="creater")
	private String creater;

	@Column(name="createrid")
	private Integer createrId;

	@Column(name="createtime")
	private String createTime;

	@Column(name="emplid")
	private Integer emplId;

	/**
	 * 变动后部门ID
	 */
	@Column(name="hdeptid")
	private Integer afDeptId;

	/**
	 * 变动后大区部门ID
	 */
	@Column(name="hdqdeptid")
	private Integer afBigDeptId;

	/**
	 * 变动后大区经理员工ID
	 */
	@Column(name="hdqemplid")
	private Integer afBigDeptManager;

	/**
	 * 变动后职务
	 */
	@Column(name="hdutyname")
	private String afDutyName;

	/**
	 * 变动后店长ID	
	 */
	@Column(name="hdzemplid")
	private Integer afShopMasterId;

	/**
	 * 变动后门店部门ID
	 */
	@Column(name="hmddeptid")
	private Integer afShopId;
	
	/**
	 * 变动后门店负责人ID
	 */
	@Column(name="hmdemplid")
	private Integer afShopManager;

	/**
	 * 变动后岗位id
	 */
	@Column(name="hpositiid")
	private Integer afPositonId;

	/**
	 * 变动后的岗位
	 */
	@Column(name="hposition")
	private String afPositonName;

	/**
	 * 变动后区域部门ID
	 */
	@Column(name="hqydeptid")
	private Integer afDisDeptId;

	/**
	 * 变动后区域部门员工ID
	 */
	@Column(name="hqyemplid")
	private Integer afDeptManager;

	/**
	 * 变动后战区部门ID
	 */
	@Column(name="hzqdeptid")
	private Integer afCompDeptId;

	/**
	 * 变动后战区总监员工ID
	 */
	@Column(name="hzqemplid")
	private Integer afCompManager;

	/**
	 * 流程路径名称
	 */
	@Column(name="procename")
	private String processName;

	/**
	 * 流程路径id
	 */
	@Column(name="procepathid")
	private Integer processPathId;

	/**
	 * 流程状态
	 */
	@Column(name="processstatu")
	private String processStatus;

	/**
	 * 变动前部门id
	 */
	@Column(name="qdeptid")
	private Integer bfDeptId;

	/**
	 * 变动前大区部门ID
	 */
	@Column(name="qdqdeptid")
	private Integer bfBigDeptId;

	/**
	 * 变动前大区经理员工ID
	 */
	@Column(name="qdqemplid")
	private Integer bfBigDeptManager;

	/**
	 * 变动前的职务
	 */
	@Column(name="qdutyname")
	private String bfDutyName;

	/**
	 * 变动前店长id
	 */
	@Column(name="qdzemplid")
	private Integer bfShopMasterId;

	/**
	 * 变动前门店部门ID
	 */
	@Column(name="qmddeptid")
	private Integer bfShopId;

	/**
	 * 变动前门店负责人ID
	 */
	@Column(name="qmdemplid")
	private Integer bfShopManager;

	/**
	 * 变动前岗位id
	 */
	@Column(name="qpositiid")
	private Integer bfPositonId;

	/**
	 * 变动前岗位
	 */
	@Column(name="qposition")
	private String bfPositonName;

	/**
	 * 变动前区域部门ID
	 */
	@Column(name="qqydeptid")
	private Integer bfDisDeptId;

	/**
	 * 变动前区域经理员工ID
	 */
	@Column(name="qqyemplid")
	private Integer bfDeptManager;

	/**
	 * 变动前战区部门id
	 */
	@Column(name="qzqdeptid")
	private Integer bfCompDeptId;

	/**
	 * 变动前战区总监员工ID
	 */
	@Column(name="qzqemplid")
	private Integer bfCompManager;
	
	/**
	 * 审批人id
	 */
	@Column(name="sprid")
	private Integer approverId;

	/**
	 * 审批人姓名
	 */
	@Column(name="sprname")
	private String approverName;

	/**
	 * 未完结流程去向
	 * 选择：转给上级领导/保持不变
	 */
	@Column(name="wwlcqx")
	private String flowTo;

	/**
	 * 异动类型
	 */
	@Column(name="ydtype")
	private String changeType;

}