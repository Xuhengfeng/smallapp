package com.ztj.dichan.entity.assets;

import java.util.List;

import lombok.Data;

@Data
public class BindingReq {

	private Integer officeId;
	
	private List<BindingPic> bindList;
}
