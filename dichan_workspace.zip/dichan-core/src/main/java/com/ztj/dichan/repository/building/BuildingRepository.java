package com.ztj.dichan.repository.building;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.Building;

@Repository
public interface BuildingRepository extends PagingAndSortingRepository<Building, Integer>{

	@Query("select b from Building b where b.id in ?1 ")
	List<Building> findByids(List<Integer> ids);
	
	List<Building> findByBuildName(String buildName);
	
	List<Building> findAll();
	
	Building queryByBuildName(String buildName);
	
	List<Building> findBySdidIsNull();
	
	List<Building> queryBuildingPage(String scity,String serachMsg,Pageable pageable);
	
	Integer buildingTotalRecords(String scity,String serachMsg);
	
}
