package com.ztj.dichan.enums;

public enum ShardingKeyType {
	AIO,JAVA
}
