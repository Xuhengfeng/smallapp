package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 通用申请栏目表
 * 
 */
@Table(name="tysqitem")
@Entity
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="TysqItem.findAll", query="SELECT t FROM TysqItem t")
public class TysqItem extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tysqitemid")
	private Integer id;

	@Column(name="colwidth")
	private Integer colWidth;

	@Column(name="itemname")
	private String itemName;

	/**
	 * 通用申请id
	 */
	@Column(name="tysqtypeid")
	private Integer comReqTypeId;

	@Column(name="xh")
	private Integer showOrder;
	
	@Column(name="field_type_id")
	private Integer fieldTypeId;
	
	@Column(name="field_chk_rule_id")
	private Integer fieldChkRuleId;
	
	@Column(name="is_mandatory")
	private String isMandatory;
	
	@Column(name="rel_column_name")
	private String relColumnName;
	

}