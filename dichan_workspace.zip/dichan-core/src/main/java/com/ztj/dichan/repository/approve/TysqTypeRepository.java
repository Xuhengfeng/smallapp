package com.ztj.dichan.repository.approve;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.TysqType;

/**
 * 通用申请类型 
 * @author zhouqiao
 *
 */
@Repository
public interface TysqTypeRepository extends PagingAndSortingRepository<TysqType,Integer>{
	
	List<TysqType> queryTysqType(String subManageType,String emplAcco,String scity);
	
	@Query("select t.id from TysqType t where t.subManageType = ?1")
	List<Integer> findTysqTypeIDByScity(String subManageType);
}
