package com.ztj.dichan.repository.assets;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.assets.EmplOffice;

@Repository
public interface OfficePermissionsRespository extends PagingAndSortingRepository<EmplOffice, Integer> {

	List<EmplOffice> queryEmplOfficeList(String scity,Integer officeId,Pageable pageable);
	
	Integer emplTotalRecords(String scity,Integer officeId);

	List<EmplOffice> findByOfficeId(Integer officeId);
	
	List<EmplOffice> findByEmplID(Integer emplId);
}
