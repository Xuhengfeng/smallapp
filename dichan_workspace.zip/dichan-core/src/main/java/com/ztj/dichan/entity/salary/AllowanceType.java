package com.ztj.dichan.entity.salary;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 津贴类别信息
 * 
 * @author test01
 */
 @Entity
 @Table(name = "allowance_type")
@Data
@EqualsAndHashCode(callSuper = true)
public class AllowanceType extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "allowance_type_id")
	private Integer id;

	/**
	 * 津贴类别名称
	 */
	private String allowanceTypeName;

	/**
	 * 岗位id
	 */
	private Integer positionId;

	/**
	 * 备注
	 */
	private String note;

	/**
	 * 创建人
	 */
	private Long createId;

	/**
	 * 创建时间
	 */
	private LocalDateTime createTime;

	/**
	 * 最后修改员工id
	 */
	private Long lastUpdateId;

	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime;
}