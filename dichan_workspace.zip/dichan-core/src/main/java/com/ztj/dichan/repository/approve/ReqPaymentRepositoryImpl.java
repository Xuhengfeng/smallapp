package com.ztj.dichan.repository.approve;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.ztj.common.util.DateUtil;
import com.ztj.dichan.entity.TysqA;
import com.ztj.dichan.vo.approve.RepaymentVo;
import com.ztj.dichan.vo.approve.ReqPayQuery;
import com.ztj.dichan.vo.approve.ReqPaymentVo;
import com.ztj.dichan.vo.city.GroupVo;

@Repository
public class ReqPaymentRepositoryImpl {

	@PersistenceContext
	private EntityManager em;
	
	/**
	 * 获取请款列表
	 * @param reqPayQuery
	 * @param pageable
	 * @return
	 */
	List<ReqPaymentVo> getReqPaymentList(ReqPayQuery reqPayQuery,Pageable pageable){

		List<ReqPaymentVo> list = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
	    sql.append("SELECT top (?1) * FROM( ");
	    sql.append("SELECT  ROW_NUMBER() OVER ( ");
//	       动态排序
	   if(pageable.getSort()!=null) {
		   Sort s = pageable.getSort();
		   s.forEach(v ->{
		     sql.append("ORDER BY o."+getColumnName(v.getProperty(),TysqA.class)+" "+v.getDirection());
			   });
	 	}else {
	 		 sql.append("ORDER BY o.createtime desc,o.modify_time desc");
	 	}
	    sql.append(" ) AS rownum, * from ( ");
		sql.append(" select a.*,t.sqlx as comReqType,e.phone");
		sql.append(" from TysqA a ");
		sql.append(" left join employee e on e.emplid =a.createrid");
		sql.append(" join TysqType t on a.TysqTypeID =t.TysqTypeID ");
		if(StringUtils.isNotEmpty(reqPayQuery.getDeptName())) {
			if(reqPayQuery.getIsOrShop()!=null) {
				if(reqPayQuery.getIsOrShop().equals("Y")) {
					sql.append(" left join office f on f.office_id = a.deptid");
				}else {
					sql.append(" left join department d on d.deptid = a.deptid");
				}
			}else {
				sql.append(" left join department d on d.deptid = a.deptid");		
			}
		}
//		动态条件
		sql.append(" where a.tysq_type ='"+reqPayQuery.getTysqType()+"'");
		if(reqPayQuery.getBeginTime()!=null) {
			sql.append(" and a.createtime >='"+DateUtil.formatDate(reqPayQuery.getBeginTime(), DateUtil.DATEFORMAT_DATE10)+"'");
		}
		if(reqPayQuery.getEndTime()!=null) {
			sql.append(" and a.createtime <= '"+DateUtil.formatDate(reqPayQuery.getEndTime(), DateUtil.DATEFORMAT_DATE10)+"'");
		}
		if(StringUtils.isNotEmpty(reqPayQuery.getTaskType())) {
			sql.append(" and t.sqlx ='"+reqPayQuery.getTaskType()+"'");
		}
		if(StringUtils.isNotEmpty(reqPayQuery.getVerifyType())) {
			sql.append(" and a.status ='"+reqPayQuery.getVerifyType()+"'");
		}
		if(reqPayQuery.getProcessStatus()!=null) {
			if(reqPayQuery.getProcessStatus().equals("")) {
				sql.append(" and (a.processstatu is null or a.processstatu ='' )");
			}else {
				sql.append(" and a.processstatu ='"+reqPayQuery.getProcessStatus()+"'");
			}
		}
		
//		针对核销申请对应请款查询
		if(reqPayQuery.getStatus()!=null && reqPayQuery.getStatus().size()>0) {
			sql.append(" and a.status in ("+concatArray(reqPayQuery.getStatus())+")");
			if(reqPayQuery.getRelTysqTypeId()!=null) {
				sql.append(" and a.tysqtypeid ="+reqPayQuery.getRelTysqTypeId());
			}
		}else {
			if(reqPayQuery.getDeptList()!=null && reqPayQuery.getDeptList().size()>0) {
				sql.append(" and ( a.deptId in ("+concatArrayDeptId(reqPayQuery.getDeptList())+") or a.CreaterId ="+reqPayQuery.getEmplId()+")");
			}else {
				sql.append(" and a.CreaterId ="+reqPayQuery.getEmplId()+" ");
			}
		}
		
		if(StringUtils.isNotEmpty(reqPayQuery.getDeptName())) {
			if(reqPayQuery.getIsOrShop().equals("Y")) {
				sql.append(" and f.office_name ='"+reqPayQuery.getDeptName()+"'");
			}else {
				sql.append(" and d.deptname ='"+reqPayQuery.getDeptName()+"'");
			}
		}
		
		if(StringUtils.isNotEmpty(reqPayQuery.getKeyword())) {
			sql.append(" and (a.com_req_no like '%"+reqPayQuery.getKeyword()+"%'");
			sql.append(" or a.sqzt like '%"+reqPayQuery.getKeyword()+"%' )");
		}
		
		sql.append(") as o ) A WHERE rownum >?2 ");
		Query query = em.createNativeQuery(sql.toString());
		List<Object> paramList = new ArrayList<>();
		  paramList.add(pageable.getPageSize());
		  paramList.add(pageable.getPageSize()*pageable.getPageNumber());
		  int i = 1;
		  for (Object param : paramList) {
			query.setParameter(i, param);
			i++;
		  }
		query.unwrap(SQLQuery.class).addEntity(TysqA.class)
		.addScalar("comReqType",StringType.INSTANCE).addScalar("phone",StringType.INSTANCE).list();
		 List<Object[]> tysqList= query.getResultList();
		  for(Object[] o : tysqList) {
			  ReqPaymentVo detail = new ReqPaymentVo();
		    	 BeanUtils.copyProperties(o[0], detail);
		    	 if(o[1]!=null) {
		    		 detail.setComReqType(o[1].toString());	 
		    	 }
		    	 if(o[2]!=null) {
		    		 detail.setPhone(o[2].toString());
		    	 }
		    	 list.add(detail);
		    }
		return list;
	}
	
	
	
	public String concatArray (List<String> status) {
		StringBuffer str = new StringBuffer();
		for(int i =0 ;i<status.size();i++) {
			str.append("'"+status.get(i)+"'");
			if(i<(status.size()-1)) {
				str.append(",");
			}
		}
		return str.toString();
	}
	
	public String concatArrayDeptId (List<GroupVo> deptList) {
		StringBuffer str = new StringBuffer();
		for(int i =0 ;i<deptList.size();i++) {
			str.append(deptList.get(i).getDeptId());
			if(i<(deptList.size()-1)) {
				str.append(",");
			}
		}
		return str.toString();
	}
	
	/**
	 * 获取请款总记录数
	 * @param reqPayQuery
	 * @return
	 */
	public Integer getReqPaymentTotalSize(ReqPayQuery reqPayQuery){
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(*) as count");
		sql.append(" from TysqA a ");
		sql.append(" left join employee e on e.emplid =a.createrid");
		sql.append(" join TysqType t on a.TysqTypeID =t.TysqTypeID ");
		if(StringUtils.isNotEmpty(reqPayQuery.getDeptName())) {
			if(reqPayQuery.getIsOrShop()!=null) {
				if(reqPayQuery.getIsOrShop().equals("Y")) {
					sql.append(" left join office f on f.office_id = a.deptid");
				}else {
					sql.append(" left join department d on d.deptid = a.deptid");
				}
			}else {
				sql.append(" left join department d on d.deptid = a.deptid");		
			}
		}
//		动态条件
		sql.append(" where a.tysq_type ='"+reqPayQuery.getTysqType()+"'");
		if(reqPayQuery.getBeginTime()!=null) {
			sql.append(" and a.createtime >='"+DateUtil.formatDate(reqPayQuery.getBeginTime(), DateUtil.DATEFORMAT_DATE10)+"'");
		}
		if(reqPayQuery.getEndTime()!=null) {
			sql.append(" and a.createtime <= '"+DateUtil.formatDate(reqPayQuery.getEndTime(), DateUtil.DATEFORMAT_DATE10)+"'");
		}
		if(StringUtils.isNotEmpty(reqPayQuery.getTaskType())) {
			sql.append(" and t.sqlx ='"+reqPayQuery.getTaskType()+"'");
		}
		if(StringUtils.isNotEmpty(reqPayQuery.getVerifyType())) {
			sql.append(" and a.status ='"+reqPayQuery.getVerifyType()+"'");
		}
		if(reqPayQuery.getProcessStatus()!=null) {
			if(reqPayQuery.getProcessStatus().equals("")) {
				sql.append(" and (a.processstatu is null or a.processstatu ='' )");
			}else {
				sql.append(" and a.processstatu ='"+reqPayQuery.getProcessStatus()+"'");
			}
		}

//		针对核销申请对应请款查询
		if(reqPayQuery.getStatus()!=null && reqPayQuery.getStatus().size()>0) {
			sql.append(" and a.status in ("+concatArray(reqPayQuery.getStatus())+")");
			if(reqPayQuery.getRelTysqTypeId()!=null) {
				sql.append(" and a.tysqtypeid ="+reqPayQuery.getRelTysqTypeId());
			}
		}else {
			if(reqPayQuery.getDeptList()!=null && reqPayQuery.getDeptList().size()>0) {
				sql.append(" and ( a.deptId in ("+concatArrayDeptId(reqPayQuery.getDeptList())+") or a.CreaterId ="+reqPayQuery.getEmplId()+")");
			}else {
				sql.append(" and a.CreaterId ="+reqPayQuery.getEmplId()+" ");
			}
		}
		
		if(StringUtils.isNotEmpty(reqPayQuery.getDeptName())) {
			if(reqPayQuery.getIsOrShop().equals("Y")) {
				sql.append(" and f.office_name ='"+reqPayQuery.getDeptName()+"'");
			}else {
				sql.append(" and d.deptname ='"+reqPayQuery.getDeptName()+"'");
			}
		}
		
		
		
		if(StringUtils.isNotEmpty(reqPayQuery.getKeyword())) {
			sql.append(" and (a.com_req_no like '%"+reqPayQuery.getKeyword()+"%'");
			sql.append(" or a.sqzt like '%"+reqPayQuery.getKeyword()+"%' )");
		}
		
		Query query = em.createNativeQuery(sql.toString());
		Integer totalSize = (Integer) query.getSingleResult();
		return totalSize;
	}
	
    /** 
     * 获取实体类 @Column 的其中一个属性名称 
     * 
     * @param clazz 
     * @return 
     */  
    public static String getColumnName(String name,Class<?> clazz) {  
        Field[] fields = clazz.getDeclaredFields();  
        for (Field field : fields) {  
            if (field.isAnnotationPresent(Column.class)) {  
                /** 
                 * 获取字段名 
                 */  
                Column declaredAnnotation = field.getDeclaredAnnotation(Column.class);  
                String column = declaredAnnotation.name();
                if(field.getName().equals(name)) {
                    return column;
                }   
            }  
        }
        return name;
    } 
    
    
    
    /**
	 * 获取核销列表
	 * @param reqPayQuery
	 * @param pageable
	 * @return
	 */
	List<RepaymentVo> getRePaymentList(ReqPayQuery reqPayQuery,Pageable pageable){

		List<RepaymentVo> list = new ArrayList<>();
		StringBuilder sql = new StringBuilder();
	    sql.append("SELECT top (?1) * FROM( ");
	    sql.append("SELECT  ROW_NUMBER() OVER ( ");
//	       动态排序
	   if(pageable.getSort()!=null) {
		   Sort s = pageable.getSort();
		   s.forEach(v ->{
		     sql.append("ORDER BY o."+getColumnName(v.getProperty(),TysqA.class)+" "+v.getDirection());
			   });
	 	}else {
	 		 sql.append("ORDER BY o.createtime desc,o.modify_time desc");
	 	}
	    sql.append(" ) AS rownum, * from ( ");
		sql.append(" select a.*,t.sqlx as comReqType,e.phone,");
		sql.append(" b.status as oriStatus,b.com_req_no as oriComReqNo,");
		sql.append(" b.tysqtypeid as oriTysqTypeId,b.tysqaid as oriTysqAId");
		sql.append(" from TysqA a ");
		sql.append(" join TysqA b on a.ori_tysqa_id = b.tysqaid ");
		sql.append(" left join employee e on e.emplid =a.createrid");
		sql.append(" join TysqType t on a.TysqTypeID =t.TysqTypeID ");
//		动态条件
		sql.append(" where a.tysq_type ='核销'");
		if(reqPayQuery.getBeginTime()!=null) {
			sql.append(" and a.createtime >='"+DateUtil.formatDate(reqPayQuery.getBeginTime(), DateUtil.DATEFORMAT_DATE10)+"'");
		}
		if(reqPayQuery.getEndTime()!=null) {
			sql.append(" and a.createtime <= '"+DateUtil.formatDate(reqPayQuery.getEndTime(), DateUtil.DATEFORMAT_DATE10)+"'");
		}
		if(StringUtils.isNotEmpty(reqPayQuery.getTaskType())) {
			sql.append(" and t.sqlx ='"+reqPayQuery.getTaskType()+"'");
		}
		if(StringUtils.isNotEmpty(reqPayQuery.getVerifyType())) {
			sql.append(" and b.status ='"+reqPayQuery.getVerifyType()+"'");
		}
		if(reqPayQuery.getProcessStatus()!=null) {
			if(reqPayQuery.getProcessStatus().equals("")) {
				sql.append(" and (a.processstatu is null or a.processstatu ='' )");
			}else {
				sql.append(" and a.processstatu ='"+reqPayQuery.getProcessStatus()+"'");
			}
		}
		
		if(reqPayQuery.getDeptList()!=null && reqPayQuery.getDeptList().size()>0) {
			sql.append(" and ( a.deptId in ("+concatArrayDeptId(reqPayQuery.getDeptList())+") or a.CreaterId ="+reqPayQuery.getEmplId()+")");
		}else {
			sql.append(" and a.CreaterId ="+reqPayQuery.getEmplId()+" ");
		}
		
		if(StringUtils.isNotEmpty(reqPayQuery.getKeyword())) {
			sql.append(" and (a.com_req_no like '%"+reqPayQuery.getKeyword()+"%'");
			sql.append(" or b.com_req_no like '%"+reqPayQuery.getKeyword()+"%'");
			sql.append(" or a.sqzt like '%"+reqPayQuery.getKeyword()+"%' )");
		}
		sql.append(") as o ) A WHERE rownum >?2 ");
		Query query = em.createNativeQuery(sql.toString());
		List<Object> paramList = new ArrayList<>();
		  paramList.add(pageable.getPageSize());
		  paramList.add(pageable.getPageSize()*pageable.getPageNumber());
		  int i = 1;
		  for (Object param : paramList) {
			query.setParameter(i, param);
			i++;
		  }
		query.unwrap(SQLQuery.class).addEntity(TysqA.class)
		.addScalar("comReqType",StringType.INSTANCE).addScalar("phone",StringType.INSTANCE)
		.addScalar("oriStatus",StringType.INSTANCE).addScalar("oriComReqNo",StringType.INSTANCE)
		.addScalar("oriTysqTypeId",IntegerType.INSTANCE).addScalar("oriTysqAId",IntegerType.INSTANCE).list();
		 List<Object[]> tysqList= query.getResultList();
		  for(Object[] o : tysqList) {
			  RepaymentVo detail = new RepaymentVo();
		    	 BeanUtils.copyProperties(o[0], detail);
		    	 detail.setComReqType(o[1].toString());
		    	 if(o[2]!=null) {
		    		 detail.setPhone(o[2].toString());
		    	 }
		    	 if(o[3]!=null) {
		    		 detail.setOriStatus(o[3].toString());
		    	 }
		    	 if(o[4]!=null) {
		    		 detail.setOriComReqNo(o[4].toString());
		    	 }
		    	 if(o[5]!=null) {
		    		 detail.setOriTysqTypeId((Integer) o[5]);
		    	 }
		    	 if(o[6]!=null) {
		    		 detail.setOriTysqAId((Integer) o[6]);
		    	 }
		    	 list.add(detail);
		    }
		return list;
	}
	
	
	/**
	 * 获取核销总记录数
	 * @param reqPayQuery
	 * @return
	 */
	public Integer getRePaymentTotalSize(ReqPayQuery reqPayQuery){
		StringBuilder sql = new StringBuilder();
		sql.append(" select count(*) as count");
		sql.append(" from TysqA a ");
		sql.append(" join TysqA b on a.ori_tysqa_id = b.tysqaid ");
		sql.append(" left join employee e on e.emplid =a.createrid");
		sql.append(" join TysqType t on a.TysqTypeID =t.TysqTypeID ");
//		动态条件
		sql.append(" where a.tysq_type ='核销' ");
		if(reqPayQuery.getBeginTime()!=null) {
			sql.append(" and a.createtime >='"+DateUtil.formatDate(reqPayQuery.getBeginTime(), DateUtil.DATEFORMAT_DATE10)+"'");
		}
		if(reqPayQuery.getEndTime()!=null) {
			sql.append(" and a.createtime <= '"+DateUtil.formatDate(reqPayQuery.getEndTime(), DateUtil.DATEFORMAT_DATE10)+"'");
		}
		if(StringUtils.isNotEmpty(reqPayQuery.getTaskType())) {
			sql.append(" and t.sqlx ='"+reqPayQuery.getTaskType()+"'");
		}
		if(StringUtils.isNotEmpty(reqPayQuery.getVerifyType())) {
			sql.append(" and a.status ='"+reqPayQuery.getVerifyType()+"'");
		}
		if(reqPayQuery.getProcessStatus()!=null) {
			if(reqPayQuery.getProcessStatus().equals("")) {
				sql.append(" and (a.processstatu is null or a.processstatu ='' )");
			}else {
				sql.append(" and a.processstatu ='"+reqPayQuery.getProcessStatus()+"'");
			}
		}
		
		if(reqPayQuery.getDeptList()!=null && reqPayQuery.getDeptList().size()>0) {
			sql.append(" and ( a.deptId in ("+concatArrayDeptId(reqPayQuery.getDeptList())+") or a.CreaterId ="+reqPayQuery.getEmplId()+")");
		}else {
			sql.append(" and a.CreaterId ="+reqPayQuery.getEmplId()+" ");
		}
		
		if(StringUtils.isNotEmpty(reqPayQuery.getKeyword())) {
			sql.append(" and (a.com_req_no like '%"+reqPayQuery.getKeyword()+"%'");
			sql.append(" or b.com_req_no like '%"+reqPayQuery.getKeyword()+"%'");
			sql.append(" or a.sqzt like '%"+reqPayQuery.getKeyword()+"%' )");
		}
		
		Query query = em.createNativeQuery(sql.toString());
		Integer totalSize = (Integer) query.getSingleResult();
		return totalSize;
	}
	
}
