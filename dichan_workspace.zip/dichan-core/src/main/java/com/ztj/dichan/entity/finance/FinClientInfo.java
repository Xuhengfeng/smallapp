package com.ztj.dichan.entity.finance;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;
import com.ztj.dichan.enums.BasicSalaryStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 买卖双方信息表
 * 
 * @author zuohuan
 *
 */
@Entity
@Table(name = "fin_client_info")
@Data
@EqualsAndHashCode(callSuper = true)
public class FinClientInfo extends ShardingEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4612318468890789073L;


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fin_client_info_id")
	private Integer id;


	//房屋信息ID
	private Integer finHouseId;
	
	//客户类型
	private String clientType;
	
	//客户姓名
	private String cClientName;
	
	//客户证件类型
	private Integer cCardTypeId;
	
	//客户证件号码
	private String cCardNum;
	
	//客户户籍所在地
	private String cDomicilePlace;
	
	//客户性别
	private String cSex;
	
	//客户婚姻状况
	private Integer cMarrigeId;
	
	//客户是否有子女
	private Boolean cHasChild;
	
	//客户工作单位
	private String cWorkComp;
	
	//客户月收入
	private BigDecimal cSalary;
	
	//客户联系电话
	private String cPhoneNum;
	
	//客户现居住地
	private String cCurAddr;
	
	//客户是否有公积金
	private Boolean cHasFund;
	
	//配偶姓名
	private String pClientName;
	
	//配偶证件类型
	private Integer pCardTypeId;
	
	//配偶证件号码
	private String pCardNum;
	
	//配偶户籍所在地
	private String pDomicilePlace;
	
	//配偶性别
	private String pSex;
	
	//配偶工作单位
	private String pWorkComp;
	
	//配偶工作单位地址
	private String pWorkAddr;
	
	//配偶月收入
	private BigDecimal pSalary;
	
	//配偶联系电话
	private String pPhoneNum;
	
	//配偶是否有公积金
	private Boolean pHasFund;
	
	//担保人姓名
	private String gClientName;
	
	//担保人证件类型
	private Integer gCardTypeId;
	
	//担保人证件号码
	private String gCardNum;
	
	//担保人户籍所在地
	private String gDomicilePlace;
	
	//担保人性别
	private String gSex;
	
	//担保人婚姻状况
	private Integer gMarrigeId;
	
	//担保人是否有子女
	private Boolean gHasChild;
	
	//担保人工作单位
	private String gWorkComp;
	
	//担保人月收入
	private BigDecimal gSalary;
	
	//担保人联系电话
	private String gPhoneNum;
	
	//担保人现居住地
	private String gCurAddr;
	
	//担保人是否 房产担保
	private Boolean gHasHouse;
	
	//担保人房产地址
	private String gHouseAddr;
	
	//担保人房产权证编号
	private String gHouseNo;
	
	//担保人房产面积
	private BigDecimal gHouseArea;
	
	//创建人
	private Integer createId;
	
	//创建时间
	private LocalDateTime createTime;
	
	//修改人
	private Integer lastUpdateId;
	
	//修改时间
	private LocalDateTime lastUpdateTime;

	public String getcClientName() {
		return cClientName;
	}

	public void setcClientName(String cClientName) {
		this.cClientName = cClientName;
	}

	public Integer getcCardTypeId() {
		return cCardTypeId;
	}

	public void setcCardTypeId(Integer cCardTypeId) {
		this.cCardTypeId = cCardTypeId;
	}

	public String getcCardNum() {
		return cCardNum;
	}

	public void setcCardNum(String cCardNum) {
		this.cCardNum = cCardNum;
	}

	public String getcDomicilePlace() {
		return cDomicilePlace;
	}

	public void setcDomicilePlace(String cDomicilePlace) {
		this.cDomicilePlace = cDomicilePlace;
	}

	public String getcSex() {
		return cSex;
	}

	public void setcSex(String cSex) {
		this.cSex = cSex;
	}

	public Integer getcMarrigeId() {
		return cMarrigeId;
	}

	public void setcMarrigeId(Integer cMarrigeId) {
		this.cMarrigeId = cMarrigeId;
	}

	public Boolean getcHasChild() {
		return cHasChild;
	}

	public void setcHasChild(Boolean cHasChild) {
		this.cHasChild = cHasChild;
	}

	public String getcWorkComp() {
		return cWorkComp;
	}

	public void setcWorkComp(String cWorkComp) {
		this.cWorkComp = cWorkComp;
	}

	public BigDecimal getcSalary() {
		return cSalary;
	}

	public void setcSalary(BigDecimal cSalary) {
		this.cSalary = cSalary;
	}

	public String getcPhoneNum() {
		return cPhoneNum;
	}

	public void setcPhoneNum(String cPhoneNum) {
		this.cPhoneNum = cPhoneNum;
	}

	public String getcCurAddr() {
		return cCurAddr;
	}

	public void setcCurAddr(String cCurAddr) {
		this.cCurAddr = cCurAddr;
	}

	public Boolean getcHasFund() {
		return cHasFund;
	}

	public void setcHasFund(Boolean cHasFund) {
		this.cHasFund = cHasFund;
	}

	public String getpClientName() {
		return pClientName;
	}

	public void setpClientName(String pClientName) {
		this.pClientName = pClientName;
	}

	public Integer getpCardTypeId() {
		return pCardTypeId;
	}

	public void setpCardTypeId(Integer pCardTypeId) {
		this.pCardTypeId = pCardTypeId;
	}

	public String getpCardNum() {
		return pCardNum;
	}

	public void setpCardNum(String pCardNum) {
		this.pCardNum = pCardNum;
	}

	public String getpDomicilePlace() {
		return pDomicilePlace;
	}

	public void setpDomicilePlace(String pDomicilePlace) {
		this.pDomicilePlace = pDomicilePlace;
	}

	public String getpSex() {
		return pSex;
	}

	public void setpSex(String pSex) {
		this.pSex = pSex;
	}

	public String getpWorkComp() {
		return pWorkComp;
	}

	public void setpWorkComp(String pWorkComp) {
		this.pWorkComp = pWorkComp;
	}

	public String getpWorkAddr() {
		return pWorkAddr;
	}

	public void setpWorkAddr(String pWorkAddr) {
		this.pWorkAddr = pWorkAddr;
	}

	public BigDecimal getpSalary() {
		return pSalary;
	}

	public void setpSalary(BigDecimal pSalary) {
		this.pSalary = pSalary;
	}

	public String getpPhoneNum() {
		return pPhoneNum;
	}

	public void setpPhoneNum(String pPhoneNum) {
		this.pPhoneNum = pPhoneNum;
	}

	public Boolean getpHasFund() {
		return pHasFund;
	}

	public void setpHasFund(Boolean pHasFund) {
		this.pHasFund = pHasFund;
	}

	public String getgClientName() {
		return gClientName;
	}

	public void setgClientName(String gClientName) {
		this.gClientName = gClientName;
	}

	public Integer getgCardTypeId() {
		return gCardTypeId;
	}

	public void setgCardTypeId(Integer gCardTypeId) {
		this.gCardTypeId = gCardTypeId;
	}

	public String getgCardNum() {
		return gCardNum;
	}

	public void setgCardNum(String gCardNum) {
		this.gCardNum = gCardNum;
	}

	public String getgDomicilePlace() {
		return gDomicilePlace;
	}

	public void setgDomicilePlace(String gDomicilePlace) {
		this.gDomicilePlace = gDomicilePlace;
	}

	public String getgSex() {
		return gSex;
	}

	public void setgSex(String gSex) {
		this.gSex = gSex;
	}

	public Integer getgMarrigeId() {
		return gMarrigeId;
	}

	public void setgMarrigeId(Integer gMarrigeId) {
		this.gMarrigeId = gMarrigeId;
	}

	public Boolean getgHasChild() {
		return gHasChild;
	}

	public void setgHasChild(Boolean gHasChild) {
		this.gHasChild = gHasChild;
	}

	public String getgWorkComp() {
		return gWorkComp;
	}

	public void setgWorkComp(String gWorkComp) {
		this.gWorkComp = gWorkComp;
	}

	public BigDecimal getgSalary() {
		return gSalary;
	}

	public void setgSalary(BigDecimal gSalary) {
		this.gSalary = gSalary;
	}

	public String getgPhoneNum() {
		return gPhoneNum;
	}

	public void setgPhoneNum(String gPhoneNum) {
		this.gPhoneNum = gPhoneNum;
	}

	public String getgCurAddr() {
		return gCurAddr;
	}

	public void setgCurAddr(String gCurAddr) {
		this.gCurAddr = gCurAddr;
	}

	public Boolean getgHasHouse() {
		return gHasHouse;
	}

	public void setgHasHouse(Boolean gHasHouse) {
		this.gHasHouse = gHasHouse;
	}

	public String getgHouseAddr() {
		return gHouseAddr;
	}

	public void setgHouseAddr(String gHouseAddr) {
		this.gHouseAddr = gHouseAddr;
	}

	public String getgHouseNo() {
		return gHouseNo;
	}

	public void setgHouseNo(String gHouseNo) {
		this.gHouseNo = gHouseNo;
	}

	public BigDecimal getgHouseArea() {
		return gHouseArea;
	}

	public void setgHouseArea(BigDecimal gHouseArea) {
		this.gHouseArea = gHouseArea;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
}
