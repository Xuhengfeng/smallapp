package com.ztj.dichan.entity.port;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "net_cost")
@Data
@EqualsAndHashCode(callSuper = true)
public class ManagementPort extends ShardingEntity{
	private static final long serialVersionUID = 643226609123963375L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "net_cost_id")
	private Integer id;
	
	/**
	 *  关联的用户信息  
	 */  
	@Column(name = "empl_id")
	private Integer emplId;
	

	/**
	 * 网络类
	 */
	@Column(name = "net_type")
	private String netType;
	
	/**
	 * 网络账号
	 */
	@Column(name = "net_account")
	private String netAccount;
	
	/**
	 * 套餐类型
	 */
	@Column(name = "cost_prod_type")
	private String costProdType;
	
	/**
	 * 套餐名字
	 */
	@Column(name = "cost_prod_name")
	private String costProdName;
	
	/**
	 * 开始时间
	 */
	@Column(name = "cost_prod_start")
	private LocalDateTime costProdStart;
	
	/**
	 * 结束时间
	 */
	@Column(name = "cost_prod_end")
	private LocalDateTime costProdEnd;
	
	/**
	 * 消费金额
	 */
	@Column(name = "cost_prod_price")
	private BigDecimal costProdPrice;
	
	/**
	 * 状态
	 */
	@Column(name = "cost_prod_status")
	private String costProdStatus;
	
	/**
	 * 创建人
	 */
	@Column(name = "create_id")
	private Integer createId;
	
	/**
	 * 创建时间
	 */
	@Column(name = "create_time")
	private LocalDateTime createTime;
	
	/**
	 * 最后修改人
	 */
	@Column(name="last_update_id")
	private Integer lastUpdater;
	
	/**
	 * 最后修改时间
	 */
	@Column(name="last_update_time")
	private LocalDateTime lastUpdateTime;
	
	/**
	 * 套餐付款方
	 */
	@Column(name="cost_prod_pay")
	private String costProdPay;
}
