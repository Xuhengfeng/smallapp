package com.ztj.dichan.entity.assets;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BindingPic {

	private Integer id;//附件Id
	private String xtwjm;//拼接路径
	private String fjmc;//图片类型
	private String wjm;//图片名称
	private String wjlx;//扩展名
}
