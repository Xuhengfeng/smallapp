package com.ztj.dichan.entity.finance;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "parameter_finance")
@Data
@EqualsAndHashCode(callSuper = true)
public class Parameter extends ShardingEntity {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="param_id")
	private Integer id;//
	
	@Column(name="param_type")
	private String paramType;//参数类型
	
	@Column(name="param_name")
	private String paramName;//参数名称
	
	@Column(name="param_value")
	private String paramValue;//参数值
	
	@Column(name="is_valid")
	private String isValid;//是否有效
	
	@Column(name="create_id")
	private String creater;//创建人
	
	@Column(name="create_time")
	private LocalDateTime CreateTime;//创建时间
	
	@Column(name="last_update_id")
	private String lastUpdater;//最后修改人
	
	@Column(name="last_update_time")
	private LocalDateTime lastUpdateTime;//最后修改时间
}
