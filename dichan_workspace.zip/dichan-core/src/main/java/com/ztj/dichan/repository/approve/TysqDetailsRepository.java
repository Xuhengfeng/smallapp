package com.ztj.dichan.repository.approve;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.dichan.entity.TysqDetails;

@Repository
@Transactional
public interface TysqDetailsRepository extends PagingAndSortingRepository<TysqDetails,Integer>{
	
	List<TysqDetails> findTysqDetailList(Integer id,Integer comReqTypeId);
	
	
	
	
	@Query(" delete TysqDetails t where t.tysqAId = ?1 and t.tysqTypeId =?2")
	void deleteTysqDetails(Integer id,Integer comReqTypeId);

	void deleteTysqDetailsByIds(String ids);
	
	List<TysqDetails> findByTysqAId(Integer tysqAid);
	
	@Query(value ="select * from tysq_details where tysq_details_id in (?1)",nativeQuery =true)
	List<TysqDetails> searchInIds(Integer[] ids);
	
	
	List<TysqDetails> calculateTysqDetails(String field,List<Integer> ids);
	
}


















































































