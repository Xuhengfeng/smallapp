
/**
* @Title: FinEmployeeStatusEnum.java
* @Package com.ztj.dichan.enums.finance
* @Description: TODO 
* @author zuohuan
* @date 2018年7月18日
* @version V1.0
**/
package com.ztj.dichan.enums.finance;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

import com.ztj.dichan.enums.AssetRequestParamEnum;

/**
* @ClassName: FinEmployeeStatusEnum
* @Description: TODO 买卖方
* @author zuohuan
* @date 2018年7月18日
*
**/
public enum ClientTypeEmum implements Serializable{
	ALL("all", "全部", ""),
	BUY("buy", "买方", ""),
    SHELL("shell", "买方", "");

    private String code;

    private String name;
    
    private String desc;

    private ClientTypeEmum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}

	public static ClientTypeEmum queryEnumByName(String name) {
		List<ClientTypeEmum> clientTypeEmums=Arrays.asList(ClientTypeEmum.values());
		for (ClientTypeEmum clientTypeEmum : clientTypeEmums) {
			if(name.equals(clientTypeEmum.getName())) 
				return clientTypeEmum;
		}
		return null;
	}
}
