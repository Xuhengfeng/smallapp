package com.ztj.dichan.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.ztj.dichan.entity.CustWatchPic;


public interface CustWatchPicRepository extends PagingAndSortingRepository<CustWatchPic, Long>{

	CustWatchPic findByImgUrl(String imgUrl);
	
}
