package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 审批路径表
 * 
 */
@Table(name="procepath")
@Entity
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="ProcePath.findAll", query="SELECT p FROM ProcePath p")
public class ProcePath extends ShardingEntity  {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="procepathid")
	private Integer id;

	@Column(name="creater")
	private String createName;

	@Column(name="createrid")
	private Integer createId;

	@Column(name="createtime")
	private String createTime;

	/**
	 * 审批人id
	 */
	@Column(name="emplid")
	private Integer emplId;

	@Column(name="opertype")
	private String operType;

	@Column(name="proceid")
	private Integer proceId;

	@Column(name="procename")
	private String proceName;

	/**
	 * 审批结果
	 */
	@Column(name="proceresult")
	private String proceResult;

	/**
	 * 作业类型表
	 */
	@Column(name="taskid")
	private Integer taskId;

	@Column(name="taskorder")
	private Integer taskOrder;

	/**
	 * 具体业务id
	 */
	@Column(name="workid")
	private Integer workId;
	
	@Column(name="is_read")
	private String isRead;
	
	@Transient
	private String emplName;
	@Transient
	private String taskName;
	@Transient
	private String sendEmplName;
	@Transient
	private String info;
	
	


}