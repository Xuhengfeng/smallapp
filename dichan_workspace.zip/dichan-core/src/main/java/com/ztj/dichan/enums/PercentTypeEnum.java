package com.ztj.dichan.enums;

import java.io.Serializable;

public enum PercentTypeEnum implements Serializable{
	PERSON("persion", "个人", ""),
    GROUP("group", "团队", ""),
    AREA("area","组均",""),
    SHOP("shop","店均","");
	
    private String code;

    private String name;
    
    private String desc;

    private PercentTypeEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}


}
