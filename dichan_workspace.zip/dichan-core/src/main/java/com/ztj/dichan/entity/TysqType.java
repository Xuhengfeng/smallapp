package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 通用申请类型表
 * 
 */
@Table(name="tysqtype")
@Entity
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="TysqType.findAll", query="SELECT t FROM TysqType t")
public class TysqType extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tysqtypeid")
	private Integer id;

	/**
	 * 管理类型
	 */
	@Column(name="gllx")
	private String managementType;

	/**
	 * 申请类型
	 */
	@Column(name="sqlx")
	private String comReqType;

	/**
	 * 申请类型说明
	 */
	@Column(name="sqlxsm")
	private String reqTypeNote;
	
	/**
	 * 判断是否是新系统，默认为Y
	 */
	@Column(name="is_new_sys")
	private String isNewSys;
	
	/**
	 * 审批范围
	 * 集团内部审批；分公司内部；跨集团审批
	 */
	@Column(name="tysq_scope")
	private String tysqScope;
	
	/**
	 * 管理子类型
	 */
	@Column(name="sub_manage_type")
	private String subManageType;
	
	/**
	 * 是否需要核销
	 */
	@Column(name="need_verify")
	private String needVerify;
	
	/**
	 * 是否门店费用申请
	 * Y 是的，N是非门店（包括个人，组别，团体等），为了完成门店费用统计，组织架构上来卡
	 */
	@Column(name="is_shop_type")
	private String isShopType;
	

	/**
	 * 核销设置详情时，限制tysq_details不出现重复字段设置
	 */
	@Column(name="rel_tysqtypeid")
	private Integer relTysqTypeId;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}