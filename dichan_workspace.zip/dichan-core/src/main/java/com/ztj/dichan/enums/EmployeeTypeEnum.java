package com.ztj.dichan.enums;

import java.io.Serializable;

public enum EmployeeTypeEnum implements Serializable{
	
	CURRENT("current", "当前员工", ""),
	ENTRY("entry", "入职员工", ""),
	LEAVE("leave", "离职员工", "");
	
	
	private String code;

    private String name;
    
    private String desc;

    private EmployeeTypeEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    
    public String getCode() {
  		return code;
  	}

  	public String getName() {
  		return name;
  	}

  	public String getDesc() {
  		return desc;
  	}
}
