package com.ztj.dichan.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 字段校验规则表
 * 
 */
@Entity
@Table(name="field_chk_rules")
@Data
@EqualsAndHashCode(callSuper=true)
public class FieldChkRules extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	/**
	 * 主键id
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="field_chk_rule_id")
	private Integer fieldChkRuleId;

	/**
	 * 规则名称
	 */
	@Column(name="field_chk_rule_name")
	private String fieldChkRuleName;

	/**
	 * 字段类型id
	 */
	@Column(name="field_type_id")
	private Integer fieldTypeId;
	
	/**
	 * 文本最小长度
	 */
	@Column(name="min_len")
	private Integer minLen;

	/**
	 * 文本最大长度
	 */
	@Column(name="max_len")
	private Integer maxLen;
	
	/**
	 * 数值最小值
	 */
	@Column(name="min_value")
	private Integer minValue;
	
	/**
	 * 数值最大值
	 */
	@Column(name="max_value")
	private Integer maxValue;
	
	/**
	 * 最小日期
	 */
	@Column(name="min_date")
	private Date minDate;
	
	/**
	 * 最大日期
	 */
	@Column(name="max_date")
	private Date maxDate;
	
	/**
	 * 小数点位数
	 */
	@Column(name="float_len")
	private Integer floatLen;
	
	/**
	 * 正则表达式
	 */
	@Column(name="reg_express")
	private String regExpress;
	
	/**
	 * 备注说明
	 */
	@Column(name="remark")
	private String remark;
	
}