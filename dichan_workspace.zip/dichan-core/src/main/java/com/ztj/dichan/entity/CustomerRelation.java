package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 客户关系表
 */
@Table(name="customerrelation")
@Entity
@Data
@EqualsAndHashCode(callSuper = true)
@NamedQuery(name="CustomerRelation.findAll", query="SELECT c FROM CustomerRelation c")
public class CustomerRelation extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="crid")
	private Integer id;

	@Column(name="custoname")
	private String custoName;

	/**
	 * 业主/客户
	 */
	@Column(name="custotype")
	private String custoType;

	@Column(name="taskid")
	private Integer taskId;

	@Column(name="workid")
	private Integer workId;


}