package com.ztj.dichan.entity.finance;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;
import com.ztj.dichan.enums.BasicSalaryStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 还款明细表
 * 
 * @author zuohuan
 *
 */
@Entity
@Table(name = "fin_return")
@Data
@EqualsAndHashCode(callSuper = true)
public class FinReturn extends ShardingEntity {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4083479440457215104L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fin_return_id")
	private Integer id;

	// 借款申请ID
	private Integer finLoanId;

	//还款人
	private Integer returnEmployeeId;
	
	//还款类型
	private String  returnType;
	
	//还款金额
	private BigDecimal returnAmt;
	
	//还款时间
	private Date returnDate;
	
	//核销人ID
	private Integer verifyId;
	
	//核销人姓名
	private String verifyName;
	
	//核销状态
	private String verifyStatus;
	
	
	//核销时间
	private Date verifyDate;
	
	//创建人
	private Integer createId;
	
	//创建时间
	private LocalDateTime createTime;
	
	//修改人
	private Integer lastUpdateId;
	
	//修改时间
	private LocalDateTime lastUpdateTime;
	
}
