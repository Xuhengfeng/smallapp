package com.ztj.dichan.enums;

import java.io.Serializable;

public enum ManagementStstusEnum implements Serializable {
	

	USE("USE", "使用中", ""),
	COLSE("COLSE", "关闭", "");
	
	private String code;

	private String name;

	private String desc;

	private ManagementStstusEnum(String code, String name, String desc) {
		this.code = code;
		this.name = name;
		this.desc = desc;
	}

	public String getName() {
		return name;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

}
	
