package com.ztj.dichan.entity.finance;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;
import com.ztj.dichan.enums.BasicSalaryStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 出款明细表
 * 
 * @author zuohuan
 *
 */
@Entity
@Table(name = "fin_pay")
@Data
@EqualsAndHashCode(callSuper = true)
public class FinPay extends ShardingEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8731397047478508532L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "fin_pay_id")
	private Integer id;

	// 借款申请ID
	private Integer finLoanId;

	//出款金额
	private BigDecimal payAmt;
	
	//出款时间
	private Date payDate;
	
	//创建人
	private Integer createId;
	
	//创建时间
	private LocalDateTime createTime;
	
	//修改人
	private Integer lastUpdateId;
	
	//修改时间
	private LocalDateTime lastUpdateTime;
	
}
