package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 作业默认流程表
 * 
 */
@Entity
@Data
@Table(name="taskproc")
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="TaskProc.findAll", query="SELECT t FROM TaskProc t")
public class TaskProc extends ShardingEntity  {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="taskprocid")
	private Integer id;

	@Column(name="taskid")
	private Integer taskId;

	@Column(name="taskpname")
	private String taskProceName;

}