package com.ztj.dichan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 字段类型定义表
 * 
 */
@Entity
@Table(name="field_types")
@Data
@EqualsAndHashCode(callSuper=true)
public class FieldTypes extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	/**
	 * 主键id
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="field_type_id")
	private Integer fieldTypeId;

	/**
	 * 字段类型
	 */
	@Column(name="field_type")
	private String fieldType;

	/**
	 * 栏目名称
	 */
	@Column(name="remark")
	private String remark;

}