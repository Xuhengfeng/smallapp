package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 输入选项表
 * @author admin
 *
 */

@Entity
@Table(name ="optionclass")
@Data
@EqualsAndHashCode(callSuper = true)
public class OptionClass extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="optionid")
	private Integer id;

	/**
	 * 创建人
	 */
	@Column(name="creater")
	private String createId;

	
	/**
	 * 创建时间
	 */
	@Column(name="createtime")
	private String createTime;

	/**
	 * 选项名称
	 */
	@Column(name="optionname")
	private String optionName;

	/**
	 * 选项类别
	 */
	@Column(name="optiontype")
	private String optionType;
	
}
	
	