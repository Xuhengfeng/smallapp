package com.ztj.dichan.repository.approve;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.dichan.entity.TysqA;

/**
 * 通用申请a
 * @author zhouqiao
 *
 */
@Repository
@Transactional
public interface TysqARepository extends PagingAndSortingRepository<TysqA,Integer>{

	
	/**
	 * 查询已经通过审批的核销申请
	 * @param tysqaId
	 * @return
	 */
	  @Query(value="select t from TysqA t where oriTysqaId =? and processStatus ='审批完成' and tysqType ='核销'")
	  List<TysqA> searchVerifyTysqaList(Integer tysqaId);
	  
	
	  
	  
	  TysqA findByIdAndProcessStatus(Integer id,String processStatus);
	  
	 /**
	  * 查询请款有几条核销完成的记录
	  * @param oriTysqaId
	  * @param tysqType
	  * @param processStatus
	  * @return
	  */
	  List<TysqA> findTysqAByOriTysqaIdAndTysqTypeAndProcessStatus (Integer oriTysqaId,String tysqType,String processStatus);
	  
	  
	  /**
	   * 查询请款有几条核销完成的记录
	   * @param oriTysqaId
	   * @param processStatus
	   * @return
	   */
	  List<TysqA> findTysqAByOriTysqaIdAndProcessStatus(Integer oriTysqaId,String processStatus);
	  
	  
	/**
	 * 删除tysqa记录
	 * @param id
	 */
	void deleteTysqaByIds(List<Integer> ids);
	
	
}
