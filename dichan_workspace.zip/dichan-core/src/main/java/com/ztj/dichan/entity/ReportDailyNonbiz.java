package com.ztj.dichan.entity;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 非业务日报表
 * @author zhouqiao
 */

@Entity
@Table(name="report_daily_nonbiz")
@Data
@EqualsAndHashCode(callSuper=true)
public class ReportDailyNonbiz extends ShardingEntity implements Serializable{
	private static final long serialVersionUID = 1L;
	  	@Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long id;
	  	
	  	private String cityName;
	  	
		/**
		 * 获取数据的所属日期
		 */
		private java.sql.Date reportDate;
	  	
		/**
		 * 当前总人数
		 */
	  	private Long emplTotalNum;
	  	
	  	/**
	  	 * 入职人数
	  	 */
	  	private Long emplJoinNum;
	  	
	  	/**
	  	 * 离职人数
	  	 */
	  	private Long emplDimmisionNum;
	  	
		/**
		 * 创建人
		 * 第一次自动跑:AUTO_JOB
		 *自动重跑：RETRY_JOB
		 *人工重跑：操作员工
		 */
		private Long createId;
		
	    /**
	     * 创建时间
	     */
	    private LocalDateTime createDateTime;

	    /**
	     * 修改时间
	     */
	    private LocalDateTime lastUpdateTime;
	  	
	  	/**
	  	 * 修改人
	  	 */
	    private Long lastUpdateId;
	  	
	  	
	  	
	    @Transient
	    private Date beginDate;
	    
	    @Transient
	    private Date endDate;
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
	  	
}
