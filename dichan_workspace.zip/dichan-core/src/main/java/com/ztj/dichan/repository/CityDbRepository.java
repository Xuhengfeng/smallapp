package com.ztj.dichan.repository;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.CityDb;

@Repository
public interface CityDbRepository extends PagingAndSortingRepository<CityDb, Integer>{
	
	public CityDb findByCityNamePy(String cityNamePy);
	
}
