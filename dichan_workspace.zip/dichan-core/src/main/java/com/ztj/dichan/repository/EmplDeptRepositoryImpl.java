package com.ztj.dichan.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LocalDateTimeType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.Department;
import com.ztj.dichan.vo.ContractDetailVo;

@Repository
public class EmplDeptRepositoryImpl {
private Logger logger = LoggerFactory.getLogger(getClass());
	
	@PersistenceContext
	private EntityManager em;
	
	
	

	 public List<Department> queryAuthDept(Integer emplId){
		 List<Department> deptList = new ArrayList<>();
		 StringBuilder sql = new StringBuilder();
		 sql.append(" select DISTINCT d.deptid as id,d.addr,d.areaid as areaId,d.createtime  as createTime,"
		 		+ "d.deptname as deptName,d.parentid as parentId ,d.modify_time as modifyTime  from EmplDept eml "
		 		+ "join Department d on eml.deptId=d.deptid and eml.emplId ="+emplId);
		 
		 Query query = em.createNativeQuery(sql.toString());
		  query.unwrap(SQLQuery.class).addScalar("id", IntegerType.INSTANCE).addScalar("addr", StringType.INSTANCE)
			.addScalar("areaId", IntegerType.INSTANCE).addScalar("createTime",StringType.INSTANCE)
			.addScalar("deptName",StringType.INSTANCE).addScalar("parentId",IntegerType.INSTANCE)
			.addScalar("modifyTime",LocalDateTimeType.INSTANCE).setResultTransformer(Transformers.aliasToBean(Department.class));
		  deptList =query.getResultList();
		  return deptList;
	 }
}
