package com.ztj.dichan.repository.approve;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.dichan.entity.TysqA;
import com.ztj.dichan.vo.approve.RepaymentVo;
import com.ztj.dichan.vo.approve.ReqPayQuery;
import com.ztj.dichan.vo.approve.ReqPaymentVo;


@Repository

public interface ReqPaymentRepository extends PagingAndSortingRepository<TysqA,Long> {
	
	public List<ReqPaymentVo> getReqPaymentList(ReqPayQuery reqPayQuery,Pageable pageable);
	
	public Integer getReqPaymentTotalSize(ReqPayQuery reqPayQuery);
	
	
//	核销记录
	public List<RepaymentVo> getRePaymentList(ReqPayQuery reqPayQuery,Pageable pageable); 
	
	
//	核销总条数
	public Integer getRePaymentTotalSize(ReqPayQuery reqPayQuery);
	
//	
//	public void  add(Map<String,Object> tysqDetails);
//	
//	public void upate(Map<String,Object> tysqDetails);
}
