package com.ztj.dichan.entity;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ztj.dichan.enums.ShardingKeyType;
import com.ztj.dichan.util.SdidKeyGenerator;

import lombok.Data;

@MappedSuperclass  
@Data
public class ShardingEntity implements Serializable{
	private static final long serialVersionUID = 1L;
	 static final SdidKeyGenerator generator = new SdidKeyGenerator();
		
		protected Long  sdid;
		
		protected String scity;
		
		public ShardingEntity() {
			this.sdid = generator.generateKey().longValue();
		}
		
//		public void setSdid(ShardingKeyType type) {
//			if (type == null) {
//				this.sdid = null;
//			}
//			else {
//				this.sdid = generator.generateKey(type).longValue();
//			}
//			
//		}
		
		public void setSdidByType(ShardingKeyType type) {
			if (type == null) {
				this.sdid = null;
			}
			else {
				this.sdid = generator.generateKey(type).longValue();
			}
		}

	//@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name="modify_time")
	protected LocalDateTime modifyTime=LocalDateTime.now();
	
	
	
}
