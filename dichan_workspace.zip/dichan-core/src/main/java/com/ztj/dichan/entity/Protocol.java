package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;


/**
 *合同表
 * 
 */
@Table(name="protocol")
@Data
@Entity
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="Protocol.findAll", query="SELECT p FROM Protocol p")
public class Protocol extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="contid")
	private Integer id;

	/**
	 * 附加条款
	 */
	@Column(name="addnote")
	private String extraNote;

	/**
	 * 物业地址
	 */
	@Column(name="addr")
	private String houseAddr;

	/**
	 * 当前售后流程id
	 */
	@Column(name="aftersaleid")
	private Integer saleServiceFlowId;

	@Column(name="areaid")
	private Integer areaId;

	@Column(name="areaname")
	private String areaName;

	/**
	 * 甲方中介费
	 */
	@Column(name="aservicefee")
	private BigDecimal aServiceFee;

	/**
	 * 评估费
	 */
	@Column(name="assessfee")
	private BigDecimal assessFee;

	/**
	 * 按揭银行
	 */
	@Column(name="bank")
	private String bank;

	@Column(name="bankid")
	private Integer bankId;

	/**
	 * 乙方中介费
	 */
	@Column(name="bservicefee")
	private BigDecimal bServiceFee;

	@Column(name="buildid")
	private Integer buildId;

	@Column(name="buildname")
	private String buildName;

	@Column(name="builtarea")
	private BigDecimal builtArea;

	/**
	 * 是否包税
	 */
	@Column(name="containtax")
	private String isContainTax;

	/**
	 * 合同编号
	 */
	@Column(name="contno")
	private String contNo;

	/**
	 * 签约人
	 */
	@Column(name="contractor")
	private String contractor;

	@Column(name="creater")
	private String creater;

	@Column(name="createrid")
	private Integer createrId;

	@Column(name="createtime")
	private String createTime;

	/**
	 * 客户地址
	 */
	@Column(name="custoaddr")
	private String custoAddr;

	/**
	 * 客户身份证号码
	 */
	@Column(name="custocard")
	private String custoCard;

	@Column(name="custoid")
	private Integer custoId;

	@Column(name="customerid")
	private Integer customerId;

	@Column(name="custoname")
	private String custoName;

	/**
	 *业主净收价
	 */
	@Column(name="custoprice")
	private BigDecimal custoPrice;

	/**
	 *客户来源
	 */
	@Column(name="custosource")
	private String custoSource;


	@Column(name="custotel")
	private String custoTel;

	/**
	 * 诚意金id
	 */
	@Column(name="cyjid")
	private Integer sincerityId;

	/**
	 * 是否达到收佣标准
	 */
	@Column(name="ddsybz")
	private String isStandard;

	/**
	 *签约时间
	 */
	@Column(name="dealdate")
	private String dealDate;

	/**
	 * 签约部门ID
	 */
	@Column(name="deptid")
	private Integer deptId;

	/**
	 * 一级部门
	 */
	@Column(name="deptid1")
	private Integer deptId1;

	/**
	 * 二级部门
	 */
	@Column(name="deptid2")
	private Integer deptId2;

	/**
	 * 三级部门
	 */
	@Column(name="deptid3")
	private Integer deptId3;

	/**
	 * 四级部门
	 */
	@Column(name="deptid4")
	private Integer deptId4;

	/**
	 * 片区id
	 */
	@Column(name="districtid")
	private Integer districtId;

	@Column(name="districtname")
	private String districtName;

	/**
	 * 贷款金额
	 */
	@Column(name="dkje")
	private BigDecimal creditAmount;

	/**
	 * 分配比例确认人
	 */
	@Column(name="fpblqrr")
	private String distrRatioConfirmName;

	/**
	 * 分配比例确认人id
	 */
	@Column(name="fpblqrrid")
	private Integer distrRatioConfirmId;

	/**
	 * 分配比例确认日期
	 */
	@Column(name="fpblqrrq")
	private String distrRatioConfirmdate;

	/**
	 * 户型
	 */
	@Column(name="househx")
	private String houseForm;

	@Column(name="houseid")
	private Integer houseId;

	/**
	 * 房屋结构
	 */
	@Column(name="housestru")
	private String houseStru;

	@Column(name="housetype")
	private String houseType;

	/**
	 * 物业类别（用途）
	 */
	@Column(name="houseuse")
	private String houseUse;

	/**
	 * 套内面积
	 */
	@Column(name="innerarea")
	private BigDecimal innerArea;

	/**
	 * 结利状态
	 */
	@Column(name="jlzt")
	private String completeMoneyStatus;

	/**
	 * 楼层
	 */
	@Column(name="lcname")
	private Integer floorNum;

	/**
	 * 按揭费
	 */
	@Column(name="mortgfee")
	private BigDecimal mortgFee;

	/**
	 * 年度奖项
	 */
	@Column(name="ndjx")
	private String annualPrize;

	/**
	 * 其他约定应收
	 */
	@Column(name="otherfee")
	private BigDecimal otherFee;

	/**
	 * 业主地址
	 */
	@Column(name="owneraddr")
	private String ownerAddr;

	/**
	 * 业主身份证
	 */
	@Column(name="ownercard")
	private String ownerCard;

	@Column(name="ownerid")
	private Integer ownerId;

	@Column(name="ownername")
	private String ownerName;

	/**
	 * 业主来源
	 */
	@Column(name="ownersource")
	private String ownerSource;

	@Column(name="ownertel")
	private String ownerTel;

	/**
	 * 付款方式
	 */
	@Column(name="paytype")
	private String payType;

	@Column(name="price")
	private BigDecimal price;

	@Column(name="procename")
	private String proceName;

	@Column(name="procepathid")
	private Integer procePathId;

	@Column(name="ProcessStatu")
	private String processStatu;

	/**
	 * 缺资料说明
	 */
	@Column(name="qzlsm")
	private String lackDocNote;


	@Column(name="sfkp")
	private String sfkp;

	/**
	 * 售后经办人id
	 */
	@Column(name="shjbrid")
	private Integer saleServiceId;

	/**
	 * 售后经办人姓名
	 */
	@Column(name="shjbrname")
	private String saleServiceName;

	/**
	 * 售后类型
	 */
	@Column(name="shlx")
	private String saleServiceType;

	/**
	 * 独家调入ID
	 */
	@Column(name="solesaleid")
	private int soleSaleId;

	/**
	 * 审批截止时间
	 */
	@Column(name="spjzsj")
	private String terminApproveTime;

	/**
	 * 审批人id
	 */
	@Column(name="sprid")
	private Integer approverId;
	
	/**
	 * 审批人名字
	 */
	@Column(name="sprname")
	private String approverName;

	@Column(name="statu")
	private String status;

	/**
	 * 状态时间
	 */
	@Column(name="statutime")
	private String statusTime;

	/**
	 * 提交审批时间
	 */
	@Column(name="tjspsj")
	private String applyApproveTime;

	/**
	 * 总楼层
	 */
	@Column(name="totalfloor")
	private Integer totalFloor;

	/**
	 * 交易类别
	 */
	@Column(name="tradetype")
	private String tradeType;

	/**
	 * 过户日期
	 */
	@Column(name="transferdate")
	private String transferDate;

	/**
	 * 过户方式
	 */
	@Column(name="transfermode")
	private String transferMode;

	/**
	 * 权证费
	 */
	@Column(name="warrantfee")
	private BigDecimal warrantFee;

	/**
	 * 权证费是否收取
	 */
	@Column(name="warrantrec")
	private String isWarrantRec;

	/**
	 * 未达账
	 */
	@Column(name="wdz")
	private BigDecimal moneynpay;


	@Column(name="xfid")
	private Integer xfid;

	/**
	 * 业绩分配说明
	 */
	@Column(name="yjfpsm")
	private String incomeDistrNote;
	
	/**
	 * 预留总费用
	 */
	@Column(name="reserve_fee")
	private BigDecimal reserveFee;
	
	
	
}