package com.ztj.dichan.entity.assets;

import java.util.List;

import lombok.Data;

@Data
public class ResponseOffice {

	private Office office;
	
	private List<BindingPic> bindList;
}
