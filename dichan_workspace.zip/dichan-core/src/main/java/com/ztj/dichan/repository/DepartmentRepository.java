package com.ztj.dichan.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.Department;
import com.ztj.dichan.vo.employee.TreeVo;
import com.ztj.dichan.entity.Employee;
import com.ztj.dichan.vo.city.GroupVo;

@Repository
public interface DepartmentRepository extends PagingAndSortingRepository<Department, Integer>{

	List<Department> findByDeptLevelAndDeptNameInAndScity(String deptLevel, List<String> shopNameList, String scity);
	
	
	Department findByDeptName(String deptName);

	@Query(value="SELECT d.* FROM EmplDept eml, Department d, Department d2  "
			+ "WHERE eml.deptId = d.DeptID "
			+ " AND eml.emplId =?1 "
			+ " AND d.deptLevel = '组别' and d.is_biz_team='Y'"
			+ " AND d2.DeptID = d.parentId AND "
			+ " d2.deptLevel = '门店' "
			+ " and d.scity=?2",nativeQuery = true)
	List<Department> getUserdministerGroup(Integer employeeId, String scity);

	List<Department> getUserdministerAreaDeptIds(String deptLevel, Integer employeeId, String scity);
	
	Department findByIdAndScity(Integer deptId, String scity);

	List<Integer> queryAllShopByeara(Integer earaDeptId,String parentLevel,String deptLevel, String scity);

	List<Department> findByOfficeIdAndIsBizTeam(Integer officeId, String isBizTeam);

	@Query(value="select DeptID from Department where (parentID=0 or DeptName='集团人员') and scity=?1",nativeQuery=true)
	Set<Integer> queryBlocIds(String scity);
	
	@Query(value="select DeptID from Department where DeptName='集团人员' and scity=?1",nativeQuery=true)
	Integer queryBlocId(String scity);
	
	@Query(value="select DeptID from Department where (DeptTree like CONCAT('%',?1,'%')) and scity=?2",nativeQuery=true)
	Set<Integer> queryBlocChildDeptIds(String blocId1, String scity);

	@Query(value="SELECT COUNT (DeptID) FROM Department  WHERE "
			+ "ParentID IN ( SELECT DeptID FROM Department WHERE ParentID =?1 ) AND LeaderID != ?2 and scity=?3",nativeQuery=true)
	Integer queryDenominatorCount(Integer id, Integer leaderId, String scity);

	@Query(value="select * from Department",nativeQuery=true)
	Iterable<Department> findList();


	List<TreeVo> deptTreeList(String scity);


	List<GroupVo> getGroupListByType(Employee user, String type);


}
