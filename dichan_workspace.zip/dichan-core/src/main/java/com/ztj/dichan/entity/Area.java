package com.ztj.dichan.entity;

import javax.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.math.BigDecimal;
import java.time.LocalDateTime;


/**
 * 区域相关信息
 * 
 */
@Entity
@Table(name="area")
@Data
@EqualsAndHashCode(callSuper=true)
public class Area extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	/**
	 * 区域id 自动生成
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="areaid")
	private Integer id;

	/**
	 * 区域名
	 */
	@Column(name="areaname")
	private String name;

	/**
	 * 创建人
	 */
	@Column(name="creater")
	private String creater;

	/**
	 * 创建时间
	 */
	@Column(name="createtime")
	private String createTime;

	/**
	 * 东经
	 */
	@Column(name="px")
	private BigDecimal px;

	/**
	 * 北纬
	 */
	@Column(name="py")
	private BigDecimal py;

	/**
	 * 最后修改员工id
	 *//*
	private Long lastUpdateId;
	
	*//**
	 * 最后修改时间
	 *//*
	private LocalDateTime lastUpdateTime;*/
}