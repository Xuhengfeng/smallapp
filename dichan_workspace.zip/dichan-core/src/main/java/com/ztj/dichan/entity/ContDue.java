package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;


/**
 * 合同应收款表
 */
@Data
@Table(name="contdue")
@Entity
@EqualsAndHashCode(callSuper = true)
@NamedQuery(name="ContDue.findAll", query="SELECT c FROM ContDue c")
public class ContDue extends ShardingEntity {
	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="dueid")
	private Integer id;

	/**
	 * 核实日期
	 */
	@Column(name="checkdate")
	private String checkDate;

	/**
	 * 合同id
	 */
	@Column(name="contid")
	private Integer contId;

	/**
	 * 应收款金额
	 */
	@Column(name="cost")
	private BigDecimal cost;

	/**
	 *项目id
	 */
	@Column(name="costitemid")
	private Integer costItemId;

	/**
	 * 客户关系表id
	 */
	@Column(name="crid")
	private Integer crid;

	/**
	 * 应收款日期
	 */
	@Column(name="duedate")
	private String dueDate;

	@Column(name="duetype")
	private String dueType;

	@Column(name="emplid")
	private Integer emplId;

	@Column(name="emplname")
	private String emplName;

}