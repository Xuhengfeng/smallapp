package com.ztj.dichan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 字段类型定义表
 * 
 */
@Entity
@Table(name="field_set_values")
@Data
@EqualsAndHashCode(callSuper=true)
public class FieldSetValues extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	/**
	 * 主键id
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="field_set_value_id")
	private Integer fieldSetValueId;

	/**
	 * field_chk_rules表的id
	 */
	@Column(name="field_chk_rule_id")
	private Integer fieldChkRuleId;
	
	/**
	 * 下拉值
	 */
	@Column(name="set_value")
	private String setValue;
	
	/**
	 * 显示顺序
	 */
	@Column(name="order_num")
	private Integer orderNum;

}