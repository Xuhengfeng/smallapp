package com.ztj.dichan.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 通用申请主表
 * 
 */
@Table(name="tysqa")
@Entity
@Data
@EqualsAndHashCode(callSuper=true)
@NamedQuery(name="TysqA.findAll", query="SELECT t FROM TysqA t")
public class TysqA extends ShardingEntity{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tysqaid")
	private Integer id;

	@Column(name="creater")
	private String createName;

	@Column(name="createrid")
	private Integer createId;

	@Column(name="createtime")
	private String createTime;

	@Column(name="deptid")
	private Integer deptId;

	@Column(name="procename")
	private String proceName;

	@Column(name="procepathid")
	private Integer procePathId;

	@Column(name="processstatu")
	private String processStatus;

	/**
	 * 审批人id
	 */
	@Column(name="sprid")
	private Integer approverId;

	@Column(name="sprname")
	private String approverName;

	/**
	 * 申请说明
	 */
	@Column(name="sqsm")
	private String reqNote;

	/**
	 * 申请主题
	 */
	@Column(name="sqzt")
	private String reqSubject;

	/**
	 * 通用申请类型id
	 */
	@Column(name="tysqtypeid")
	private Integer comReqTypeId;
	
	/**
	 * 通用申请编号
	 */
	@Column(name="com_req_no")
	private String comReqNo;
	
	/**
	 * 是否门店费用申请
	 * 当新建审批时，从TysqType中取得，前端当为Y,部门选择（Office表Office_id关联），N（部门ID，与部门表(Department)的DeptID关联）
	 */
	@Column(name="is_shop_type")
	private String isShopType;
	
	/**
	 * 针对请款申请：空，未还款（审批完成），部分还款，还清
	 */
	@Column(name="status")
	private String status;
	
	/**
	 * 请款id
	 * 针对核销，核销对应的请款,当核销时，选择请款
	 */
	@Column(name="ori_tysqa_id")
	private Integer oriTysqaId;
	
	/**
	 * 请款类型
	 * 请款申请-->请款，核销申请-->核销
	 */
	@Column(name="tysq_type")
	private String tysqType;
	
	/**-------------新增属性
	 * 所在店名
	 */
	@Transient
	private String storeName;
	
	/**
	 * 申请类型的名称
	 */
	@Transient
	private String typeName;
	
	/**
	 * 审批的时间
	 */
	@Transient
	private String approveTime;
	
	/**
	 * 审批的结果
	 */
	@Transient
	private String result;
	
}