package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 部门片区
 * 
 */
@Entity
@Table(name="deptdist")
@Data
@EqualsAndHashCode(callSuper=true)
public class DeptDist extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="deptdistid")
	private Integer id;

	@Column(name="creater")
	private String createId;

	@Column(name="createtime")
	private String createTime;

	@Column(name="deptid")
	private Integer deptId;

	@Column(name="districtid")
	private Integer districtId;

}