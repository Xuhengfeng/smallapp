package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.time.LocalDateTime;


/**
 * 片区表
 */
@Entity
@Table(name ="district")
@Data
@EqualsAndHashCode(callSuper=true)
public class District extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	/**
	 * 片区 ID 
	 * 自动增长
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="districtid")
	private Integer id;

	
	/**
	 * 区域id
	 */
	@Column(name="areaid")
	private Integer areaId;

	/**
	 * 创建人
	 */
	@Column(name="creater")
	private String creater;

	/**
	 * 创建时间
	 */
	@Column(name="createtime")
	private String createTime;

	/**
	 * 片区名字
	 */
	@Column(name="districtname")
	private String name;

	/**
	 * 东经
	 */
	@Column(name="px")
	private BigDecimal px;

	/**
	 * 北纬
	 */
	@Column(name="py")
	private BigDecimal py;

	/**
	 * 再租数量
	 */
	@Column(name="rentcount")
	private Integer rentcount;

	/**
	 * 在售数量
	 */
	@Column(name="salecount")
	private Integer salecount;
	/**
	 * 最后修改员工id
	 *//*
	private Long lastUpdateId;
	
	*//**
	 * 最后修改时间
	 *//*
	private LocalDateTime lastUpdateTime;*/
	

	
	
	
}