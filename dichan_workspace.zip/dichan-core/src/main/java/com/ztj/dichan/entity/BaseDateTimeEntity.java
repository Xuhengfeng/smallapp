package com.ztj.dichan.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.MappedSuperclass;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 基本的时间实体对象,只定义公共的时间属性
 *
 * @author test01
 */
@MappedSuperclass
@Data
@EqualsAndHashCode(callSuper = true)
public class BaseDateTimeEntity extends BaseEntity {
    private static final long serialVersionUID = 1L;
    	

    /**
     * 创建时间
     */
    protected LocalDateTime createDateTime = LocalDateTime.now();

    /**
     * 修改时间
     */
    protected LocalDateTime updateDateTime;
    
    
}
