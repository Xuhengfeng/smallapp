package com.ztj.dichan;

/**
 * 全局常量类
 * @author xiecheng
 */
public class GlobalConstants {
	
	// 全局配置数据库的名称，里面存在三个重要的配置表，syslogin, city_db,            table_info 
	public static final String GlobalConfigDBName="master2";
	            
}
