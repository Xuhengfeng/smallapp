package com.ztj.dichan.repository.approve;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;
import com.ztj.dichan.entity.FieldChkRules;
import com.ztj.dichan.entity.TysqType;

@Repository
public class TysqTypeRepositoryImpl {

	@PersistenceContext
	private EntityManager em;
	
	List<TysqType> queryTysqType(String subManageType,String emplAcco,String scity){
		List<TysqType> tysqtypeList = new ArrayList<>();
		StringBuffer sql = new StringBuffer();
		sql.append("select * from tysqtype where sub_manage_type ='"+subManageType+"' ");
		sql.append(" and is_new_sys ='Y' ");
		if(scity.equals("jituan") && emplAcco.startsWith("18")) {
			sql.append(" and tysq_scope ='集团内部审批' ");
		}
		Query query = em.createNativeQuery(sql.toString());
		query.unwrap(SQLQuery.class).addEntity(TysqType.class).list();
		tysqtypeList = query.getResultList();
		return tysqtypeList;
		
	}
	
}
