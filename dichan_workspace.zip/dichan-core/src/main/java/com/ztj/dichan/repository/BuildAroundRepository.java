package com.ztj.dichan.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.ztj.dichan.entity.BuildAround;

public interface BuildAroundRepository extends PagingAndSortingRepository<BuildAround, Long> {

}
