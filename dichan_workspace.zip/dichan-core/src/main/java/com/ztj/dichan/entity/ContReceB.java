package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;


/**
 * 合同收款子款B
 * 
 */
@Data
@Table(name="contreceb")
@Entity
@EqualsAndHashCode(callSuper = true)
@NamedQuery(name="ContReceB.findAll", query="SELECT c FROM ContReceB c")
public class ContReceB extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="recptbid")
	private Integer id;

	@Column(name="amount")
	private BigDecimal amount;

	@Column(name="bankamount")
	private BigDecimal bankAmount;

	/**
	 * 结利缺人日期
	 */
	@Column(name="confirmdate")
	private String confirmDate;

	/**
	 * 项目id
	 */
	@Column(name="costitemid")
	private Integer costItemId;

	/**
	 * 应收id
	 */
	@Column(name="dueid")
	private Integer dueId;

	@Column(name="emplid")
	private Integer emplId;

	@Column(name="emplname")
	private String emplName;

	/**
	 * 合同收款主表id
	 */
	@Column(name="recptid")
	private Integer recptId;

	@Column(name="remark")
	private String remark;

}