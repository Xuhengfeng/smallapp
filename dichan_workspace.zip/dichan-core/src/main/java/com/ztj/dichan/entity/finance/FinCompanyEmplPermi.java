
/**
* @Title: FinCompanyEmplPermi.java
* @Package com.ztj.dichan.entity.finance
* @Description: TODO 
* @author zuohuan
* @date 2018年7月18日
* @version V1.0
**/
package com.ztj.dichan.entity.finance;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
* @ClassName: FinCompanyEmplPermi
* @Description: TODO 公司员工管辖范围
* @author zuohuan
* @date 2018年7月18日
*
**/
@Entity
@Table(name = "fin_company_empl_permi")
@Data
@EqualsAndHashCode(callSuper = true)
public class FinCompanyEmplPermi extends ShardingEntity{
	/**
	* @Fields field:field:{todo}
	**/
	private static final long serialVersionUID = -1173136807304850817L;

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "company_empl_permi_id")
	private Integer id;

	//员工ID  绑定员工表
	private Integer emplId;
	
	//所属公司ID
	private Integer finCompanyId;
	
	//创建人
	private Integer createId;
	
	//创建时间
	@Column(name="create_time")
	private LocalDateTime createTime;
	
	//修改人
	private Integer lastUpdateId;
	
	//修改时间
	private LocalDateTime lastUpdateTime;
}
