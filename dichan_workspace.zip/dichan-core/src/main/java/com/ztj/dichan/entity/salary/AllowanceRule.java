package com.ztj.dichan.entity.salary;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 津贴规则信息
 * 
 * @author test01
 */
 @Entity
 @Table(name = "allowance_rule")
@Data
@EqualsAndHashCode(callSuper = true)
public class AllowanceRule extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "salary_allowance_rule_id")
	private Integer id;

	/**
	 * 津贴类别id
	 */
	private Integer allowanceTypeId;

	/**
	 * 业绩起始
	 */
	private BigDecimal incomingStart;

	/**
	 * 业绩结束
	 */
	private BigDecimal incomingEnd;
	
	/**
	 * 津贴金额
	 */
	private BigDecimal allowanceAmt;

	/**
	 * 备注
	 */
	private String note;

	/**
	 * 创建人
	 */
	private Long createId;

	/**
	 * 创建时间
	 */
	private LocalDateTime createTime;

	/**
	 * 最后修改员工id
	 */
	private Long lastUpdateId;

	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime;
}