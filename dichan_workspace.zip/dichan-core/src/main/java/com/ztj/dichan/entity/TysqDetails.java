package com.ztj.dichan.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 通用申请详情表
 * @author zhouqiao
 *
 */

@Table(name="tysq_details")
@Entity
@Data
@EqualsAndHashCode(callSuper=true)
public class TysqDetails extends ShardingEntity{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tysq_details_id")
	private Integer id;
	
	
	@Column(name="tysq_a_id")
	private Integer tysqAId;
	
	@Column(name="tysq_type_id")
	private Integer tysqTypeId;

	/**
	 * 短文本
	 */
	@Column(name="text1")
	private String text1;
	
	@Column(name="text2")
	private String text2;
	
	@Column(name="text3")
	private String text3;
	
	@Column(name="text4")
	private String text4;
	@Column(name="text5")
	/**
	 * 中文本
	 */
	private String text5;
	@Column(name="text6")
	private String text6;
	@Column(name="text7")
	private String text7;
	@Column(name="text8")
	private String text8;
	@Column(name="text9")
	private String text9;
	
	/**
	 * 长文本
	 */
	@Column(name="text10")
	private String text10;
	@Column(name="text11")
	private String text11;
	@Column(name="text12")
	private String text12;
	@Column(name="text13")
	private String text13;
	@Column(name="text14")
	private String text14;
	
	
	//追加	
	@Column(name="text20")
	private String text20;
	@Column(name="text21")
	private String text21;
	@Column(name="text22")
	private String text22;
	@Column(name="text23")
	private String text23;
	@Column(name="text24")
	private String text24;
	@Column(name="text25")
	private String text25;
	@Column(name="text26")
	private String text26;
	@Column(name="text27")
	private String text27;
	@Column(name="text28")
	private String text28;
	@Column(name="text29")
	private String text29;
	@Column(name="text30")
	private String text30;
	
	private Date date1;
	
	private Date date2;
	
	private Date date3;
	
	private Date date4;
	
	private LocalDateTime datetime1;
	
	private LocalDateTime datetime2;
	
	private LocalDateTime datetime3;
	
	private LocalDateTime datetime4;
	
	private Long number1;
	
	private Long number2;
	
	private Long number3;
	
	private Long number4;
	
	private Long number5;
	
	private Long number6;
	
//追加	
	private Long number7;
	
	private Long number8;
	
	private Long number9;
	
	private Long number10;
	
	private Long number11;
	
	private Long number12;
	
	private Long number13;
	
	private Long number14;
	
	
	private BigDecimal amount1;
	
	private BigDecimal amount2;
	
	private BigDecimal amount3;
	
	private BigDecimal amount4;
	
	private BigDecimal amount5;
	
	private BigDecimal amount6;
	
	
	//追加	
	private BigDecimal amount7;
	
	private BigDecimal amount8;
	
	private BigDecimal amount9;
	
	private BigDecimal amount10;
	
	private BigDecimal amount11;
	
	private BigDecimal amount12;
	
	
	@Column(name="create_id")
	private Integer createId;
	
	@Column(name="create_time")
	private LocalDateTime createTime;
	
	@Column(name="last_update_id")
	private Integer lastUpdateId;
	
	@Column(name="last_update_time")
	private LocalDateTime lastUpdateTime;
	
	
	/**
	 * 未核销金额
	 */
	@javax.persistence.Transient
	private BigDecimal notReturnAmount;
	
	
}


