package com.ztj.dichan.entity.assets;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestOffice {

	private String city_list;
	private String startBeginTime;
	private String endBeginTime;
	private String startFinishTime;
	private String endFinishTime;
	private Integer emplId;
	private String rentStatus;
	private String address;
	private String storeName;
}
