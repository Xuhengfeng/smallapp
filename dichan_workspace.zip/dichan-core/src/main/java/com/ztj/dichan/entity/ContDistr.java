package com.ztj.dichan.entity;

import javax.persistence.*;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;


/**
 * 合同分配表
 * 
 */
@Data
@Table(name="contdistr")
@Entity
@EqualsAndHashCode(callSuper = true)
@NamedQuery(name="ContDistr.findAll", query="SELECT c FROM ContDistr c")
public class ContDistr extends ShardingEntity {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="distrid")
	private Integer id; 

	@Column(name="contid")
	private Integer contId;

	@Column(name="costitemid")
	private Integer costItemId;

	@Column(name="deptid1")
	private Integer deptId1;

	@Column(name="deptid2")
	private Integer deptId2;

	@Column(name="deptid3")
	private Integer deptId3;

	@Column(name="deptid4")
	private Integer deptId4;

	@Column(name="deptid5")
	private Integer deptId5;

	@Column(name="deptname1")
	private String deptName1;

	@Column(name="deptname2")
	private String deptName2;

	@Column(name="deptname3")
	private String deptName3;

	@Column(name="deptname4")
	private String deptName4;

	/**
	 * 五级部门名称
	 */
	@Column(name="deptname5")
	private String deptName5;

	/**
	 * 分配套数
	 */
	@Column(name="distrcount")
	private BigDecimal distrCount;

	/**
	 * 分配比例
	 */
	@Column(name="distrratio")
	private BigDecimal distrRatio;


	/**
	 * 总监比例
	 */
	@Column(name="distrratio1")
	private BigDecimal distrRatio1;

	/**
	 * 大区经理比例
	 */
	@Column(name="distrratio2")
	private BigDecimal distrRatio2;

	/**
	 * 区域经理比例
	 */
	@Column(name="distrratio3")
	private BigDecimal distrRatio3;

	/**
	 * 店组长比例
	 */
	@Column(name="distrratio4")
	private BigDecimal distrRatio4;

	/**
	 * 分配金额
	 */
	@Column(name="distrsum")
	private BigDecimal distrSum;

	/**
	 * 一级部门负责人id
	 */
	@Column(name="emplid1")
	private Integer emplId1;

	/**
	 * 二级部门负责人id
	 */
	@Column(name="emplid2")
	private Integer emplId2;

	/**
	 * 三级部门负责人id
	 */
	@Column(name="emplid3")
	private Integer emplId3;

	/**
	 * 四级部门负责人id
	 */
	@Column(name="emplid4")
	private Integer emplId4;


	/**
	 * 五级部门负责人id
	 */
	@Column(name="emplid5")
	private Integer emplId5;

	/**
	 * 一级部门负责人姓名
	 */
	@Column(name="emplname1")
	private String emplName1;

	/**
	 * 二级部门负责人姓名
	 */
	@Column(name="emplname2")
	private String emplName2;

	/**
	 * 三级部门负责人姓名
	 */
	@Column(name="emplname3")
	private String emplName3;

	/**
	 * 四级部门负责人姓名
	 */
	@Column(name="emplname4")
	private String emplName4;

	/**
	 * 五级部门负责人姓名
	 */
	@Column(name="emplname5")
	private String emplName5;

	/**
	 * 备注
	 */
	@Column(name="explain")
	private String explain;

	/**
	 * 一级部门负责人岗位
	 */
	@Column(name="positionname1")
	private String positionName1;

	/**
	 * 二级部门负责人岗位
	 */
	@Column(name="positionname2")
	private String positionName2;

	/**
	 * 三级部门负责人岗位
	 */
	@Column(name="positionname3")
	private String positionName3;


	/**
	 * 四级部门负责人岗位
	 */
	@Column(name="positionname4")
	private String positionName4;

	/**
	 * 五级部门负责人岗位
	 */
	@Column(name="positionname5")
	private String positionName5;

	/**
	 *交接日期
	 */
	@Column(name="relaydate")
	private String relayDate;

	/**
	 * 交接人id
	 */
	@Column(name="relayid")
	private Integer relayId;

	/**
	 * 交接人名字
	 */
	@Column(name="relayname")
	private String relayName;

	/**
	 * 交接分配比例
	 */
	@Column(name="relayratio")
	private BigDecimal relayRatio;


}