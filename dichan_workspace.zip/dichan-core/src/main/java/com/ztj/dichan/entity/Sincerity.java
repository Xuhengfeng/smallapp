package com.ztj.dichan.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 诚意金表
 * 
 */
@Data
@Table(name="sincerity")
@Entity
@EqualsAndHashCode(callSuper=true)
public class Sincerity extends ShardingEntity {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="recptid")
	private Integer id;

	@Column(name="addr")
	private String addr;

	/**
	 * 收款总金额
	 */
	@Column(name="amount")
	private BigDecimal amount;

	/**
	 * 存回未用
	 */
	@Column(name="chwy")
	private String chwy;

	/**
	 * 存款核销金额
	 */
	@Column(name="ckhxje")
	private BigDecimal depositVerifyAmt;

	/**
	 * 存款人
	 */
	@Column(name="ckr")
	private String depositName;

	/**
	 * 存款日期
	 */
	@Column(name="ckrq")
	private String depositDate;

	/**
	 * 款项id
	 */
	@Column(name="costitemid")
	private Integer costItemId;

	@Column(name="creater")
	private String creater;

	@Column(name="createrid")
	private Integer createId;

	@Column(name="createtime")
	private String createTime;

	@Column(name="customerid")
	private Integer customerId;

	@Column(name="custoname")
	private String custoName;

//	@OneToOne
//    @JoinColumn(name="deptid")
	@Column(name="deptid")
	private Integer deptId;

	@Column(name="explain")
	private String explain;

	@Column(name="houseid")
	private Integer houseId;

	/**
	 * 收款人
	 */
	@Column(name="payee")
	private String payee;
	

	@Column(name="payeeaccount")
	private String payeeAccount;

	@Column(name="payeeid")
	private Integer payeeId;

	/**
	 * 存款方式
	 */
	@Column(name="payeemode")
	private String payeeMode;

	@Column(name="procename")
	private String proceName;

	@Column(name="procepathid")
	private Integer procePathId;

	@Column(name="processstatu")
	private String processStatus;

	/**
	 * 收款日期
	 */
	@Column(name="recedate")
	private String receDate;

	/**
	 * 收据编号
	 */
	@Column(name="recptno")
	private String recptNo;

	@Column(name="sprid")
	private Integer approverId;

	@Column(name="sprname")
	private String approverName;

	/**
	 * 无卡无折
	 */
	@Column(name="wkwz")
	private String wkwz;

	/**
	 * 原诚意金收款id
	 */
	@Column(name="yrecptid")
	private Integer oriRecptId;

	
	/**
	 * 代收房款
	 * 新加
	 */
	@Column(name="other_amount")
	private BigDecimal otherAmount;
	
}