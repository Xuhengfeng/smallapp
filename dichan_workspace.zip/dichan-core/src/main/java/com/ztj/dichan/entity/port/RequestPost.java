package com.ztj.dichan.entity.port;

import java.util.Date;
import java.util.List;

import lombok.Data;


@Data
public class RequestPost {

	private String scity;
	private List<String> shopNameList;
	private String emplName;
	private Date rangeStartTime;
	private Date rangeEndTime;
	private String yearMonth;
	private String status;
	private boolean checkMonth;
}
