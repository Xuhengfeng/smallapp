package com.ztj.dichan.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.entity.District;


@Repository
public interface DistrictRepository extends PagingAndSortingRepository<District, Integer> {
	Page<District> findByName(String name, Pageable pageable);

	List<District> findAll();
}