package com.ztj.dichan.enums;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

public enum CommissionTypeEnum implements Serializable{
	ALL("all", "所有状态", ""),
	PERSON_COMMISSION("person_commission", "个人提成", ""),
    MANAGER_COMMISSION("manager_commission", "营业经理提成", ""),
    AREA_MANAGER_COMMISSION("area_manager_commission", "组均提成", ""),
    GENERAL_MANAGER_COMMISSION("general_manager_commission", "店均提成", "");

    private String code;

    private String name;
    
    private String desc;

    private CommissionTypeEnum(String code, String name, String desc) {
        this.code = code;
        this.name = name;
        this.desc = desc;
    }
    
    public String getCode() {
		return code;
	}

	public String getName() {
		return name;
	}

	public String getDesc() {
		return desc;
	}

	public static CommissionTypeEnum queryEnumByName(String name) {
		List<CommissionTypeEnum> commissionTypeEnums=Arrays.asList(CommissionTypeEnum.values());
		for (CommissionTypeEnum commissionTypeEnum : commissionTypeEnums) {
			if(name.equals(commissionTypeEnum.getName())) 
				return commissionTypeEnum;
		}
		return null;
	}

}
