package com.ztj.dichan.repository.assets.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.hibernate.type.BigDecimalType;
import org.hibernate.type.IntegerType;
import org.hibernate.type.StringType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.ztj.common.util.DateUtil;
import com.ztj.common.util.Verify;
import com.ztj.dichan.enums.AssetRequestParamEnum;
import com.ztj.dichan.vo.asset.ReportWeeklyAssetVo;
import com.ztj.dichan.vo.request.BasicRequest;
import com.ztj.dichan.vo.request.asset.ReportWeeklyAssetRequest;
import com.ztj.dichan.vo.salary.BasicSalaryVo;

/**
 * 
 * @author zuohuan
 *
 */
@Repository
public class ReportWeeklyAssetRepositoryImpl {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@PersistenceContext
	private EntityManager em;

	public Integer reportAssetTotalRecords(ReportWeeklyAssetRequest reportWeeklyAssetRequest) {

		StringBuffer sb = new StringBuffer();
		sb.append("SELECT 	COUNT (*) FROM 	(");
		sb.append(" SELECT 	city_name	FROM report_weekly_asset where 1=1 ");
		Map<String, Object> params = new HashMap<>();
		if(reportWeeklyAssetRequest!=null) {
			if(Verify.collectionIfValue(reportWeeklyAssetRequest.getCityNames())) {
				sb.append(" and city_name in :cityNames");
				params.put("cityNames", reportWeeklyAssetRequest.getCityNames());
			}
			if(reportWeeklyAssetRequest.getType()==AssetRequestParamEnum.TOTAL_ASSET) {
				//有效的截止时间
				sb.append(" and end_date>=");
				if(reportWeeklyAssetRequest.getEndTime()!=null) {
					sb.append(":endTime ");
					params.put("endTime", DateUtil.formatDate(reportWeeklyAssetRequest.getEndTime(), DateUtil.DATEFORMAT_DATE10));
				}else
					sb.append(" convert(date,getdate(),120) ");
				//默认时间空到当天
				sb.append(" and start_date <=convert(date,getdate(),120) ");
			}
			/*else if(reportWeeklyAssetRequest.getType()==AssetRequestParamEnum.NEW_ASSET) {
				//默认是过去一个月
				sb.append(" and start_date >DATEADD(mm, -1, convert(date,getdate(),120)) and start_date <=convert(date,getdate(),120) ");
			}*/
			
			if(reportWeeklyAssetRequest.getBeginTime()!=null) {
				sb.append(" and start_date>=:startDate ");
				params.put("startDate", DateUtil.formatDate(reportWeeklyAssetRequest.getBeginTime(), DateUtil.DATEFORMAT_DATE10));
			}
			
			if(reportWeeklyAssetRequest.getEndTime()!=null) {
				sb.append(" and start_date<=:endDate");
				params.put("endDate", DateUtil.formatDate(reportWeeklyAssetRequest.getEndTime(), DateUtil.DATEFORMAT_DATE10));
			}
				
		}
		sb.append("	GROUP BY city_name ) AS s");
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		return (Integer) query.getSingleResult();
	}
	
	public List<ReportWeeklyAssetVo> assetPage(ReportWeeklyAssetRequest reportWeeklyAssetRequest, Pageable pageable) {
		List<ReportWeeklyAssetVo> reportWeeklyAssetVos = new ArrayList<>();
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		sb.append("SELECT top (:top) * FROM( ");
		sb.append("SELECT  ROW_NUMBER() OVER (");

		if (pageable.getSort() != null) {
			pageable.getSort().forEach(s -> {
				String orderBy = s.getProperty();
				sb.append("order by o.");
				if(orderBy.equals("cityNameCh"))
					sb.append("cityName ");
				else
					sb.append(orderBy + " ");
				sb.append(s.getDirection());
			});
		} else {
			sb.append(" ORDER BY o.cityName DESC ");
		}
		sb.append(") AS rownum, * from ( ");

		sb.append("SELECT " + 
				"	city_name as cityName, " + 
				"	COUNT (city_name) AS count, " + 
				"	SUM (rent_money) AS totalRentMoney, " + 
				"	SUM (decorate_money) AS totalDecorateMoney, " + 
				"	SUM (security_money) as totalSecurityMoney, " + 
				"	SUM (transfer_money) as totalTransferMoney, " + 
				"  ("
				+ "SUM (office_total_it_amt)"
				+ "+SUM (office_total_it_cons_amt)"
				+ "+SUM (office_totalerp_equ_amt)"
				+ "+sum(office_total_wor_fur_amt)"
				+ "+sum(office_total_wor_thi_amt)"
				+ "+sum(office_total_ent_cul_amt)"
				+ "+sum(office_total_tra_amt)) as totalAmount, " + 
				"	SUM (office_total_it_amt) as officeTotalItAmt, " + 
				"	SUM (office_total_it_cons_amt) as officeTotalItConsAmt, " + 
				"	SUM (office_totalerp_equ_amt) as officeTotalErpEquAmt, " + 
				"	sum(office_total_wor_fur_amt) as officeTotalWorFurAmt, "+ 
				"SUM (office_total_wor_thi_amt) as officeTotalWorThiAmt,"+ 
				"SUM (office_total_ent_cul_amt) as officeTotalEntCulAmt,"+ 
				"SUM (office_total_tra_amt) as officeTotalTraAmt " + 
				"FROM " + 
				"	report_weekly_asset where 1=1 ");
			if(reportWeeklyAssetRequest!=null) {
				if(Verify.collectionIfValue(reportWeeklyAssetRequest.getCityNames())) {
					sb.append(" and city_name in :cityNames");
					params.put("cityNames", reportWeeklyAssetRequest.getCityNames());
				}
				if(reportWeeklyAssetRequest.getType()==AssetRequestParamEnum.TOTAL_ASSET) {
					//有效的
					//有效的截止时间
					sb.append(" and end_date>=");
					if(reportWeeklyAssetRequest.getEndTime()!=null) {
						sb.append(":endTime ");
						params.put("endTime", DateUtil.formatDate(reportWeeklyAssetRequest.getEndTime(), DateUtil.DATEFORMAT_DATE10));
					}else
						sb.append(" convert(date,getdate(),120) ");
					//默认时间空到当天
					sb.append(" and start_date <=convert(date,getdate(),120) ");
				}
				//前端已处理
				/*else if(reportWeeklyAssetRequest.getType()==AssetRequestParamEnum.NEW_ASSET) {
					//默认是过去一个月
					sb.append(" and start_date >DATEADD(mm, -1, convert(date,getdate(),120)) and start_date <=convert(date,getdate(),120) ");
				}*/
				
				if(reportWeeklyAssetRequest.getBeginTime()!=null) {
					sb.append(" and start_date>=:startDate ");
					params.put("startDate", DateUtil.formatDate(reportWeeklyAssetRequest.getBeginTime(), DateUtil.DATEFORMAT_DATE10));
				}
				
				if(reportWeeklyAssetRequest.getEndTime()!=null) {
					sb.append(" and start_date<=:endDate");
					params.put("endDate", DateUtil.formatDate(reportWeeklyAssetRequest.getEndTime(), DateUtil.DATEFORMAT_DATE10));
				}
					
			}
				sb.append(" GROUP BY " + 
				"	city_name");

		sb.append(") as o ) A WHERE rownum >:rownum ");

		params.put("top", pageable.getPageSize());

		params.put("rownum", pageable.getPageSize() * pageable.getPageNumber());
		Query query = em.createNativeQuery(sb.toString());
		for (String param : params.keySet()) {
			query.setParameter(param, params.get(param));
		}
		query.unwrap(SQLQuery.class)
		.addScalar("cityName", StringType.INSTANCE)
		.addScalar("count",IntegerType.INSTANCE)
		.addScalar("totalRentMoney",BigDecimalType.INSTANCE)
		.addScalar("totalDecorateMoney",BigDecimalType.INSTANCE)
		.addScalar("totalSecurityMoney",BigDecimalType.INSTANCE)
		.addScalar("totalTransferMoney",BigDecimalType.INSTANCE)
		.addScalar("totalAmount",BigDecimalType.INSTANCE)
		.addScalar("officeTotalItAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalItConsAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalErpEquAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalWorFurAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalWorThiAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalEntCulAmt",BigDecimalType.INSTANCE)
		.addScalar("officeTotalTraAmt",BigDecimalType.INSTANCE)
		.setResultTransformer(Transformers.aliasToBean(ReportWeeklyAssetVo.class));
		reportWeeklyAssetVos = query.getResultList();
		return reportWeeklyAssetVos;
	}
}
