package com.ztj.dichan.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class SystemConfig {
	
	//@Value("${dichan.keycloak.rest.url}")
	private String keycloakRestUrl = "http://112.74.181.229:8087/auth";
	
	//@Value("${dichan.keycloak.rest.username}")
	private String keycloakRestUsername = "admin";
	
	//@Value("${dichan.keycloak.rest.password}")
	private String keycloakRestPassword = "admin123";
	
}
