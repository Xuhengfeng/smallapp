package com.ztj.dichan.entity;

import javax.persistence.Entity;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class CustWatchPic extends BaseDateTimeEntity  {
	private static final long serialVersionUID = 1L;
	/**
	 * 图片名称
	 */
	private String picName ;
	
	/**
	 * 图片地址
	 */
	private String imgUrl;
	
	/**
	 * 备注
	 */
	private String remark;
	
	/**
	 * 排序
	 */
	private Long sort =0L;
	
	/**
	 * 是否是首刊图片
	 */
	private Boolean isFirst;
	
}
