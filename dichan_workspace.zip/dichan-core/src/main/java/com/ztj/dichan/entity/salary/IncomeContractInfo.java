package com.ztj.dichan.entity.salary;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.ztj.dichan.entity.ShardingEntity;
import com.ztj.dichan.enums.IncomeContractStatusEnum;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 佣金合同信息
 * 
 * @author test01
 */
@Entity
@Table(name = "income_contract_Info")
@Data
@EqualsAndHashCode(callSuper = true)
public class IncomeContractInfo extends ShardingEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "income_contr_info_id")
	private Integer id;

	/**
	 * 佣金月份
	 */
	private String yearMonth;

	/**
	 * 员工id
	 */
	private Integer employeeId;

	/**
	 * 员工名称
	 */
	private String employeeName;

	/**
	 * 部門id
	 */
	private Integer deptId;

	/**
	 * 店名
	 */
	private String shopName;

	/**
	 * 組名
	 */
	private String groupName;

	/**
	 * 岗位id
	 */
	private Integer positionId;

	/**
	 * 崗位名称
	 */
	private String positonName;

	/**
	 * 合同id
	 */
	private Integer contId;

	/**
	 * 合同编号
	 */
	private String contNo;

	/**
	 * 票据编号
	 */
	private String recptNo;

	/**
	 * 交易类别
	 */
	private String tradeType;

	/**
	 * 付款方式
	 */
	private String payType;

	/**
	 * 物业
	 */
	private String houseAddr;

	/**
	 * 签约日期
	 */
	private LocalDate dealDate;

	/**
	 * 分配比例
	 */
	private BigDecimal distrRatio;

	/**
	 * 应收总佣金金额
	 */
	private BigDecimal dueAmountTotal;

	/**
	 * 应收收入金额
	 */
	private BigDecimal dueIncomeTotal;

	/**
	 * 此单实收佣金金额
	 */
	private BigDecimal incomeAmount;
	
	/**
	 * 员工佣金:distrRatio*incomeAmount
	 */
	private BigDecimal empIncome;
	
	/**
	 * 上一次员工佣金
	 */
	private BigDecimal oldEmpIncome;

	/**
	 * 收款日期
	 */
	private String receDate;

	/**
	 * 拒绝原因
	 */
	private String rejectNode;

	/**
	 * 状态
	 */
	@Enumerated(EnumType.STRING)
	private IncomeContractStatusEnum status;

	/**
	 * 旧状态
	 */
	@Enumerated(EnumType.STRING)
	private IncomeContractStatusEnum oldStatus;

	/**
	 * 创建人
	 */
	private Long createId;

	/**
	 * 创建时间
	 */
	@Column(name = "create_time")
	private LocalDateTime createTime;

	/**
	 * 最后修改员工id
	 */
	private Long lastUpdateId;

	/**
	 * 最后修改时间
	 */
	private LocalDateTime lastUpdateTime;
	
	/**
	 * 是否锁定
	 */
	private  Boolean isLock;
	
	/**
	 * 合同b表ID
	 */
	private Integer recptBid;
	
	/**
	 * 新增ContDistr 备注   与合同b表进行唯一判断
	 */
	private String explain;
	
	/**
	 * 入职时间
	 */
	private LocalDate changePositionTime;
}