package com.ztj.dichan.repository.approve;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;

@Repository
public class TysqARepositoryImpl {

	
	@PersistenceContext
	private EntityManager em;
	
	public void deleteTysqaByIds(List<Integer> ids){
		StringBuffer sb = new StringBuffer();
		sb.append("delete TysqA where tysqaid in ("+concatIdsArrys(ids)+")");
	    Query query = em.createNativeQuery(sb.toString());
	    query.executeUpdate();
	}
	
	
	/**
	 * 拼接groupArrays
	 * @param reportDetailParams
	 * @return
	 */
	public String concatIdsArrys(List<Integer> ids) {
		StringBuffer sb = new StringBuffer();
	    for (int i = 0 ; i < ids.size(); i++) {
	      sb.append(ids.get(i));
	      if (i < ids.size()-1 ) {
	        sb.append(",");
	      }
	    } 
	    return sb.toString();
	}
}
