# dichan-core
地产的核心项目， 包括entity, repository