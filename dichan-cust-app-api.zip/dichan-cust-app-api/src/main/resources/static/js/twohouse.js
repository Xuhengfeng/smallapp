/*
 * @Author: 徐横峰 
 * @Date: 2018-07-08 01:31:50 
 * @Last Modified by: 564297479@qq.com
 * @Last Modified time: 2018-07-12 15:56:30
 */

//开启es5严格模式
'use strict';
function getQueryString(name) { 
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return decodeURI(r[2]); return null; 
} 
//解析一下baseUrl 匹配搜索条件
$(function(){
	var baseUrl = location.href.split('?')[0] + '?scity=' + getQueryString('scity');
	var areaId = getQueryString('areaId')||'';
	var keyword=parseUrl(location.href).keyword||'';
	var minPrice=getQueryString('minPrice')||'';
	var maxPrice=getQueryString('maxPrice')||'';
	var minBuildArea=getQueryString('minBuildArea')||'';
	var maxBuildArea=getQueryString('maxBuildArea')||'';
	var roomsNum=getQueryString('roomsNum')||'';
	var useYear=getQueryString('useYear')||'';
	var houseDecor=getQueryString('houseDecor')||'';
	var houseDirec=getQueryString('houseDirec')||'';
	var houseFeature=getQueryString('houseFeature')||'';
	var pageNo=getQueryString('pageNo')||'';
    // 分页器
	laypage.render({
	    elem: 'opagination', //分页容器的id
	    count: total, //总页数
	    curr: pageNo,
	    jump: function(obj, first){
	      if(!first){
	        layer.msg('第'+ obj.curr +'页');
	        var list=[{
	        	key:"pageNo",
	        	name:obj.curr
	        },{
	        	key:"pageSize",
	        	name:"10"
	        }]
	        changeurl(list);
	        $('html,body').scrollTop(0);
	      }
	    }
	 });
	//位置
	$(".areas").click(function(){
		areaId=$(this).data('value')
		var list = [{
            key:"areaId",
            name:areaId
          }];
		 changeurl(list) 
	});
	 //点击搜索
    $("#keywordbtn").click(function(){
    	var keywordtext = $("#keywordtext").val();
    	var list = [{
            key:"keyword",
            name:keywordtext
          }];
          changeurl(list);
    });
    //售价
    $(".shoujia").click(function(){
    	minPrice=$(this).data('value').split("-")[0];
    	maxPrice=$(this).data('value').split("-")[1];
    	var list = [{
            key:"minPrice",
            name:minPrice
          },{
            key:"maxPrice",
            name:maxPrice
          }];
          changeurl(list)  
    	
   	});
    //面积
    $(".mianji").click(function(){
    	minBuildArea=$(this).data('value').split("-")[0];
    	maxBuildArea=$(this).data('value').split("-")[1];
    	var list = [{
            key:"minBuildArea",
            name:minBuildArea
          },{
            key:"maxBuildArea",
            name:maxBuildArea
          }];
          changeurl(list) 
   	});
    //户型
    $(".housetag").click(function(){
    	roomsNum=$(this).data('value')
    	var list = [{
            key:"roomsNum",
            name:roomsNum
          }];
          changeurl(list) 
   	});
  //装修
    $(".zhuangxiu").click(function(){
    	houseDecor=$(this).data('value')
    	console.log(houseDecor)
    	var list = [{
            key:"houseDecor",
            name:houseDecor
          }];
          changeurl(list) 
   	});
    //楼龄
    $(".louling").click(function(){
    	 useYear=$(this).data('value')
    	 var list = [{
             key:"useYear",
             name:useYear
           }];
           changeurl(list) 
   	});
    //朝向
    $(".chaoxiang").click(function(){
    	 houseDirec=$(this).data('value')
    	 var list = [{
             key:"houseDirec",
             name:houseDirec
           }];
           changeurl(list) 

   	});
    //特色
    $(".tese").click(function(){
    	 houseFeature=$(this).data('value')
    	 var list = [{
             key:"houseFeature",
             name:houseFeature
           }];
           changeurl(list) 
   	});
    //取消 不限 位置
    $(".cancelarea").click(function(){
    	areaId="";
    	var list = [{
            key:"areaId",
            name:areaId
          }];
          changeurl(list) 
   	}); 
    //取消 不限 售价
    $(".cancelPrice").click(function(){
    	maxPrice="";
    	minPrice="";
    	var list = [{
            key:"maxPrice",
            name:maxPrice
          },{
            key:"minPrice",
            name:minPrice
          }];
          changeurl(list) 	
   	}); 
    //取消 不限 面积
    $(".cancelMian").click(function(){
    	maxBuildArea="";
    	minBuildArea="";
    	var list = [{
            key:"maxBuildArea",
            name:maxBuildArea
          },{
            key:"minBuildArea",
            name:minBuildArea
          }];
          changeurl(list) 		
   	}); 
    //取消 不限 户型
    $(".cancelHutag").click(function(){
    	roomsNum="";
    	var list = [{
            key:"roomsNum",
            name:roomsNum
          }];
          changeurl(list) 
   	}); 
    //取消 不限 装修
    $(".cancelDecoration").click(function(){
    	houseDecor="";
    	var list = [{
            key:"houseDecor",
            name:houseDecor
          }];
          changeurl(list) 
   	}); 
    //取消 不限 楼龄
    $(".cancelLouling").click(function(){
    	useYear="";
    	var list = [{
            key:"useYear",
            name:useYear
          }];
          changeurl(list) 	
   	}); 
    //取消 不限 朝向
    $(".cancelChao").click(function(){
    	houseDirec="";
    	var list = [{
            key:"houseDirec",
            name:houseDirec
          }];
          changeurl(list) 	
   	});
    //取消 不限 特色
    $(".cancelTeshe").click(function(){
    	houseFeature="";
    	var list = [{
            key:"houseFeature",
            name:houseFeature
          }];
          changeurl(list) 
   	});  
    //存储筛选条件
    $("#keywordtext").val(decodeURI(keyword))
  //改变筛选条件颜色
    $('.test li').each(function () {
	  if ($(this).data().value == areaId && $(this).data().type=='area'){
	   	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
	   }
      if ($(this).data().value == minPrice+"-"+maxPrice && $(this).data().type=='sale'){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
      if ($(this).data().value == minBuildArea+"-"+maxBuildArea && $(this).data().type=='mianji'){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
      if ($(this).data().value == roomsNum && $(this).data().type=='huxing'){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
      if ($(this).data().value == houseDecor && $(this).data().type=='decoration'){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
      if ($(this).data().value == useYear && $(this).data().type=='houseage'){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
      if ($(this).data().value == houseDirec && $(this).data().type=='direction'){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
      if ($(this).data().value == houseFeature && $(this).data().type=='decorationtwo'){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
   }); 
    
   //监听搜索框点击
	$('.search').on('click', 'input[type="button"]', function(){
		var keyword = $('.search input[type="text"]').val();
		location.href=_host+"/house_c/twohouse?scity="+selectCity.scity+"&keyword="+keyword;
	}).on('keyup', 'input[type="text"]', function(e){
		var keyword = $('.search input[type="text"]').val();
		if(e.keyCode==13){
			location.href=_host+"/house_c/twohouse?scity="+selectCity.scity+"&keyword="+keyword;
		}
	})
    
   //点击加入对比
   $('#houselist').on('click', '.add', function(e){
	   if(!sessionStorage.token) return layer.msg('请先登录');
	   if($(this).text()=='已加入对比') return layer.msg('已加入对比');
	   
	   
	   var $data = $(this).data();
	   var currentObj = {
		   builtArea: $data.builtarea,
		   housePic: $data.housepic,
		   houseTitle: $data.housetitle,
		   houseType: $data.housetype,
		   id: $data.id,
		   saleTotal: $data.saletotal,
		   scity: $data.scity,
		   sdid: $data.sdid
	   }
	   var src = currentObj.housePic;
	   var params = {scity: currentObj.scity, houseSdid: currentObj.sdid, houseId: currentObj.id};
	   var $list = $('#contrastList>li');
	   //判断当前的对比列表是否超过4条
	   if($list.length!=0&&$list.length<4){
		   $(this).text('已加入对比');
		   //飞入动画
		   addProduct(e, '.end2', src);
		   var flag = false;
		   $list.each(function(index, item){
			   //判断是否存在于对比列表中
			   if($(item).data().sdid != currentObj.sdid){
				   flag = true;
			   }
		   })		
		   //不存在则进行加入
		   if(flag){
			   onecontrastDom(currentObj);	
			   api_twohouseContrast(params);			   
		   }
	   }else if($list.length==0){	
		   $(this).text('已加入对比');
		   //飞入动画
		   addProduct(e, '.end2', src);
		   onecontrastDom(currentObj);	
		   api_twohouseContrast(params);
	   }else{
		   layer.msg('最多可对比4套房源!');
	   }
   })
})



