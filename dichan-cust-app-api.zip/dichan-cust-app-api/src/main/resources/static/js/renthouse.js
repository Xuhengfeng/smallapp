//开启es5严格模式
'use strict';
//解析一下baseUrl 匹配搜索条件
  var minRentPrice=parseUrl(location.href).minRentPrice||'';
  var maxRentPrice=parseUrl(location.href).maxRentPrice||'';
  var roomsNum=parseUrl(location.href).roomsNum||'';
  var areaId=parseUrl(location.href).areaId||'';
  var keyword=parseUrl(location.href).keyword||'';
  var pageNo=parseUrl(location.href).pageNo||'';
  // 分页器
	laypage.render({
	    elem: 'opagination', //分页容器的id
	    count: total, //总页数
	    curr: pageNo,
      jump: function(obj, first){
        if(!first){
          layer.msg('第'+ obj.curr +'页');
          var list = [{
              key:"pageNo",
              name:obj.curr
            },{
              key:"pageSize",
              name:"10"
            }];
            changeurl(list);
          $('html,body').scrollTop(0);
            // 请求
        }
      }
   });
  	//位置
		$(".areas").click(function(){
			areaId=$(this).data('value')
			var list = [{
	          key:"areaId",
	          name:areaId
	        }];
			 changeurl(list) 
		});
    //售价
    $(".shoujia").click(function(){
      minRentPrice=$(this).data('value').split("-")[0];
      maxRentPrice=$(this).data('value').split("-")[1];
      var list = [{
        key:"minRentPrice",
        name:minRentPrice
      },{
        key:"maxRentPrice",
        name:maxRentPrice
      }];
      changeurl(list)  
     });
    //点击搜索
    $("#keywordbtn").click(function(){
    	var keywordtext = $("#keywordtext").val();
    	var list = [{
            key:"keyword",
            name:keywordtext
          }];
          changeurl(list);
    });
    //户型
    $(".huxing").click(function(){
      roomsNum=$(this).data('value');
      var list = [{
        key:"roomsNum",
        name:roomsNum
      }];
      changeurl(list)
      
     });
    
    //取消 不限 位置
    $(".cancelarea").click(function(){
    	areaId="";
    	var list = [{
            key:"areaId",
            name:areaId
          }];
          changeurl(list) 
   	}); 
    //取消 不限 售价
    $(".cancelPrice").click(function(){
      minRentPrice="";
      maxRentPrice="";      
      var list = [{
        key:"minRentPrice",
        name:minRentPrice
      },{
        key:"maxRentPrice",
        name:maxRentPrice
      }];
      changeurl(list)  
     }); 
    //取消 不限 户型
    $(".cancelHuxing").click(function(){
      var list = [{
        key:"roomsNum",
        name:""
      }];
      changeurl(list)
     });
    //改变筛选条件颜色
    $('.test li').each(function () {
	  if ($(this).data().value == areaId && $(this).data().type=='area'){
   	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
   	  }
      if ($(this).data().value == minRentPrice+"-"+maxRentPrice){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
      if ($(this).data().value == roomsNum){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
   });
    //存储筛选条件
    $("#keywordtext").val(decodeURI(keyword));
    
   //监听搜索框点击
    $('.search').on('click', 'input[type="button"]', function(){
    	var keyword = $('.search input[type="text"]').val();
    	location.href=_host+"/house_r/renthouse?scity="+selectCity.scity+"&keyword="+keyword;
    }).on('keyup', 'input[type="text"]', function(e){
    	var keyword = $('.search input[type="text"]').val();
    	if(e.keyCode==13){
    		location.href=_host+"/house_r/renthouse?scity="+selectCity.scity+"&keyword="+keyword;
    	}
    })