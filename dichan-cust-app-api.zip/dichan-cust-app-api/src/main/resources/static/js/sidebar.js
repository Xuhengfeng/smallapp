'use strict';
$(function(){
	// console.log('------------------------------------------------初始化操作-----------------------------------------------------------')
	try{
		var data1 = appointList.data;
		var data2 = contrastList.data;
		//约看房源
		changeAppointDom(data1);
		//对比房源
		changeContrastDom(data2);		
	}catch(error){}
	
	// console.log('------------------------------------------------预约看房清单操作-----------------------------------------------------------')
	//约看房源单独删除
	$('#appointList').on('click', '.delete', function(){
		var currentItem = $(this).parent().data();
		var params = {scity: currentItem.scity,id: currentItem.id};
		var list = $('#appointList>li');
		var findIndex;
		list.each(function(index,item){
			if($(item).data().id == currentItem.id){
				//还原状态
				restate2();
				return findIndex = index;
			}
		})
		//请求删除
		list[findIndex].remove();
		api_appointDeleteOne(params);
		if($('#appointList>li').length==0){
			$('#appointBtn').hide();
			$('#appointList p').show();
		}	
	})
	
	//预约看房全删
	$('#clearAllAppointList').click(function() {
		var list = $('#appointList>li');
		list.each(function(index,item){
			//请求删除
			var params = {id: $(item).data().id, scity: $(item).data().scity};
			api_appointDeleteOne(params);
			//还原状态
			restate2();
		})
		//清空还原
		$('#appointList>li').remove();
		$('#appointBtn').hide();
		$('#appointList p').show();
	})

	
	// console.log('------------------------------------------------对比清单操作-----------------------------------------------------------')
	//对比房源单删
	$('#contrastList').on('click', '.delete', function(){
		var data = $(this).parent().data();
		var list = $('#contrastList>li');
		var params = {sdid: data.sdid, scity: data.scity};
		var findIndex;
		list.each(function(index,item){
			if($(item).data().sdid==data.sdid){
				return findIndex = index;
			}
		})
		//请求删除
		list[findIndex].remove();
		api_twohouseListDel(params);
		//状态还原
		restate(list);
		//显示按钮
		if($('#contrastList>li').length==0){
			$('#contrastBtn').hide();
			$('#contrastList p').show();
		}
		
		
	})
	
	//对比房源全删
	$('#clearAllContrastList').click(function(){
		var list = $('#contrastList>li');
		list.each(function(index,item){
			//请求删除
			var params = {sdid: $(item).data().sdid, scity: $(item).data().scity};
			api_twohouseListDel(params);
			//状态还原
			restate(list);
		})
		//清空还原
		$('#contrastList>li').remove();
		$('#contrastBtn').hide();	
		$('#contrastList p').show();
		
	})
	
	
	
	//对比列表 点击单删 或 全删 还原相关状态
	var $houselist = $('#houselist>li');
	function restate(list) {
		//判断当前是否在详情页面
		var regexp =  /\d{0,}$/g;
		var sdid = location.href.match(regexp)[0];
		list.each(function(index, item){
			$houselist.each(function(index, item2){
				if($(item).data().sdid == $(item2).data().sdid){
					$(item2).find('.add').text('加入对比');
				}
			})
			if(sdid){
				if($(item).data().sdid == sdid){
					$('.addComparison span').text('加入对比');					
				}
			}
		});
	}
	
	//预约看房 点击单删 或 全删 还原相关状态
	function restate2() {
		//判断当前是否在详情页面
		$('#appoint').text('预约看房');		
	}
	
	// console.log('------------------------------------------------跳转收藏-----------------------------------------------------------')
	//跳转收藏
	$('#collectBtn').click(function(){
		if(sessionStorage.token){
			location.href = 'http://www.shyj.cn/#/mine/indexcollection';
		}
	});
	
	
})	
