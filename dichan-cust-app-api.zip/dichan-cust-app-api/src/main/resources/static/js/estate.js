/*
 * @Author: 徐横峰 
 * @Date: 2018-07-08 01:31:50 
 * @Last Modified by: 564297479@qq.com
 * @Last Modified time: 2018-07-12 15:56:30
 */

//开启es5严格模式
'use strict';
function getQueryString(name) { 
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); 
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return decodeURI(r[2]); return null; 
} 
//解析一下baseUrl 匹配搜索条件
$(function(){
	var baseUrl = location.href.split('?')[0] + '?scity=' + getQueryString('scity');
	var areaId = getQueryString('areaId')||'';
	var useYear=getQueryString('useYear')||'';
	var keyword=parseUrl(location.href).keyword||'';
	var minSellPrice=getQueryString('minSellPrice')||'';
	var maxSellPrice=getQueryString('maxSellPrice')||'';
	var pageNo=getQueryString('pageNo')||'';
    // 分页器
	laypage.render({
	    elem: 'opagination', //分页容器的id
	    count: total, //总页数
	    curr: pageNo,
	    jump: function(obj, first){
	      if(!first){
	        layer.msg('第'+ obj.curr +'页');
	        var list=[{
	        	key:"pageNo",
	        	name:obj.curr
	        },{
	        	key:"pageSize",
	        	name:"10"
	        }]
	        changeurl(list);
	        $('html,body').scrollTop(0);
            // 请求
	      }
	    }
	 });
	//位置
	$(".areas").click(function(){
		areaId=$(this).data('value')
		var list = [{
            key:"areaId",
            name:areaId
          }];
		 changeurl(list) 
	});
	 //点击搜索
    $("#keywordbtn").click(function(){
    	var keywordtext = $("#keywordtext").val();
    	var list = [{
            key:"keyword",
            name:keywordtext
          }];
          changeurl(list);
    });
    //均价
    $(".price").click(function(){
    	minSellPrice=$(this).data('value').split("-")[0];
    	maxSellPrice=$(this).data('value').split("-")[1];
    	var list = [{
            key:"minSellPrice",
            name:minSellPrice
          },{
            key:"maxSellPrice",
            name:maxSellPrice
          }];
          changeurl(list)  
    	
   	});
    //楼龄
    $(".louling").click(function(){
    	 useYear=$(this).data('value')
    	 var list = [{
             key:"useYear",
             name:useYear
           }];
           changeurl(list) 
   	});
 

  //取消 不限 位置
    $(".cancelarea").click(function(){
    	areaId="";
    	var list = [{
            key:"areaId",
            name:areaId
          }];
          changeurl(list) 
   	}); 
    //取消 不限 均价
    $(".cancelPrice").click(function(){
    	maxSellPrice="";
    	minSellPrice="";
    	var list = [{
            key:"maxSellPrice",
            name:maxSellPrice
          },{
            key:"minSellPrice",
            name:minSellPrice
          }];
          changeurl(list) 	
   	}); 
    //取消 不限 楼龄
    $(".cancelLouling").click(function(){
    	useYear="";
    	var list = [{
            key:"useYear",
            name:useYear
          }];
          changeurl(list) 	
   	}); 
    //存储筛选条件
    $("#keywordtext").val(decodeURI(keyword))
    
  //改变筛选条件颜色
    $('.test li').each(function () {
	  if ($(this).data().value == areaId && $(this).data().type=='area'){
	   	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
	   }
      if ($(this).data().value == minSellPrice+"-"+maxSellPrice && $(this).data().type=='price'){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
      if ($(this).data().value == useYear && $(this).data().type=='houseage'){
    	  $(this).addClass('selected').attr('href', 'javascript:void(0);').siblings().removeClass('selected');
      }
   });
    
  //监听搜索框点击
    $('.search').on('click', 'input[type="button"]', function(){
    	var keyword = $('.search input[type="text"]').val();
    	location.href=_host+"/buildController/estate?scity="+selectCity.scity+"&keyword="+keyword;
    }).on('keyup', 'input[type="text"]', function(e){
    	var keyword = $('.search input[type="text"]').val();
    	if(e.keyCode==13){
    		location.href=_host+"/buildController/estate?scity="+selectCity.scity+"&keyword="+keyword;
    	}
    })
    
})



