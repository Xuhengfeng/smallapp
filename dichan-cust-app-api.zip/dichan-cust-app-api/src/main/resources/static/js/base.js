'use strict';
/* 常用公共js 
 * 注意: 本文件内的所有方法以“sin_”作为前缀
 * 开发: localhost:7031
 * 生产: www.shyj.cn
 */

/*
 * @Author: 徐横峰 
 * @Date: 2018-07-08 01:33:08 
 * @Last Modified by: Xuhengfeng
 * @Last Modified time: 2018-07-08 22:47:14
 */
//全局url
//var _host="http://localhost:7031/custAppApi";
var _host="http://shyj.cn/custAppApi";
var selectCity =  window.localStorage.selectCity?JSON.parse(window.localStorage.selectCity):"";//当前城市对象；

// 使用layer组件
var layer = layui.layer;//弹窗
var laypage = layui.laypage;//分页

//约看列表 对比列表
var appointList;
var contrastList;

//禁用浏览器 默认右键菜单
document.oncontextmenu = new Function("return false");

//公共类 ol列表动画
$('#menu li,#omenu li').hover(
	function(){
		$(this).find('ol').show();
	},
	function(){
		$(this).find('ol').hide();
	}
);

//公共类  回到顶部
$('.up').click(()=>{
	$('html,body').animate({scrollTop: 0},'slow');
})


//扩展jquery方法
$.fn.extend({
	animateCss: function (animationName) {
		var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
		$(this).addClass('animated ' + animationName);
	}
});

//监听窗体滚动高度
$(window).scroll(function(){
	var oScrollTop = $(window).scrollTop();
	var oHeight = $(window).height()||$(document).height();
	var oMoveY = -(oScrollTop/10) + 'px';
	$('header').css({'background-position-y': oMoveY})
	if(oScrollTop>oHeight-200){
	  $('.up').fadeIn();
	}else{
	  $('.up').fadeOut();
	}
})

//服务请求出错处理
function sin_ajaxError(XMLHttpRequest, textStatus, errorThrown){
	if(errorThrown===undefined || errorThrown===null ||errorThrown===''){
		console.log('服务请求失败');
	}else{
		console.log('服务请求失败:'+errorThrown);
	}
}

//添加抛物线
function addProduct(event, node, src){
	// 设置落脚点
	var offset = $(node).get(0).getBoundingClientRect();	
	// 获取当前点击的js对象
	var _this = $(event.target);
	var flyer = $("<img src='"+src+"' class='fly'/>");
	flyer.fly({
		start:{
			left:event.clientX, // 获取点击购物车按钮的X,Y坐标
			top:event.clientY
		},
		end:{
			left: offset.left,
			top: offset.top,
			width:20,
			height:20
		},
		onEnd:function(){
			flyer.fadeOut("slow",function(){
				$(this).remove();
			});
		}

	});
}

//解析url
function parseUrl(url) {
    try{
        var urlStr=url.split("?")[1].split("&");
        var urlparams = {
        	baseUrl: url.split("?")[0]
        };
        for( let i=0;i<urlStr.length;i++){
            var item = urlStr[i].split("=")
            urlparams[item[0]]=item[1]
            
        }
        return urlparams;
    }
    catch(err){}
}  

//load加载事件
window.onload=function(){
	//自动聚焦
	$('textarea').focus();
	try{
		var baseUrl = parseUrl(location.href).baseUrl;
		$('#menu a').removeClass('oactive');
		switch(true){
			case baseUrl.indexOf('index')!=-1: return $('#index a').addClass('oactive');
			case baseUrl.indexOf('twohouse')!=-1: return $('#twohouse a').addClass('oactive');
			case baseUrl.indexOf('renthouse')!=-1: return $('#renthouse a').addClass('oactive');
		
		}		
	}
	catch(err){};
}



//打开登录窗口
function loginBox_open() {
	$('#loginContentBox .shadow').fadeIn('fast');
	$('.loginBox,.phoneBox,.registerBox,.resetPwd').hide();
	$('.loginBox').show();
}

//打开聊天窗口 
function chatBox_open() {
	var key;
	try{
		key = JSON.parse(sessionStorage.userInfo).easemobUsername;		
	}catch(error){}
	if(localStorage.getItem(key)){
		$('.chatBox').show();
	}
	$('.chatList').animate({
		marginBottom : 0
	}, 0.2);
	$('.upDown').show();		
}
//关闭聊天窗口
function chatBox_close(){
	$('.chatList').animate({
		marginBottom : "-460px"
	}, 0.2);
	$('.chatBox').hide();
	$('.upDown').hide();
}

//时间格式化
function newDate(val) {
	var dateTime = new Date(val);
	var year = dateTime.getFullYear();
	var month = dateTime.getMonth() + 1;
	var day = dateTime.getDate();
	var hour = dateTime.getHours();
	var minute = dateTime.getMinutes();
	var second = dateTime.getSeconds();
	var now = new Date();
	var now_new = new Date().getTime(); //typescript转换写法
	var milliseconds = 0;
	var timeSpanStr;
	milliseconds = now_new - val;
	if (milliseconds <= 1000 * 60 * 1) {
	timeSpanStr = '刚刚';
	}
	else if (1000 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60) {
	timeSpanStr = Math.round((milliseconds / (1000 * 60))) + '分钟前';
	}
	else if (1000 * 60 * 60 * 1 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24) {
	timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60)) + '小时前';
	}
	else if (1000 * 60 * 60 * 24 < milliseconds && milliseconds <= 1000 * 60 * 60 * 24 * 15) {
	timeSpanStr = Math.round(milliseconds / (1000 * 60 * 60 * 24)) + '天前';
	}
	else if (milliseconds > 1000 * 60 * 60 * 24 * 15 && year == now.getFullYear()) {
	timeSpanStr = month + '-' + day + ' ' + hour + ':' + minute;
	} else {
	timeSpanStr = year + '-' + month + '-' + day + ' ' + hour + ':' + minute;
	}
	return timeSpanStr;
}


//更改url拼接
function changeurl(list){
  var url = window.location.href;
  var urlobj=parseUrl(url);
  for(var i=0;i<list.length;i++){
    urlobj[list[i].key]=list[i].name
  } 
  var urlget="";

  for(var p in urlobj){
	if(urlobj[p]){
		console.log(p,urlobj[p])
		urlget=urlget+p+'='+urlobj[p]+"&"
	}
  }
  urlget=urlget.substring(0,urlget.length-1)
  window.location.href = window.location.href.split("?")[0]+"?"+urlget;     
};
//判断是url是否存在这个 字段; 
function parseUrl(url) {
    try{
        var urlStr=url.split("?")[1].split("&");
        var urlparams = {};
        for( let i=0;i<urlStr.length;i++){
            var item = urlStr[i].split("=")
            urlparams[item[0]]=item[1]
        }
        return urlparams;
    }
    catch(err){}
};

//登录之后获取约看列表 和 对比列表
function appointContrasList() {
	var params = {
		scity: selectCity.scity,
		pageNo: 1,
		pageSize: 4
	}
	//约看房源列表数据
	appointList = api_appointHouseList(params);
	//对比列表数据
	contrastList = api_twohouseList(params);
}

//生成一个预约看房列表
function oneAppointDom(item) {
	$('#appointList').prepend(
		'<li data-scity="'+item.scity+'" data-id="'+item.id+'">'+
			'<div class="fl image">'+
				'<img src="'+item.housePic+'" alt="图片" />'+
			'</div>'+
			'<div class="r-content">'+
				'<div>'+item.houseTitle+'</div>'+
			'<div>'+
			'	<span>'+item.houseType+'</span><span>'+item.builtArea+'平</span>'+
			'</div>'+
			'<div>'+
				'<span>'+item.saleTotal+'</span>万'+
			'</div>'+
			'</div>'+
			'<div class="delete">删除</div>'+
		'</li>'
	);
	//显示按钮
	$('#appointBtn').show();	
	$('#appointList p').hide();
}

//生成预约看房列表
function changeAppointDom(result) {
	if(Array.isArray(result)){
		//刷新列表
		result.forEach(function(item){
			oneAppointDom(item);
		})
		if(result.length){
			//显示按钮
			$('#appointBtn').show();	
			$('#appointList p').hide();
		}else{
			//隐藏按钮
			$('#appointBtn').hide();	
			$('#appointList p').show();
		}
	}
}

//生成对比列表一个
function onecontrastDom(item){
	$('#contrastList').prepend(
			'<li data-scity="'+item.scity+'" data-sdid="'+item.sdid+'">'+
			'<div class="fl image">'+
			'<img src="'+item.housePic+'" alt="图片" />'+
			'</div>'+
			'<div class="r-content">'+
			'<div>'+item.houseTitle+'</div>'+
			'<div>'+
			'	<span>'+item.houseType+'</span><span>'+item.builtArea+'平</span>'+
			'</div>'+
			'<div>'+
			'<span>'+item.saleTotal+'</span>万'+
			'</div>'+
			'</div>'+
			'<div class="delete">删除</div>'+
			'</li>'
	);
	//显示按钮
	$('#contrastBtn').show()
	$('#contrastList p').hide();
}

//生成对比列表
function changeContrastDom(result) {
	if(Array.isArray(result)){
		//刷新列表
		result.forEach(function(item){
			onecontrastDom(item);
		})
		if(result.length){
			//显示按钮
			$('#contrastBtn').show()
			$('#contrastList p').hide();	
		}else{
			//隐藏按钮
			$('#contrastBtn').hide();	
			$('#contrastList p').show();
		}
	}
}


//百度地图实例化
function initMap(info) {
	var selectCity =  window.localStorage.selectCity?JSON.parse(window.localStorage.selectCity):"";//当前城市对象；
	var cityName = selectCity.name;
	var omap = new BMap.Map("oMap");
	var point = new BMap.Point(info.px, info.py);//城市的坐标
	var marker = new BMap.Marker(point);//将点转化成标注点
	omap.centerAndZoom(point, 12);//初始中心和倍数
	omap.enableScrollWheelZoom(true);// 开启滚轮放大缩小
	omap.addOverlay(marker);  //将标注点添加到地图上
	var infoWindow = new BMap.InfoWindow('', {// 创建信息窗口对象 
	    width : 20,    // 信息窗口宽度    
	    height: 20,     // 信息窗口高度    
	    title: '<p style="color:#cc5522;text-overflow:ellipsis;white-space: nowrap;overflow: hidden;">'+info.houseTitle+'</p>'      // 信息窗口标题   
	});     
	omap.openInfoWindow(infoWindow, point); 
	
	//百度地图检索实例化
	function selectMap(num) {
		var local = new BMap.LocalSearch(omap, {
			renderOptions : {
				map : omap,
				autoViewport : true
			}
		});
		switch (num) {
			case 0:
				return local.searchNearby('交通', cityName);
			case 1:
				return local.searchNearby('购物', cityName);
			case 2:
				return local.searchNearby('学校', cityName);
			case 3:
				return local.searchNearby('餐饮', cityName);
			case 4:
				return local.searchNearby('医疗', cityName);
			case 5:
				return local.searchNearby('娱乐', cityName);
		}
	}
	$('.queryword').on('click', 'ul>li', function() {
		var num = $(this).index();
		selectMap(num);
	})
}
