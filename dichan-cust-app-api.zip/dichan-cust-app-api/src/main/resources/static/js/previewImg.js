/*
 * @Author: 徐横峰 
 * @Date: 2018-07-08 01:32:30 
 * @Last Modified by: 564297479@qq.com
 * @Last Modified time: 2018-07-09 10:40:48
 */
//$(function(){
'use strict';
// 图片交互区域
var oSwiper1 = new Swiper(".view .swiper-container", {
	onSlideChangeStart : function() {
		updateNavPosition();
	}
});
var oSwiper2 = new Swiper(".preview .swiper-container", {
	visibilityFullFit : true,
	slidesPerView : "auto",
	allowTouchMove : false,
	onTap : function() {
		$('#bigImg img').attr('src', pics[oSwiper2.clickedIndex]);
		oSwiper1.slideTo(oSwiper2.clickedIndex);
	}
});

// 上一张图片
$(".preview .arrow-left").on("click", function(e) {
	e.preventDefault();
	if (oSwiper1.activeIndex == 0) {
		oSwiper1.slideTo(oSwiper1.slides.length - 1, 1000);
		$('#bigImg img').attr('src', pics[oSwiper1.slides.length - 1]);
		return;
	}
	$('#bigImg img').attr('src', pics[oSwiper1.activeIndex - 1]);
	oSwiper1.slidePrev();
});

// 下一张图片
$(".preview .arrow-right").on("click", function(e) {
	e.preventDefault();
	if (oSwiper1.activeIndex == oSwiper1.slides.length - 1) {
		oSwiper1.slideTo(0, 1000);
		$('#bigImg img').attr('src', pics[0]);
		return;
	}
	$('#bigImg img').attr('src', pics[oSwiper1.activeIndex + 1]);
	oSwiper1.slideNext();
});

// 更新acitve位置
function updateNavPosition() {
	$(".preview .active-nav").removeClass("active-nav");
	var activeNav = $(".preview .swiper-slide").eq(oSwiper1.activeIndex)
			.addClass("active-nav");
	if (!activeNav.hasClass("swiper-slide-visible")) {
		if (activeNav.index() > oSwiper2.activeIndex) {
			var thumbsPerNav = Math.floor(oSwiper2.width / activeNav.width()) - 1;
			oSwiper2.slideTo(activeNav.index() - thumbsPerNav);
		} else {
			oSwiper2.slideTo(activeNav.index());
		}
	}
}


// 放大镜
$('.view').mousemove(
		function(ent) {
			$('#move,#bigImg').show();
			var e = ent || event;
			// 文档位置
			var x = e.pageX;
			var y = e.pageY;
			// 坐标原点对齐
			x = x - $(this).offset().left;
			y = y - $(this).offset().top;
			// move的位置
			x = x - $('#move').width() / 2;
			y = y - $('#move').height() / 2;
			// 边界限制
			var maxLeft = $(this).width() - $('#move').width() - 1;
			var maxTop = $(this).height() - $('#move').height() - 1;
			if (x <= 0) {
				x = 0;
			} else if (x >= maxLeft) {
				x = maxLeft;
			}
			if (y <= 0) {
				y = 0;
			} else if (y >= maxTop) {
				y = maxTop;
			}
			// 移动的比例
			var bLeft = x / maxLeft
					* ($('#bigImg img').width() - $('#bigImg').width());
			var bTop = y / maxTop
					* ($('#bigImg img').height() - $('#bigImg').height());
			$('#move').css({
				'left' : x,
				'top' : y
			});
			$('#bigImg img').css({
				'marginLeft' : -bLeft,
				'marginTop' : -bTop
			});
		}).mouseout(function() {
	$('#move,#bigImg').hide();
})



