'use strict';
/*
 * @Author: 徐横峰 
 * @Date: 2018-07-08 01:32:58 
 * @Last Modified by: 564297479@qq.com
 * @Last Modified time: 2018-08-24 10:46:24
 */

// 城市modal 切换
$('#toggleCity').click(function(){
    $('.citylist .shadow').fadeIn('fast');
    $('.citylist .dialog').addClass('pulse');
})
$('.citylist .shadow, #closeDialog').click(function(){
    $('.citylist .shadow').fadeOut('fast');
    $('.citylist .dialog').removeClass('pulse');
})

//所搜类型判断
var num = 0;
// 首页切换浏览器地址
//如果缓存里面不存在城市就走定位
if(!window.localStorage.selectCity){
	baiduCityRequest()
}else{
	try{$("#toggleCityname").text(selectCity.name)}catch(error){};
}
	
//百度定位
function baiduCityRequest(){
  var geoc = new BMap.Geocoder(); 
  var geolocation = new BMap.Geolocation();
    //定位 初始城市
    geolocation.enableSDKLocation();//开启SDK辅助定位
    geolocation.getCurrentPosition(function(r) {
      if(this.getStatus() == BMAP_STATUS_SUCCESS){//逆地址解析成功
        var point = new BMap.Point(r.point.lng,r.point.lat);
        geoc.getLocation(point, function(rs) {
        	//显示到页面
        	selectCity={
        			name:rs.addressComponents.city.slice(0, -1),
        			scity:getPinYinByName(rs.addressComponents.city.slice(0, -1))
        	};
        	$("#toggleCityname").text(selectCity.name);
        	window.location.href=_host+'/index/'+selectCity.scity
        	//汉子转拼音       	
        	localStorage.selectCity = JSON.stringify(selectCity);
        });    
      }else{//逆地址解析失败
    	  selectCity={
      			name:"北海",
      			scity:getPinYinByName("北海")
      	  };
    	  $("#toggleCityname").text(selectCity.name);
    	  window.location.href=_host+'/index/beihai'
    	  localStorage.selectCity = JSON.stringify(selectCity);
      }
    });

};

//检索 二手房 租房  小区
$('#selectQuery li').click(function(){
    num = $(this).index();
    var oleft = $(this).position().left+10+'px';
    switch(num) {
    case 0: 
        $(".search-box input:eq(0)").attr("placeholder", '请输入区域丶商圈或小区名开始找房');
        $('#cursor').animate({left: oleft},300);
        $(this).addClass('active').siblings().removeClass('active');
        break;
    case 1: 
        $(".search-box input:eq(0)").attr("placeholder", '请输区名开始租房');
        $('#cursor').animate({left: oleft},300);
        $(this).addClass('active').siblings().removeClass('active');
        break;
    case 2: 
        $(".search-box input:eq(0)").attr("placeholder", '请输入区域丶名开始找房');
        $('#cursor').animate({left: oleft},300);
        $(this).addClass('active').siblings().removeClass('active');
        break;
    }
});

//点击搜索按钮
$("#submitkeywordbtn").click(function(){
	search();
});

//按下回车搜索
$("#keywordinput").keydown(function(e){
	var ev = window.event ? window.event : e;
    if(ev.keyCode==13) {
    	search();
     }
})

function search(){
	var keyword = $("#keywordinput").val();
	if(keyword){
		switch(num) {
			case 0: 
		    	window.location.href=_host+"/house_c/twohouse?scity="+selectCity.scity+"&keyword="+keyword
		        break;
			case 1: 
		    	window.location.href=_host+"/house_r/renthouse?scity="+selectCity.scity+"&keyword="+keyword
		        break;
			case 2: 
				window.location.href=_host+"/buildController/estate?scity="+selectCity.scity+"&keyword="+keyword
	            break;
	    }
	}else{
		layer.msg('请输入要所搜内容')
	}	
}



//跟换城市按钮
$(".changecitybtn").click(function(){
	var obj={
			name:$(this).data().name,
  			scity:getPinYinByName($(this).data().name)	
	};
	localStorage.selectCity = JSON.stringify( obj);
	location.href=_host+"/index/"+obj.scity;
});

