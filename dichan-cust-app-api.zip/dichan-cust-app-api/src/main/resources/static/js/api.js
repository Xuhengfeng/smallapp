/* 
 * 注意：本文件内的所有方法以“api_”作为前缀
 * @Author: 徐横峰 
 * @Date: 2018-07-08 01:23:51 
 * @Last Modified by: Xuhengfeng
 * @Last Modified time: 2018-07-08 22:44:42
 */

//简单封装ajax
function api_base(ip, params, methods) {
	var result,token,scity;
	try{token = sessionStorage.token}catch(error){};
	if(methods == 'GET') {
		scity = params.scity ? params.scity 
				: (localStorage.selectCity?JSON.parse(localStorage.selectCity).scity: 'beihai');
	}
	else if(methods == 'POST' || methods == 'PUT' || methods=='DELETE'){
		//转成字符串
		params = JSON.stringify(params);
		scity = JSON.parse(params).scity ? JSON.parse(params).scity : 'beihai';
	}
	$.ajax({
		url: ip,
		contentType: 'application/json;charset=UTF-8',
		dataType:'json',
		data: params,
		type: methods,
		beforeSend: function(XMLHttpRequest) {
			XMLHttpRequest.setRequestHeader("scity", scity);
			XMLHttpRequest.setRequestHeader("unique-code", token);
	    },
		async: false,
		success: function(data){
			result = data;
		},
		error: function(XMLHttpRequest, textStatus, errorThrown){
			sin_ajaxError(XMLHttpRequest, textStatus, errorThrown);
		}
	})	
	return result;
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             

// 手机账号登陆提交
function api_requestLogin(params){
	var ip = apiUrl.USER_LOGIN;
	var result = api_base(ip, params, 'POST');
		sessionStorage.token = result.data;
	return result;
}

// 手机快捷帐号登录
function api_request2Login(params){
	var ip = apiUrl.SMSCODE_LOGIN;
	var result = api_base(ip, params, 'POST');
		sessionStorage.token = result.data;
	return result;
}

// 获取登录用户信息
function api_userInfo(token){
	var result;
	var ip = apiUrl.MEMBER_MYINFO;
	$.ajax({
		url: ip,
		contentType: 'application/json;charset=UTF-8',
		dataType:'json',
		type: 'GET',
		beforeSend: function(XMLHttpRequest) {
			XMLHttpRequest.setRequestHeader("unique-code", token);
	    },
		async: false,
		success: function(data){
			sessionStorage.userInfo = JSON.stringify(data.data);
			result = data;
		},
		error: function(XMLHttpRequest, textStatus, errorThrown){
			sin_ajaxError(XMLHttpRequest, textStatus, errorThrown);
		}
	})	
	return result;
}
 
// 手机号码注册
function api_registerUser(params) {
	var ip = apiUrl.USER_REGISTER;
	var result = api_base(ip, params, 'POST');
	return result;
}
//经纪人注册
function api_brokerRegsiter(params) {
	var ip = apiUrl.BROKER_REGUSTER;
	var result = api_base(ip, params, 'POST');
	return result;
}

// 用户退出
function api_logOut() {
	var ip = apiUrl.USER_LOGOUT;
	var token = sessionStorage.token;
	var result;
	$.ajax({
		url: ip,
		contentType: 'application/json;charset=UTF-8',
		dataType:'json',
		type: 'POST',
		beforeSend: function(XMLHttpRequest) {
			XMLHttpRequest.setRequestHeader("unique-code", token);
	    },
		async: false,
		success: function(data){
			location.reload();
			result = data;
		},
		error: function(XMLHttpRequest, textStatus, errorThrown){
			sin_ajaxError(XMLHttpRequest, textStatus, errorThrown);
		}
	})	
	return result;
}
// 手机号码注册发送验证码
function api_sendCode(params) {
	var ip = apiUrl.FETCHSMSCODE;
	var result = api_base(ip, params, 'POST');
	return result;
}

// 找回密码
function api_registerPwd(params) {
	var ip = apiUrl.SMSCODE_RESETLOGIN;
	var result = api_base(ip, params, 'POST');
	return result;
}

//房源动态的带看记录(二手房)
function api_twoHouseSeeHouseList(params) {
	var id = params.id;
	var ip = apiUrl.HOUSE_HOUSESEE+id;
	delete params.id;
	var result = api_base(ip, params, 'GET');
	return result;
}
//加入收藏(二手房)
function api_addCollection1(params) {
	var ip = apiUrl.HOUSECOLLECTION_ADD+params.scity+'/'+params.sdid;
	var result = api_base(ip, params, 'POST');
	return result;
}
//取消收藏(二手房)
function api_cancelCollection1(params) {
	var ip = apiUrl.HOUSECOLLECTION_CANCEL+params.scity+'/'+params.sdid;
	var result = api_base(ip, params, 'POST');
	return result;
}

//加入预约看房(二手房)
function api_appointMent(params) {
	var ip = apiUrl.APPOINT_ADD;
	var result = api_base(ip, params, 'POST');
	return result;
}
//删除待看房源中的一个
function api_appointDeleteOne(params) {
	var ip = apiUrl.APPOINT_DELETE+params.id;
	var result = api_base(ip, params, 'DELETE');
	return result;
}
//预约看房列表(二手房)
function api_appointHouseList(params) {
	var ip = apiUrl.APPOINT_READYHOUSELIST;
	var result = api_base(ip, params, 'GET');
	return result;
}
//加入对比房源(二手房)
function api_twohouseContrast(params) {
	var ip = apiUrl.JOIN_CONTRAST;
	var result = api_base(ip, params, 'PUT');
	return result;
}
//对比房源列表(二手房)
function api_twohouseList(params) {
	var ip = apiUrl.TWOHOUSELIST_CONTRAST;
	var result = api_base(ip, params, 'GET');
	return result;
}
//对比房源点击删除(二手房)
function api_twohouseListDel(params) {
	var ip = apiUrl.CANCEL_CONTRAST+'?houseSdid='+params.sdid;
	var result = api_base(ip, params, 'DELETE');
	return result;
}

//获取房源详情登录相关数据
function api_loginCorrelation(params) {
	var ip = apiUrl.USER_LOGINCORRELATION;
	var result = api_base(ip, params, 'GET');
	return result;
}









