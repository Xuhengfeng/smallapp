'use strict';
/*
 * @Author: 徐横峰 
 * @Date: 2018-07-08 01:32:30 
 * @Last Modified by: 564297479@qq.com
 * @Last Modified time: 2018-08-24 10:44:25
 */



initMap(info);

//登录之后获取数据
function loginAfterRefresh() {
	try{var scity = JSON.parse(localStorage.selectCity).scity||'beihai'}catch(error){};
	if(sessionStorage.userInfo){
		var params = {
			scity: scity,
			sdid: info.sdid,
			houseType: 'HOUSE' 
		};
		var result =  api_loginCorrelation(params).data;
		//判断是否预约
		result.isAppoint? $('#appoint').text('已预约') : $('#appoint').text('预约看房');
		//判断是否收藏
		result.isCollect? $('#addCollection').text('已收藏') : $('#addCollection').text('收藏房源');	
		//判断是否加入
		result.isComparison ? $('#comparison>span').text('已加入') : $('#comparison>span').text('加入对比');	
	}
}

// console.log('------------------------------------------------预约看房清单操作-----------------------------------------------------------')
//点击预约看房
$('#appoint').click(function(e){
	if($(this).text()=='已预约')return layer.msg('已存在约看房源列表');
	var src = $('.view .swiper-slide-active img').attr('src');
	var params = {scity: info.scity,sdid: info.sdid};
	//判断是否加入预约看房
	var result = api_appointMent(params);
	if(result.status == '1'){
		$(this).text('已预约');//加入预约成功		
		addProduct(e, '.end1', src);//飞入动画
		oneAppointDom(info);
	}else{
		layer.msg(result.msg);
	}
})


// console.log('------------------------------------------------对比清单操作-----------------------------------------------------------')
//点击加入对比
$('#comparison').click(function(e){
	//判断是否预约
	if ($('#comparison>span').text()=='已加入') return layer.msg('已存在对比房源列表中');
	var src = $('.view .swiper-slide-active img').attr('src');
	var params = {scity: info.scity, houseId: info.id, houseSdid: info.sdid};
	var result = api_twohouseContrast(params);
	//判断是否加入对比
	if(result.status == '1'){
		$('#comparison>span').text('已加入');//加入对比成功
		addProduct(e, '.end2', src);//飞入动画		
		onecontrastDom(info);	
	}else{
		layer.msg(result.msg);
	}
})

// console.log('------------------------------------------------加入收藏操作-----------------------------------------------------------')
//收藏房源
$('#addCollection').click(function(e){
	if ($(this).text() == '已收藏') {
		//取消收藏
		var params = {scity: info.scity, sdid: info.sdid};
		var result = api_cancelCollection1(params);
		//取消收藏成功
		if(result.status == '1'){		
			$(this).text('收藏房源');	
			return layer.msg('取消收藏');
		}else{
			var msg = result.msg;
			return layer.msg(msg);
		}	
	} else {
		//加入收藏(二手房)
		var params = {scity: info.scity, sdid: info.sdid};
		var result = api_addCollection1(params);
		//收藏成功
		if(result.status == '1'){		
			$(this).text('已收藏');	
			return layer.msg('收藏成功');
		}else{
			var msg = result.msg||'收藏失败';
			return layer.msg(msg);
		}		
	} 
})

//监听分享移入移出
$('.share,.myShare').mouseover(function(){
	$('.myShare').show();
}).mouseout(function(){
	$('.myShare').hide();
})

//监听地图点击
$('.mapQuery').click(function(){
    location.href="http://www.shyj.cn/#/mapSearch?houseType=11";
})

//监听搜索框点击
$('.search').on('click', 'input[type="button"]', function(){
	var keyword = $('.search input[type="text"]').val();
	location.href=_host+"/house_c/twohouse?scity="+selectCity.scity+"&keyword="+keyword;
}).on('keyup', 'input[type="text"]', function(e){
	var keyword = $('.search input[type="text"]').val();
	if(e.keyCode==13){
		location.href=_host+"/house_c/twohouse?scity="+selectCity.scity+"&keyword="+keyword;
	}
})

//带看记录 
$('#next,#prev').click(function(){
	if($(this).find('.xhf-icon-left').length){
		page--;
		if(page<=1){
			page=1;
		}
	}else{
		page++;
	}
	var params = {
		scity: 'beihai',
		pageNo: page,
		id: info.id
	}
	var result = api_twoHouseSeeHouseList(params);
	var $td1 = $('.houseDynamic .two tr:first-child');
	var $td2 = $('.houseDynamic .two tr:not(":first-child")');
	//先进行清空
	$td2.remove();
	result.data.forEach(function(item,index){
		$td1.after(		
			'<tr class="tr-desc">'+
			'<td>'+item.seeDate+'</td>'+
			'<td>'+item.emplName+'</td>'+
			'<td>'+item.phone+'</td>'+
			'</tr>' 
		)
	}); 
})

