package com.ztj.dichan.cust.appapi.repository.activity;


import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.cust.core.entity.activity.Activity;

/**
 * 
 * @author sily
 */
@Repository
public interface ActivityRepository extends PagingAndSortingRepository<Activity, Long> {
	

}