/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.appapi.external.BuildingCollectionServiceClient;
import com.ztj.dichan.cust.appapi.external.BuildingServiceClient;
import com.ztj.dichan.cust.core.constant.OtherConstant;
import com.ztj.dichan.cust.core.entity.BuildCollection;
import com.ztj.dichan.cust.core.repository.BuildCollectionRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.BuildCollectionRequest;
import com.ztj.dichan.cust.rule.response.building.BuildingCollectionVo;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;

/**
 * @author sily
 *
 */
@Service
@Transactional
public class BuildCollectionService extends BaseAppService {

	@Resource
	private BuildCollectionRepository buildCollectionRepository;

	@Resource
	private BuildingCollectionServiceClient buildingCollectionServiceClient;

	@Resource
	private BuildingServiceClient buildingServiceClient;

	public List<BuildingCollectionVo> queryList(Long memberId, Integer pageNo, Integer pageSize) {
		
		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}
		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "collectDateTime");

		List<BuildCollection> collectionList = buildCollectionRepository.findByMemberId(memberId, pageRequest);
		if (collectionList == null || collectionList.isEmpty()) {
			return new ArrayList<BuildingCollectionVo>();
		}
		
		List<BuildCollectionRequest> request = new ArrayList<>();

		collectionList.stream().forEach(collection -> {
			BuildCollectionRequest vo = new BuildCollectionRequest();
			vo.setSdid(collection.getBuildSdid());
			vo.setScity(collection.getBuildScity());

			request.add(vo);
		});

		List<BuildingCollectionVo> buildVoList = buildingCollectionServiceClient.queryCollectionList(request);

		buildVoList.forEach(build -> {
			build.setHousePic(PhotoUtil.getBuildPhotoOne(systemConstant.getOssCdnUrl(), build.getHousePic(),
					build.getScity(), String.valueOf(build.getId())));
			
			if (build.getAveragePrice() != null && build.getAveragePrice() > 0) {
				build.setAvgSalePrice(build.getAveragePrice());
			}
		});

		return buildVoList;

	}

	/**
	 * 
	 * @param memberId
	 * @param sdid
	 * @param scity
	 */
	public void add(Long memberId, Long sdid, String scity) {

		try {
			
			Long count = this.buildCollectionRepository.countByMemberIdAndBuildSdid(memberId, sdid);
			if (count > 0) {
				throw new RuntimeException();
			}
			
			// 这里共用了dichan-cust-service工程里面的小区详情接口
			BuildingDetailVo buildingDetailVo = buildingServiceClient.buildInfo(sdid, scity);
			
			if (buildingDetailVo == null) {
				throw new RuntimeException();
			}

			BuildCollection buildCollection = new BuildCollection();

			buildCollection.setBuildScity(buildingDetailVo.getScity());
			buildCollection.setBuildSdid(Long.valueOf(buildingDetailVo.getSdid()));
			buildCollection.setMemberId(memberId);
			buildCollection.setBuildingId(Long.valueOf(buildingDetailVo.getId()));
			buildCollection.setCollectDateTime(LocalDateTime.now());

			buildCollectionRepository.save(buildCollection);
		} catch (Exception e) {
			throw new BizException("收藏小区出错了");
		}
	}
	
	public void cancelCollection(Long memberId, Long sdid, String scity) {
		BuildCollection buildCollection = buildCollectionRepository.findByMemberIdAndBuildSdid(memberId, sdid);
		
		if (buildCollection != null) {
			buildCollectionRepository.delete(buildCollection);
		}
	}

}
