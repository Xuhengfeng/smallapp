/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo;

import java.math.BigDecimal;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "默认地市")
@Data
@EqualsAndHashCode(callSuper = true)
public class DefaultCityVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "城市编码")
	private String value;

	@ApiModelProperty(value = "城市名称")
	private String name;
	
	@ApiModelProperty(value = "经度")
	private BigDecimal px;

	@ApiModelProperty(value = "纬度")
	private BigDecimal py;
	
	

}
