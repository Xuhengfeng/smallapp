/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.newbuilding;


import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "新盘信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class NewBuildingVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "新盘名称")
	private String buildName;

	@ApiModelProperty(value = "新盘摘要")
	private String buildSummary;

	@ApiModelProperty(value = "新盘标签")
	private String tag;

	@ApiModelProperty(value = "新盘特色")
	private String buildFeature;

	@ApiModelProperty(value = "售均价")
	private Double avgPrice;

	@ApiModelProperty(value = "最小-建筑面积")
	private Double minBuildArea;

	@ApiModelProperty(value = "最大-建筑面积")
	private Double maxBuildArea;

	@ApiModelProperty(value = "图片URL")
	private String imageUrl;

	@ApiModelProperty(value = "PC内容URL")
	private String contenUrl;

	@ApiModelProperty(value = "手机内容URL")
	private String phoneContenUrl;
	
	@ApiModelProperty(value = "客服电话")
	private String customerPhone;
	
	
    
}
