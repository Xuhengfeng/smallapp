package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.StatisticalService;
import com.ztj.dichan.cust.appapi.vo.StatisticsInfoVo;
import com.ztj.dichan.cust.appapi.vo.trend.TrendVo;
import com.ztj.dichan.cust.rule.request.TrendRequest;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author yincp
 *
 */
@Api(value = "统计",description="趋势统计接口")
@RestController
@RequestMapping(value = "/statistics")
public class StatisticalRest extends BaseCustRest {
	
	
	@Resource
	private StatisticalService statisticalService;
	
	
	
	@ApiOperation(value = "查询房价统计", response = StatisticsInfoVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true)})
	@GetMapping("/houseUsed/{scity}")
	public RestResult<StatisticsInfoVo> houseUsedStati(@PathVariable("scity")String scity) {
		
		return RestResult.success(statisticalService.querCurrentMonthStatistics(scity));
		
	}
	
	@ApiOperation(value="查询趋势统计",response=TrendVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true)})
	@PostMapping(value = "/trend")
	public RestResult<TrendVo> trend() {
		return RestResult.success(statisticalService.trend());
	
	}
	
	
	@ApiOperation(value="查看近60天成交房源  ",response=SecondHouseVo.class)
//	@ApiImplicitParams(value = {
//			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true)})
	@PostMapping(value = "/housing60-days")
	public RestResult<List<SecondHouseVo>> housing60Days(@RequestBody TrendRequest request) {
		return RestResult.success(statisticalService.housing60Days(request));
	
	}
}
