package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.RentHouseService;
import com.ztj.dichan.cust.rule.request.RentHouseRequest;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeRecordVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseRecmdVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author sily
 *
 */
@Api(value = "租房相关接口",description="租房相关接口")
@RestController
@RequestMapping(value = "/rentHouse")
public class RentHouseRest extends BaseCustRest {

	@Resource
	private RentHouseService rentHouseService;
	
	
	
	@ApiOperation(value = "查询租房信息列表(搜索)", response = RentHouseVo.class)
	@PostMapping(value = "/query")
	public RestResult<List<RentHouseVo>> queryList(@RequestBody RentHouseRequest rentHouseRequest) {

		List<RentHouseVo> voList = rentHouseService.queryList(rentHouseRequest,getCurrentMemberIdAllowNull());

		return RestResult.success(voList);

	}
	
	@ApiOperation(value = "查询租房信息列表(搜索)-总数量", response = RentHouseVo.class)
	@PostMapping(value = "/queryCount")
	public RestResult<CountVo> queryListCount(@RequestBody RentHouseRequest rentHouseRequest) {

		CountVo count = rentHouseService.queryListCount(rentHouseRequest);

		return RestResult.success(count);

	}
	
	@ApiOperation(value = "首页猜你喜欢-租房列表", response = HouseVo.class)
	@GetMapping(value = "/queryLike/{scity}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType="query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType="query")})
	public RestResult<List<RentHouseVo>> queryLikeList(@PathVariable("scity")String scity,
			@RequestParam(name="pageNo", required = false)Integer pageNo,@RequestParam(name="pageSize", required = false)Integer pageSize) {

		List<RentHouseVo> voList = rentHouseService.queryLikeList(scity,pageNo,pageSize,getCurrentMemberIdAllowNull());

		return RestResult.success(voList);

	}

	@ApiOperation(value = "查看租房详情", response = RentHouseDetailVo.class)
	@GetMapping(value = "/getDetailInFo/{scity}/{sdid}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "sdid", value = "房源sdid", dataType = "int", paramType = "path", required = true)})
	public RestResult<RentHouseDetailVo> getDetailInFo(@PathVariable("scity")String scity,@PathVariable("sdid")Long sdid) {

		RentHouseDetailVo voList = rentHouseService.getDetailInfo(scity, sdid,getCurrentMemberIdAllowNull());

		return RestResult.success(voList);

	}
	
	@ApiOperation(value = "租房推荐", response = RentHouseRecmdVo.class)
	@GetMapping(value = "/recmdList/{scity}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true)})
	public RestResult<List<RentHouseRecmdVo>> queryRecmdList(@PathVariable("scity")String scity) {
		
		List<RentHouseRecmdVo> rentHouseRecmdVo = rentHouseService.queryRecmdList(scity);

		return RestResult.success(rentHouseRecmdVo);

	}
	
	@ApiOperation(value = "租房-周边房源", response = RentHouseVo.class)
	@PostMapping(value = "/rimHousing")
	public RestResult<List<RentHouseVo>> rimHousing(@RequestBody RimHouseRequest rimHouseRequest ) {
		List<RentHouseVo> rimHousingList = rentHouseService.rimHousing(rimHouseRequest);
		return RestResult.success(rimHousingList);

	}
	
	@ApiOperation(value = "获取租房带看记录列表", response = HouseSeeRecordVo.class)
	@GetMapping(value = "/houseSee/{id}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "id", value = "房源id", dataType = "int", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query")})
	public RestResult<List<HouseSeeRecordVo>> getHouseSeeRecordList(@PathVariable("id") Integer id,
			@RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {

		List<HouseSeeRecordVo> voList = this.rentHouseService.getHouseSeeRecordList(id, pageNo, pageSize);
		return RestResult.success(voList);

	}

	


}
