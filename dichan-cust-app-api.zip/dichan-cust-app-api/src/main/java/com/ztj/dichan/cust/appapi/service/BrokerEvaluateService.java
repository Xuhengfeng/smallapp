/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.ztj.common.util.DateUtil;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.request.BrokerEvaluateRequest;
import com.ztj.dichan.cust.appapi.util.PageUtil;
import com.ztj.dichan.cust.appapi.vo.BrokerEvaluateVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.BrokerEvaluate;
import com.ztj.dichan.cust.core.repository.BrokerEvaluateRepository;
import com.ztj.dichan.cust.core.vo.BrokerEvaluateQueryVo;

/**
 * @author lbs
 * 经纪人评价处理
 */
@Service
@Transactional
public class BrokerEvaluateService extends BaseAppService {

	@Resource
	private BrokerEvaluateRepository brokerEvaluateRepository;
	
	@Resource
	private BrokerServiceClient brokerServiceClient;
	
	
	/**
	 * 新增经纪人评价
	 * @param memberId
	 * @param request
	 */
	public void fillBrokerEvaluate(Long memberId,BrokerEvaluateRequest request) {

		if (request.getAppHouseRecId() == null || request.getAppHouseRecId() <= 0) {
			throw new IllegalArgumentException("已看记录id不能为空");
		}
		
		if (request.getBrokerId() == null || request.getBrokerId() <= 0) {
			throw new IllegalArgumentException("经纪人id不能为空");
		}
		
		if (request.getGrade() == null || request.getGrade() <= 0 || request.getGrade() > 5) {
			throw new IllegalArgumentException("评分不能为空并且不能大于5");
		}
		
		if (StringUtils.isEmpty(request.getContent())) {
			throw new IllegalArgumentException("评价内容不能为空");
		}
		
		String cityCode = RequestContextHolder.getCityCode();
		
		BrokerEvaluate brokerEvaluate = new BrokerEvaluate();
		brokerEvaluate.setAppHouseRecId(request.getAppHouseRecId());
		brokerEvaluate.setBrokerId(request.getBrokerId());
		brokerEvaluate.setCreationTime(LocalDateTime.now());
		brokerEvaluate.setGrade(request.getGrade());
		brokerEvaluate.setContent(request.getContent());
		brokerEvaluate.setTag(request.getTag());
		brokerEvaluate.setMemberId(memberId);
		brokerEvaluate.setBrokerScity(cityCode);
		
		brokerEvaluateRepository.save(brokerEvaluate);
		try {
			Double gradeAvg = brokerEvaluateRepository.queryAvgGrade(request.getBrokerId());
			if (gradeAvg != null && gradeAvg > 0) {
				gradeAvg = (double)Math.round(gradeAvg.doubleValue()*10)/10;//保留1位小数点
			} else {
				gradeAvg = 0.0;
			}
			brokerServiceClient.updateEmployeeGrade(cityCode, request.getBrokerId().intValue(), gradeAvg);
		} catch (Exception e) {
			logger.error("更新经纪人评分失败>>>",e);
		}
		
	}
	
	/**
	 * 获取经纪人评价列表
	 * @param brokerId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<BrokerEvaluateVo> queryBrokerEvaluates(Long brokerId,Integer pageNo,Integer pageSize) {
		List<BrokerEvaluateQueryVo> brokerEvaluates = brokerEvaluateRepository.findBybrokerId(brokerId, PageUtil.createPage(pageNo, pageSize));
		
		if (brokerEvaluates == null) {
			return new ArrayList<>(0);
		}
		
		List<BrokerEvaluateVo> voList = brokerEvaluates.stream().map(brokerEvaluate -> {
			BrokerEvaluateVo brokerEvaluateVo = new BrokerEvaluateVo();
			brokerEvaluateVo.setContent(brokerEvaluate.getContent());
			brokerEvaluateVo.setEvaluateDate(DateUtil.formatLocalDateTime(brokerEvaluate.getCreationTime(), "yyyy.MM.dd"));
			brokerEvaluateVo.setGrade(brokerEvaluate.getGrade());
			brokerEvaluateVo.setHeadUrl(brokerEvaluate.getHeadUrl());
			brokerEvaluateVo.setMemberName(brokerEvaluate.getMemberName());
			brokerEvaluateVo.setTag(brokerEvaluate.getTag());
            return brokerEvaluateVo;
        }).collect(Collectors.toList());
		return voList;
	}
	
}
