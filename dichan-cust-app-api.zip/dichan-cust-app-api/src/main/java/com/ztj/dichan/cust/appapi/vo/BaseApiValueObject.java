/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@Data
@EqualsAndHashCode(callSuper=true)
public class BaseApiValueObject extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	protected String  sdid;
	
	protected String scity;
}
