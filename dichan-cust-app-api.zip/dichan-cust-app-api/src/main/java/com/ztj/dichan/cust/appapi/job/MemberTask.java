package com.ztj.dichan.cust.appapi.job;

import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.Resource;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ztj.dichan.cust.appapi.service.MemberService;

@Component
public class MemberTask extends BaseTask {

	private AtomicLong atomicLong = new AtomicLong(0);

	@Resource
	private MemberService memberService;

	@Scheduled(cron = "0 */10 * * * ?")
	public void fetchMemberCity() {
		long count = 0L;

		try {

			count = atomicLong.incrementAndGet();
			
			memberService.fetchCitymessage();

			logger.info("memberTask组件执行开始,atomicLong=" + count);

		} catch (Exception e) {
			logger.error("填充会员城市任务执行出错", e);
		} finally {
			logger.info("memberTask组件执行结束,atomicLong=" + count);
		}
	}
}
