package com.ztj.dichan.cust.appapi.util;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * 没有采用连接池的http请求类,每次的请求响应过程都会把全链路的资源全部关闭,适用于非大并发、不需保持会话的单次请求的场景
 * 
 * @author test01
 */
public class HttpUtil {
	private static Logger logger = LoggerFactory.getLogger(HttpUtil.class);

	public static final String CHARSET = "UTF-8";

	// Connection timeout is the timeout until a connection with the server is
	// established.
	// ConnectionRequestTimeout used when requesting a connection from the
	// connection manager.
	private static RequestConfig defaultRequestConfig = RequestConfig.custom().setConnectionRequestTimeout(4000)
			.setConnectTimeout(5000).build();

	static {
		CloseableHttpClient httpClient = HttpClientBuilder.create().setDefaultRequestConfig(defaultRequestConfig)
				.build();
	}

	public static String doGet(String url) {
		return doGet(url, null, CHARSET);
	}

	public static String doGet(String url, Map<String, String> paramMap) {
		return doGet(url, paramMap, CHARSET);
	}

	public static String doPost(String url) {
		return doPost(url, null, CHARSET);
	}

	public static String doPost(String url, Map<String, String> paramMap) {
		return doPost(url, paramMap, CHARSET);
	}

	/**
	 * HTTP Get 获取内容
	 * 
	 * @param url
	 *            请求的url地址 ?之前的地址
	 * @param paramMap
	 *            请求的参数
	 * @param charset
	 *            编码格式
	 * @return
	 */
	public static String doGet(String url, Map<String, String> paramMap, String charset) {
		if (org.apache.commons.lang3.StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("url不能为空");
		}

		CloseableHttpClient httpClient = null;

		HttpGet httpGet = null;

		CloseableHttpResponse response = null;

		HttpEntity entity = null;

		try {
			if (paramMap != null && !paramMap.isEmpty()) {

				List<NameValuePair> pairs = new ArrayList<>(paramMap.size());

				for (Entry<String, String> entry : paramMap.entrySet()) {
					String value = entry.getValue();
					if (value != null) {
						pairs.add(new BasicNameValuePair(entry.getKey(), value));
					}
				}
				url += "?" + EntityUtils.toString(new UrlEncodedFormEntity(pairs, charset));
			}

			httpClient = HttpClients.createDefault();

			httpGet = new HttpGet(url);

			response = httpClient.execute(httpGet);

			int statusCode = response.getStatusLine().getStatusCode();

			entity = response.getEntity();

			if (statusCode != HttpStatus.SC_OK) {
				throw new IllegalStateException("http请求出错：期待的状态码为" + HttpStatus.SC_OK + ",实际的状态码为" + statusCode
						+ ",返回的响应体=" + EntityUtils.toString(entity, Consts.UTF_8));
			}

			String result = null;

			if (entity != null) {
				result = EntityUtils.toString(entity, "utf-8");
			}

			return result;
		} catch (IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new RuntimeException("http请求出错", e);
		} finally {
			try {
				if (httpGet != null) {
					httpGet.abort();
				}

				EntityUtils.consume(entity);

				if (response != null) {
					response.close();
				}

				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				logger.error("连接和响应资源关闭出错", e);
			}
		}
	}

	/**
	 * HTTP Post 获取内容
	 * 
	 * @param url
	 *            请求的url地址 ?之前的地址
	 * @param paramMap
	 *            请求的参数
	 * @param charset
	 *            编码格式
	 * @return 页面内容
	 */
	public static String doPost(String url, Map<String, String> paramMap, String charset) {
		if (org.apache.commons.lang3.StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("url不能为空");
		}

		CloseableHttpClient httpClient = null;

		HttpPost httpPost = null;

		CloseableHttpResponse response = null;

		HttpEntity entity = null;

		try {
			List<NameValuePair> pairs = null;
			if (paramMap != null && !paramMap.isEmpty()) {
				pairs = new ArrayList<>(paramMap.size());
				for (Entry<String, String> entry : paramMap.entrySet()) {
					String value = entry.getValue();
					if (value != null) {
						pairs.add(new BasicNameValuePair(entry.getKey(), value));
					}
				}
			}

			httpPost = new HttpPost(url);

			if (pairs != null && pairs.size() > 0) {
				httpPost.setEntity(new UrlEncodedFormEntity(pairs, Consts.UTF_8));
			}

			// // 设置请求头
			// Header platformHeader = new BasicHeader("platform", "4");
			// Header appKeyHeader = new BasicHeader("appKey", "yywg");
			// httpPost.addHeader(platformHeader);
			// httpPost.addHeader(appKeyHeader);
			//
			// // 依次是代理地址，代理端口号，协议类型
			// HttpHost proxy = new HttpHost("yourproxy", 8080, "http");

			RequestConfig requestConfig = RequestConfig.copy(defaultRequestConfig).build();
			httpPost.setConfig(requestConfig);

			httpClient = HttpClients.createDefault();
			response = httpClient.execute(httpPost);

			int statusCode = response.getStatusLine().getStatusCode();

			entity = response.getEntity();

			if (statusCode != HttpStatus.SC_OK) {
				throw new IllegalStateException("http请求出错：期待的状态码为" + HttpStatus.SC_OK + ",实际的状态码为" + statusCode
						+ ",返回的响应体=" + EntityUtils.toString(entity, Consts.UTF_8));
			}

			String result = null;

			if (entity != null) {
				result = EntityUtils.toString(entity, Consts.UTF_8);
			}

			return result;
		} catch (IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new RuntimeException("http请求出错", e);
		} finally {
			try {
				if (httpPost != null) {
					httpPost.abort();
				}

				EntityUtils.consume(entity);

				if (response != null) {
					response.close();
				}

				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				logger.error("连接和响应资源关闭出错", e);
			}
		}
	}

	public static String doPostByJson(String url, String jsonStr) {
		CloseableHttpClient httpClient = null;

		HttpPost httpPost = null;

		CloseableHttpResponse response = null;

		HttpEntity entity = null;

		try {
			StringEntity stringEntity = new StringEntity(jsonStr);
			stringEntity.setContentEncoding(CHARSET);
			stringEntity.setContentType("application/json");

			httpPost = new HttpPost(url);
			httpPost.setEntity(stringEntity);

			RequestConfig requestConfig = RequestConfig.copy(defaultRequestConfig).build();
			httpPost.setConfig(requestConfig);

			httpClient = HttpClients.createDefault();
			response = httpClient.execute(httpPost);

			int statusCode = response.getStatusLine().getStatusCode();

			entity = response.getEntity();

			if (statusCode != HttpStatus.SC_OK) {
				throw new IllegalStateException("http请求出错：期待的状态码为" + HttpStatus.SC_OK + ",实际的状态码为" + statusCode
						+ ",返回的响应体=" + EntityUtils.toString(entity, Consts.UTF_8));
			}

			String result = null;

			if (entity != null) {
				result = EntityUtils.toString(entity, Consts.UTF_8);
			}

			return result;
		} catch (IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new RuntimeException("http请求出错", e);
		} finally {
			try {
				if (httpPost != null) {
					httpPost.abort();
				}

				EntityUtils.consume(entity);

				if (response != null) {
					response.close();
				}

				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				logger.error("连接和响应资源关闭出错", e);
			}
		}
	}

	/**
	 * 
	 * @param url
	 * @param inputStream
	 * @return
	 */
	public String doPostByInputStream(String url, InputStream inputStream) {
		CloseableHttpClient httpClient = null;

		HttpPost httpPost = null;

		CloseableHttpResponse response = null;

		HttpEntity entity = null;

		try {
			// 输入流中的字节是需要经过编码处理的,如果传入的输入流进行了编码,这里就不再需要指定具体的编码
			InputStreamEntity inputStreamEntity = new InputStreamEntity(inputStream, -1);
			inputStreamEntity.setContentType("binary/octet-stream");
			inputStreamEntity.setContentEncoding(CHARSET);
			inputStreamEntity.setChunked(true);

			BufferedHttpEntity bufferedHttpEntity = new BufferedHttpEntity(inputStreamEntity);

			httpPost = new HttpPost(url);
			httpPost.setEntity(bufferedHttpEntity);

			httpClient = HttpClients.createDefault();
			response = httpClient.execute(httpPost);

			int statusCode = response.getStatusLine().getStatusCode();

			entity = response.getEntity();

			if (statusCode != HttpStatus.SC_OK) {
				throw new IllegalStateException("http请求出错：期待的状态码为" + HttpStatus.SC_OK + ",实际的状态码为" + statusCode
						+ ",返回的响应体=" + EntityUtils.toString(entity, Consts.UTF_8));
			}

			String result = null;

			if (entity != null) {
				result = EntityUtils.toString(entity, Consts.UTF_8);
			}

			return result;
		} catch (IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new RuntimeException("http请求出错", e);
		} finally {
			try {
				if (httpPost != null) {
					httpPost.abort();
				}

				EntityUtils.consume(entity);

				if (response != null) {
					response.close();
				}

				if (httpClient != null) {
					httpClient.close();
				}
			} catch (IOException e) {
				logger.error("连接和响应资源关闭出错", e);
			}
		}
	}
}