package com.ztj.dichan.cust.appapi.interceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.google.gson.Gson;
import com.ztj.dichan.cust.core.constant.RestResult;

/**
 * 
 * @author test01
 */
@ControllerAdvice(basePackages = "com.ztj.dichan.cust.appapi.rest")
public class SystemResponseBodyAdvice implements ResponseBodyAdvice<Object> {
	private static Logger logger = LoggerFactory.getLogger(SystemResponseBodyAdvice.class);

	@Override
	public boolean supports(MethodParameter methodParameter, Class<? extends HttpMessageConverter<?>> converterType) {
		return methodParameter.getMethod().getReturnType().isAssignableFrom(RestResult.class);
	}

	@Override
	public Object beforeBodyWrite(Object body, MethodParameter methodParameter, MediaType mediaType,
			Class<? extends HttpMessageConverter<?>> converterType, ServerHttpRequest serverHttpRequest,
			ServerHttpResponse serverHttpResponse) {

		RestResult result = ((RestResult) body);

		if (logger.isDebugEnabled()) {
			StringBuilder sb = new StringBuilder();
			sb.append("\n" + new Gson().toJson(result));
			sb.append("\n");

			logger.debug("\n返回的响应信息={}", sb);
		}

		return result;
	}
}
