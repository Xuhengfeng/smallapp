/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.ztj.dichan.cust.appapi.external.TradeProgressClient;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.enums.OperateTypeEnum;
import com.ztj.dichan.cust.core.util.VerifyUtil;
import com.ztj.dichan.cust.rule.response.house.HouseTradeProgressVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * @author lbs
 *
 */
@Service
public class TradeProgressService extends BaseAppService {

	@Resource
	private TradeProgressClient tradeProgressClient;
	
	
	public List<HouseTradeProgressVo> queryTradeProgress(String phone,String smsCode) {
	    
		if (StringUtils.isEmpty(phone)) {
			throw new IllegalStateException("手机号码不能为空");
		}
		
		if (!VerifyUtil.isMobile(phone)) {
			throw new IllegalArgumentException("手机号码格式不正确");
		}
		
		if (StringUtils.isEmpty(smsCode)) {
			throw new IllegalStateException("手机验证码不能为空");
		}
		
		String verifyCode = (String) redisTemplate.opsForValue().get(phone + "_" + OperateTypeEnum.TRADE_PROGRESS.name());
        
		if (!Utils.checkSmsCode(smsCode, verifyCode)) {
			throw new IllegalStateException("手机验证码不正确");
		}
		
		String scity = RequestContextHolder.getCityCode();
		return tradeProgressClient.queryTradeProgress(phone, scity);
		
	}
}
