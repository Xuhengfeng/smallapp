package com.ztj.dichan.cust.appapi.config;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

import com.ztj.dichan.cust.appapi.CustAppApiApplication;

/**
 * spring boot jar转成war时使用
 * 
 * @author sily
 */
public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(CustAppApiApplication.class);
	}
}
