/**
 * 
 */
package com.ztj.dichan.cust.appapi.easemob.external;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSONObject;

/**
 * 环信用户服务接口
 * @author lbs
 *
 */
@FeignClient(name = "easemobUserServiceClient", url= "${easemob.api.url}")
public interface EasemobUserServiceClient {

	
	@RequestMapping(method = RequestMethod.POST, value = "/token")
	public JSONObject getToken(@RequestBody JSONObject request);
	
	@RequestMapping(method = RequestMethod.POST, value = "/users")
	public JSONObject regUser(@RequestBody JSONObject request,
			@RequestHeader(value = "Authorization", required = true) String token);
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/users/{ownerUsername}/contacts/users/{friendUsername}")
	public JSONObject addFriend(@RequestHeader(value = "Authorization", required = true) String token,
			@PathVariable("ownerUsername")String ownerUsername,
			@PathVariable("friendUsername")String friendUsername);
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/messages")
	public JSONObject sendMessage(@RequestHeader(value = "Authorization", required = true) String token,
			@RequestBody JSONObject request);
	
	
}
