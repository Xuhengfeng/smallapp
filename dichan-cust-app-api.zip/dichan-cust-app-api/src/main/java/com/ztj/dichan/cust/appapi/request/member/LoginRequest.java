/**
 * 
 */
package com.ztj.dichan.cust.appapi.request.member;

import com.ztj.dichan.cust.appapi.request.BaseApiRequest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author liuweichen
 *
 */
@ApiModel(value = "用户登陆")
@Data
@EqualsAndHashCode(callSuper = true)
public class LoginRequest extends BaseApiRequest {
	
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "用户手机号，必填")
	private  String mobile;
	
	@ApiModelProperty(value = "密码")
	private  String password;
	
	@ApiModelProperty(value = "设备ID")
	private  String deviceCode;
	

}
