package com.ztj.dichan.cust.appapi.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.external.CityFilePathServiceClient;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.response.CityFilePathVo;

@Service
public class CityFilePathService extends BaseAppService {

	@Resource
	private CityFilePathServiceClient cityFilePathServiceClient;
	
	public void initCityFilePath() {
		try {
			logger.warn("初始化城市图片路径差异....");
			List<CityFilePathVo> dataList = cityFilePathServiceClient.getCityFilePath();
			if (dataList == null || dataList.isEmpty()) {
				logger.warn("城市图片目录无差异");
			}
			for (CityFilePathVo cityFilePathVo : dataList) {
				logger.warn(cityFilePathVo.getCityCode() + "=" + cityFilePathVo.getFilePath());
				PhotoUtil.addPathMap(cityFilePathVo.getCityCode(), cityFilePathVo.getFilePath());
			}
			logger.warn("初始化城市图片路径差异完成！");
		} catch (Exception e) {
			logger.error("初始化城市图片路径差异失败》》》》",e);
		}
		
	}
	
}
