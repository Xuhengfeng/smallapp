/**
 * 
 */
package com.ztj.dichan.cust.appapi.request.member;


import com.ztj.dichan.cust.appapi.request.BaseApiRequest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author liuweichen
 *
 */
@ApiModel(value = "更改手机号码")
@Data
@EqualsAndHashCode(callSuper = true)
public class UpdateMobileRequest extends BaseApiRequest{
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "用户手机号，必填")
	private  String mobile;
	
	@ApiModelProperty(value = "验证码，必填")
	private  String smsCode;
	

}
