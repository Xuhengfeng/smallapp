package com.ztj.dichan.cust.appapi.service;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.vo.RecordVersionQueryVo;
import com.ztj.dichan.cust.appapi.vo.RecordVersionVo;
import com.ztj.dichan.cust.core.entity.RecordVersion;
import com.ztj.dichan.cust.core.entity.RecordVersionOld;
import com.ztj.dichan.cust.core.enums.VersionTypeEnum;
import com.ztj.dichan.cust.core.repository.RecordVersionOldRepository;
import com.ztj.dichan.cust.core.repository.RecordVersionRepository;

/**
 * 
 * @author sily
 *
 */
@Service
@Transactional
public class RecordVersionService extends BaseAppService {

	@Resource
	private RecordVersionRepository recordVersionRepository;

	@Resource
	private RecordVersionOldRepository recordVersionOldRepository;

	/**
	 * 
	 * @param versionType
	 * @return
	 */
	public RecordVersionVo queryList(RecordVersionQueryVo queryVo) {
		RecordVersion currentrecordVersion = recordVersionRepository.findByAppCodeAndVersionTypeAndVersionNo(
				queryVo.getAppCode(), queryVo.getVersionType(), queryVo.getVersionNo());

		RecordVersionVo vo = new RecordVersionVo();
		if (currentrecordVersion != null) {
			RecordVersion lastestRecordVersion = recordVersionRepository
					.findTop1ByVersionTypeAndAppCodeOrderByCreateDateTimeDesc(queryVo.getVersionType(),
							queryVo.getAppCode());

			vo.setIsForcedUpdate(currentrecordVersion.getIsForcedUpdate());
			vo.setVersionNo(lastestRecordVersion.getVersionNo());
			vo.setVersionUrl(lastestRecordVersion.getVersionUrl());
		} else {
			RecordVersion lastestRecordVersion = recordVersionRepository
					.findTop1ByVersionTypeAndAppCodeOrderByCreateDateTimeDesc(queryVo.getVersionType(),
							queryVo.getAppCode());

			vo.setIsForcedUpdate(lastestRecordVersion.getIsForcedUpdate());
			vo.setVersionNo(lastestRecordVersion.getVersionNo());
			vo.setVersionUrl(lastestRecordVersion.getVersionUrl());
		}
		return vo;

	}

	public RecordVersionVo generalize() {
		RecordVersion reVersion = recordVersionRepository
				.findTop1ByVersionTypeAndAppCodeOrderByCreateDateTimeDesc(VersionTypeEnum.ANDROID, "shyj");

		RecordVersionVo vo = new RecordVersionVo();

		vo.setAppCode(reVersion.getAppCode());
		vo.setVersionContent(reVersion.getVersionContent());
		vo.setVersionUrl(reVersion.getVersionUrl());
		vo.setVersionType(reVersion.getVersionType());
		vo.setVersionNo(reVersion.getVersionNo());
		vo.setAppVerison(reVersion.getAppVerison());
		vo.setCreateDateTime(reVersion.getCreateDateTime());

		return vo;
	}

	public RecordVersionOld getOne(RecordVersionQueryVo param) {
		RecordVersionOld recordVersionOld = recordVersionOldRepository
				.findTop1ByVersionTypeOrderByCreateDateTimeDesc(param.getVersionType());
		return recordVersionOld;
	}
}
