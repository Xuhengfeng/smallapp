package com.ztj.dichan.cust.appapi.vo;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.core.enums.AgencyApplicantTypeEnum;
import com.ztj.dichan.cust.core.enums.ApplicationStatusEnum;
import com.ztj.dichan.cust.core.enums.LoanTypeEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author liuweichen
 *
 */
@ApiModel(value = "贷款委托信息")
@Data
@EqualsAndHashCode(callSuper= true)
public class LoanAgencyApplyVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "申请Id")
	protected Long id;
	/**
	 * 联系人名字
	 */
	@ApiModelProperty(value = "名字")
	private String name;

	/**
	 *  申请类型
	 */
	@ApiModelProperty(value = "业务类型(该属性为兼容之前APP，后续删除掉)")
	private LoanTypeEnum applicationType;

	/**
	 *  申请类型
	 */
	@ApiModelProperty(value = "业务类型")
	private LoanTypeEnum loanAgencyType;
	
	@ApiModelProperty(value = "业务类型名称")
	private String loanAgencyTypeName;

	/**
	 *城市
	 */
	@ApiModelProperty(value = "城市")
	private String cityCode;
	
	@ApiModelProperty(value = "城市名称")
	private String cityName;

	/**
	 *地址
	 */
	@ApiModelProperty(value = "地址")
	private String address;
	
	/**
	 * 电话
	 */
	@ApiModelProperty(value = "电话")
	private String phone;
	
	/**
	 * 小区名字
	 */
	@ApiModelProperty(value = "小区名字")
	private String buildingName;
	
	@ApiModelProperty(value = "栋号")
	private String buildNum;
	
	@ApiModelProperty(value = "单元号")
	private String unitNum;
	
	@ApiModelProperty(value = "房号")
	private String roomNum;
	
	/**
	 * 申请时间
	 */
	@ApiModelProperty(value = "申请时间")
	private String applicationTime;
	
	/**
	 *状态 
	 */
	@ApiModelProperty(value = "审核状态")
	@Enumerated(EnumType.STRING)
	private ApplicationStatusEnum status;
	
	
	/**
	 * 会员ID
	 */
	@ApiModelProperty(value = "会员id")
	private Long memberId;
	
	@ApiModelProperty(value = "申请人类型[卖方=SELLER,买方=PURCHASER,推荐人=RECMD_MAN]")
	private AgencyApplicantTypeEnum applicantType;



}
