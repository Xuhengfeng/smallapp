/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.common.util.ShopUtil;
import com.ztj.dichan.cust.appapi.external.ShopServiceClient;
import com.ztj.dichan.cust.rule.request.ShopRequest;
import com.ztj.dichan.cust.rule.response.shop.CountVo;
import com.ztj.dichan.cust.rule.response.shop.ShopVo;

/**
 * @author lbs
 *
 */
@Service
@Transactional
public class ShopService extends BaseAppService {

	@Resource
	private ShopServiceClient shopServiceClient;
	
	
	public List<ShopVo> queryShops(ShopRequest shopRequest) {
		
		String scity = this.getScityNew(shopRequest);
		
		List<ShopVo> shopVoList = shopServiceClient.queryShops(shopRequest,scity);
		
		
		/*shopVoList.forEach(shopVo -> {
			try {
				shopVo.setDistance(DistanceUtil.calcuDistance(lon1, lat1, lon2, lat2));
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		});*/
		if (shopVoList == null) {
			return new ArrayList<>(0);
		}
		/*shopVoList.forEach(shopVo -> {
			shopVo.setDeptName(ShopUtil.updateName(shopVo.getDeptName()));
			
		});*/

		return shopVoList;
	}
	
	public CountVo queryShopsCount(ShopRequest shopRequest) {
		
		String scity = this.getScityNew(shopRequest);
		
		CountVo countVo = shopServiceClient.queryShopsCount(shopRequest,scity);

		return countVo;
	}
	
}
