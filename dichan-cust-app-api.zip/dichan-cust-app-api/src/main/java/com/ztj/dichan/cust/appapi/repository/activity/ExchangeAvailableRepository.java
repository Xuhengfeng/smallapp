package com.ztj.dichan.cust.appapi.repository.activity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.cust.core.entity.activity.ExchangeAvailable;
import com.ztj.dichan.cust.core.enums.ExchangeAvailableStatusEnum;

/**
 * 
 * @author sily
 */
@Repository
public interface ExchangeAvailableRepository extends PagingAndSortingRepository<ExchangeAvailable, Long> {

	ExchangeAvailable findBytemplateId(Long templateId);
	
	Page<ExchangeAvailable> findByStatus(ExchangeAvailableStatusEnum status,Pageable pageable);
}