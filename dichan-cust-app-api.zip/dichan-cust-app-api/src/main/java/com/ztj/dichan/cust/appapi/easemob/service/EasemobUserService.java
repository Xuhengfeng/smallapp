/**
 * 
 */
package com.ztj.dichan.cust.appapi.easemob.service;

import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSONObject;
import com.ztj.dichan.cust.appapi.easemob.EasemobConfig;
import com.ztj.dichan.cust.appapi.easemob.external.EasemobUserServiceClient;
import com.ztj.dichan.cust.appapi.exception.ResourceNotFoundException;
import com.ztj.dichan.cust.appapi.exception.UserDefinedException;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.service.BaseAppService;
import com.ztj.dichan.cust.core.constant.RedisConstant;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;

/**
 * @author lbs
 *
 */
@Service
public class EasemobUserService extends BaseAppService {

	@Resource
	private EasemobConfig easemobConfig;
	
	@Resource
	private EasemobUserServiceClient easemobUserServiceClient;
	
	@Resource
	private BrokerServiceClient brokerServiceClient;
	
	/**
	 * 初始化环信token
	 * @return
	 */
	public String initToken() {
		
		try {
			logger.info("初始化环信配置>>>>>>>>>>>>>>>>>>>");
			String token  = (String)redisTemplate.opsForValue().get(RedisConstant.REDIS_EASEMOB_TOKEN_KEY + easemobConfig.getClientId());
			if (!StringUtils.isEmpty(token)) {
				logger.info("环信token未过期!!!");
				return token;
			}
			
			JSONObject request = new JSONObject();
			request.put("client_id", easemobConfig.getClientId());
			request.put("client_secret", easemobConfig.getClientSecret());
			request.put("grant_type", easemobConfig.getGrantType());
			JSONObject obj = easemobUserServiceClient.getToken(request);
			if (obj == null) {
				throw new RuntimeException("未获取到环信token");
			}
			
			String accessToken = obj.getString("access_token");
			Long expiresIn = obj.getLong("expires_in");
			if (StringUtils.isEmpty(accessToken)) {
				throw new RuntimeException("未获取到环信token");
			}
			
			if (expiresIn == null || expiresIn <=0) {
				expiresIn = 240L;
			}
			
			accessToken = "Bearer " + accessToken;
			//redisTemplate.opsForValue().set(RedisConstant.REDIS_EASEMOB_TOKEN_KEY, accessToken, expiresIn-60, TimeUnit.SECONDS);
			redisTemplate.opsForValue().set(RedisConstant.REDIS_EASEMOB_TOKEN_KEY + easemobConfig.getClientId(), accessToken, expiresIn-60, TimeUnit.SECONDS);
			logger.info("环信初始化成功！！！");
			return accessToken;
			
		} catch (Exception e) {
			logger.error("环信初始化失败>>>",e);
		}
		return null;
		
	}
	
	/**
	 * 获取环信token
	 * @return
	 */
	public String getToken() {
		String token  = (String)redisTemplate.opsForValue().get(RedisConstant.REDIS_EASEMOB_TOKEN_KEY + easemobConfig.getClientId());
		if (StringUtils.isEmpty(token)) {
			return this.initToken();
		}
		return token;
	}
	
	/**
	 * 注册环信账户
	 * @param username
	 * @param password
	 * @param nickname
	 */
	public void regUser(String username,String password,String nickname) {
		
		try {
			
			JSONObject request = new JSONObject();
			request.put("username", username);
			request.put("password", password);
			request.put("nickname", nickname);
			String token = this.getToken();
			easemobUserServiceClient.regUser(request, token);
			
			/*
			 添加好友
			server_info	服务消息
		  	house_trends 二手房源动态
		  	rent_house_trends 租房房源动态
		  	building_trends 小区新上二手房
		  	*/
			/*easemobUserServiceClient.addFriend(token, username, "server_info");
			easemobUserServiceClient.addFriend(token, username, "house_trends");
			easemobUserServiceClient.addFriend(token, username, "rent_house_trends");
			easemobUserServiceClient.addFriend(token, username, "building_trends");*/
			
		} catch (Exception e) {
			logger.error("注册环信用户失败,==>",e);
		}
		
		
	}
	
	
	public void brokerRegUser(String chatUsername) {
		
		if (StringUtils.isEmpty(chatUsername)) {
			throw new IllegalArgumentException("聊天账号不能为空");
		}
		
		String[] strs = chatUsername.split("_");
		if (strs.length != 3) {
			throw new IllegalArgumentException("聊天账号格式不正确");
		}
		BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker2(strs[0], Integer.valueOf(strs[1]));
		if (brokerDetailVo == null) {
			throw new ResourceNotFoundException("未找到相应的经纪人");
		}
		
		if (strs[2] == null || !strs[2].equals(brokerDetailVo.getEmplAccNo())) {
			throw new IllegalArgumentException("聊天账号格式不正确");
		}
		
		try {
			
			//String username = brokerDetailVo.getScity() + "_" + brokerDetailVo.getId() + "_" +brokerDetailVo.getEmplAccNo();
			String password = brokerDetailVo.getScity() + brokerDetailVo.getId() + brokerDetailVo.getEmplAccNo();
			String nickname = brokerDetailVo.getEmplName();
			
			JSONObject request = new JSONObject();
			request.put("username", chatUsername);
			request.put("password", password);
			request.put("nickname", nickname);
			String token = this.getToken();
			easemobUserServiceClient.regUser(request, token);
			
		} catch (Exception e) {
			if (e.getMessage().indexOf("duplicate_unique_property_exists") == -1) {
				throw new UserDefinedException("500","经纪人-注册环信用户失败！",e);
			} else {
				logger.warn("经纪人环信账号已存在" + e.getMessage());
			}
		}
		
	}
	
	
}
