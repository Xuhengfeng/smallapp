package com.ztj.dichan.cust.appapi.external;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ztj.dichan.cust.rule.response.EmployeeDetailVo;




/**
 * @author sily
 *
 */
@FeignClient(name = "employServiceClient", url= "${cust.service.url}", fallback = EmployeeServiceClient.class)
public interface EmployeeServiceClient {
	
	@RequestMapping(method = RequestMethod.GET, value = "/employee/{empId}")
	public EmployeeDetailVo queryBroker(@RequestHeader(value = "scity", required = true) String scity,
			@PathVariable("empId")Integer empId);
	
	@RequestMapping(method = RequestMethod.GET, value = "/employee/{emplName}")
	public EmployeeDetailVo queryEmployee(@RequestHeader(value = "scity", required = true) String scity,
			@PathVariable("emplName")String emplName);
	
}