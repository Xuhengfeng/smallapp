/**
 * 
 */
package com.ztj.dichan.cust.appapi.request.member;

import com.ztj.dichan.cust.appapi.request.BaseApiRequest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "用户验证码登陆")
@Data
@EqualsAndHashCode(callSuper = true)
public class LoginSmsRequest  extends BaseApiRequest {
	
	
	private static final long serialVersionUID = -205885323631827340L;
	
	@ApiModelProperty(value = "用户手机号，必填")
	private  String mobile;
	
	@ApiModelProperty(value="验证码，必填")
	private String smsCode;
	
	@ApiModelProperty(value="设备标识")
	private String deviceCode;
	

}
