/**
 * 
 */
package com.ztj.dichan.cust.appapi.easemob;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 
 * 环信配置信息
 * @author lbs
 *
 */
@Component
public class EasemobConfig {

	@Value("${easemob.client.id}")
    private String clientId;
	
	@Value("${easemob.client.secret}")
    private String clientSecret;
	
	private String grantType = "client_credentials";
	
	/**
	 * 环信token
	 */
	private String token;
	
	/**
	 *	token 有效时间，以秒为单位，在有效期内不需要重复获取
	 */
	private Long expiresIn;
	
	/**
	 * 当前 APP 的 UUID 值
	 */
	private String application;

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public void setClientSecret(String clientSecret) {
		this.clientSecret = clientSecret;
	}

	public String getGrantType() {
		return grantType;
	}

	public void setGrantType(String grantType) {
		this.grantType = grantType;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public Long getExpiresIn() {
		return expiresIn;
	}

	public void setExpiresIn(Long expiresIn) {
		this.expiresIn = expiresIn;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}
	
	
	

}
