package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.druid.util.StringUtils;
import com.ztj.dichan.cust.appapi.external.HouseSeeServiceClient;
import com.ztj.dichan.cust.appapi.external.HouseServiceClient;
import com.ztj.dichan.cust.appapi.vo.house.HouseDetailCountVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.HouseUsedRecmd;
import com.ztj.dichan.cust.core.entity.SearchRecord;
import com.ztj.dichan.cust.core.enums.SearchType;
import com.ztj.dichan.cust.core.repository.AppointHouseDetailRepository;
import com.ztj.dichan.cust.core.repository.AppointHouseRepository;
import com.ztj.dichan.cust.core.repository.HouseCollectionRepository;
import com.ztj.dichan.cust.core.repository.HouseContrastRepository;
import com.ztj.dichan.cust.core.repository.HouseUsedRecmdRepository;
import com.ztj.dichan.cust.core.repository.SearchRecordRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRecmdRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRequest;
import com.ztj.dichan.cust.rule.response.HouseBrokerVo;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseRecmdVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeCountVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeRecordVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * 
 * @author sily
 */
@Service
@Transactional
public class HouseService extends BaseAppService {

	@Resource
	private HouseServiceClient houseServiceClient;

	@Resource
	private HouseUsedRecmdRepository houseUsedRecmdRepository;
	
	@Resource
	private HouseCollectionRepository houseCollectionRepository;
	
	@Resource
	private HouseSeeServiceClient houseSeeServiceClient;
	
	@Resource
	private HouseContrastRepository houseContrastRepository;
	
	@Resource
	private SearchRecordRepository searchRecordRepository;
	
	@Resource
	private AppointHouseDetailRepository appointHouseDetailRepository;
	
	@Resource
	private AppointHouseRepository appointHouseRepository;
	
	
	

	/**
	 * 
	 * @param houseRequest
	 * @return
	 */
	public List<HouseVo> queryList(HouseRequest houseRequest,Long memberId) {

		String scity = this.getScityNew(houseRequest);
		
		List<HouseVo> houseVoList = houseServiceClient.queryList(houseRequest,scity);
		if (houseVoList == null) {
			return new ArrayList<HouseVo>(0);
		}
		houseVoList.forEach(houseVo -> {
			houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseVo.getHousePic(),
					houseRequest.getScity(), String.valueOf(houseVo.getId())));

		});
		
		if (!StringUtils.isEmpty(houseRequest.getKeyword()) && memberId != null) {
			SearchRecord searchRecord = new SearchRecord();
			searchRecord.setMemberId(memberId);
			searchRecord.setKeyword(houseRequest.getKeyword());
			searchRecord.setSearchType(SearchType.SELL);
			searchRecord.setSearchTime(LocalDateTime.now());
			searchRecord.setSearchNum(1);
			this.searchRecordRepository.save(searchRecord);
		}
		
		return houseVoList;
	}
	
	public CountVo queryListCount(HouseRequest houseRequest,Long memberId) {
		String scity = this.getScityNew(houseRequest);
		return houseServiceClient.queryListCount(houseRequest,scity);
	}
	
	/**
	 * @param houseRequest
	 * @return
	 */
	public List<HouseVo> queryLikeList(String scity,Integer pageNo,Integer pageSize,Long memberId) {

		//String scity = RequestContext.getCityCode();
		
		HouseRequest houseRequest = new HouseRequest();
		houseRequest.setScity(scity);
		if (memberId != null) {
			SearchRecord searchRecord = this.searchRecordRepository.findTop1ByMemberIdAndSearchTypeOrderBySearchTimeDesc(memberId, SearchType.SELL);
			if (searchRecord != null 
					&& !StringUtils.isEmpty(searchRecord.getKeyword())) {
				houseRequest.setKeyword(searchRecord.getKeyword());
			}
		}
		
		houseRequest.setPageNo(pageNo);
		houseRequest.setPageSize(pageSize);
		List<HouseVo> houseVoList = houseServiceClient.queryList(houseRequest,scity);
		
		if ((houseVoList == null || houseVoList.isEmpty()) && !StringUtils.isEmpty(houseRequest.getKeyword())) {
			houseRequest.setKeyword(null);
			houseVoList = houseServiceClient.queryList(houseRequest,houseRequest.getScity());
		}
		
		
		houseVoList.forEach(houseVo -> {
			houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseVo.getHousePic(),
					houseRequest.getScity(), String.valueOf(houseVo.getId())));

		});
		return houseVoList;
	}
	
	

	/**
	 * 
	 * @param scity
	 * @param sdid
	 * @return
	 */
	public HouseDetailVo getDetailInfo(String scity, Long sdid,Long memberId) {
		
		HouseDetailVo houseDetailVo = houseServiceClient.getDetailInfo(scity, sdid);
		if (houseDetailVo == null || houseDetailVo.getId() == null) {
			return null;
		}
		
		houseDetailVo.setHousePicList(PhotoUtil.converPhoto(systemConstant.getOssCdnUrl(), houseDetailVo.getHousePic(), scity,String.valueOf(houseDetailVo.getId())));
		/*houseDetailVo.setHousePic(
				PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseDetailVo.getHousePic(), scity,String.valueOf(houseDetailVo.getId())));*/
		
		if (houseDetailVo.getHousePicList() != null && !houseDetailVo.getHousePicList().isEmpty()) {
			houseDetailVo.setHousePic(houseDetailVo.getHousePicList().get(0));
		} else {
			houseDetailVo.setHousePic(null);
		}
		HouseBrokerVo broker = houseDetailVo.getBroker();
		if (broker != null) {
			houseDetailVo.getBroker().setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(),
					broker.getPhoto(), scity, broker.getId()));
		}
		if (houseDetailVo.getTotalFloorNum() != null && houseDetailVo.getTotalFloorNum() >= 10) {
			houseDetailVo.setElevator("有");//这里目前AIO没有电梯属性固定给值
		} else {
			houseDetailVo.setElevator("无");//这里目前AIO没有电梯属性固定给值
		}
		
		houseDetailVo.setPaymentBudget("首付及贷款情况请咨询经纪人");//首付预算暂时给固定的值
		
		if (memberId != null && memberId > 0) {
			Long countCollect = houseCollectionRepository.countByMemberIdAndHouseSdid(memberId, sdid);
			houseDetailVo.setIsCollect(countCollect > 0?true:false);
			
			Long countComp = houseContrastRepository.countByMemberIdAndHouseSdid(memberId, sdid);
			houseDetailVo.setIsComparison(countComp > 0?true:false);
			
			
			Integer countHouse = this.appointHouseRepository.countByMemberIdAndHouseSdid(memberId, sdid);
			if (countHouse > 0) {
				houseDetailVo.setIsAppoint(true);
			} else {
				Integer countDetail = appointHouseDetailRepository.countByMemberIdAndHouseSdid(memberId, sdid);
				houseDetailVo.setIsAppoint(countDetail > 0?true:false);
			}
			
		}
		
		HouseSeeCountVo houseSeeCountVo = houseSeeServiceClient.queryCount(scity, houseDetailVo.getId());
		
		houseDetailVo.setDay7Num(houseSeeCountVo.getDay7Count());
		houseDetailVo.setDay30Num(houseSeeCountVo.getDay30Count());
		houseDetailVo.setTotalSeeNum(houseSeeCountVo.getTotalCount());
		Integer collectNum = houseCollectionRepository.countByHouseSdid(sdid);
		houseDetailVo.setCollectNum(collectNum);
		if (!StringUtils.isEmpty(houseSeeCountVo.getRecentlySeeDate())) {
			houseDetailVo.setRecentlySee(houseSeeCountVo.getRecentlySeeDate().split(" ")[0].replace("-", "."));
		} else {
			houseDetailVo.setRecentlySee("");
		}

		return houseDetailVo;
	}

	/**
	 * 
	 * @param scity
	 * @return
	 */
	public List<HouseRecmdVo> queryRecmdList(String scity) {
		
		List<HouseUsedRecmd> recmdList = houseUsedRecmdRepository.findTop5ByHouseScity(scity);
		
		if (recmdList == null || recmdList.isEmpty()) {
			//return new ArrayList<HouseRecmdVo>(0);
			return getDefRecmdList(scity);
		}
		
		List<Long> houseSdidList = new ArrayList<>(recmdList.size());
		Map<String,String> recmdMap = new HashMap<String,String>(recmdList.size());
		recmdList.stream().forEach(recmd -> {
			houseSdidList.add(recmd.getHouseSdid());
			recmdMap.put(recmd.getHouseSdid()+"", recmd.getImageUrl());
		});

		HouseRecmdRequest houseRecmdRequest = new HouseRecmdRequest();
		houseRecmdRequest.setSdidList(houseSdidList);
		houseRecmdRequest.setScity(scity);

		List<HouseRecmdVo> houseRecmdList = houseServiceClient.queryRecmdList(houseRecmdRequest,houseRecmdRequest.getScity());
		
		houseRecmdList.forEach(houseRecmdVo -> {
			String image = recmdMap.get(houseRecmdVo.getSdid()+"");
			if (StringUtils.isEmpty(image)) {
				houseRecmdVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseRecmdVo.getHousePic(),
						scity, String.valueOf(houseRecmdVo.getId())));
			} else {
				houseRecmdVo.setHousePic(image);
			}
		});

		return houseRecmdList;
	}
	
	private List<HouseRecmdVo> getDefRecmdList(String scity) {
		
		HouseRequest houseRequest = new HouseRequest();
		houseRequest.setPageNo(4);
		houseRequest.setPageSize(4);
		List<HouseVo> houseVoList = houseServiceClient.queryList(houseRequest,scity);
		if (houseVoList == null) {
			return new ArrayList<HouseRecmdVo>(0);
		}
		
		return houseVoList.stream().map(houseVo -> {
			HouseRecmdVo houseRecmdVo = new HouseRecmdVo();
			BeanUtils.copyProperties(houseVo, houseRecmdVo);
			houseRecmdVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseRecmdVo.getHousePic(),
					houseRecmdVo.getScity(), String.valueOf(houseRecmdVo.getId())));
			return houseRecmdVo;
		}).collect(Collectors.toList());
	}

	/**
	 * 
	 * @param buildID
	 * @param px
	 * @param py
	 * @return
	 */
	public List<HouseVo> rimHousing(RimHouseRequest rimHouseRequest) {
		
		String scity = this.getScityNew(rimHouseRequest);
		
		List<HouseVo> rimHousingList = houseServiceClient.rimHousing(rimHouseRequest,scity);
		if (rimHousingList == null) {
			return new ArrayList<HouseVo>(0);
		}
		rimHousingList.forEach(houseVo -> {
			houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseVo.getHousePic(),
					rimHouseRequest.getScity(), String.valueOf(houseVo.getId())));

		});
		return rimHousingList;
	}
	
	
	public List<HouseSeeRecordVo> getHouseSeeRecordList(Integer houseId,Integer pageNo,Integer pageSize) {
		String scity = RequestContextHolder.getCityCode();
		List<HouseSeeRecordVo> voList = this.houseSeeServiceClient.queryDkInfoList(scity, houseId, pageNo, pageSize);
		if (voList == null) {
			return new ArrayList<>(0);
		}
		voList.forEach(vo -> {
			if (!StringUtils.isEmpty(vo.getSeeDate())) {
				vo.setSeeDate(vo.getSeeDate().split(" ")[0].replace("-", "."));
			}

		});
		return voList;
	}
	
	
	public List<HouseSeeRecordVo> getHouseSeeRecordList(Integer houseId,Integer pageNo,Integer pageSize,String scity) {
		List<HouseSeeRecordVo> voList = this.houseSeeServiceClient.queryDkInfoList(scity, houseId, pageNo, pageSize);
		if (voList == null) {
			return new ArrayList<>(0);
		}
		voList.forEach(vo -> {
			if (!StringUtils.isEmpty(vo.getSeeDate())) {
				vo.setSeeDate(vo.getSeeDate().split(" ")[0].replace("-", "."));
			}

		});
		return voList;
	}
	
	
	
	public HouseDetailCountVo getHouseDetailCount(Long memberId) {
		
		HouseDetailCountVo houseDetailCountVo = new HouseDetailCountVo();
		if (memberId == null || memberId <= 0) {
			houseDetailCountVo.setContrastCount(0);
			houseDetailCountVo.setAppointCount(0);
		} else {
			houseDetailCountVo.setContrastCount(houseContrastRepository.countByMemberId(memberId).intValue());
			houseDetailCountVo.setAppointCount(appointHouseDetailRepository.countByMemberId(memberId));
		}
		
		return houseDetailCountVo;
	}
}