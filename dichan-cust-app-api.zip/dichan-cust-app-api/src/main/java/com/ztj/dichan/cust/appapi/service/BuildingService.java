package com.ztj.dichan.cust.appapi.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.exception.ResourceNotFoundException;
import com.ztj.dichan.cust.appapi.external.BuildingServiceClient;
import com.ztj.dichan.cust.appapi.util.PageUtil;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.BuildingRecmd;
import com.ztj.dichan.cust.core.repository.BuildCollectionRepository;
import com.ztj.dichan.cust.core.repository.BuildingRecmdRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.buildnew.BuildRecmdRequest;
import com.ztj.dichan.cust.rule.request.buildnew.BuildRequest;
import com.ztj.dichan.cust.rule.request.buildnew.BuildingDyFhRequest;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.building.BuildingDzdyDetailVo;
import com.ztj.dichan.cust.rule.response.building.BuildingVo;
import com.ztj.dichan.cust.rule.response.building.DzDetailVo;
import com.ztj.dichan.cust.rule.response.building.HotBuildingVo;
import com.ztj.dichan.cust.rule.response.building.RentHouseVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * 
 * @author sily
 */
@Service
@Transactional
public class BuildingService extends BaseAppService {


	@Resource
	private BuildingServiceClient buildingServiceClient;
	
	@Resource
	private BuildingRecmdRepository buildingRecmdRepository;
	
	@Resource
	private BuildCollectionRepository buildCollectionRepository;

	public List<BuildingVo> buildList(BuildRequest buildRequest) {
		
		String scity = this.getScityNew(buildRequest);
		
		List<BuildingVo> buildList = buildingServiceClient.buildList(buildRequest,scity);
		if (buildList == null) {
			return new ArrayList<>(0);
		}
		buildList.forEach(buildingVo -> {
			buildingVo.setHousePic(PhotoUtil.getBuildPhotoOne(systemConstant.getOssCdnUrl(), 
					buildingVo.getHousePic(), buildRequest.getScity(), buildingVo.getId().toString()));
			
			if (buildingVo.getAveragePrice() != null && buildingVo.getAveragePrice() > 0) {
				buildingVo.setAvgSalePrice(buildingVo.getAveragePrice());
			}

		});
		return buildList;
	}
	
	public CountVo buildListCount(BuildRequest buildRequest) {
		
		String scity = this.getScityNew(buildRequest);
		
		CountVo countVo = buildingServiceClient.buildListCount(buildRequest,scity);

		return countVo;
	}
	
	public BuildingDetailVo buildInfo(Long sdid, String scity,Long memberId) {
		BuildingDetailVo detailVo = buildingServiceClient.buildInfo(sdid,scity);
		
		if (detailVo == null) {
			throw new ResourceNotFoundException("未找到相应的小区信息,["+scity+","+sdid+"]");
		}
		detailVo.setHousePicList(PhotoUtil.converBuildPhoto(systemConstant.getOssCdnUrl(), 
				detailVo.getHousePic(), scity, detailVo.getId().toString()));
		if (detailVo.getHousePicList() != null && !detailVo.getHousePicList().isEmpty()) {
			detailVo.setHousePic(detailVo.getHousePicList().get(0));
		} else {
			detailVo.setHousePic(null);
		}
		if (memberId != null && memberId > 0) {
			Long count = buildCollectionRepository.countByMemberIdAndBuildSdid(memberId, Long.valueOf(detailVo.getSdid()));
			detailVo.setIsCollect(count > 0?true:false);
		}
		if (detailVo.getAveragePrice() != null && detailVo.getAveragePrice() > 0) {
			detailVo.setAvgSalePrice(detailVo.getAveragePrice());
		}
		return detailVo;
	}
	
	public List<SecondHouseVo> secondHouseList(Long sdid, String scity,Integer pageNo,Integer pageSize) {
		List<SecondHouseVo> recmdVoList  = buildingServiceClient.secondHouseList(scity,sdid,pageNo,pageSize);
		if (recmdVoList == null) {
			return new ArrayList<>(0);
		}
		recmdVoList.forEach(secondHouseVo -> {
			secondHouseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), 
					secondHouseVo.getHousePic(), scity, secondHouseVo.getId().toString()));

		});
		return recmdVoList;
	}
	
	
	public List<RentHouseVo> rentHouseList(Long sdid, String scity,Integer pageNo,Integer pageSize) {
		List<RentHouseVo> recmdVoList  = buildingServiceClient.rentHouseList(scity,sdid,pageNo,pageSize);
		if (recmdVoList == null) {
			return new ArrayList<>(0);
		}
		recmdVoList.forEach(rentHouseVo -> {
			rentHouseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), 
					rentHouseVo.getHousePic(), scity, rentHouseVo.getId().toString()));

		});
		return recmdVoList;
	}
	
	public List<HotBuildingVo> hotBuilding(String scity,Integer pageNo,Integer pageSize) {
		
		List<BuildingRecmd> recmdList =	buildingRecmdRepository.findByBuildScity(scity,PageUtil.createPage(pageNo, pageSize));
		if (recmdList == null || recmdList.isEmpty()) {
			//return new ArrayList<HotBuildingVo>(0);
			return this.getDefHotBuilding(scity);
		}
		List<Long> buildSdidList = new ArrayList<>(recmdList.size());
		Map<String,String> recmdMap = new HashMap<String,String>(recmdList.size());
		recmdList .stream().forEach(recmd -> {
			buildSdidList.add(recmd.getBuildSdid());
			recmdMap.put(recmd.getBuildSdid()+"", recmd.getImageUrl());
		});
		
		BuildRecmdRequest buildRequest = new BuildRecmdRequest();
		buildRequest.setSdidList(buildSdidList);
		buildRequest.setScity(scity);
		buildRequest.setPageNo(pageNo);
		buildRequest.setPageSize(pageSize);
		List<HotBuildingVo> hotList  = buildingServiceClient.hotBuilding(buildRequest,buildRequest.getScity());
		
		hotList.forEach(hotBuildingVo -> {
			String image = recmdMap.get(hotBuildingVo.getSdid()+"");
			if (StringUtils.isEmpty(image)) {
				hotBuildingVo.setHousePic(PhotoUtil.getBuildPhotoOne(systemConstant.getOssCdnUrl(), 
					hotBuildingVo.getHousePic(), buildRequest.getScity(), hotBuildingVo.getId().toString()));
			} else {
				hotBuildingVo.setHousePic(image);
			}
			
			if (hotBuildingVo.getAveragePrice() != null && hotBuildingVo.getAveragePrice() > 0) {
				hotBuildingVo.setAvgSalePrice(hotBuildingVo.getAveragePrice());
			}
		});
		return hotList;
	}
	
	private List<HotBuildingVo> getDefHotBuilding(String scity) {
		
		BuildRequest buildRequest = new BuildRequest();
		buildRequest.setPageNo(4);
		buildRequest.setPageSize(4);
		buildRequest.setScity(scity);
		List<BuildingVo> buildList = buildingServiceClient.buildList(buildRequest,scity);
		if (buildList == null) {
			return new ArrayList<>(0);
		}
		return buildList.stream().map(build -> {
			HotBuildingVo hotBuildingVo = new HotBuildingVo();
			BeanUtils.copyProperties(build, hotBuildingVo);
			
			hotBuildingVo.setHousePic(PhotoUtil.getBuildPhotoOne(systemConstant.getOssCdnUrl(), 
					hotBuildingVo.getHousePic(), hotBuildingVo.getScity(), hotBuildingVo.getId().toString()));
			
			if (hotBuildingVo.getAveragePrice() != null && hotBuildingVo.getAveragePrice() > 0) {
				hotBuildingVo.setAvgSalePrice(hotBuildingVo.getAveragePrice());
			}
			return hotBuildingVo;
		}).collect(Collectors.toList());
		
	}
	
	/**
	 * 根据小区sdid获取小区信息-栋座-单元-房号
	 * @param request
	 * @return
	 */
	public BuildingDzdyDetailVo queryBuildingDzdyDetail(Long sdid) {
		String scity = RequestContextHolder.getCityCode();
		return this.buildingServiceClient.queryBuildingDzdyDetail(sdid,scity);
	}
	
	
	public List<DzDetailVo> queryBuildingDz(Integer id) {
		String scity = RequestContextHolder.getCityCode();
		return this.buildingServiceClient.queryBuildingDz(id,scity);
	}
	
	public List<String> queryBuildingDyFh(BuildingDyFhRequest request) {
		String scity = RequestContextHolder.getCityCode();
		if (StringUtils.isEmpty(request.getScity())) {
			request.setScity(scity);
		}
		return this.buildingServiceClient.queryBuildingDyfh(request,scity);
	}
	
	
}