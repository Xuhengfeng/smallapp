/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.response.house.HouseTradeProgressVo;

/**
 * @author lbs
 *
 */
public class TradeProgressClientFallBack implements TradeProgressClient {

	
	@Override
	public List<HouseTradeProgressVo> queryTradeProgress(String phone, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

}
