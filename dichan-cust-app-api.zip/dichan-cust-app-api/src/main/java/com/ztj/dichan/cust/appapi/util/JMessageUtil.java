package com.ztj.dichan.cust.appapi.util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.jiguang.common.resp.APIConnectionException;
import cn.jiguang.common.resp.APIRequestException;
import cn.jmessage.api.JMessageClient;
import cn.jmessage.api.common.model.message.MessageBody;
import cn.jmessage.api.message.SendMessageResult;

public class JMessageUtil {
	
	protected static final Logger LOG = LoggerFactory.getLogger(JMessageUtil.class);
	private static final String appkey = "cf6c8b8ec5558097ce06237d";
    private static final String masterSecret = "c11add584e98b784b69ada80";
    
    /**
     * 发送单条信息
     */
    public static void SendSingleText(String targetUserName,String fromUserName,String message) {
    	
    	 JMessageClient client = new JMessageClient(appkey, masterSecret);
    	 try {
             MessageBody body = MessageBody.text(message);
             SendMessageResult result = client.sendSingleTextByAdmin(targetUserName, fromUserName, body);
             LOG.info(String.valueOf(result.getMsg_id()));
         } catch (APIConnectionException e) {
             LOG.error("Connection error. Should retry later. ", e);
         } catch (APIRequestException e) {
             LOG.error("Error response from JPush server. Should review and fix it. ", e);
             LOG.info("HTTP Status: " + e.getStatus());
             LOG.info("Error Message: " + e.getMessage());
         }
    	 
    }

}
