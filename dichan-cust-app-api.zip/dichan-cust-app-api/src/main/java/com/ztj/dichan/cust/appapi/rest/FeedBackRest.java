package com.ztj.dichan.cust.appapi.rest;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.dichan.cust.appapi.service.FeedBackService;
import com.ztj.dichan.cust.appapi.vo.FeedBackVo;

import org.springframework.web.bind.annotation.RequestMethod;
import com.ztj.dichan.cust.core.constant.RestResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
/**
 * 
 * @author liuweichen
 *
 */
@Api(value = "意见反馈", description = "意见反馈")
@RestController
@RequestMapping(value = "/feedback")
public class FeedBackRest extends BaseCustRest{
	
	@Resource
	private FeedBackService feedBackService;
	

	@ApiOperation(value = "投诉意见", response = FeedBackVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "content", value = "内容", dataType = "String", paramType = "form", required = true) })
	@RequestMapping(value = "/advice", method = { RequestMethod.POST })
	public RestResult feedBack(String content) {
		RestResult result = new RestResult();

		feedBackService.addFeedBack(getCurrentMemberId(), content);

		return result;

	}
	

}
