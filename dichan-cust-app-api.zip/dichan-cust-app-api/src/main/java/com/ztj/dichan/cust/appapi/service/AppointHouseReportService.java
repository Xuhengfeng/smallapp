/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseReportVo;
import com.ztj.dichan.cust.core.constant.OtherConstant;
import com.ztj.dichan.cust.core.entity.AppointHouseReport;
import com.ztj.dichan.cust.core.repository.AppointHouseReportRepository;

/**
 * @author sily
 *
 */
@Service
@Transactional
public class AppointHouseReportService extends BaseAppService {

	@Resource
	private AppointHouseReportRepository appointHouseReportRepository;

	/**
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<AppointHouseReportVo> queryList(Long memberId, Integer pageNo, Integer pageSize) {

		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}
		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createDateTime");

		List<AppointHouseReport> list = appointHouseReportRepository.findByMemberId(memberId, pageRequest);

		List<AppointHouseReportVo> voList = list.stream().map(report -> {
			return AppointHouseReportVo.fromAppointHouseReport(report);
		}).collect(Collectors.toList());

		return voList;
	}

	/**
	 * 
	 * @param memberId
	 * @param summary
	 */
	public void addReport(Long memberId, String summary) {

		if (StringUtils.isEmpty(summary)) {
			throw new IllegalArgumentException("看房报告不能为空");
		}

		try {

			AppointHouseReport report = new AppointHouseReport();

			report.setSummary(summary);
			report.setCreateDateTime(LocalDateTime.now());
			appointHouseReportRepository.save(report);

		} catch (Exception e) {
			throw new BizException("填写看房报告出错了");
		}
	}
}
