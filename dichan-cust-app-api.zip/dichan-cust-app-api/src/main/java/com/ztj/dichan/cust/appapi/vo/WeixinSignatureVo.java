package com.ztj.dichan.cust.appapi.vo;


import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value="微信签名信息")
@Data
@EqualsAndHashCode(callSuper=false)
public class WeixinSignatureVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "公众号的唯一标识")
	private String appId;
	
	@ApiModelProperty(value = "生成签名的时间戳")
	private Long timestamp;
	
	@ApiModelProperty(value = "生成签名的随机串")
	private String nonceStr;
	
	@ApiModelProperty(value = "签名")
	private String signature;
}
