/**
 * 
 */
package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.request.BrokerRequest;
import com.ztj.dichan.cust.appapi.service.BrokerService;
import com.ztj.dichan.cust.rule.request.BrokerHouseRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @author lbs
 *
 */
@Api(value = "经纪人信息",description="经纪人信息相关接口")
@RestController
@RequestMapping(value = "/broker")
public class BrokerRest extends BaseCustRest {

	@Resource
	private BrokerService brokerService;
	
	
	@ApiOperation(value="查询经纪人信息列表",response=BrokerVo.class)
	@PostMapping(value = "/brokers")
	public RestResult<List<BrokerVo>> queryBrokers(@RequestBody BrokerRequest brokerRequest) {
		
		return RestResult.success(brokerService.queryBrokers(brokerRequest));
	
	}
	
	@ApiOperation(value="查询经纪人信息列表-总数量",response=BrokerVo.class)
	@PostMapping(value = "/brokerCount")
	public RestResult<CountVo> queryBrokerCount(@RequestBody BrokerRequest brokerRequest) {
		
		return RestResult.success(brokerService.queryBrokerCount(brokerRequest));
	
	}
	
	@ApiOperation(value="经纪人详情",response=BrokerDetailVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "scity", value = "城市编码", required = true, dataType = "string", paramType="path"),
		@ApiImplicitParam(name = "id", value = "经纪人id", required = true, dataType = "int", paramType="path")})
	@GetMapping(value = "/{scity}/{id}")
	public RestResult<BrokerDetailVo> queryBroker(@PathVariable("scity") String scity,@PathVariable("id") Integer id) {
		
		return RestResult.success(brokerService.queryBroker(scity,id,getCurrentMemberIdAllowNull()));
	
	}
	
	@ApiOperation(value="经纪人-他的租房列表",response=RentHouseVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "scity", value = "城市编码", required = true, dataType = "string", paramType="path"),
		@ApiImplicitParam(name = "id", value = "经纪人id", required = true, dataType = "int", paramType="path"),
		@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType="query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType="query")})
	@GetMapping(value = "/rentHouseList/{scity}/{id}")
	public RestResult<List<RentHouseVo>> queryBrokerRentHouseList(@PathVariable("scity") String scity,
			@PathVariable("id") Integer id,
			@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		
		return RestResult.success(brokerService.queryBrokerRentHouseList(scity,id,pageNo,pageSize));
	
	}
	
	@ApiOperation(value="经纪人-他的二手房列表",response=HouseVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "scity", value = "城市编码", required = true, dataType = "string", paramType="path"),
		@ApiImplicitParam(name = "id", value = "经纪人id", required = true, dataType = "int", paramType="path"),
		@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType="query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType="query")})
	@GetMapping(value = "/houseList/{scity}/{id}")
	public RestResult<List<HouseVo>> queryBrokerHouseList(@PathVariable("scity") String scity,
			@PathVariable("id") Integer id,
			@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		
		return RestResult.success(brokerService.queryBrokerHouseList(scity,id,pageNo,pageSize));
	
	}
	
	
	@ApiOperation(value="获取房源经纪人信息列表",response=BrokerVo.class)
	@PostMapping(value = "/house/brokers")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true)})
	public RestResult<List<BrokerVo>> queryHouseBrokers(@RequestBody BrokerHouseRequest request) {
		
		return RestResult.success(brokerService.queryHouseBrokers(request));
	
	}
	
	/**
	 * 下载经纪人头像
	 * @param username
	 * @param response
	 */
	@ApiOperation(value="下载经纪人头像（仅限聊天界面使用）")
	@RequestMapping(value = "/headImage/{username}",method = RequestMethod.GET)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "username", value = "经纪人聊天账号", required = true, dataType = "string", paramType="path")})
	public void downloadHeadImage(@PathVariable("username")String username, HttpServletResponse response) {
		brokerService.downloadHeadImage(username, response);
	}
}
