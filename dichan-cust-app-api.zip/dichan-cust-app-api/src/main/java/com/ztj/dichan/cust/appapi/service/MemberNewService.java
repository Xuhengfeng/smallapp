package com.ztj.dichan.cust.appapi.service;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.common.exception.NoLoginException;
import com.ztj.dichan.cust.core.constant.RedisConstant;
import com.ztj.dichan.cust.core.entity.Member;
import com.ztj.dichan.cust.core.repository.MemberRepository;

/**
 * 新建一个新的service,临时解决MemberService无法注入拦截器的错误
 * 
 * @author sily
 */
@Service
@Transactional
public class MemberNewService extends BaseAppService {

	@Resource
	private MemberRepository memberRepository;

	/**
	 * @param uniqueCode
	 * @return
	 */
	public Long getMemberId(String uniqueCode) {
		String memberId = null;

		try {
			memberId = (String) redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).get(uniqueCode);
		} catch (Exception e) {
			logger.error("从redis获取用户信息出错", e);
		}

		if (StringUtils.isEmpty(memberId)) {
			Member member = memberRepository.findByUniqueCode(uniqueCode);

			if (member == null) {
				throw new NoLoginException("用户未登录");
			}

			memberId = String.valueOf(member.getId());

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(uniqueCode,
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}
		}
		return Long.valueOf(memberId);
	}

	/**
	 * @param uniqueCode
	 * @return
	 */
	public Long getMemberIdAllowNull(String uniqueCode) {
		String memberId = null;

		try {
			memberId = (String) redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).get(uniqueCode);
		} catch (Exception e) {
			logger.error("从redis获取用户信息出错", e);
		}

		if (StringUtils.isEmpty(memberId)) {
			Member member = memberRepository.findByUniqueCode(uniqueCode);

			if (member == null) {
				return null;
			}

			memberId = String.valueOf(member.getId());

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(uniqueCode,
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}
		}

		return Long.valueOf(memberId);
	}
}