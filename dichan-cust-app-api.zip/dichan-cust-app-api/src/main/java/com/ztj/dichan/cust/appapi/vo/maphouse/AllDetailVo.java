/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.maphouse;

import java.util.List;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.rule.response.maphouse.ArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.DistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.HousingDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentDistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentHousingDetailVo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "地图找房数据")
@Data
@EqualsAndHashCode(callSuper = true)
public class AllDetailVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "二手房-城区均价列表")
	private List<ArerDetailVo> arerDetails;
	
	@ApiModelProperty(value = "二手房-片区均价列表")
	private List<DistrictDetailVo> districtDetails;
	
	@ApiModelProperty(value = "二手房-小区均价列表")
	private List<HousingDetailVo> housingDetails;
	
	@ApiModelProperty(value = "租房-城区套数列表")
	private List<RentArerDetailVo> rentArerDetails;
	
	@ApiModelProperty(value = "租房-片区套数列表")
	private List<RentDistrictDetailVo> rentDistrictDetails;
	
	@ApiModelProperty(value = "租房-小区套数列表")
	private List<RentHousingDetailVo> rentHousingDetails;
	
	

}
