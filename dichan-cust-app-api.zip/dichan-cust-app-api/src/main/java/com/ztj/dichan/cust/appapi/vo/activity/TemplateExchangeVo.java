package com.ztj.dichan.cust.appapi.vo.activity;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class TemplateExchangeVo extends ExchangeVo {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "模板id")
	private Long id;

	@ApiModelProperty(value = "模板名称")
	private String name;

	@ApiModelProperty(value = "已兑换数量")
	private Long soldNumber;

	@ApiModelProperty(value = "图片地址")
	private String imageUrl;
}
