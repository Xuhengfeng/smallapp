/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.activity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 已转赠状态的卡券信息对象
 * 
 * @author sily
 */
@ApiModel(value = "已转赠状态的卡券信息对象")
@Data
@EqualsAndHashCode(callSuper = true)
public class CouponGiveVo extends CouponVo {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "卡券转赠时间")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDateTime giveDateTime;

	@ApiModelProperty(value = "赠送后得到卡券的会员名称")
	private String giveToPersonName;
	
	@ApiModelProperty(value = "卡券流水记录的id")
	private Long couponFollowId;
}
