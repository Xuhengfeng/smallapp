
package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.core.constant.RedisConstant;
import com.ztj.dichan.cust.core.entity.ShareRelation;
import com.ztj.dichan.cust.core.repository.ShareRelationRepository;
import com.ztj.dichan.cust.core.util.CodeUtil;

/**
 * @author sily
 * 
 */
@Service
@Transactional
public class ShareRelationService extends BaseAppService {

	@Resource
	private ShareRelationRepository shareRelationRepository;

	public String fetchShareCode(Long memberId, String shareUrl, String parentCode) {
		try {
			ShareRelation shareRelation = new ShareRelation();

			shareRelation.setMemberId(memberId);
			shareRelation.setShareCode(CodeUtil.fetchShareCode());
			shareRelation.setShareUrl(shareUrl);
			shareRelation.setShareNumber(0L);
			shareRelation.setReadNumber(0L);
			shareRelation.setCreateDateTime(LocalDateTime.now());

			ShareRelation parentShareRelation = null;

			if (StringUtils.isNotEmpty(parentCode)) {
				parentShareRelation = shareRelationRepository.findByShareCode(parentCode);

				if (parentShareRelation != null) {
					shareRelation.setParentCode(parentShareRelation.getShareCode());
					shareRelation.setParentMemberId(parentShareRelation.getMemberId());
				}
			}

			shareRelationRepository.save(shareRelation);

			if (parentShareRelation != null) {
				redisTemplate.boundListOps(RedisConstant.SHARE_CODE_LIST)
						.leftPush(parentShareRelation.getShareCode() + "_SHARE");
			}

			return shareRelation.getShareCode();
		} catch (Exception e) {
			throw new BizException("获取分享编码出错了", e);
		}
	}

	/**
	 * 
	 * @param shareCode
	 */
	public void toAddReadNumber(String shareCode) {
		if (StringUtils.isEmpty(shareCode)) {
			throw new IllegalArgumentException("分享cdoe不能为空");
		}

		try {
			redisTemplate.boundListOps(RedisConstant.SHARE_CODE_LIST).leftPush(shareCode + "_READ");
		} catch (Exception e) {
			throw new BizException("增加阅读量出错了", e);
		}
	}

	public void updateCount() {
		try {
			String shareCode = (String) redisTemplate.boundListOps(RedisConstant.SHARE_CODE_LIST).rightPop();

			if (shareCode != null) {
				int index = shareCode.indexOf("_");
				String prefix = shareCode.substring(0, index);
				String subfix = shareCode.substring(index + 1);

				if (subfix.equals("READ")) {
					ShareRelation shareRelation = shareRelationRepository.findByShareCode(prefix);

					shareRelation.setReadNumber(shareRelation.getReadNumber() + 1);
					shareRelation.setUpdateDateTime(LocalDateTime.now());

					shareRelationRepository.save(shareRelation);
				} else if (subfix.equals("SHARE")) {
					ShareRelation shareRelation = shareRelationRepository.findByShareCode(prefix);

					shareRelation.setReadNumber(shareRelation.getReadNumber() + 1);
					shareRelation.setShareNumber(shareRelation.getShareNumber() + 1);
					shareRelation.setUpdateDateTime(LocalDateTime.now());

					shareRelationRepository.save(shareRelation);
				}
			}
		} catch (Exception e) {
			throw new BizException("增加阅读量或者分享量出错了", e);
		}
	}
	
	
}
