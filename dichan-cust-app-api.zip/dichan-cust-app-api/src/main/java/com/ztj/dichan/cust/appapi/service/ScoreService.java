package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.ztj.common.exception.BizException;
import com.ztj.common.util.DateUtil;
import com.ztj.dichan.cust.appapi.repository.activity.CouponFollowRecordRepository;
import com.ztj.dichan.cust.appapi.repository.activity.CouponRepository;
import com.ztj.dichan.cust.appapi.repository.activity.ExchangeAvailableRepository;
import com.ztj.dichan.cust.appapi.repository.activity.ScoreFollowRecordRepository;
import com.ztj.dichan.cust.appapi.repository.activity.TemplateRepository;
import com.ztj.dichan.cust.appapi.repository.activity.WalletRepository;
import com.ztj.dichan.cust.appapi.vo.activity.ExchangeVo;
import com.ztj.dichan.cust.appapi.vo.activity.GoodsDetailVo;
import com.ztj.dichan.cust.appapi.vo.activity.ScoreDetailVo;
import com.ztj.dichan.cust.appapi.vo.activity.ScoreFollowRecordVo;
import com.ztj.dichan.cust.appapi.vo.activity.TemplateDetailVo;
import com.ztj.dichan.cust.appapi.vo.activity.TemplateExchangeVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.Member;
import com.ztj.dichan.cust.core.entity.activity.Coupon;
import com.ztj.dichan.cust.core.entity.activity.CouponFollowRecord;
import com.ztj.dichan.cust.core.entity.activity.ExchangeAvailable;
import com.ztj.dichan.cust.core.entity.activity.ScoreFollowRecord;
import com.ztj.dichan.cust.core.entity.activity.Template;
import com.ztj.dichan.cust.core.entity.activity.Wallet;
import com.ztj.dichan.cust.core.enums.CouponFollwTypeEnum;
import com.ztj.dichan.cust.core.enums.CouponStatusEnum;
import com.ztj.dichan.cust.core.enums.ExchangeAvailableStatusEnum;
import com.ztj.dichan.cust.core.enums.GoodsTypeEnum;
import com.ztj.dichan.cust.core.enums.OperateTypeEnum;
import com.ztj.dichan.cust.core.enums.ScoreFollowTypeEnum;
import com.ztj.dichan.cust.core.repository.MemberRepository;
import com.ztj.dichan.cust.core.util.CodeUtil;
import com.ztj.dichan.cust.core.util.VerifyUtil;
import com.ztj.dichan.cust.rule.util.Utils;

@Service
@Transactional
public class ScoreService extends BaseAppService {

	@Resource
	private MemberRepository memberRepository;

	@Resource
	private TemplateRepository couponModelRepository;

	@Resource
	private CouponRepository couponRepository;

	@Resource
	private ScoreFollowRecordRepository scoreFollowRecordRepository;

	@Resource
	private WalletRepository walletRepository;

	@Resource
	private TemplateRepository templateRepository;

	@Resource
	private ExchangeAvailableRepository exchangeAvailableRepository;
	
	@Resource
	CouponFollowRecordRepository couponFollowRecordRepository;

	/**
	 * 获取兑换商品的详细信息
	 * 
	 * @param memberId
	 * @param templateId
	 * @return
	 */
	public GoodsDetailVo getGoodsDetail(Long memberId, Long exchangeId) {
		if (exchangeId == null) {
			throw new IllegalArgumentException("商品编号不能为空");
		}

		ExchangeAvailable exchange = exchangeAvailableRepository.findOne(exchangeId);

		if (exchange == null) {
			throw new IllegalStateException("找不到兑换商品信息");
		}

		if (exchange.getGoodsType() == GoodsTypeEnum.COUPON) {
			Template template = templateRepository.findOne(exchange.getTemplateId());

			if (template == null) {
				throw new IllegalStateException("找不到卡券模板信息");
			}

			TemplateDetailVo detailVo = new TemplateDetailVo();
			detailVo.setName(template.getName());
			detailVo.setImageUrl(template.getImageUrl());
			detailVo.setContent(template.getContent());
			detailVo.setNeedScore(exchange.getScore());
			detailVo.setSoldNumber(exchange.getSoldNumber());
			detailVo.setExchangeId(exchange.getId());

			if (memberId != null) {
				Wallet wallet = walletRepository.findByMemberId(memberId);

				detailVo.setCurrentScore(wallet.getScore());
			}

			return detailVo;
		} else {
			return new GoodsDetailVo();
		}
	}

	/**
	 * 获取积分明细信息
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public ScoreDetailVo getScoreDetails(Long memberId, Integer pageNo, Integer pageSize) {
		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createDateTime");

		ScoreDetailVo detailVo = new ScoreDetailVo();

		Wallet wallet = walletRepository.findByMemberId(memberId);

		if (wallet != null) {
			detailVo.setCurrentScore(wallet.getScore());
		}

		detailVo.setYear(LocalDateTime.now().getYear());

		Page<ScoreFollowRecord> page = scoreFollowRecordRepository.findByMemberId(memberId, pageRequest);

		List<ScoreFollowRecordVo> scoreDetailList = new ArrayList<>();

		if (page.getContent() != null && !page.getContent().isEmpty()) {
			page.getContent().forEach(record -> {
				ScoreFollowRecordVo scoreDetailVo = new ScoreFollowRecordVo();
				scoreDetailVo.setFollowTypeName(record.getFollowType().getName());
				scoreDetailVo.setCreateDate(
						DateUtil.formatLocalDateTime(record.getCreateDateTime(), DateUtil.DATEFORMAT_DATETIME16));
				scoreDetailVo.setScore(record.getScore());
				scoreDetailVo.setRemainingScore(record.getRemainingScore());

				scoreDetailList.add(scoreDetailVo);
			});
		}

		detailVo.setRecordVoList(scoreDetailList);

		return detailVo;
	}

	/**
	 * 查询积分可以兑换的物品
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<ExchangeVo> queryList(Integer pageNo, Integer pageSize) {
		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createDateTime");

		Page<ExchangeAvailable> pageInfo = exchangeAvailableRepository.findByStatus(ExchangeAvailableStatusEnum.NORMAL,
				pageRequest);

		List<ExchangeVo> voList = new ArrayList<>();

		pageInfo.getContent().stream().forEach(exchange -> {
			if (exchange.getGoodsType() == GoodsTypeEnum.COUPON) {
				TemplateExchangeVo vo = new TemplateExchangeVo();
				vo.setScore(exchange.getScore());
				vo.setExchangeId(exchange.getId());
				vo.setScore(exchange.getScore());
				vo.setSoldNumber(exchange.getSoldNumber());
				Template template = templateRepository.findOne(exchange.getTemplateId());

				if (template != null) {
					vo.setName(template.getName());
					vo.setImageUrl(template.getImageUrl());
					vo.setId(template.getId());
				}

				voList.add(vo);
			}
		});

		return voList;
	}

	public void giveScore(Long memberId, Long scoreNumber, String smsCode, String giveMobile) {
		if (StringUtils.isEmpty(smsCode)) {
			throw new IllegalArgumentException("验证码不能为空");
		}

		if (scoreNumber == null || scoreNumber <= 0) {
			throw new IllegalArgumentException("赠送积分不能为空或者数值要大于0");
		}

		if (StringUtils.isEmpty(giveMobile)) {
			throw new IllegalArgumentException("赠送人手机号不能为空");
		}

		if (!VerifyUtil.isMobile(giveMobile)) {
			throw new IllegalArgumentException("赠送人手机格式不正确");
		}

		try {
			Member member = memberRepository.findOne(memberId);

			String verifyCode = (String) redisTemplate.opsForValue()
					.get(member.getMobile() + "_" + OperateTypeEnum.GIVE_SCORE.toString());

			if (!Utils.checkSmsCode(smsCode, verifyCode)) {
				throw new IllegalArgumentException("手机验证码不正确");
			}

			// 处理当前用户的积分
			Wallet wallet = walletRepository.findByMemberId(memberId);

			if (wallet.getScore() < scoreNumber) {
				throw new IllegalStateException("赠送的积分超过了用户当前积分总数");
			}

			wallet.setScore(wallet.getScore() - scoreNumber);
			wallet.setUpdateDateTime(LocalDateTime.now());

			walletRepository.save(wallet);

			// 处理赠送人用户积分
			Member giveMember = memberRepository.findByMobile(giveMobile);

			if (giveMember == null) {
				throw new IllegalStateException("找不到赠送的用户");
			}

			Wallet giveWallet = walletRepository.findByMemberId(giveMember.getId());

			giveWallet.setScore(giveWallet.getScore() + scoreNumber);
			giveWallet.setUpdateDateTime(LocalDateTime.now());

			walletRepository.save(giveWallet);

			// 保存流水记录
			ScoreFollowRecord fromFollowRecord = new ScoreFollowRecord();
			fromFollowRecord.setFollowType(ScoreFollowTypeEnum.GIVE_FROM);
			fromFollowRecord.setMemberId(member.getId());
			fromFollowRecord.setMemberCode(member.getCode());
			fromFollowRecord.setGiveToMemberId(giveMember.getId());
			fromFollowRecord.setScore(-scoreNumber);
			fromFollowRecord.setRemainingScore(wallet.getScore());
			fromFollowRecord.setUpdateDateTime(LocalDateTime.now());

			scoreFollowRecordRepository.save(fromFollowRecord);

			ScoreFollowRecord toFollowRecord = new ScoreFollowRecord();
			toFollowRecord.setFollowType(ScoreFollowTypeEnum.GIVE_TO);
			toFollowRecord.setMemberId(giveMember.getId());
			toFollowRecord.setMemberCode(giveMember.getCode());
			toFollowRecord.setScore(scoreNumber);
			toFollowRecord.setRemainingScore(giveWallet.getScore());
			toFollowRecord.setUpdateDateTime(LocalDateTime.now());

			scoreFollowRecordRepository.save(toFollowRecord);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("赠送积分出错了", e);
		}
	}

	/**
	 * 积分兑换礼品
	 * 
	 * @param memberId
	 * @param exchangeId
	 * @param number
	 * @param smsCode
	 */
	public void scoreExchangeGift(Long memberId, Long exchangeId, Long number, String smsCode) {
		if (exchangeId == null) {
			throw new IllegalArgumentException("商品id不能为空");
		}

		if (number == null || number <= 0) {
			throw new IllegalArgumentException("商品数量不合法");
		}

		if (number > 5) {
			throw new IllegalArgumentException("一次兑换的物品数量不能超过5个");
		}

		if (StringUtils.isEmpty(smsCode)) {
			throw new IllegalArgumentException("验证码不能为空");
		}

		try {
			Member member = memberRepository.findOne(memberId);

			String verifyCode = (String) redisTemplate.opsForValue()
					.get(member.getMobile() + "_" + OperateTypeEnum.SCORE_EXCHANGE_GIFT.toString());

			if (!Utils.checkSmsCode(smsCode, verifyCode)) {
				throw new IllegalArgumentException("手机验证码不正确");
			}

			ExchangeAvailable exchangeAvailable = exchangeAvailableRepository.findOne(exchangeId);

			if (exchangeAvailable == null) {
				throw new IllegalStateException("找不到对应的商品");
			}

			Template template = templateRepository.findOne(exchangeAvailable.getTemplateId());

			if (template == null) {
				throw new IllegalStateException("礼品id参数异常");
			}
			
//			已兑换数量+1
			Long soldNumber = exchangeAvailable.getSoldNumber();
			if(soldNumber==null) {
				soldNumber =0L;
			}
			exchangeAvailable.setSoldNumber(soldNumber+number);

//			扣除积分
			Wallet wallet = walletRepository.findByMemberId(memberId);
			Long currentPoints = wallet.getScore();
			Long consumePoints = number * exchangeAvailable.getScore();
			if (currentPoints < consumePoints) {
				throw new IllegalStateException("兑换礼品的积分超过了用户当前积分");
			}
			wallet.setScore(currentPoints - consumePoints);
			wallet.setUpdateDateTime(LocalDateTime.now());
			Integer currentCoupons = wallet.getCouponCount();
			wallet.setCouponCount(currentCoupons+number.intValue());
			walletRepository.save(wallet);

			for (int i = 1; i <= number; i++) {

//				生成一张券,并绑定到用户
				Coupon coupon = new Coupon();
				coupon.setTemplateId(template.getId());
				coupon.setBeginDateTime(template.getBeginDateTime());
				coupon.setEndDateTime(template.getEndDateTime());
				coupon.setStatus(CouponStatusEnum.NO_USED);
				coupon.setFetchDateTime(LocalDateTime.now());
				coupon.setOwnMemberId(memberId);
				coupon.setFetchMemberId(memberId);
				coupon.setCode(CodeUtil.couponCode());
				coupon.setCouponType(template.getCouponType());
				coupon.setName(template.getName());
				couponRepository.save(coupon);

//				保存积分流水详情
				ScoreFollowRecord scoreFollowRecord = new ScoreFollowRecord();
				scoreFollowRecord.setCreateDateTime(LocalDateTime.now());
				scoreFollowRecord.setMemberId(memberId);
				scoreFollowRecord.setMemberCode(member.getCode());
				scoreFollowRecord.setScore(-exchangeAvailable.getScore());
				scoreFollowRecord.setFollowType(ScoreFollowTypeEnum.COUPON);
				scoreFollowRecord.setRemainingScore(wallet.getScore());
				scoreFollowRecord.setCouponCode(coupon.getCode());
				scoreFollowRecordRepository.save(scoreFollowRecord);

//				保存券的流水记录
				CouponFollowRecord couponFollowRecord = new CouponFollowRecord();
				String scity = RequestContextHolder.getCityCode();
				couponFollowRecord.setCityCode(scity);
				couponFollowRecord.setCouponCode(coupon.getCode());
				couponFollowRecord.setCouponId(coupon.getId());
				couponFollowRecord.setFollwType(CouponFollwTypeEnum.SCORE_EXCHANGE);
				couponFollowRecord.setMemberId(memberId);
				couponFollowRecord.setPersonName(member.getUsername());
				couponFollowRecord.setScore(exchangeAvailable.getScore());
				
				couponFollowRecordRepository.save(couponFollowRecord);

			}

		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("积分兑换礼品出错了", e);
		}
	}

}
