/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.alibaba.druid.util.StringUtils;
import com.ztj.dichan.cust.appapi.external.HouseServiceClient;
import com.ztj.dichan.cust.appapi.vo.StatisticsInfoVo;
import com.ztj.dichan.cust.appapi.vo.trend.TrendDetailVo;
import com.ztj.dichan.cust.appapi.vo.trend.TrendVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.StatisticsInfo;
import com.ztj.dichan.cust.core.enums.DicType;
import com.ztj.dichan.cust.core.repository.StatisticsInfoRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.TrendRequest;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * @author yincp
 *
 */
@Service
public class StatisticalService extends BaseAppService {

	@Resource
	private StatisticsInfoRepository statisticsInfoRepository;
	
	@Resource
	private HouseServiceClient houseServiceClient;
	
	@Resource
	private DictionaryService dictionaryService;
	
	public TrendVo trend() {
		 
		TrendVo trendVo = new TrendVo();
		
		List<TrendDetailVo> tdList = new LinkedList<TrendDetailVo>();
	     String cityCode = RequestContextHolder.getCityCode();
	     List<Map<String, Integer>> ymArray = get12Months();
		 for (Map<String, Integer> map : ymArray) {
			 Integer year = Integer.parseInt(map.get("year").toString());
			 Integer month = Integer.parseInt(map.get("month").toString());
			 StatisticsInfo info = statisticsInfoRepository.findByCityCodeAndYearAndMonth(cityCode, year, month);
			 if(info!=null) {
				 TrendDetailVo detailVo = new TrendDetailVo();
				 detailVo.setAvgPrice(info.getAvgPrice());
				 detailVo.setMarketPrice(info.getMarketPrice());
				 detailVo.setMonth(info.getMonth());
				 detailVo.setSuiteCount(info.getSuiteCount());
				 detailVo.setTitle(info.getTitle());
				 detailVo.setYear(info.getYear());
				 tdList.add(detailVo);
			 }
		 }
		 trendVo.setTrendList(tdList);
		 
		 StatisticsInfoVo statisticsInfoVo = this.querCurrentMonthStatistics(cityCode);
		 
		 trendVo.setAvgPrice(statisticsInfoVo.getAvgPrice());
		 trendVo.setMonth(statisticsInfoVo.getMonth());
		 trendVo.setSuiteCount(statisticsInfoVo.getSuiteCount());
		
		 boolean flag = dictionaryService.checkDictionaryExist(DicType.DEAL_FORBID_CITY, cityCode);
		 
		 if (!flag) {
			 TrendRequest trendRequest = new TrendRequest();
			 trendRequest.setScity(cityCode);
			 CountVo countVo = houseServiceClient.housing60DaysCount(trendRequest, cityCode);
			 if (countVo != null && countVo.getCount() != null) {
				 trendVo.setDay60SuiteCount(countVo.getCount());
			 } else {
				 trendVo.setDay60SuiteCount(0);
			 }
			 trendVo.setIsViewRecord(true);
		 } else {
			 trendVo.setDay60SuiteCount(0);
			 trendVo.setIsViewRecord(false);
		 }
		 
		return trendVo;
	}
	
	
	/**
	 * 获取最近12个月，用于统计图表的X轴  
	 */
    public static List<Map<String, Integer>> get12Months(){  
        List<Map<String, Integer>> list = new LinkedList<Map<String, Integer>>();
        Calendar cal = Calendar.getInstance();  
        cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)); 
        for(int i=0; i<12; i++){  
        	Map<String, Integer> map = new LinkedHashMap<String, Integer>();
            cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)-1); 
            map.put("year", cal.get(Calendar.YEAR));
            map.put("month", cal.get(Calendar.MONTH)+1);
            list.add(map);
        }  
        return list;  
    }
    
    
    public List<SecondHouseVo> housing60Days(TrendRequest request) {
    	
    	String scity = this.getScityNew(request);
    	
    	List<SecondHouseVo> day60List = houseServiceClient.housing60Days(request,scity);
    	if (day60List == null) {
			return new ArrayList<>(0);
		}
    	day60List.forEach(secondHouseVo -> {
    		secondHouseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), secondHouseVo.getHousePic(),
    				scity, String.valueOf(secondHouseVo.getId())));

		});
		return day60List;
	}
    
    
    /**
	 * 房价统计
	 * @param city_id
	 * @param month
	 * @return
	 */
	public StatisticsInfoVo querCurrentMonthStatistics(String cityCode) {
		LocalDateTime now = LocalDateTime.now();
		Integer year = now.getYear();
		Integer month = now.getMonthValue()-1;
		StatisticsInfoVo vo = new StatisticsInfoVo();
		if (StringUtils.isEmpty(cityCode)) {
			vo.setAvgPrice(0.0);
			vo.setMonth(month);
			vo.setSuiteCount(0);
			return vo;
		}
		
		StatisticsInfo info = statisticsInfoRepository.findByCityCodeAndYearAndMonth(cityCode,year,month);
		if (info == null) {
			vo.setAvgPrice(0.0);
			vo.setMonth(month);
			vo.setSuiteCount(0);
			return vo;
		}
		vo.setAvgPrice(info.getAvgPrice() == null? 0:info.getAvgPrice());
		vo.setMonth(info.getMonth());
		vo.setSuiteCount(info.getSuiteCount() == null? 0:info.getSuiteCount());
		return vo;
	}

}
