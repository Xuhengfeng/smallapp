package com.ztj.dichan.cust.appapi.handler;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.web.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ztj.common.constant.ReturnCode;
import com.ztj.dichan.cust.core.constant.RestResult;


/**
 * 处理404错误,支持返回jsp页面或者使用@ResponseBody注解返回对应的json串
 * 
 * @author test01
 */
@Controller
public class DefaultErrorController implements ErrorController {
	private static Logger logger = LoggerFactory.getLogger(DefaultErrorController.class);

	private static final String ERROR_PATH = "/error";

	/**
	 *
	 * @param request
	 * @return
	 */
	@RequestMapping(value = ERROR_PATH)
	@ResponseBody
	public ResponseEntity<Object> errorHtml(HttpServletRequest request) {
		RestResult restResult = new RestResult();
		restResult.setStatus(ReturnCode.REC_5.getCode());
		restResult.setMsg(ReturnCode.REC_5.getName());

		logger.error("找不到请求地址,返回的响应数据=" + restResult + "," + request.getRequestURI());

		return new ResponseEntity<>(restResult, HttpStatus.NOT_FOUND);
	}

	/**
	 *
	 * @return the error path
	 */
	@Override
	public String getErrorPath() {
		return ERROR_PATH;
	}
}