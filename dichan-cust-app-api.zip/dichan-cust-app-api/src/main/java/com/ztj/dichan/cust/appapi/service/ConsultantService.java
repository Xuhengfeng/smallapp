package com.ztj.dichan.cust.appapi.service;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Service;

import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.request.SubProblemRequest;
import com.ztj.dichan.cust.appapi.util.PageUtil;
import com.ztj.dichan.cust.appapi.vo.consultant.AnswerVo;
import com.ztj.dichan.cust.appapi.vo.consultant.ConcernConsultVo;
import com.ztj.dichan.cust.appapi.vo.consultant.ConsultantInfoVo;
import com.ztj.dichan.cust.appapi.vo.consultant.ConsultantVo;
import com.ztj.dichan.cust.appapi.vo.consultant.HotConsultVo;
import com.ztj.dichan.cust.appapi.vo.consultant.MyConsultVo;
import com.ztj.dichan.cust.appapi.vo.consultant.ProblemAnswerVo;
import com.ztj.dichan.cust.appapi.vo.consultant.ProblemInfoVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.Consultant;
import com.ztj.dichan.cust.core.entity.ConsultantProblem;
import com.ztj.dichan.cust.core.entity.Member;
import com.ztj.dichan.cust.core.entity.ProblemAnswer;
import com.ztj.dichan.cust.core.entity.ProblemConcern;
import com.ztj.dichan.cust.core.enums.ConcernOperateStatusEnum;
import com.ztj.dichan.cust.core.enums.ConcernStatusEnum;
import com.ztj.dichan.cust.core.enums.RemdStatusEnum;
import com.ztj.dichan.cust.core.enums.WhetherAdoptEnum;
import com.ztj.dichan.cust.core.repository.ConsultantProblemRepository;
import com.ztj.dichan.cust.core.repository.ConsultantRepository;
import com.ztj.dichan.cust.core.repository.MemberRepository;
import com.ztj.dichan.cust.core.repository.ProblemAnswerRepository;
import com.ztj.dichan.cust.core.repository.ProblemConcernRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.core.vo.ConsultantQueryVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;

/**
 * 
 * @author yincp
 */
@Service
@Transactional
public class ConsultantService extends BaseAppService {
	
	private static Map<String,String> CLASSIFY_MAP = new HashMap<String,String>();
	  
	  static {
	    CLASSIFY_MAP.put("1001", "交易过户");
	    CLASSIFY_MAP.put("1002", "卖房");
	    CLASSIFY_MAP.put("1003", "买房");
	    CLASSIFY_MAP.put("1004", "贷款");
	    
	    CLASSIFY_MAP.put("交易过户", "1001");
	    CLASSIFY_MAP.put("卖房", "1002");
	    CLASSIFY_MAP.put("买房", "1003");
	    CLASSIFY_MAP.put("贷款", "1004");
	  }
	  
	@Resource
	private ConsultantRepository consultantRepository ;
	
	
	@Resource
	private ProblemConcernRepository problemConcernRepository ;
	
	@Resource
	private ConsultantProblemRepository consultantProblemRepository ;
	
	@Resource
	private ProblemAnswerRepository problemAnswerRepository ;
	
	@Resource
	private BrokerServiceClient brokerServiceClient;
	
	@Resource
	private MemberRepository memberRepository;
	
	
	
	public List<ConsultantVo> recommendConsultant(){
		String cityCode = RequestContextHolder.getCityCode();
		List<Consultant>  list = 	consultantRepository.findTop4ByCityCodeAndRemdStatus(cityCode,RemdStatusEnum.YES);
		List<ConsultantVo> clList = new LinkedList<>();
		list.forEach(cl->{
			ConsultantVo consultantVo = new ConsultantVo();
			consultantVo.setEmployeeId(cl.getEmployeeId());
			consultantVo.setName(cl.getName());
			consultantVo.setPhoto(queryEmployeePhoto(cityCode, cl.getEmployeeId()));
			consultantVo.setLabel(cl.getLabel());
			
			String classifyCode = cl.getClassifyCode();
			consultantVo.setClassifyName(String.valueOf(CLASSIFY_MAP.get(classifyCode)));
			clList.add(consultantVo);
		});
		return clList;
		
	}

	public List<ConsultantVo> consultantList(){
		String cityCode = RequestContextHolder.getCityCode();
		ConsultantQueryVo queryVo = new ConsultantQueryVo();
		queryVo.setCityCode(cityCode);
		List<Consultant>  list = 	consultantRepository.queryList(queryVo);
		List<ConsultantVo> clList = new LinkedList<>();
		list.forEach(cl->{
			ConsultantVo consultantVo = new ConsultantVo();
			consultantVo.setEmployeeId(cl.getEmployeeId());
			consultantVo.setName(cl.getName());
			consultantVo.setPhoto(queryEmployeePhoto(cityCode, cl.getEmployeeId()));
			consultantVo.setLabel(cl.getLabel());
			
			String classifyCode = cl.getClassifyCode();
			consultantVo.setClassifyName(String.valueOf(CLASSIFY_MAP.get(classifyCode)));
			
			clList.add(consultantVo);
		});
		return clList;
		
	}
	
	public List<HotConsultVo> hotConsultList(){
		/*String cityCode = RequestContext.getCityCode();
		List<BigInteger> ids = problemConcernRepository.queryHotProblemId(cityCode);
		List<Long> idArray = new ArrayList<>();
		for (BigInteger obj : ids) {
			Long l =  obj.longValue();
			idArray.add(l);
		}
		
		if(ids==null || ids.isEmpty()) {
			return new ArrayList<>(0);
		}*/
		List<HotConsultVo> hotList = new LinkedList<>();
//		List<ConsultantProblem> hotConsults =  consultantProblemRepository.findByCityCodeAndIdIn(cityCode,idArray);
		Iterable<ConsultantProblem> hotConsults = 	consultantProblemRepository.findAll();
		hotConsults.forEach(houtCon->{
			HotConsultVo hotConsultVo = new HotConsultVo();
			hotConsultVo.setId(houtCon.getId());
			hotConsultVo.setProblemTitle(houtCon.getProblemTitle());
			hotConsultVo.setProblemDescribe(houtCon.getProblemDescribe());
			hotConsultVo.setLabel(houtCon.getLabel());
			String classifyCode = houtCon.getClassifyCode();
			hotConsultVo.setClassifyName(String.valueOf(CLASSIFY_MAP.get(classifyCode)));
			hotConsultVo.setScity(houtCon.getCityCode());
			
			
			hotConsultVo.setPubTime(formDate(houtCon.getPubDateTime()));
			hotConsultVo.setAnswerNum(houtCon.getAnswerNum());
			hotList.add(hotConsultVo);
		});
		return hotList;
		
	}
	
	public void submitProblem(SubProblemRequest request){
		String cityCode = RequestContextHolder.getCityCode();
		ConsultantProblem entity = new ConsultantProblem();
		try {
			BeanUtils.copyProperties(entity, request);
		} catch (IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}
		Member member = memberRepository.findOne(request.getMemberId());
		if (member != null) {
			entity.setMemberName(member.getUsername());
		}
		
		if(request.getEmployeeId()!=null)
		entity.setEmployeeId(request.getEmployeeId()==0?null:request.getEmployeeId());
		entity.setPubDateTime(LocalDateTime.now());
		entity.setClassifyCode(CLASSIFY_MAP.get(request.getLabel()));
		entity.setCityCode(cityCode);
		entity.setAnswerNum(0L);
		consultantProblemRepository.save(entity);
		
	}
	
	
	public List<MyConsultVo> myProblem(Long memberId, Integer pageNo, Integer pageSize){
		String cityCode = RequestContextHolder.getCityCode();
		List<ConsultantProblem> myProblems = consultantProblemRepository.queryMyProblem(cityCode, memberId, PageUtil.createPage(pageNo, pageSize));
		List<MyConsultVo> hotList = new LinkedList<>();
		myProblems.forEach(myCon ->{
			MyConsultVo myConsultVo = new MyConsultVo();
			myConsultVo.setId(myCon.getId());
			myConsultVo.setProblemTitle(myCon.getProblemTitle());
			myConsultVo.setProblemDescribe(myCon.getProblemDescribe());
			myConsultVo.setLabel(myCon.getLabel());
			String classifyCode = myCon.getClassifyCode();
			myConsultVo.setClassifyName(String.valueOf(CLASSIFY_MAP.get(classifyCode)));

			myConsultVo.setPubTime(formDate(myCon.getPubDateTime()));
			myConsultVo.setAnswerNum(myCon.getAnswerNum());
			hotList.add(myConsultVo);
			
		});
		return hotList;
	}
	
	
	public List<ConcernConsultVo> myConcern(Long memberId){
		String cityCode = RequestContextHolder.getCityCode();
		List<ProblemConcern> ids = problemConcernRepository.findByCityCodeAndMemberId(cityCode,memberId);
		if(ids==null || ids.isEmpty()) {
			return new ArrayList<>(0);
		}
		List<Long> idArray = new ArrayList<>();
		for (ProblemConcern problemConcern : ids) {
			idArray.add(problemConcern.getContProblemId());
		}
		
		List<ConcernConsultVo> concernList = new LinkedList<>();
		Iterable<ConsultantProblem> conConsults =  consultantProblemRepository.findAll(idArray);
		conConsults.forEach(houtCon->{
			ConcernConsultVo conConsultVo = new ConcernConsultVo();
			conConsultVo.setId(houtCon.getId());
			conConsultVo.setProblemTitle(houtCon.getProblemTitle());
			conConsultVo.setProblemDescribe(houtCon.getProblemDescribe());
			conConsultVo.setLabel(houtCon.getLabel());
			String classifyCode = houtCon.getClassifyCode();
			conConsultVo.setClassifyName(String.valueOf(CLASSIFY_MAP.get(classifyCode)));
			
			conConsultVo.setPubTime(formDate(houtCon.getPubDateTime()));
			conConsultVo.setAnswerNum(houtCon.getAnswerNum());
			concernList.add(conConsultVo);
		});
		return concernList;
		
	}
	
	public void concernOrCancel(Long memberId,Long contProblemId,String state){
		String cityCode = RequestContextHolder.getCityCode();
		ProblemConcern concern =  problemConcernRepository.findByCityCodeAndMemberIdAndContProblemId(cityCode, memberId,contProblemId);
		if(concern == null) {
			if(state.equals(ConcernOperateStatusEnum.CONCERN.getCode())) {
				ProblemConcern problemConcern = new ProblemConcern();
				problemConcern.setCityCode(cityCode);
				problemConcern.setMemberId(memberId);
				problemConcern.setContProblemId(contProblemId);
				problemConcern.setCreateTime(LocalDateTime.now());
				problemConcern.setConcernStatus(ConcernOperateStatusEnum.CONCERN);
				problemConcernRepository.save(problemConcern);
			}else {
				throw new BizException("你还未关注过该问题");
			}
		}else {
			if(state.equals(ConcernOperateStatusEnum.CANCEL.getCode())) {
				problemConcernRepository.updateConcernStatus(ConcernOperateStatusEnum.CANCEL, cityCode, memberId, contProblemId);
			}else {
				problemConcernRepository.updateConcernStatus(ConcernOperateStatusEnum.CONCERN, cityCode, memberId, contProblemId);
			}
		}
		
		
	}
	
	public void adopt(Long problemAnswerId){
		ProblemAnswer problemAnswer =  	problemAnswerRepository.findOne(problemAnswerId);
		problemAnswer.setWhetherAdopt(WhetherAdoptEnum.YES);
		problemAnswerRepository.save(problemAnswer);
		
	}
	
	
	
	public ConsultantInfoVo consultantInfo(Long employeeId){
		String cityCode = RequestContextHolder.getCityCode();
		Consultant consultant =  consultantRepository.findByCityCodeAndEmployeeId(cityCode, employeeId);
		if(consultant == null) {
			throw new BizException("找不到顾问数据");
		}
		ConsultantInfoVo infoVo = new ConsultantInfoVo();
		infoVo.setEmployeeId(consultant.getEmployeeId());
		infoVo.setLabel(consultant.getLabel());
		infoVo.setSummary(consultant.getSummary());
		infoVo.setAnswerNum(consultant.getAnswerNum());
		Long problemNum = consultantProblemRepository.countByEmployeeId(employeeId);
		infoVo.setProblemNum(problemNum);
		infoVo.setPhoto(queryEmployeePhoto(cityCode, consultant.getEmployeeId()));
		
		List<ConsultantProblem> problemList =  problemAnswerRepository.queryProblem(employeeId);
		List<AnswerVo> answerList = new LinkedList<>();
		for (ConsultantProblem consultantProblem : problemList) {
			AnswerVo answerVo = new AnswerVo();
			answerVo.setContProblemId(consultantProblem.getId());
			answerVo.setProblemTitle(consultantProblem.getProblemTitle());
			answerList.add(answerVo);
		}
		infoVo.setAnswerList(answerList);
		return infoVo;
		
	}
	
	public ProblemInfoVo problemInfo(Long memberId,Long contProblemId){
		
		ConsultantProblem consultantProblem = consultantProblemRepository.findOne(contProblemId);
		if(consultantProblem == null) {
			throw new BizException("找不到问题数据");
		}
		ProblemInfoVo problemInfoVo = new ProblemInfoVo();
		problemInfoVo.setContProblemId(consultantProblem.getId());
		problemInfoVo.setProblemTitle(consultantProblem.getProblemTitle());
		problemInfoVo.setProblemDescribe(consultantProblem.getProblemDescribe());
		problemInfoVo.setPubTime(formDate(consultantProblem.getPubDateTime()));
		problemInfoVo.setLabel(consultantProblem.getLabel());
		
		String classifyCode = consultantProblem.getClassifyCode();
		problemInfoVo.setClassifyName(String.valueOf(CLASSIFY_MAP.get(classifyCode)));
		
		problemInfoVo.setMemberId(consultantProblem.getMemberId());
		problemInfoVo.setMemberName(consultantProblem.getMemberName());
		problemInfoVo.setAnswerNum(consultantProblem.getAnswerNum());
		
		String cityCode = RequestContextHolder.getCityCode();
		if (memberId != null && memberId > 0) {
			ProblemConcern concern =  problemConcernRepository.findByCityCodeAndMemberIdAndContProblemId(cityCode, memberId,contProblemId);
			if(concern == null || concern.getConcernStatus().getCode().equals("cancel") ) {
				problemInfoVo.setConcernStatus(ConcernStatusEnum.NO);
			}else {
				problemInfoVo.setConcernStatus(ConcernStatusEnum.YES);
			}
		} else {
			problemInfoVo.setConcernStatus(ConcernStatusEnum.NO);
		}
		

		List<ProblemAnswerVo> problemAnswers = new LinkedList<>();
		List<ProblemAnswer> problemAnswerList =  problemAnswerRepository.findByCityCodeAndContProblemId(cityCode, contProblemId);
		problemAnswerList.forEach(pa->{
			ProblemAnswerVo answerVo = new ProblemAnswerVo();
			answerVo.setContProblemId(pa.getContProblemId());
			answerVo.setConsultantId(pa.getConsultantId());
			answerVo.setConsultantName(pa.getConsultantName());
			answerVo.setAnswerTime(formDate(pa.getAnswerDateTime()));
			answerVo.setAnswerContent(pa.getAnswerContent());
			answerVo.setWhetherAdopt(pa.getWhetherAdopt());
			answerVo.setScity(pa.getCityCode());
			//answerVo.setPhone(queryEmployeePhone(pa.getCityCode(), pa.getConsultantId()));
			if (pa.getConsultantId() != null) {
				BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker2(pa.getCityCode(),pa.getConsultantId().intValue());
				if (brokerDetailVo != null) {
					/*if ("1".equals(brokerDetailVo.getPhoto())) {
						answerVo.setPhoto(systemConstant.getOssCdnUrl() + brokerDetailVo.getScity()
						+ "/Empl/PIC/" + brokerDetailVo.getId() + "/"+ brokerDetailVo.getId() + ".jpg");
					}*/
					 
					answerVo.setPhone(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), brokerDetailVo.getPhoto(), brokerDetailVo.getScity(), brokerDetailVo.getId()));
				} 
				
			}
			
			if (memberId != null && memberId > 0) {
				if (memberId.longValue() == problemInfoVo.getMemberId().longValue()) {
					answerVo.setStatus("2");
				} else {
					answerVo.setStatus("1");
				}
			} else {
				answerVo.setStatus("0");
			}
			
			problemAnswers.add(answerVo);
		});
		problemInfoVo.setProblemAnswers(problemAnswers);
		
		return problemInfoVo;
		
	}
	
	
	
	
	private String formDate(LocalDateTime dateTime) {
		if (dateTime == null) {
			return	 null;
		}
		return dateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
	}
	
	
	public String queryEmployeePhoto(String scity,Long id) {
		if(id == null) {
			return "";
		}
		
		return PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), "1", scity, id.intValue());
		/*BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(scity,Integer.parseInt(id+""));
		String photo ="";
		if (brokerDetailVo != null) {
			photo = PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), brokerDetailVo.getPhoto(), scity, id.intValue());
			if ("1".equals(brokerDetailVo.getPhoto())) {
				photo=systemConstant.getOssCdnUrl() + brokerDetailVo.getScity()
				+ "/Empl/PIC/" + brokerDetailVo.getId() + "/"+ brokerDetailVo.getId() + ".jpg";
			}
		}
		return photo;*/
	}
	
	public String queryEmployeePhone(String scity,Long id) {
		if(id == null) {
			return "";
		}
		BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(scity,Integer.parseInt(id+""));
		String phone ="";
		if (brokerDetailVo != null) {
			phone = brokerDetailVo.getPhone();
		}
		return phone;
	}
	
}