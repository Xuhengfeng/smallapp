package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.druid.util.StringUtils;
import com.ztj.dichan.cust.appapi.external.HouseSeeServiceClient;
import com.ztj.dichan.cust.appapi.external.RentHouseServiceClient;
import com.ztj.dichan.cust.appapi.request.BaseRequest;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.HouseRentRecmd;
import com.ztj.dichan.cust.core.entity.SearchRecord;
import com.ztj.dichan.cust.core.enums.SearchType;
import com.ztj.dichan.cust.core.repository.HouseRentRecmdRepository;
import com.ztj.dichan.cust.core.repository.RentHouseCollectionRepository;
import com.ztj.dichan.cust.core.repository.SearchRecordRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.RentHouseRequest;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRecmdRequest;
import com.ztj.dichan.cust.rule.response.HouseBrokerVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeCountVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeRecordVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseRecmdVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * 
 * @author sily
 */
@Service
@Transactional
public class RentHouseService extends BaseAppService {

	@Resource
	private RentHouseServiceClient rentHouseServiceClient;

	@Resource
	private HouseRentRecmdRepository houseRentRecmdRepository;
	
	@Resource
	private RentHouseCollectionRepository rentHouseCollectionRepository;
	
	@Resource
	private HouseSeeServiceClient houseSeeServiceClient;
	
	@Resource
	private SearchRecordRepository searchRecordRepository;

	/**
	 * 
	 * @param rentHouseRequest
	 * @return
	 */
	public List<RentHouseVo> queryList(RentHouseRequest rentHouseRequest,Long memberId) {
		
		String scity = this.getScityNew(rentHouseRequest);
		List<RentHouseVo> houseVoList = rentHouseServiceClient.queryList(rentHouseRequest,scity);
		if (houseVoList == null) {
			return new ArrayList<>(0);
		}
		houseVoList.forEach(houseVo -> {
			houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseVo.getHousePic(),
					rentHouseRequest.getScity(), String.valueOf(houseVo.getId())));

		});
		
		if (!StringUtils.isEmpty(rentHouseRequest.getKeyword()) && memberId != null) {
			SearchRecord searchRecord = new SearchRecord();
			searchRecord.setMemberId(memberId);
			searchRecord.setKeyword(rentHouseRequest.getKeyword());
			searchRecord.setSearchType(SearchType.RENT);
			searchRecord.setSearchTime(LocalDateTime.now());
			searchRecord.setSearchNum(1);
			this.searchRecordRepository.save(searchRecord);
		}

		return houseVoList;
	}
	
	public CountVo queryListCount(RentHouseRequest rentHouseRequest) {
		String scity = this.getScityNew(rentHouseRequest);
		return rentHouseServiceClient.queryListCount(rentHouseRequest,scity);
	}
	
	public List<RentHouseVo> queryLikeList(String scity,Integer pageNo,Integer pageSize,Long memberId) {

		RentHouseRequest rentHouseRequest = new RentHouseRequest();
		rentHouseRequest.setScity(scity);
		
		if (memberId != null) {
			SearchRecord searchRecord = this.searchRecordRepository.findTop1ByMemberIdAndSearchTypeOrderBySearchTimeDesc(memberId, SearchType.RENT);
			if (searchRecord != null 
					&& !StringUtils.isEmpty(searchRecord.getKeyword())) {
				rentHouseRequest.setKeyword(searchRecord.getKeyword());
			}
		}
		
		rentHouseRequest.setPageNo(BaseRequest.valPageNoDef(pageNo));
		rentHouseRequest.setPageSize(BaseRequest.valPageSizeDef(pageSize));
		List<RentHouseVo> houseVoList = rentHouseServiceClient.queryList(rentHouseRequest,scity);

		houseVoList.forEach(houseVo -> {
			houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseVo.getHousePic(),
					rentHouseRequest.getScity(), String.valueOf(houseVo.getId())));

		});
		return houseVoList;
	}

	/**
	 * 
	 * @param scity
	 * @param sdid
	 * @return
	 */
	public RentHouseDetailVo getDetailInfo(String scity, Long sdid,Long memberId) {

		RentHouseDetailVo rentHouseDetailVo = rentHouseServiceClient.getDetailInfo(scity, sdid);
		
		if (rentHouseDetailVo == null) {
			return null;
		}
		
		rentHouseDetailVo.setHousePicList(PhotoUtil.converPhoto(systemConstant.getOssCdnUrl(), rentHouseDetailVo.getHousePic(), scity,String.valueOf(rentHouseDetailVo.getId())));
		
		//rentHouseDetailVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), rentHouseDetailVo.getHousePic(), scity,String.valueOf(rentHouseDetailVo.getId())));
		if (rentHouseDetailVo.getHousePicList() != null && !rentHouseDetailVo.getHousePicList().isEmpty()) {
			rentHouseDetailVo.setHousePic(rentHouseDetailVo.getHousePicList().get(0));
		} else {
			rentHouseDetailVo.setHousePic(null);
		}
		
		HouseBrokerVo broker = rentHouseDetailVo.getBroker();
		if (broker != null) {
			rentHouseDetailVo.getBroker().setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(),
					broker.getPhoto(), scity, broker.getId()));
		}
		
		
		rentHouseDetailVo.setElevator("--");//这里目前AIO没有电梯属性固定给值
		
		if (memberId != null && memberId > 0) {
			Long countCollect = rentHouseCollectionRepository.countByMemberIdAndHouseSdid(memberId, sdid);
			rentHouseDetailVo.setIsCollect(countCollect > 0?true:false);
		}
		
		HouseSeeCountVo houseSeeCountVo = houseSeeServiceClient.queryCount(scity, rentHouseDetailVo.getId());
		
		rentHouseDetailVo.setDay7Num(houseSeeCountVo.getDay7Count());
		rentHouseDetailVo.setDay30Num(houseSeeCountVo.getDay30Count());
		rentHouseDetailVo.setTotalSeeNum(houseSeeCountVo.getTotalCount());
		Integer collectNum = rentHouseCollectionRepository.countByHouseSdid(sdid);
		rentHouseDetailVo.setCollectNum(collectNum.intValue());
		if (!StringUtils.isEmpty(houseSeeCountVo.getRecentlySeeDate())) {
			rentHouseDetailVo.setRecentlySee(houseSeeCountVo.getRecentlySeeDate().split(" ")[0].replace("-", "."));
		} else {
			rentHouseDetailVo.setRecentlySee("");
		}
		
		return rentHouseDetailVo;
	}

	/**
	 * 
	 * @param scity
	 * @return
	 */
	public List<RentHouseRecmdVo> queryRecmdList(String scity) {
		List<HouseRentRecmd> recmdList = houseRentRecmdRepository.findTop5ByHouseScity(scity);

		if (recmdList == null || recmdList.isEmpty()) {
			//return new ArrayList<RentHouseRecmdVo>(0);
			return this.getDefRecmdList(scity);
		}
		List<Long> houseSdidList = new ArrayList<>(recmdList.size());
		Map<String,String> recmdMap = new HashMap<String,String>(recmdList.size());
		recmdList.stream().forEach(recmd -> {
			houseSdidList.add(recmd.getHouseSdid());
			recmdMap.put(recmd.getHouseSdid()+"", recmd.getImageUrl());
		});

		HouseRecmdRequest houseRecmdRequest = new HouseRecmdRequest();
		houseRecmdRequest.setSdidList(houseSdidList);
		houseRecmdRequest.setScity(scity);

		List<RentHouseRecmdVo> rentHouseList = rentHouseServiceClient.queryRecmdList(houseRecmdRequest,scity);
		
		rentHouseList.forEach(houseRecmdVo -> {
			String image = recmdMap.get(houseRecmdVo.getSdid()+"");
			if (StringUtils.isEmpty(image)) {
				houseRecmdVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseRecmdVo.getHousePic(),
						scity, String.valueOf(houseRecmdVo.getId())));
			} else {
				houseRecmdVo.setHousePic(image);
			}

		});
		
		return rentHouseList;
	}
	
	
	private List<RentHouseRecmdVo> getDefRecmdList(String scity) {
		
		
		RentHouseRequest rentHouseRequest = new RentHouseRequest();
		rentHouseRequest.setPageNo(4);
		rentHouseRequest.setPageSize(4);
		List<RentHouseVo> houseVoList = rentHouseServiceClient.queryList(rentHouseRequest,scity);
		if (houseVoList == null) {
			return new ArrayList<>(0);
		}
		return houseVoList.stream().map(houseVo -> {
			
			RentHouseRecmdVo rentHouseRecmdVo = new RentHouseRecmdVo();
			BeanUtils.copyProperties(houseVo, rentHouseRecmdVo);
			rentHouseRecmdVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), rentHouseRecmdVo.getHousePic(),
					rentHouseRecmdVo.getScity(), String.valueOf(rentHouseRecmdVo.getId())));
			
			return rentHouseRecmdVo;

		}).collect(Collectors.toList());
	}
	
	public List<RentHouseVo> rimHousing(RimHouseRequest rimHouseRequest) {
		
		String scity = this.getScityNew(rimHouseRequest);
		List<RentHouseVo> rimHousingList = rentHouseServiceClient.rimHousing(rimHouseRequest,scity);
		if (rimHousingList == null) {
			return new ArrayList<>(0);
		}
		rimHousingList.forEach(rentHouseVo -> {
			rentHouseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), rentHouseVo.getHousePic(),
					rimHouseRequest.getScity(), String.valueOf(rentHouseVo.getId())));

		});
		return rimHousingList;
	}
	
	/**
	 * 获取租房带看记录列表
	 * @param houseId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<HouseSeeRecordVo> getHouseSeeRecordList(Integer houseId,Integer pageNo,Integer pageSize) {
		String scity = RequestContextHolder.getCityCode();
		List<HouseSeeRecordVo> voList = this.houseSeeServiceClient.queryDkInfoList(scity, houseId, pageNo, pageSize);
		if (voList == null) {
			return new ArrayList<>(0);
		}
		voList.forEach(vo -> {
			if (!StringUtils.isEmpty(vo.getSeeDate())) {
				vo.setSeeDate(vo.getSeeDate().split(" ")[0].replace("-", "."));
			}

		});
		return voList;
	}
	
	
	public List<HouseSeeRecordVo> getHouseSeeRecordList(Integer houseId,Integer pageNo,Integer pageSize,String scity) {
		List<HouseSeeRecordVo> voList = this.houseSeeServiceClient.queryDkInfoList(scity, houseId, pageNo, pageSize);
		if (voList == null) {
			return new ArrayList<>(0);
		}
		voList.forEach(vo -> {
			if (!StringUtils.isEmpty(vo.getSeeDate())) {
				vo.setSeeDate(vo.getSeeDate().split(" ")[0].replace("-", "."));
			}

		});
		return voList;
	}
	
}