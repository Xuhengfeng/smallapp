package com.ztj.dichan.cust.appapi.filter;

import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;

import net.bull.javamelody.MonitoringFilter;

/**
 * 可以设置storage-directory参数修改数据的存储路径,但是直接指定的话会影响自动化打包和部署,
 *
 * 所以开发环境不需要指定,测试和生产环境可以通过修改tomcat的配置文件去实现
 *
 * @author test01
 */
@WebFilter(asyncSupported = true, filterName = "monitoring", urlPatterns = "/*", initParams = {
		@WebInitParam(name = "system-actions-enabled", value = "true"),
		@WebInitParam(name = "displayed-counters", value = "http,spring,sql,jsp,log,error"),
		@WebInitParam(name = "log", value = "true"), @WebInitParam(name = "disabled", value = "false") })
public class RequestMonitorFilter extends MonitoringFilter {

}
