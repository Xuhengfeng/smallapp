/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "提交经纪人评价参数对象")
@Data
@EqualsAndHashCode(callSuper = true)
public class BrokerEvaluateRequest extends BaseApiRequest {
	
	private static final long serialVersionUID = -4943970798197025925L;

	@ApiModelProperty(value = "评分,必填", required = true)
	private Integer grade;
	
	@ApiModelProperty(value = "评价内容,必填", required = true)
	private String content;
	
	@ApiModelProperty(value = "标签，多个使用英文逗号隔开", required = false)
	private String tag;
	
	@ApiModelProperty(value = "已看记录id,必填", required = true)
	private Long appHouseRecId;
	
	@ApiModelProperty(value = "经纪人id,必填", required = true)
	private Long brokerId;
	
	
}
