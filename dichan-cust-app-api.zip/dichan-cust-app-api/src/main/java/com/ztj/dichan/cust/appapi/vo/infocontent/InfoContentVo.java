/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.infocontent;


import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.core.enums.InfoContentTypeEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "资讯内容信息VO")
@Data
@EqualsAndHashCode(callSuper = true)
public class InfoContentVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "资讯内容id")
	private Long id;
	
	@ApiModelProperty(value = "标题")
	private String title;

	@ApiModelProperty(value = "摘要")
	private String summary;
	
	@ApiModelProperty(value = "栏目名称")
	private String columnesName;

	@ApiModelProperty(value = "资讯内容的类型")
	private InfoContentTypeEnum type;

	@ApiModelProperty(value = "图片URL")
	private String imageUrl;

	@ApiModelProperty(value = "PC内容URL")
	private String contentUrl;

	@ApiModelProperty(value = "手机内容URL")
	private String phoneContentUrl;

	@ApiModelProperty(value = "发布时间")
	private Long publishDateTime;
	
	@ApiModelProperty(value = "是否置顶,0=否，1=是")
	private Integer isTop;
	
	

}
