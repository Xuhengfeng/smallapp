/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.ztj.dichan.cust.core.enums.AgencyApplicantTypeEnum;
import com.ztj.dichan.cust.core.enums.LoanTypeEnum;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class LoanAgencyApplyRequest extends BaseApiRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6977746897347231200L;

	@ApiModelProperty(value = "姓名,必填", dataType = "string", required = true)
	private String name;
	
	@ApiModelProperty(value = "联系电话,必填", dataType = "string", required = true)
	private String phone;
	
	@ApiModelProperty(value = "城市编码,必填", dataType = "string", required = true)
	private String cityCode;
	
	@ApiModelProperty(value = "小区名称,必填", dataType = "string", required = true)
	private String buildingName;
	
	@ApiModelProperty(value = "小区sdid", dataType = "string", required = false)
	private Long buildingSdid;
	
	@ApiModelProperty(value = "详细地址", dataType = "string", required = false)
	private String address;
	
	@ApiModelProperty(value = "栋号,必填", dataType = "string", required = true)
	private String buildNum;
	
	@ApiModelProperty(value = "单元号,必填", dataType = "string", required = true)
	private String unitNum;
	
	@ApiModelProperty(value = "房号,必填", dataType = "string", required = true)
	private String roomNum;
	
	@ApiModelProperty(value = "经纪人,必填", dataType = "int", required = true)
	private Long brokerId;
	
	
	@ApiModelProperty(value = "代办类型(LONA=贷款,TRANSFER=过户,DETENTION=解押,DUTIABLE=报税,CONTRACT=签合同,OTHER=其他综合)", dataType = "string", required = true)
	private LoanTypeEnum loanAgencyType;
	
	@ApiModelProperty(value = "申请人类型[卖方=SELLER,买方=PURCHASER,推荐人=RECMD_MAN],必填", dataType = "string", required = false)
	private AgencyApplicantTypeEnum applicantType;
	
}
