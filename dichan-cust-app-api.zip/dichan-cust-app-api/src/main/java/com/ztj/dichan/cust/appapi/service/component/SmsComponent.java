package com.ztj.dichan.cust.appapi.service.component;

import java.util.Random;
import java.util.UUID;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSONObject;
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.IAcsClient;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.FormatType;
import com.aliyuncs.http.MethodType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;

/**
 * 短信验证
 * 
 * @author HHF
 */
@Component
public class SmsComponent extends BaseAppComponent {
	
	/**
	 * 发送短信验证码
	 * @param phoneNumber
	 * @return
	 */
	public String sendPhoneCode(String phoneNumber) {
		if (StringUtils.isEmpty(phoneNumber)) {
			return null;
		}
		String verifyCode = getVerifyCode(6);
		String data = "{\"code\":\"" + verifyCode + "\"}";
		this.sendSms(phoneNumber, data,systemConstant.getSmsTemplateCode());
	    return verifyCode;
	}
	
	/**
	 * 客户提交预约看房发送短信通知经纪人
	 * @param phoneNumber
	 * @return
	 */
	public void sendAppointNotifiBroker(String phoneNumber,JSONObject data) {
		if (StringUtils.isEmpty(phoneNumber) || data == null) {
			return;
		}
		try {
			//data.put("url", "http://www.shyj.cn");
			logger.info("预约看房发送短信: phone=" + phoneNumber + ",data=" + data.toJSONString() + ",template=" + systemConstant.getAppointSmsTemplateCode());
			//this.sendSms(phoneNumber, data.toJSONString(),systemConstant.getAppointSmsTemplateCode());
		} catch (Exception e) {
			logger.error("",e);
		}
		
	}
	
	/**
	 * 客户提交卖房/出租委托申请发送短信通知经纪人
	 * @param phoneNumber
	 * @return
	 */
	public void sendApplyNotifiBroker(String phoneNumber,JSONObject data) {
		if (StringUtils.isEmpty(phoneNumber) || data == null) {
			return;
		}
		try {
			//data.put("url", "http://www.shyj.cn");
			logger.info("委托申请发送短信: phone=" + phoneNumber + ",data=" + data.toJSONString() + ",template=" + systemConstant.getAppointSmsTemplateCode());
			//this.sendSms(phoneNumber, data.toJSONString(),systemConstant.getApplySmsTemplateCode());
		} catch (Exception e) {
			logger.error("",e);
		}
		
	}
	
	private SendSmsResponse sendSms(String phoneNumber,String data,String templateCode) {
		
		String smsSwitch = systemConstant.getSmsSwitch();
		if (StringUtils.isEmpty(smsSwitch) || "false".equals(smsSwitch.toLowerCase())) {
			logger.warn("发短信开关是关闭状态！！！！");
			return null;
		}
		try {
			// 可自助调整超时时间
			// System.setProperty("sun.net.client.defaultConnectTimeout", "10000");
			// System.setProperty("sun.net.client.defaultReadTimeout", "10000");

			// 初始化acsClient,暂不支持region化
			/*IClientProfile profile = DefaultProfile.getProfile("cn-hangzhou", systemConstant.getSmsAccessKeyId(),
					systemConstant.getSmsAccessKeySecret());
			DefaultProfile.addEndpoint("cn-hangzhou", "cn-hangzhou", "Dysmsapi", "dysmsapi.aliyuncs.com");*/
			
			IClientProfile profile = DefaultProfile.getProfile(systemConstant.getSmsRegionId(), systemConstant.getSmsAccessKeyId(),
					systemConstant.getSmsAccessKeySecret());
			DefaultProfile.addEndpoint(systemConstant.getSmsEndpointName(), systemConstant.getSmsRegionId(), systemConstant.getSmsProduct(), systemConstant.getSmsDomain());
			IAcsClient acsClient = new DefaultAcsClient(profile);
			
			// 组装请求对象-具体描述见控制台-文档部分内容
			SendSmsRequest request = new SendSmsRequest();
			// 必填:待发送手机号
			request.setPhoneNumbers(phoneNumber);
			// 必填:短信签名-可在短信控制台中找到
			request.setSignName("世华易居");
			// 必填:短信模板-可在短信控制台中找到,这是验证短信
			request.setTemplateCode(templateCode);
			// 可选:模板中的变量替换JSON串,如模板内容为"亲爱的${name},您的验证码为${code}"时,此处的值为
			request.setTemplateParam(data);
			
			 //选填-上行短信扩展码(无特殊需求用户请忽略此字段)
	        //request.setSmsUpExtendCode("90997");
			
			// 可选:outId为提供给业务方扩展字段,最终在短信回执消息中将此值带回给调用者
			request.setOutId("yourOutId");
			//修改数据提交方式
			request.setMethod(MethodType.POST);
			//修改数据交互格式
			request.setAcceptFormat(FormatType.JSON);

			// hint 此处可能会抛出异常，注意catch
			SendSmsResponse sendSmsResponse = acsClient.getAcsResponse(request);
			//logger.info("code=" +sendSmsResponse.getCode() + ",Message=" + sendSmsResponse.getMessage());
			return sendSmsResponse;
			
		} catch (ClientException e) {
			throw new RuntimeException("短信发送失败[" + phoneNumber + "]" + e);
		}
	}

	private String getVerifyCode(int len) {
		String result = "";

		String temp = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase().replaceAll("[A-Z]", "");

		for (int i = 0; i < len; i++) {
			int index = new Random().nextInt(temp.length());

			result += temp.charAt(index);
		}

		return result;
	}
}
