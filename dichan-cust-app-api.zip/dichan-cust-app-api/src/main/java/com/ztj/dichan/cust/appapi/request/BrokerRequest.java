/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;



import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "经纪人请求参数对象")
@Data
@EqualsAndHashCode(callSuper = true)
public class BrokerRequest extends BaseRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = -160284168508058230L;
	
	@ApiModelProperty(value = "城区ID")
	private Long areaId;

	@ApiModelProperty(value = "片区ID")
	private Long districtId;
	
	@ApiModelProperty(value = "岗位ID")
	private Long positiId;
	
	@ApiModelProperty(value = "排序方式,GRADE=评分从高到低,DK_COUNT=带看量从高到低,DEAL_COUNT=成交量从高到低")
	private String sortMode;
	
	@ApiModelProperty(value = "搜索关键字")
	private String keyword;

	
}
