/**
 * 
 */
package com.ztj.dichan.cust.appapi.jiguang.service;

import javax.annotation.Resource;

import org.springframework.security.crypto.codec.Base64;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.appapi.exception.ResourceNotFoundException;
import com.ztj.dichan.cust.appapi.exception.UserDefinedException;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.jiguang.JiguangConfig;
import com.ztj.dichan.cust.appapi.jiguang.external.JiguangServiceClient;
import com.ztj.dichan.cust.appapi.service.BaseAppService;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;

/**
 * 
 * 极光IMfu
 * 
 * @author lbs
 *
 */
@Service
public class JiguangService extends BaseAppService {

	@Resource
	private JiguangConfig jiguangConfig;
	
	@Resource
	private JiguangServiceClient jiguangServiceClient;
	
	@Resource
	private BrokerServiceClient brokerServiceClient;
	
	public void regUser(String username,String password,String nickname) {
		
		try {
			JSONObject request = new JSONObject();
			request.put("username", username);
			request.put("password", password);
			request.put("nickname", nickname);
			
			JSONArray array = new JSONArray();
			array.add(request);
			
			String key = jiguangConfig.getAppkey()+":"+jiguangConfig.getSecret();
			String token = new String(Base64.encode(key.getBytes()));
			jiguangServiceClient.regUser(array, "Basic " + token);
			
			
			
			/*
			 添加好友
			server_info	服务消息
		  	house_trends 二手房源动态
		  	rent_house_trends 租房房源动态
		  	building_trends 小区新上二手房
		  	*/
			/*easemobUserServiceClient.addFriend(token, username, "server_info");
			easemobUserServiceClient.addFriend(token, username, "house_trends");
			easemobUserServiceClient.addFriend(token, username, "rent_house_trends");
			easemobUserServiceClient.addFriend(token, username, "building_trends");*/
			
		} catch (Exception e) {
			throw new BizException("会员-注册极光用户失败！",e);
		}
	}
	
	public void brokerRegUser(String chatUsername) {
		
		if (StringUtils.isEmpty(chatUsername)) {
			throw new IllegalArgumentException("聊天账号不能为空");
		}
		
		String[] strs = chatUsername.split("_");
		if (strs.length != 3) {
			throw new IllegalArgumentException("聊天账号格式不正确");
		}
		BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker2(strs[0], Integer.valueOf(strs[1]));
		if (brokerDetailVo == null) {
			throw new ResourceNotFoundException("未找到相应的经纪人");
		}
		
		if (strs[2] == null || !strs[2].equals(brokerDetailVo.getEmplAccNo())) {
			throw new IllegalArgumentException("聊天账号格式不正确");
		}
		
		try {
			
			//String username = brokerDetailVo.getScity() + "_" + brokerDetailVo.getId() + "_" +brokerDetailVo.getEmplAccNo();
			String password = brokerDetailVo.getScity() + brokerDetailVo.getId() + brokerDetailVo.getEmplAccNo();
			String nickname = brokerDetailVo.getEmplName();
			
			
			JSONObject request = new JSONObject();
			request.put("username", chatUsername);
			request.put("password", password);
			request.put("nickname", nickname);
			
			JSONArray array = new JSONArray();
			array.add(request);
			
			String key = jiguangConfig.getBrokerAppKey()+":"+jiguangConfig.getBrokerSecret();
			String token = new String(Base64.encode(key.getBytes()));
			jiguangServiceClient.regUser(array, "Basic " + token);
			
		} catch (Exception e) {
			if (e.getMessage().indexOf(":899001,") == -1) {
				throw new UserDefinedException("500","经纪人-注册极光用户失败！",e);
			} else {
				logger.warn("经纪人极光账号已存在" + e.getMessage());
			}
		}
		
	}
	
	public void regUser2(String username,String password,String nickname) {
		
		try {
			JSONObject request = new JSONObject();
			request.put("username", username);
			request.put("password", password);
			request.put("nickname", nickname);
			
			JSONArray array = new JSONArray();
			array.add(request);
			
			String key = jiguangConfig.getAppkey()+":"+jiguangConfig.getSecret();
			String token = new String(Base64.encode(key.getBytes()));
			jiguangServiceClient.regUser(array, "Basic " + token);
		} catch (Exception e) {
			if (e.getMessage().indexOf(":899001,") == -1) {
				throw new UserDefinedException("500","注册极光用户失败！",e);
			}
			
			logger.warn("regUser2出错了" +e.getMessage());
		}
		
	}
}
