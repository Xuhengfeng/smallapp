/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;


import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.ztj.dichan.cust.core.enums.AppointRangeEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "约看房请求参数",description="约看房请求参数")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointHouseRequest extends BaseApiRequest {

	private static final long serialVersionUID = 2349714288764022396L;
	
	@ApiModelProperty(value = "约看房源列表，必填",required=true)
	private List<AppointHouseSdid> houseList;
	
	@ApiModelProperty(value = "姓名，必填",required=true)
	private String appointName;
	
	@ApiModelProperty(value = "手机号，必填",required=true)
	private String appointMobile;
	
	@ApiModelProperty(value = "预约时间（必填） 格式为2017-12-15,不需要时分秒",required=true)
    @DateTimeFormat(pattern = "yyyy-MM-dd") 
	private String appointDate;
	
	@ApiModelProperty(value = "预约时段类型,必填 \n" + 
			"ALL_DAY=全天\n" + 
			"FORENOON=上午\n" + 
			"AFTERNOON=下午\n" + 
			"NIGHT=晚上",required=true)
	private AppointRangeEnum appointRange;
	
	@ApiModelProperty(value = "经纪人id",required=true)
	private Integer brokerId;

}
