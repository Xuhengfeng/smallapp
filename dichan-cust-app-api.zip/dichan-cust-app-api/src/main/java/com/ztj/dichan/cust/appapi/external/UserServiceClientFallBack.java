package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.bean.SysLoginBean;

/**
 * @author sily
 *
 */
public class UserServiceClientFallBack implements UserServiceClient {

	@Override
	public List<SysLoginBean> cityList() {
		// TODO Auto-generated method stub
		return null;
	}

}