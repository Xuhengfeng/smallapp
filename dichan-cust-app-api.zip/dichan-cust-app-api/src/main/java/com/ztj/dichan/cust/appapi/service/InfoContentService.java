/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.util.PageUtil;
import com.ztj.dichan.cust.appapi.vo.infocontent.ColumnesGuideVo;
import com.ztj.dichan.cust.appapi.vo.infocontent.ColumnesVo;
import com.ztj.dichan.cust.appapi.vo.infocontent.InfoContentDetailVo;
import com.ztj.dichan.cust.appapi.vo.infocontent.InfoContentVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.Columnes;
import com.ztj.dichan.cust.core.entity.InformationContent;
import com.ztj.dichan.cust.core.enums.InfoContentStatusEnum;
import com.ztj.dichan.cust.core.enums.InfoContentTypeEnum;
import com.ztj.dichan.cust.core.repository.ColumnsRepository;
import com.ztj.dichan.cust.core.repository.InformationContentRepository;

/**
 * @author lbs
 * 
 */
@Service
public class InfoContentService extends BaseAppService {

	@Resource
	private InformationContentRepository informationContentRepository;
	
	@Resource
	private ColumnsRepository columnsRepository;
	
	public List<InfoContentVo> queryList(String code,Integer pageNo,Integer pageSize) {
		
		String scity = RequestContextHolder.getCityCode();
		/*List<InformationContent> infoList = informationContentRepository.queryByCodeAndStatusList(code, InfoContentStatusEnum.NORMAL,
				scity,PageUtil.createPage(pageNo, pageSize));
		if (infoList == null) {
			return new ArrayList<InfoContentVo>(0);
		}
		
		List<InfoContentVo> voList = infoList.stream().map(info->{
			InfoContentVo infoContentVo = new InfoContentVo();
			BeanUtils.copyProperties(info, infoContentVo);
			if (info.getPublishDateTime() != null) {
				infoContentVo.setPublishDateTime(info.getPublishDateTime().toInstant(ZoneOffset.of("+8")).toEpochMilli());
			}
			if (info.getType() != null && info.getType() == InfoContentTypeEnum.URL_CONTENT) {
				String phoneContentUrl = infoContentVo.getPhoneContentUrl();
				String contentUrl = infoContentVo.getContentUrl();
				if (!StringUtils.isEmpty(phoneContentUrl)) {
					if (phoneContentUrl.indexOf("?") != -1) {
						phoneContentUrl += "&id=" + info.getId();
					} else {
						phoneContentUrl += "?id=" + info.getId();
					}
					infoContentVo.setPhoneContentUrl(phoneContentUrl);
				}
				
				if (!StringUtils.isEmpty(contentUrl)) {
					if (contentUrl.indexOf("?") != -1) {
						contentUrl += "&id=" + info.getId();
					} else {
						contentUrl += "?id=" + info.getId();
					}
					infoContentVo.setContentUrl(contentUrl);
				}
			}
			return infoContentVo;
		}).collect(Collectors.toList());
		return voList;*/
		
		return this.getInfoContentList2(scity, code, pageNo, pageSize);
		
		
	}
	
	public List<ColumnesVo> queryChildColumnList(String code,Integer pageNo,Integer pageSize) {
		
		//String scity = RequestContext.getCityCode();
		List<Columnes> dataList = columnsRepository.findByParentCode(code);
		if (dataList == null) {
			return new ArrayList<ColumnesVo>(0);
		}
		List<ColumnesVo> voList = dataList.stream().map(colu -> {
			ColumnesVo columnesVo = new ColumnesVo();
			columnesVo.setCityCode(colu.getCityCode());
			columnesVo.setCode(colu.getCode());
			columnesVo.setName(colu.getName());
			return columnesVo;
		}).collect(Collectors.toList());
		return voList;
	}
	
	
	public InfoContentDetailVo getInfoContentDetail(Long id) {
		if (id == null || id <= 0) {
			return null;
		}
		InformationContent informationContent = informationContentRepository.findOne(id);
		if (informationContent == null) {
			return null;
		}
		InfoContentDetailVo detailVo =  new InfoContentDetailVo();
		BeanUtils.copyProperties(informationContent, detailVo);
		if (informationContent.getPublishDateTime() != null) {
			detailVo.setPublishDateTime(informationContent.getPublishDateTime().toInstant(ZoneOffset.of("+8")).toEpochMilli());
		}
		return detailVo;
	}
	
	public List<ColumnesGuideVo> getPurchaseGuideIndex() {
		
		List<Columnes> dataList = columnsRepository.findByParentCode("11");
		String scity = RequestContextHolder.getCityCode();
		if (dataList == null) {
			return new ArrayList<ColumnesGuideVo>(0);
		}
		List<ColumnesGuideVo> guideList = dataList.stream().map(colu -> {
			ColumnesGuideVo golumnesGuideVo = new ColumnesGuideVo();
			golumnesGuideVo.setCityCode(colu.getCityCode());
			golumnesGuideVo.setCode(colu.getCode());
			golumnesGuideVo.setName(colu.getName());
			
			golumnesGuideVo.setInfoContentList(this.getInfoContentList(scity, colu.getCode(), 1, 20));
			
			return golumnesGuideVo;
		}).collect(Collectors.toList());
		
		return guideList;
	}
	
	private List<InfoContentVo> getInfoContentList(String scity,String code,Integer pageNo,Integer pageSize) {
		
		List<InformationContent> infoList = informationContentRepository.queryByCodeAndStatusList(code, InfoContentStatusEnum.NORMAL,scity,PageUtil.createPage(1, 10));
		
		if (infoList == null || infoList.isEmpty()) {
			//return new ArrayList<InfoContentVo>(0);
			String scityTemp = "beihai";//如果相应的地市取不到值则默认取北海的数据
			infoList = informationContentRepository.queryByCodeAndStatusList(code, InfoContentStatusEnum.NORMAL,scityTemp,PageUtil.createPage(1, 10));
		}
		return infoList.stream().map(info -> {
			InfoContentVo infoContentVo = new InfoContentVo();
			BeanUtils.copyProperties(info, infoContentVo);
			infoContentVo.setColumnesName("");
			if (info.getPublishDateTime() != null) {
				infoContentVo.setPublishDateTime(info.getPublishDateTime().toInstant(ZoneOffset.of("+8")).toEpochMilli());
			}
			if (info.getType() != null && info.getType() == InfoContentTypeEnum.URL_CONTENT) {
				String phoneContentUrl = infoContentVo.getPhoneContentUrl();
				String contentUrl = infoContentVo.getContentUrl();
				if (!StringUtils.isEmpty(phoneContentUrl)) {
					if (phoneContentUrl.indexOf("?") != -1) {
						phoneContentUrl += "&id=" + info.getId();
					} else {
						phoneContentUrl += "?id=" + info.getId();
					}
					infoContentVo.setPhoneContentUrl(phoneContentUrl);
				}
				
				if (!StringUtils.isEmpty(contentUrl)) {
					if (contentUrl.indexOf("?") != -1) {
						contentUrl += "&id=" + info.getId();
					} else {
						contentUrl += "?id=" + info.getId();
					}
					infoContentVo.setContentUrl(contentUrl);
				}
			}
			return infoContentVo;
		}).collect(Collectors.toList());
	}
	
	public List<InfoContentVo> getInfoContentList2(String scity,String code,Integer pageNo,Integer pageSize) {
		
		List<InformationContent> infoList = informationContentRepository.queryByCodeAndStatusList(code, InfoContentStatusEnum.NORMAL,scity,PageUtil.createPage(pageNo, pageSize));
		
		if (infoList == null || infoList.isEmpty()) {
			//return new ArrayList<InfoContentVo>(0);
			String scityTemp = "beihai";//如果相应的地市取不到值则默认取北海的数据
			infoList = informationContentRepository.queryByCodeAndStatusList(code, InfoContentStatusEnum.NORMAL,scityTemp,PageUtil.createPage(pageNo, pageSize));
		}
		return infoList.stream().map(info -> {
			InfoContentVo infoContentVo = new InfoContentVo();
			BeanUtils.copyProperties(info, infoContentVo);
			infoContentVo.setColumnesName("资讯");
			if (info.getPublishDateTime() != null) {
				infoContentVo.setPublishDateTime(info.getPublishDateTime().toInstant(ZoneOffset.of("+8")).toEpochMilli());
			}
			if (info.getType() != null && info.getType() == InfoContentTypeEnum.URL_CONTENT) {
				String phoneContentUrl = infoContentVo.getPhoneContentUrl();
				String contentUrl = infoContentVo.getContentUrl();
				if (!StringUtils.isEmpty(phoneContentUrl)) {
					if (phoneContentUrl.indexOf("?") != -1) {
						phoneContentUrl += "&id=" + info.getId();
					} else {
						phoneContentUrl += "?id=" + info.getId();
					}
					infoContentVo.setPhoneContentUrl(phoneContentUrl);
				}
				
				if (!StringUtils.isEmpty(contentUrl)) {
					if (contentUrl.indexOf("?") != -1) {
						contentUrl += "&id=" + info.getId();
					} else {
						contentUrl += "?id=" + info.getId();
					}
					infoContentVo.setContentUrl(contentUrl);
				}
			}
			return infoContentVo;
		}).collect(Collectors.toList());
	}
	
}
