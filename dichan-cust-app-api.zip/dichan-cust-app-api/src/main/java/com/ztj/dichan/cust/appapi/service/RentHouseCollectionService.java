/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.appapi.external.RentHouseCollectionServiceClient;
import com.ztj.dichan.cust.appapi.external.RentHouseServiceClient;
import com.ztj.dichan.cust.core.constant.OtherConstant;
import com.ztj.dichan.cust.core.entity.RentHouseCollection;
import com.ztj.dichan.cust.core.repository.RentHouseCollectionRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.RentHouseCollectionRequest;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseCollectionVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseDetailVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * @author sily
 *
 */
@Service
@Transactional
public class RentHouseCollectionService extends BaseAppService {

	@Resource
	private RentHouseCollectionRepository rentHouseCollectionRepository;

	@Resource
	private RentHouseCollectionServiceClient rentHouseCollectionServiceClient;

	@Resource
	private RentHouseServiceClient rentHouseServiceClient;

	/**
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<RentHouseCollectionVo> queryList(Long memberId, Integer pageNo, Integer pageSize) {
		
		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}
		
		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "collectDateTime");

		List<RentHouseCollection> collectionList = rentHouseCollectionRepository.findByMemberId(memberId, pageRequest);
		
		if (collectionList == null || collectionList.isEmpty()) {
			return new ArrayList<RentHouseCollectionVo>(0);
		}
		
		List<RentHouseCollectionRequest> request = new ArrayList<>();

		collectionList.stream().forEach(collection -> {
			RentHouseCollectionRequest vo = new RentHouseCollectionRequest();
			vo.setSdid(collection.getHouseSdid());
			vo.setScity(collection.getHouseScity());

			request.add(vo);
		});

		List<RentHouseCollectionVo> voList = rentHouseCollectionServiceClient.queryCollectionList(request);
		if (voList == null) {
			return new ArrayList<>(0);
		}
		voList.forEach(collectionVo -> {
			
			collectionVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), collectionVo.getHousePic(),
					collectionVo.getScity(), String.valueOf(collectionVo.getId())));
			collectionVo.setStatus(Utils.checkHouseStatus(collectionVo.getBuildStatus()));
		});

		return voList;

	}

	/**
	 * 
	 * @param memberId
	 * @param sdid
	 * @param scity
	 */
	public void add(Long memberId, Long sdid, String scity) {

		try {
			
			Long count = rentHouseCollectionRepository.countByMemberIdAndHouseSdid(memberId, sdid);
			if (count >= 1) {
				throw new RuntimeException();
			}
			
			// 这里共用了dichan-cust-service工程里面的租房详情接口
			RentHouseDetailVo rentHouseDetailVo = rentHouseServiceClient.getDetailInfo(scity, sdid);
			
			if (rentHouseDetailVo == null) {
				throw new RuntimeException();
			}
			
			RentHouseCollection collection = new RentHouseCollection();

			collection.setHouseScity(rentHouseDetailVo.getScity());
			collection.setHouseSdid(Long.valueOf(rentHouseDetailVo.getSdid()));
			collection.setHouseId(Long.valueOf(rentHouseDetailVo.getId()));
			collection.setMemberId(memberId);
			collection.setCollectDateTime(LocalDateTime.now());

			rentHouseCollectionRepository.save(collection);
		} catch (Exception e) {
			throw new BizException("收藏租房出错了");
		}
	}
	
	public void cancelCollection(Long memberId, Long sdid, String scity) {
		RentHouseCollection collection = rentHouseCollectionRepository.findByMemberIdAndHouseSdid(memberId, sdid);
		
		if (collection != null) {
			rentHouseCollectionRepository.delete(collection);
		}
	}

}
