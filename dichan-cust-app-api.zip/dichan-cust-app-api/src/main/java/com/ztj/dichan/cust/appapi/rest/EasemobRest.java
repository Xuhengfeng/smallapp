/**
 * 
 */
package com.ztj.dichan.cust.appapi.rest;


import java.util.Random;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.common.constant.RestResult;
import com.ztj.common.exception.NoLoginException;
import com.ztj.dichan.cust.appapi.easemob.EasemobConfig;
import com.ztj.dichan.cust.appapi.easemob.external.EasemobUserServiceClient;
import com.ztj.dichan.cust.appapi.easemob.service.EasemobUserService;
import com.ztj.dichan.cust.appapi.request.BrokerRegUserRequest;
import com.ztj.dichan.cust.core.entity.Member;
import com.ztj.dichan.cust.core.repository.MemberRepository;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @author lbs
 *
 */
@Api(value = "环信服务接口测试",description="环信测试接口")
@RestController
@RequestMapping(value = "/easemob")
public class EasemobRest extends BaseCustRest {

	//临时设置key
	private static final String KEY = "072a5285-ed6c-4959-9273-fccf9b63d769";
	@Resource
	private EasemobUserServiceClient easemobUserServiceClient;
	
	@Resource
	private EasemobUserService easemobUserService;
	
	@Resource
	private MemberRepository memberRepository;
	
	@Resource
	private EasemobConfig easemobConfig;
	
	/*@ApiOperation(value = "获取token")
	@GetMapping(value = "/token")
	public RestResult<JSONObject> queryToken() {

		
		JSONObject request = new JSONObject();
		request.put("client_id", easemobConfig.getClientId());
		request.put("client_secret", easemobConfig.getClientSecret());
		request.put("grant_type", easemobConfig.getGrantType());
		
		return RestResult.success(this.easemobUserServiceClient.getToken(request));

	}*/
	
	@ApiOperation(value = "绑定环信账户")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "mobile", value = "手机号码", dataType = "String", paramType = "query", required = true) })
	@GetMapping(value = "/bindEasemobUser")
	public RestResult<String> regUser(@RequestParam(name = "mobile", required = true) String mobile) {
		
		Member member = memberRepository.findByMobile(mobile);
		if (member == null) {
			return RestResult.failed("您输入的账户不存在!");
		}
		try {
			String password = new Random().nextInt(100000000)+"";
			easemobUserService.regUser(member.getId() + "_" + member.getMobile(), password, member.getNickname());
			member.setEasemobPassword(password);
			member.setEasemobUsername(member.getId() + "_" + member.getMobile());
			memberRepository.save(member);
			return RestResult.success("绑定环信账户成功!!!");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return RestResult.success("绑定环信账户失败,请检测环信是否已存在相应的账户!");

	}
	
	@ApiOperation(value = "经纪人-用户注册")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true)})
	@PostMapping(value = "/broker/reguser")
	public RestResult<String> regUser(@RequestBody BrokerRegUserRequest request,@RequestHeader("unique-code")String uniqueCode) {
		
		if (StringUtils.isEmpty(uniqueCode)) {
			throw new NoLoginException();
		}
		
		if (!KEY.equals(uniqueCode)) {
			getCurrentMemberId();
		}
		easemobUserService.brokerRegUser(request.getChatUsername());
		return RestResult.success("注册成功");

	}
	
	@ApiOperation(value = "发送文本信息")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "toUser", value = "接收信息者", dataType = "string", paramType = "query", required = true),
			@ApiImplicitParam(name = "fromUser", value = "发送信息者", dataType = "string", paramType = "query", required = true),
			@ApiImplicitParam(name = "message", value = "信息内容", dataType = "string", paramType = "query", required = true)})
	@GetMapping(value = "/sendMessage")
	public RestResult<JSONObject> sendMessage(@RequestParam(name = "toUser", required = true) String toUser,
			@RequestParam(name = "fromUser", required = true) String fromUser,
			@RequestParam(name="message") String message) {
		
		try {
			JSONObject request = new JSONObject();
			JSONObject msg = new JSONObject();
			JSONArray target = new JSONArray();
			target.add(toUser);
			//"target" : ["u1", "u2", "u3"],
			msg.put("type", "txt");
			msg.put("msg", message);
			request.put("target_type", "users");
			request.put("target", target);
			request.put("msg", msg);
			request.put("from", fromUser);
			JSONObject obj = easemobUserServiceClient.sendMessage(easemobUserService.getToken(), request);
			
			return RestResult.success(obj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return RestResult.failed("发送失败!");

	}
}
