package com.ztj.dichan.cust.appapi.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.ztj.dichan.cust.appapi.service.BuildingService;
import com.ztj.dichan.cust.appapi.service.DictionaryService;
import com.ztj.dichan.cust.appapi.service.HouseService;
import com.ztj.dichan.cust.appapi.service.InfoContentService;
import com.ztj.dichan.cust.appapi.service.NewBuildingService;
import com.ztj.dichan.cust.appapi.service.RentHouseService;
import com.ztj.dichan.cust.appapi.service.StatisticalService;
import com.ztj.dichan.cust.appapi.vo.DictionaryVo;
import com.ztj.dichan.cust.appapi.vo.IndexCityVo;
import com.ztj.dichan.cust.appapi.vo.StatisticsInfoVo;
import com.ztj.dichan.cust.appapi.vo.infocontent.InfoContentVo;
import com.ztj.dichan.cust.rule.response.building.HotBuildingVo;
import com.ztj.dichan.cust.rule.response.house.HouseRecmdVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseRecmdVo;

@Controller
public class IndexController {
	
	
	
	@Resource
	private StatisticalService statisticalService;
	
	@Resource
	private HouseService houseService;
	
	@Resource
	private RentHouseService rentHouseService;
	
	
	@Resource
	private BuildingService buildingService;
	
	@Resource
	private NewBuildingService newBuildingService;
	
	@Resource
	private InfoContentService infoContentService;
	
	@Resource
	private DictionaryService dictionaryService;
		
	// 首页
	@RequestMapping("/index/{scity}")
	public String helloHtml(Model model, @PathVariable("scity") String scity) {
		if(scity.isEmpty()) {
			scity = "beihai";
		}
		StatisticsInfoVo statisticalInfo =	statisticalService.querCurrentMonthStatistics("beihai");
		List<HouseRecmdVo> HouseRemd = houseService.queryRecmdList(scity);
		List<HotBuildingVo> hotBuild = buildingService.hotBuilding(scity,1,4);
		List<RentHouseRecmdVo> rentHouseRemd = rentHouseService.queryRecmdList(scity);
		List<InfoContentVo> newBuildRemd	 = this.infoContentService.getInfoContentList2(scity, "1002",1, 6);
		List<InfoContentVo> hotRemd = this.infoContentService.getInfoContentList2(scity, "1001",1, 6);
		List<DictionaryVo>  citys = dictionaryService.queryCityList();
		
		String[] alphatables = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q",
				"R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

		List<IndexCityVo> cityList = new ArrayList<>();
		for (String c : alphatables) {
			List<Map<String, Object>> item = new ArrayList<>();

			for (DictionaryVo dictionaryVo : citys) {
				String firstLetter = dictionaryVo.getValue().substring(0, 1);
				if (c.equalsIgnoreCase(firstLetter)) {
					Map<String, Object> map = new HashMap<>();
					map.put("name", dictionaryVo.getName());
					map.put("value", dictionaryVo.getValue());
					map.put("key", c);
					item.add(map);
				}
			}
			if (item.size() > 0) {
				IndexCityVo cityVo = new IndexCityVo();
				cityVo.setItem(item);
				cityVo.setTitle(c);
				cityList.add(cityVo);
			}
		}
		System.out.println(JSON.toJSONString(cityList));
		
		model.addAttribute("statisticalInfo", statisticalInfo);
		model.addAttribute("houseRemd", HouseRemd);
		model.addAttribute("hotBuild", hotBuild);
		model.addAttribute("rentHouseRemd", rentHouseRemd);
		model.addAttribute("newBuildRemd", newBuildRemd);
		model.addAttribute("hotRemd", hotRemd);
		model.addAttribute("citys", cityList);
		model.addAttribute("scity", scity);
		
		DictionaryVo dictionaryVo = new DictionaryVo();
		dictionaryVo.setName("北海");
		dictionaryVo.setValue("beihai");
		model.addAttribute("defaultCity",dictionaryVo);
		
		return "/index";
	}
	
	


}
