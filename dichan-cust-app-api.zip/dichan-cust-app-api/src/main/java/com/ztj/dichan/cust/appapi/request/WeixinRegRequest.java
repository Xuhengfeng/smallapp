/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 * 微信注册请求
 */
@ApiModel(value = "微信注册请求参数对象")
@Data
@EqualsAndHashCode(callSuper = true)
public class WeixinRegRequest extends BaseApiRequest {

	
	private static final long serialVersionUID = -3596430172450958231L;
  
	@ApiModelProperty(value = "微信openid",required=true)
	private String openid;
	
	@ApiModelProperty(value = "手机号码",required=true)
	private String phone;
	
	@ApiModelProperty(value = "认证key",required=true)
	private String authKey;
	
	@ApiModelProperty(value = "微信昵称",required=false)
	private String nickname;
	
	@ApiModelProperty(value = "性别",required=false)
	private String sex;
	
	@ApiModelProperty(value = "头像URL",required=false)
	private String headImage;
	
	@ApiModelProperty(value = "验证码",required=false)
	private String verifyCode;
	
	

}
