/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ztj.dichan.cust.rule.request.BrokerCollectionRequest;
import com.ztj.dichan.cust.rule.response.broker.BrokerCollectionVo;



/**
 * @author sily
 *
 */
@FeignClient(name = "brokerCollectionServiceClient", url= "${cust.service.url}", fallback = BrokerCollectionServiceClient.class)
public interface BrokerCollectionServiceClient {
	
	@RequestMapping(method = RequestMethod.POST, value = "/employee/collection")
	public List<BrokerCollectionVo> queryCollectionList(List<BrokerCollectionRequest> brokerCollectionRequest);
	
}