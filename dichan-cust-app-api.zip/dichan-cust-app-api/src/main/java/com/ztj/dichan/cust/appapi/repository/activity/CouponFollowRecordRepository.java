package com.ztj.dichan.cust.appapi.repository.activity;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.cust.core.entity.activity.CouponFollowRecord;
import com.ztj.dichan.cust.core.enums.CouponFollwTypeEnum;

/**
 * 
 * @author sily
 */
@Repository
public interface CouponFollowRecordRepository extends PagingAndSortingRepository<CouponFollowRecord, Long> {

	Page<CouponFollowRecord> findByMemberIdAndFollwType(Long memberId, CouponFollwTypeEnum follwType,
			Pageable pageable);
	
	


}