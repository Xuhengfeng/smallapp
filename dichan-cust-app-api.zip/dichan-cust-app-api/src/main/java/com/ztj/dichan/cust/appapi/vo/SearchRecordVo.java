package com.ztj.dichan.cust.appapi.vo;

import java.time.LocalDateTime;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.core.enums.SearchType;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * 
 * @author liuweichen
 *
 */
@ApiModel(value = "搜索记录")
@Data
@EqualsAndHashCode(callSuper = true)
public class SearchRecordVo  extends BaseValueObject{
	private static final long serialVersionUID = 1L;

	
	/**
	 * 会员id
	 */
	@ApiModelProperty(value="会员id")
	private Long memberId;

	/**
	 * 搜索类型
	 */
	@ApiModelProperty(value="搜索类型")
	private SearchType searchType;

	/**
	 * 搜索关键字
	 */
	@ApiModelProperty(value="搜索关键字")
	private String keyword;
	
	/**
	 * 关键字搜索次数
	 */
	@ApiModelProperty(value="搜索次数")
	private Integer searchNum;

	/**
	 * 搜索时间
	 */
	@ApiModelProperty(value="搜索时间")
	private LocalDateTime searchTime;
	
}
