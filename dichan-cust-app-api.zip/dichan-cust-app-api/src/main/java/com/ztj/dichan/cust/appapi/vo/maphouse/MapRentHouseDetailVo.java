/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.maphouse;

import java.math.BigDecimal;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "租房-地图展示信息VO")
@Data
@EqualsAndHashCode(callSuper = true)
public class MapRentHouseDetailVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "城区Id")
	private Integer id;

	@ApiModelProperty(value = "城区名称")
	private String name;

	@ApiModelProperty(value = "在租套数")
	private Integer  rentCount;

	@ApiModelProperty(value = "东经")
	private BigDecimal px;

	@ApiModelProperty(value = "西纬")
	private BigDecimal py;
	
	
	@ApiModelProperty(value = "在租套数显示格式")
	private String formatRentCount;

	public String getFormatRentCount() {
		if (rentCount == null) {
			rentCount = 0;
		}
		return rentCount + "套";
	}
}
