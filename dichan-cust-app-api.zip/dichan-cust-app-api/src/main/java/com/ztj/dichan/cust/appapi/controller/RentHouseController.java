package com.ztj.dichan.cust.appapi.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.dichan.cust.appapi.constant.SystemConstant;
import com.ztj.dichan.cust.appapi.rest.BaseCustRest;
import com.ztj.dichan.cust.appapi.service.BuildingService;
import com.ztj.dichan.cust.appapi.service.DictionaryService;
import com.ztj.dichan.cust.appapi.service.RentHouseService;
import com.ztj.dichan.cust.appapi.util.HttpUtil;
import com.ztj.dichan.cust.appapi.vo.DictionaryVo;
import com.ztj.dichan.cust.core.enums.DicType;
import com.ztj.dichan.cust.rule.request.RentHouseRequest;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeRecordVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

@Controller
@RequestMapping(value = "/house_r")
public class RentHouseController extends BaseCustRest {
	
	
	@Resource
	private RentHouseService rentHouseService;
	
	@Resource
	private BuildingService buildingService;
	
	@Resource
	private DictionaryService dictionaryService;
	
	@Resource
	protected SystemConstant systemConstant;
	

	// 租房
	@RequestMapping("/renthouse")
	public String rentHouse(Model model, Integer roomsNum, Integer areaId, Integer districtId, Double minRentPrice,
			Double maxRentPrice, Double minBuildArea, Double maxBuildArea, String keyword, String scity, Integer pageNo,
			Integer pageSize) {
		
		RentHouseRequest request = new RentHouseRequest();
		request.setRoomsNum(roomsNum);
		request.setAreaId(areaId);
		request.setDistrictId(districtId);
		request.setMinRentPrice(minRentPrice);
		request.setMaxRentPrice(maxRentPrice);
		request.setMinBuildArea(minBuildArea);
		request.setMaxBuildArea(maxBuildArea);
		request.setKeyword(keyword);
		request.setScity(scity);
		request.setPageNo(pageNo);
		request.setPageSize(pageSize);
		

		DicType[] dicTypes = { DicType.SELL_PRICE,DicType.HOUSE_HUXING};
		Map<String, List<DictionaryVo>> tags = dictionaryService.queryDictionaryList(dicTypes);

		String areas = HttpUtil.doGet(systemConstant.getCustServiceUrl() + "/area/areas/" + scity + "");
		JSONObject json = JSONObject.parseObject(areas);
		JSONArray areaJson = (JSONArray) json.get("data");

		List<RentHouseVo> list = rentHouseService.queryList(request, getCurrentMemberIdAllowNull());
		CountVo countVo = rentHouseService.queryListCount(request);
		
		
		model.addAttribute("houseList", list);
		model.addAttribute("tags", tags);
		model.addAttribute("areas", areaJson);
		model.addAttribute("countVo", countVo);
		model.addAttribute("scity", scity);
		return "/renthouse";
	}

	// 租房详情
	@RequestMapping("/renthousedetail/{scity}/{sdid}")
	public String renthousedetail(Model model,@PathVariable("scity") String scity,@PathVariable("sdid") Long sdid) {
		
		RentHouseDetailVo info = rentHouseService.getDetailInfo(scity, sdid,getCurrentMemberIdAllowNull());
		List<com.ztj.dichan.cust.rule.response.building.RentHouseVo> recmdVoList = buildingService.rentHouseList(Long.parseLong(info.getBuildSdid()),scity,0,10);
		RimHouseRequest rimHouseRequest = new RimHouseRequest();
		rimHouseRequest.setBuildSdid(Long.parseLong(info.getBuildSdid()));
		rimHouseRequest.setScity(scity);
		rimHouseRequest.setPageSize(0);
		rimHouseRequest.setPageNo(10);
		rimHouseRequest.setPx(info.getPx().doubleValue());
		rimHouseRequest.setPy(info.getPy().doubleValue());
		List<RentHouseVo> rimHousingList = rentHouseService.rimHousing(rimHouseRequest);
		
		BuildingDetailVo detailVo = buildingService.buildInfo(Long.parseLong(info.getBuildSdid()),scity,getCurrentMemberIdAllowNull());
		
		List<HouseSeeRecordVo> seeList = rentHouseService.getHouseSeeRecordList(info.getId(), 1, 10,scity);
		
		model.addAttribute("info", info);
		model.addAttribute("buildDetailVo", detailVo);
		model.addAttribute("buildHouseList", recmdVoList);
		model.addAttribute("rimHousingList", rimHousingList);
		model.addAttribute("seeList", seeList);
		model.addAttribute("scity", scity);
		
		logger.info(JSON.toJSONString(info));
		logger.info(JSON.toJSONString(detailVo));
		logger.info(JSON.toJSONString(recmdVoList));
		logger.info(JSON.toJSONString(rimHousingList));
		logger.info(JSON.toJSONString(seeList));
		
		return "/renthousedetail";
	}

}
