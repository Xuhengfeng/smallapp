/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "会员我的信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class MemberMyInfoVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "用户ID")
	private Long id;
	
	@ApiModelProperty(value = "用户编码")
	private String code;
	
	@ApiModelProperty(value = "昵称")
	
	private String nickname;

	@ApiModelProperty(value = "性别")
	private String gender;

	@ApiModelProperty(value = "头像链接地址")
	private String headImage;
	
	@ApiModelProperty(value = "手机号码")
	private String mobile;
	
	@ApiModelProperty(value = "二手房收藏数")
	private Integer houseCollectCount;
	
	@ApiModelProperty(value = "租房收藏数")
	private Integer rentHouseCollectCount;
	
	@ApiModelProperty(value = "小区收藏数")
	private Integer buildCollectCount;
	
	@ApiModelProperty(value = "经纪人收藏数")
	private Integer brokerCollectCount;
	
	@ApiModelProperty(value = "客服电话")
	private String custServerPhone;
	
	@ApiModelProperty(value = "聊天账户")
	private String easemobUsername;
	
	@ApiModelProperty(value = "聊天密码")
	private String easemobPassword;
	
	@ApiModelProperty(value = "经纪人聊天appKey")
	private String brokerAppKey;
	
	@ApiModelProperty(value = "当前用户积分")
	private Long score;
	
	@ApiModelProperty(value = "当前拥有的卡券数量")
	private Integer couponCount;
	
	@ApiModelProperty(value = "今日积分数量")
	protected Long toDayScore;

	@ApiModelProperty(value = "还有多少张过期的卡券数量")
	protected Long overdueCoupon;
	
	
}
