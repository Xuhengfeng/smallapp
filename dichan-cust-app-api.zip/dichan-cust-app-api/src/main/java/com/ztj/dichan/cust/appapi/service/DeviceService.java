
package com.ztj.dichan.cust.appapi.service;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Service;

import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.appapi.request.DeviceRequest;
import com.ztj.dichan.cust.core.entity.DeviceInfo;
import com.ztj.dichan.cust.core.repository.DeviceInfoRepository;

/**
 * 
 * @author yincp
 */
@Service
@Transactional
public class DeviceService extends BaseAppService {

	@Resource
	private DeviceInfoRepository deviceInfoRepository;

	public void add(DeviceRequest request) {
		try {
			DeviceInfo deviceInfo = new DeviceInfo();

			BeanUtils.copyProperties(deviceInfo, request);

			deviceInfoRepository.save(deviceInfo);
		} catch (Exception e) {
			throw new BizException("保存设备信息出错", e);
		}
	}
}
