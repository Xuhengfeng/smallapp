package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author liuweichen
 *
 */
@ApiModel(value = "意见反馈")
@Data
@EqualsAndHashCode(callSuper = true)
public class FeedBackVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;


	/**
	 * 投诉内容
	 */
	@ApiModelProperty(dataType = "String", value = "投诉内容")
	private String content;
	
	
//	/**
//	 * 创建时间
//	 */
//	@ApiModelProperty(dataType = "string", value = "创建时间")
//	private String createDateTime;
}
