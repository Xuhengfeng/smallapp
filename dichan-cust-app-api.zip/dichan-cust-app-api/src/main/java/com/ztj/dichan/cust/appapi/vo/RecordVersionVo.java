package com.ztj.dichan.cust.appapi.vo;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.core.enums.VersionTypeEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author sily
 *
 */
@ApiModel(value = "版本返回信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class RecordVersionVo extends BaseValueObject {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "版本Url")
	private String versionUrl;

	@ApiModelProperty(value = "是否强制更新")
	private Boolean isForcedUpdate = Boolean.FALSE;

	@ApiModelProperty(value = "版本号")
	private String versionNo;

	@ApiModelProperty(value = "app版本")
	private String appVerison;

	@ApiModelProperty(value = "版本类型")
	private VersionTypeEnum versionType;

	@ApiModelProperty(value = "版本内容")
	private String versionContent;

	@ApiModelProperty(value = "app标识")
	private String appCode;

	@ApiModelProperty(value = "创建时间")
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDateTime createDateTime;

}
