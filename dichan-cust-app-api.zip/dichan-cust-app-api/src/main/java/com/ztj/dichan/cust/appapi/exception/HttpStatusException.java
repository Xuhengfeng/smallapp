package com.ztj.dichan.cust.appapi.exception;

import org.springframework.http.HttpStatus;


public class HttpStatusException extends AbstractException {

	private static final long serialVersionUID = -1992484755329273320L;

	public HttpStatusException(HttpStatus status) {
        super(status.value() + "", status.getReasonPhrase());
    }
}
