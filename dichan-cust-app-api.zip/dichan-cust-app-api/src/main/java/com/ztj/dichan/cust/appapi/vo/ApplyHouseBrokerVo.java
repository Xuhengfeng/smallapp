/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value="申请所属经纪人")
@Data
@EqualsAndHashCode(callSuper=true)
public class ApplyHouseBrokerVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;
	
	/**
	 * 经纪人ID
	 */
	@ApiModelProperty(value = "员工ID")
	private Integer id; 

	/**
	 * 姓名
	 */
	@ApiModelProperty(value = "员工姓名")
	private String emplName;
	
	/**
	 * 员工账号
	 */
	@ApiModelProperty(value = "员工账号")
	private String emplAccNo;
	
	@ApiModelProperty(value = "手机号码")
	private String phone;
	
	@ApiModelProperty(value = "性别")
	private String sex;
	
	/**
	 * 岗位名称
	 */
	@ApiModelProperty(value = "岗位名称")
	private String positionName;
	
	/**
	 * 门店
	 */
	@ApiModelProperty(value = "所在门店")
	private String deptName;
	
	
	/**
	 * 经纪人标签
	 */
	@ApiModelProperty(value = "经纪人标签")
	private String emplFlag;
	
	@ApiModelProperty(value = "头像照片")
	private String photo;
	
	@ApiModelProperty(value = "评分")
	private Double grade;
	
	@ApiModelProperty(value = "经纪人状态，0=正常，1=已离职")
	private Integer status;
	
	@ApiModelProperty(value = "经纪人聊天账号")
	private String chatUsername;
	
	public String getChatUsername() {
		return this.getScity() + "_" + this.getId() + "_" + this.getEmplAccNo();
	}

}
