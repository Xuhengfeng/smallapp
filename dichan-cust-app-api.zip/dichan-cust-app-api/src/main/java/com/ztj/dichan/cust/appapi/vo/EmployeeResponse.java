package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author sily
 */
@ApiModel(value = "会员信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class EmployeeResponse extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	private String phone;

	private String scity;

}
