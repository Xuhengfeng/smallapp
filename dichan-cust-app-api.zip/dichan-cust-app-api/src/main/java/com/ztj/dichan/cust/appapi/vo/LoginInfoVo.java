package com.ztj.dichan.cust.appapi.vo;

import java.util.List;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.house.HouseRecmdVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseRecmdVo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author yincp
 *
 */
@ApiModel(value = "pc登录信息VO")
@Data
@EqualsAndHashCode(callSuper = true)
public class LoginInfoVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "是否已收藏")
	private Boolean isCollect = false;
	
	@ApiModelProperty(value = "是否已加入约看房清单")
	private Boolean isAppoint = false;
	
	@ApiModelProperty(value = "是否已加入对比清单")
	private Boolean isComparison = false;
	
	private List<HouseVo> houseList;
	
	private List<HouseRecmdVo> contrasList;
	
	
	private List<RentHouseRecmdVo> rentContrasList;
}
