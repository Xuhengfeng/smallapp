package com.ztj.dichan.cust.appapi.vo;

import java.math.BigDecimal;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * 
 * @author sily
 *
 */
@ApiModel(value = "返回房屋信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class HouseUsedRecmdVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "房源标题")
	private String houseTitle;
	
	@ApiModelProperty(value = "区域")
	private String areaName;
	
	@ApiModelProperty(value = "楼名称")
	private String buildName;
	
	@ApiModelProperty(value = "片区")
	private String districtName;
	
	@ApiModelProperty(value = "售价")
	private BigDecimal saleTotal;
	
	@ApiModelProperty(value = "售单价")
	private BigDecimal saleprice;
	

}
