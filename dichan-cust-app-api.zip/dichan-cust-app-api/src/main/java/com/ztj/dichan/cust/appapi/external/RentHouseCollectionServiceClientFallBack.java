/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.request.RentHouseCollectionRequest;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseCollectionVo;

/**
 * @author sily
 *
 */
public class RentHouseCollectionServiceClientFallBack implements RentHouseCollectionServiceClient {

	@Override
	public List<RentHouseCollectionVo> queryCollectionList(
			List<RentHouseCollectionRequest> rentHouseCollectionRequest) {
		// TODO Auto-generated method stub
		return null;
	}









	
}