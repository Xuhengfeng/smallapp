package com.ztj.dichan.cust.appapi.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.druid.util.StringUtils;
import com.ztj.dichan.cust.appapi.util.PageUtil;
import com.ztj.dichan.cust.appapi.vo.newbuilding.NewBuildingIndexVo;
import com.ztj.dichan.cust.appapi.vo.newbuilding.NewBuildingVo;
import com.ztj.dichan.cust.core.entity.Dictionary;
import com.ztj.dichan.cust.core.entity.NewBuilding;
import com.ztj.dichan.cust.core.enums.DicType;
import com.ztj.dichan.cust.core.enums.NewBuildingStatusEnum;
import com.ztj.dichan.cust.core.repository.DictionaryRepository;
import com.ztj.dichan.cust.core.repository.NewBuildingRepository;

@Service
public class NewBuildingService extends BaseAppService {

	@Resource
	private DictionaryRepository dictionaryRepository;
	
	@Resource
	private NewBuildingRepository newBuildingRepository;
	
	public List<NewBuildingIndexVo> queryNewBuildingIndex() {
		
		List<Dictionary> cityList = dictionaryRepository.queryDictionaryList(DicType.NEW_HOUSE_CITY);
		if (cityList == null) {
			return new ArrayList<NewBuildingIndexVo>(0);
		}
		return cityList.stream().map(dic->{
			NewBuildingIndexVo indexVo = new NewBuildingIndexVo();
			indexVo.setCityCode(dic.getValue());
			indexVo.setCityName(dic.getName());
			List<NewBuildingVo> dataList = this.queryList(indexVo.getCityCode(),1,10);
			indexVo.setDataList(dataList);
			return indexVo;
		}).collect(Collectors.toList());
		
	}
	
	public List<NewBuildingVo> queryList(String cityCode,Integer pageNo,Integer pageSize) {
		
		if (StringUtils.isEmpty(cityCode)) {
			return new ArrayList<NewBuildingVo>(0);
		}
		List<NewBuilding> dataList = newBuildingRepository.findByCityCodeAndStatusOrderByCreateDateTimeDesc(cityCode, 
				NewBuildingStatusEnum.NORMAL, 
				PageUtil.createPage(pageNo, pageSize));
		
		if (dataList == null) {
			return new ArrayList<NewBuildingVo>(0);
		}
		
		return dataList.stream().map(newbuild->{
			NewBuildingVo vo = new NewBuildingVo();
			BeanUtils.copyProperties(newbuild, vo);
			vo.setTag(newbuild.getLabel());
			return vo;
		}).collect(Collectors.toList());
	}
}
