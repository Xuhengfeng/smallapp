/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.house;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "房源带看记录")
@Data
@EqualsAndHashCode(callSuper = true)
public class HouseSeeVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	private Integer day7Count;
	
	private Integer totalCount;
}
