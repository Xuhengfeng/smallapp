/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.request.HouseCollectionRequest;
import com.ztj.dichan.cust.rule.response.house.HouseCollectionVo;

/**
 * @author sily
 *
 */
public class HouseCollectionServiceClientFallBack implements HouseCollectionServiceClient {

	@Override
	public List<HouseCollectionVo> queryCollectionList(List<HouseCollectionRequest> houseCollectionVo) {
		// TODO Auto-generated method stub
		return null;
	}







	
}