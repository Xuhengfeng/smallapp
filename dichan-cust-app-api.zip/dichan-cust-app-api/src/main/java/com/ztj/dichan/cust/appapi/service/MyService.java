
package com.ztj.dichan.cust.appapi.service;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.ztj.common.util.DateUtil;
import com.ztj.dichan.cust.appapi.external.BrokerCollectionServiceClient;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.repository.activity.CouponRepository;
import com.ztj.dichan.cust.appapi.util.PageUtil;
import com.ztj.dichan.cust.appapi.vo.broker.BrokerContactVo;
import com.ztj.dichan.cust.appapi.vo.my.CommentVo;
import com.ztj.dichan.cust.core.constant.OssConstant;
import com.ztj.dichan.cust.core.constant.OtherConstant;
import com.ztj.dichan.cust.core.entity.BrokerContact;
import com.ztj.dichan.cust.core.repository.BrokerContactRepository;
import com.ztj.dichan.cust.core.repository.BrokerEvaluateRepository;
import com.ztj.dichan.cust.core.repository.MemberRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.core.vo.CommentQueryVo;
import com.ztj.dichan.cust.rule.request.BrokerCollectionRequest;
import com.ztj.dichan.cust.rule.response.broker.BrokerCollectionVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * @author yincp 我的
 */
@Service
@Transactional
public class MyService extends BaseAppService {

	@Resource
	private BrokerServiceClient brokerServiceClient;

	@Resource
	private CouponRepository couponRepository;

	@Resource
	private MemberRepository memberRepository;

	@Resource
	private BrokerContactRepository brokerContactRepository;

	@Resource
	private BrokerCollectionServiceClient brokerCollectionServiceClient;

	@Resource
	private BrokerEvaluateRepository brokerEvaluateRepository;

	public List<CommentVo> queryMyComment(Long memberId, Integer pageNo, Integer pageSize) {

		List<CommentVo> voList = new ArrayList<>();
		List<CommentQueryVo> commentList = brokerEvaluateRepository.queryComment(memberId,
				PageUtil.createPage(pageNo, pageSize));
		commentList.forEach(evaluate -> {
			CommentVo commentVo = new CommentVo();
			commentVo.setMemberName(evaluate.getUsername());
			commentVo.setBrokerId(evaluate.getBrokerId());
			commentVo.setTag(evaluate.getTag());
			commentVo.setContent(evaluate.getContent());
			commentVo.setGrade(evaluate.getGrade());

			Integer creationYear = evaluate.getCreationTime().getYear();
			Integer thisYear = LocalDateTime.now().getYear();
			if (creationYear.equals(thisYear)) {
				commentVo.setCommentTime(DateUtil.formatLocalDateTime(evaluate.getCreationTime(), "MM.dd"));
			} else {
				commentVo.setCommentTime(DateUtil.formatLocalDateTime(evaluate.getCreationTime(), "yyyy.MM.dd"));
			}

			BrokerDetailVo brokerDetailVo = queryBroker(evaluate.getBrokerScity(), evaluate.getBrokerId());
			if (brokerDetailVo != null) {
				commentVo.setEmplAccNo(brokerDetailVo.getEmplAccNo());
				commentVo.setEmplName(brokerDetailVo.getEmplName());
				commentVo.setPositionName(brokerDetailVo.getPositionName());
				commentVo.setBrokerPhoto(brokerDetailVo.getPhoto());
			}

			if (StringUtils.isNotEmpty(evaluate.getHeadImage())) {
				if (evaluate.getHeadImage().startsWith("http")) {
					commentVo.setHeadImage(commentVo.getHeadImage());
				} else {
					commentVo.setHeadImage(
							systemConstant.getOssCdnUrl() + commentVo.getHeadImage() + OssConstant.SUOFANG_YIBAN);
				}
			} else {
				commentVo.setHeadImage(
						systemConstant.getOssCdnUrl() + OtherConstant.DEFAULT_HEAD_IMAGE + OssConstant.SUOFANG_YIBAN);
			}

			voList.add(commentVo);
		});

		return voList;
	}

	/**
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<BrokerContactVo> queryList(Long memberId, Integer pageNo, Integer pageSize) {

		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}

		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createTime");

		List<BrokerContact> collectionList = brokerContactRepository.findByMemberId(memberId, pageRequest);
		if (collectionList == null || collectionList.isEmpty()) {
			return new ArrayList<BrokerContactVo>();
		}

		List<BrokerCollectionRequest> request = new ArrayList<>();

		collectionList.stream().forEach(collection -> {
			BrokerCollectionRequest vo = new BrokerCollectionRequest();
			vo.setSdid(collection.getBrokerSdid());
			vo.setScity(collection.getBrokerScity());
			request.add(vo);
		});

		List<BrokerCollectionVo> brokerVoList = brokerCollectionServiceClient.queryCollectionList(request);
		if (brokerVoList == null) {
			return new ArrayList<>(0);
		}
		List<BrokerContactVo> contactList = new LinkedList<>();
		brokerVoList.forEach(brokerVo -> {
			BrokerContactVo contactVo = new BrokerContactVo();
			try {
				BeanUtils.copyProperties(contactVo, brokerVo);
			} catch (IllegalAccessException | InvocationTargetException e) {
				e.printStackTrace();
			}
			contactVo.setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), brokerVo.getPhoto(),
					brokerVo.getScity(), brokerVo.getId()));
			contactVo.setStatus(Utils.checkBrokerStatus(brokerVo.getEmplStatus()));
			contactList.add(contactVo);
		});

		return contactList;

	}

	public BrokerDetailVo queryBroker(String scity, Long id) {
		BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(scity, Integer.parseInt(id + ""));
		if (brokerDetailVo != null) {
			if ("1".equals(brokerDetailVo.getPhoto())) {
				brokerDetailVo.setPhoto(systemConstant.getOssCdnUrl() + brokerDetailVo.getScity() + "/Empl/PIC/"
						+ brokerDetailVo.getId() + "/" + brokerDetailVo.getId() + ".jpg");
			}
			// brokerDetailVo.setDeptName(ShopUtil.updateName(brokerDetailVo.getDeptName()));
		}
		return brokerDetailVo;
	}
}