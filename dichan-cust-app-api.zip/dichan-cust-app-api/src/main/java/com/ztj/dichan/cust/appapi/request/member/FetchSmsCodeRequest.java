/**
 * 
 */
package com.ztj.dichan.cust.appapi.request.member;


import com.ztj.dichan.cust.appapi.request.BaseApiRequest;
import com.ztj.dichan.cust.core.enums.OperateTypeEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author liuweichen
 *
 */
@ApiModel(value = "发送验证码参数对象")
@Data
@EqualsAndHashCode(callSuper = true)
public class FetchSmsCodeRequest extends BaseApiRequest {
	

	private static final long serialVersionUID = 1L;
	@ApiModelProperty(value = "用户手机号，必填")
	private  String mobile;
	
	@ApiModelProperty(value = "签名数据，必填")
	private String sign;
	
	@ApiModelProperty(value = "操作类型，REGISTER(注册),RESET_PASSWORD(重置密码)，UPDATE_MOBILE(更换手机号),LOGIN(登陆)，必填")
	private OperateTypeEnum operateType;
	

	@ApiModelProperty(value="设备标识")
	private String deviceCode;
	
	
	
}
