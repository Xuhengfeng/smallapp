package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.SearchRecordService;
import com.ztj.dichan.cust.core.enums.SearchType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author liuweichen
 *
 */
@Api(value = "搜索记录", description = "搜索记录")
@RestController
@RequestMapping(value = "/searchRecord")
public class SearchRecordRest extends BaseCustRest{
	
	@Resource
	private SearchRecordService searchRecordService;
	
	@ApiOperation(value = "搜索记录")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true)})
	@RequestMapping(value = "/list", method = { RequestMethod.GET })
	public  RestResult<List<String>> searchRecordList() {
		
		return RestResult.success(searchRecordService.searchRecordList(getCurrentMemberIdAllowNull()));
	}
	
	@ApiOperation(value = "根据搜索类型获取记录")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "searchType", value = "搜索类型\r\n"
	        		+ "SELL=二手房\r\n" + 
	        		"RENT=租房\r\n" + 
	        		"BUILDING=小区\r\n" + 
	        		"BROKER=经纪人\r\n" + 
	        		"SHOP=门店", dataType = "String", paramType = "path", required = true)})
	@RequestMapping(value = "/list/{searchType}", method = { RequestMethod.GET })
	public  RestResult<List<String>> searchRecordTypeList(@PathVariable("searchType")SearchType searchType) {
		
		return RestResult.success(searchRecordService.searchRecordList(getCurrentMemberIdAllowNull(),searchType));
	}
	
	@ApiOperation(value = "清除所有搜索记录")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true)})
	@RequestMapping(value = "/clear", method = { RequestMethod.DELETE })
	public  RestResult<String> deleteAllSearchRecord() {
		searchRecordService.deleteAllSearchKeyword(getCurrentMemberIdAllowNull());
		return RestResult.success("删除成功");
	}
	
	@ApiOperation(value = "根据搜索类型清除搜索记录")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "searchType", value = "搜索类型\r\n"
	        		+ "SELL=二手房\r\n" + 
	        		"RENT=租房\r\n" + 
	        		"BUILDING=小区\r\n" + 
	        		"BROKER=经纪人\r\n" + 
	        		"SHOP=门店", dataType = "String", paramType = "path", required = true)})
	@RequestMapping(value = "/clear/{searchType}", method = { RequestMethod.DELETE })
	public  RestResult<String> deleteAllSearchRecordType(@PathVariable("searchType")SearchType searchType) {
		searchRecordService.deleteAllSearchKeyword(getCurrentMemberIdAllowNull(),searchType);
		return RestResult.success("删除成功");
	}
	
	

}
