package com.ztj.dichan.cust.appapi.vo.activity;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 积分详细信息
 * 
 * @author zhouqiao
 */
@ApiModel(value = "积分流水对象")
@Data
@EqualsAndHashCode(callSuper = true)
public class ScoreFollowRecordVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "创建时间")
	private String createDate;

	@ApiModelProperty(value = "积分来源")
	private String followTypeName;

	@ApiModelProperty(value = "积分值")
	private Long score;

	@ApiModelProperty(value = "当前总积分")
	private Long remainingScore;
}
