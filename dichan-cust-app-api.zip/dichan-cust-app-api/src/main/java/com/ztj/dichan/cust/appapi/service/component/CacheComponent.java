package com.ztj.dichan.cust.appapi.service.component;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.ztj.dichan.cust.core.constant.RedisConstant;
import com.ztj.dichan.cust.rule.bean.SysLoginBean;

/**
 * 
 * @author sily
 */
@Component
public class CacheComponent extends BaseAppComponent {

	/**
	 * 
	 * @param cityCode
	 * @param cityName
	 */
	public void addCity(String cityCode, String cityName) {
		redisTemplate.boundHashOps(RedisConstant.DICHAN_CUST_CITY_MAP).put(cityCode, cityName);
	}

	/**
	 * 
	 * @param cityCode
	 * @return
	 */
	public String getCityName(String cityCode) {
		if (StringUtils.isEmpty(cityCode)) {
			return "";
		}

		String cityName = (String) redisTemplate.boundHashOps(RedisConstant.DICHAN_CUST_CITY_MAP).get(cityCode);

		if (StringUtils.isEmpty(cityName)) {
			return "";
		}

		return cityName;
	}

	/**
	 * 
	 * @param cityCode
	 * @return
	 */
	public String getCityNameByCityCode(String cityCode) {
		if (StringUtils.isEmpty(cityCode)) {
			return "";
		}

		SysLoginBean loginBean = (SysLoginBean) redisTemplate.boundHashOps(RedisConstant.DICHAN_CUST_CITY_NAME_PY_MAP)
				.get(cityCode);

		if (loginBean == null) {
			return "";
		}

		if (StringUtils.isEmpty(loginBean.getCityName())) {
			return "";
		}

		return loginBean.getCityName();
	}
}