/**
 * 
 */
package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.PlateSerice;
import com.ztj.dichan.cust.appapi.vo.PlateVo;
import com.ztj.dichan.cust.core.enums.PlateTypeEnum;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @author lbs
 *
 */
@Api(value = "版块相关接口", description = "版块相关接口")
@RestController
@RequestMapping(value = "/plate")
public class PlateRest extends BaseCustRest {

	@Resource
	private PlateSerice plateSerice;
	
	@ApiOperation(value = "获取模块信息列表", response = PlateVo.class)
	@GetMapping(value = "/query/{type}")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "type", value = "版块类型，INDEX_PLATE=首页版面", dataType = "string", paramType="path", required = true)})
	public RestResult<List<PlateVo>> queryList(@PathVariable("type")PlateTypeEnum type) {

		List<PlateVo> voList = plateSerice.queryList(type);

		return RestResult.success(voList);

	}
}
