/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.appoint;


import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "返回约看记录信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointHouseDetailListVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "房源标题")
	private String houseTitle;

	@ApiModelProperty(value = "区域")
	private String areaName;

	@ApiModelProperty(value = "片区")
	private String districtName;

	@ApiModelProperty(value = "房源标签")
	private String houseTag;

	@ApiModelProperty(value = "朝向")
	private String houseDirection;

	@ApiModelProperty(value = "房")
	private Integer roomsNum;

	@ApiModelProperty(value = "厅")
	private Integer livingRoomNum;

	@ApiModelProperty(value = "卫")
	private Integer washRoomNum;

	@ApiModelProperty(value = "户型")
	private String houseType;

	@ApiModelProperty(value = "建筑面积")
	private Integer builtArea;

	@ApiModelProperty(value = "房源特征")
	private String houseFeature;

	@ApiModelProperty(value = "售价")
	private Double saleTotal;

	@ApiModelProperty(value = "售单价")
	private Integer salePrice;

	@ApiModelProperty(value = "房源照片")
	private String housePic;
	
	@ApiModelProperty(value = "房源Id")
	private Integer houseId;
	
	@ApiModelProperty(value = "房源sdid")
	private String houseSdid;
	
	@ApiModelProperty(value = "房源地市编码")
	private String houseScity;

	@ApiModelProperty(value = "房源状态，0=正常，1=已售，2=已失效，3=已停售")
	private Integer status;
	
	@ApiModelProperty(value = "待看记录id")
	private Long id;

	public String getHouseType() {
		return String.format("%s房%s厅", roomsNum, livingRoomNum);
	}

}
