package com.ztj.dichan.cust.appapi.vo.consultant;


import com.ztj.dichan.cust.appapi.vo.BaseApiValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author yincp
 *
 */
@ApiModel(value = "我关注的问题列表")
@Data
@EqualsAndHashCode(callSuper = true)
public class ConcernConsultVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "咨询Id")
	private Long id;

	@ApiModelProperty(value = "咨询标题")
	private String problemTitle;

	@ApiModelProperty(value = "咨询标题描述")
	private String  problemDescribe;

	@ApiModelProperty(value = "提问标签")
	private String label;
	
	@ApiModelProperty(value = "分类名称")
	private String classifyName;
	
	@ApiModelProperty(value = "发布时间")
	private String pubTime;
	
	@ApiModelProperty(value = "回答数量")
	private Long answerNum;
	
	

}