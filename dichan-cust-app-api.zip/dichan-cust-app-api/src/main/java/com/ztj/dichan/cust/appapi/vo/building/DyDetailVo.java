/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.building;

import java.util.List;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "单元信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class DyDetailVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "单元名称")
	private String name;
	
	@ApiModelProperty(value = "房号列表")
	private List<String> fhList;

}
