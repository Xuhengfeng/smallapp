package com.ztj.dichan.cust.appapi.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.dichan.cust.appapi.constant.SystemConstant;
import com.ztj.dichan.cust.appapi.rest.BaseCustRest;
import com.ztj.dichan.cust.appapi.service.BuildingService;
import com.ztj.dichan.cust.appapi.service.DictionaryService;
import com.ztj.dichan.cust.appapi.util.HttpUtil;
import com.ztj.dichan.cust.appapi.vo.DictionaryVo;
import com.ztj.dichan.cust.core.enums.DicType;
import com.ztj.dichan.cust.rule.request.buildnew.BuildRequest;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.building.BuildingVo;
import com.ztj.dichan.cust.rule.response.building.RentHouseVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

@Controller
@RequestMapping(value = "/buildController")
public class BuildingController extends BaseCustRest {

	@Resource
	private BuildingService buildingService;

	@Resource
	private DictionaryService dictionaryService;

	@Resource
	private SystemConstant systemConstant;


	// 小区列表
	@RequestMapping("/estate")
	public String queryList(Model model,  Integer areaId,Integer districtId,Double minSellPrice, Double maxSellPrice
			, String keyword, String businessType,String houseType, String useYear, String scity, Integer pageNo,
			Integer pageSize) {
		if(scity.isEmpty()) {
			scity = "beihai";
		}
		
		BuildRequest request = new BuildRequest();
		request.setAreaId(areaId);
		request.setDistrictId(districtId);
		request.setMinSellPrice(minSellPrice);
		request.setMinSellPrice(minSellPrice);
		request.setKeyword(keyword);
		request.setBusinessType(businessType);
		request.setHouseType(houseType);
		request.setUseYear(useYear);
		request.setScity(scity);
		request.setPageNo(pageNo);
		request.setPageSize(pageSize);
		
		DicType[] dicTypes = { DicType.HOUSE_AGE, DicType.SELL_UNIT_PRICE,DicType.CITY};
		Map<String, List<DictionaryVo>> tags = dictionaryService.queryDictionaryList(dicTypes);

		String areas = HttpUtil.doGet(systemConstant.getCustServiceUrl() + "/area/areas/" + scity + "");
		JSONObject json = JSONObject.parseObject(areas);
		JSONArray areaJson = (JSONArray) json.get("data");

		List<BuildingVo> voList = buildingService.buildList(request);
		CountVo countVo = buildingService.buildListCount(request);
		
		model.addAttribute("buildList", voList);
		model.addAttribute("countVo", countVo);
		model.addAttribute("tags", tags);
		model.addAttribute("areas", areaJson);
		model.addAttribute("scity", scity);
		
		return "/estate";
	}

	// 小区详情
	@RequestMapping("/estatedetail/{scity}/{sdid}")
	public String estatedetail(Model model, @PathVariable("scity") String scity, @PathVariable("sdid") Long sdid) {

		BuildingDetailVo buildingDetailVo = buildingService.buildInfo(sdid, scity, getCurrentMemberIdAllowNull());

		// 同小区房源列表
		List<RentHouseVo> recmdVoList = buildingService.rentHouseList(sdid, scity, 1, 10);
		
		// 同小区二手房
	    List<SecondHouseVo> twoVoList = buildingService.secondHouseList(sdid, scity, 1, 2);
		
		model.addAttribute("buildDetail", buildingDetailVo);
		model.addAttribute("twoVoList", twoVoList);
		model.addAttribute("sameBuildHouse", recmdVoList);

		return "/estatedetail";
	}

}
