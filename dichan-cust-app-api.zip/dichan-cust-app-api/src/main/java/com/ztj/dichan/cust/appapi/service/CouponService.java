/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alipay.api.domain.BeaconDeviceInfo;
import com.ztj.common.exception.BizException;
import com.ztj.common.util.DateUtil;
import com.ztj.dichan.cust.appapi.external.ProtocolServiceClient;
import com.ztj.dichan.cust.appapi.repository.activity.CouponFollowRecordRepository;
import com.ztj.dichan.cust.appapi.repository.activity.CouponRepository;
import com.ztj.dichan.cust.appapi.repository.activity.CouponUsedRecordRepository;
import com.ztj.dichan.cust.appapi.repository.activity.ExchangeAvailableRepository;
import com.ztj.dichan.cust.appapi.repository.activity.ScoreFollowRecordRepository;
import com.ztj.dichan.cust.appapi.repository.activity.TemplateRepository;
import com.ztj.dichan.cust.appapi.repository.activity.WalletRepository;
import com.ztj.dichan.cust.appapi.vo.activity.CouponDetailVo;
import com.ztj.dichan.cust.appapi.vo.activity.CouponGiveVo;
import com.ztj.dichan.cust.appapi.vo.activity.CouponVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.Member;
import com.ztj.dichan.cust.core.entity.activity.Coupon;
import com.ztj.dichan.cust.core.entity.activity.CouponFollowRecord;
import com.ztj.dichan.cust.core.entity.activity.CouponUsedRecord;
import com.ztj.dichan.cust.core.entity.activity.Template;
import com.ztj.dichan.cust.core.entity.activity.Wallet;
import com.ztj.dichan.cust.core.enums.CouponFollwTypeEnum;
import com.ztj.dichan.cust.core.enums.CouponStatusEnum;
import com.ztj.dichan.cust.core.enums.OperateTypeEnum;
import com.ztj.dichan.cust.core.repository.MemberRepository;
import com.ztj.dichan.cust.core.util.CodeUtil;
import com.ztj.dichan.cust.core.util.VerifyUtil;
import com.ztj.dichan.cust.rule.response.ProtocolVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * @author sily
 *
 */
@Service
@Transactional
public class CouponService extends BaseAppService {

	@Resource
	private CouponRepository couponRepository;

	@Resource
	private TemplateRepository templateRepository;

	@Resource
	private MemberRepository memberRepository;

	@Resource
	private ScoreFollowRecordRepository scoreFollowRecordRepository;

	@Resource
	private WalletRepository walletRepository;

	@Resource
	private ExchangeAvailableRepository exchangeAvailableRepository;

	@Resource
	private CouponFollowRecordRepository couponFollowRecordRepository;

	@Resource
	private CouponUsedRecordRepository couponUsedRecordRepository;

	@Resource
	private ProtocolServiceClient protocolServiceClient;

	/**
	 * 
	 * @param couponCode
	 * @return
	 */
	public CouponDetailVo getDetailInfo(Long ownMemberId, String couponCode) {
		Coupon coupon = couponRepository.findByOwnMemberIdAndCode(ownMemberId, couponCode);

		if (coupon == null) {
			throw new IllegalStateException("找不到卡券信息");
		}

		Template template = templateRepository.findOne(coupon.getTemplateId());

		if (template == null) {
			throw new IllegalStateException("找不到对应的模板");
		}

		CouponDetailVo detailVo = new CouponDetailVo();

		detailVo.setCode(coupon.getCode());
		detailVo.setName(template.getName());
		detailVo.setStatus(coupon.getStatus().toString());
		detailVo.setStatusName(coupon.getStatus().getName());
		detailVo.setVaildDateTime(DateUtil.formatLocalDateTime(coupon.getBeginDateTime(), DateUtil.DATEFORMAT_DATE10)
				+ "-" + DateUtil.formatLocalDateTime(coupon.getEndDateTime(), DateUtil.DATEFORMAT_DATE10));
		detailVo.setImageUrl(template.getImageUrl());
		detailVo.setContent(template.getContent());
		detailVo.setCouponTypeName(template.getCouponType().getName());

		return detailVo;
	}

	/**
	 * 
	 * @param couponFollowId
	 * @return
	 */
	public CouponDetailVo getGiveDetailInfo(Long couponFollowId) {

		CouponFollowRecord couponFollowRecord = couponFollowRecordRepository.findOne(couponFollowId);

		if (couponFollowRecord == null) {
			throw new IllegalStateException("找不到对应的流水信息");
		}

		Coupon coupon = couponRepository.findOne(couponFollowRecord.getCouponId());

		if (coupon == null) {
			throw new IllegalStateException("找不到对应的券");
		}

		Template template = templateRepository.findOne(coupon.getTemplateId());

		if (template == null) {
			throw new IllegalStateException("找不到对应的模板");
		}

		CouponDetailVo detailVo = new CouponDetailVo();

		detailVo.setCode(coupon.getCode());
		detailVo.setName(template.getName());
		detailVo.setStatus("GIVE");
		detailVo.setStatusName("已转赠");
		detailVo.setVaildDateTime(DateUtil.formatLocalDateTime(coupon.getBeginDateTime(), DateUtil.DATEFORMAT_DATE10)
				+ "-" + DateUtil.formatLocalDateTime(coupon.getEndDateTime(), DateUtil.DATEFORMAT_DATE10));
		detailVo.setImageUrl(template.getImageUrl());
		detailVo.setContent(template.getContent());
		detailVo.setCouponTypeName(template.getCouponType().getName());

		return detailVo;
	}

	/**
	 * 获取用户已转赠的卡券信息列表
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<CouponGiveVo> queryGiveList(Long memberId, Integer pageNo, Integer pageSize) {
		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createDateTime");

		Page<CouponFollowRecord> page = couponFollowRecordRepository.findByMemberIdAndFollwType(memberId,
				CouponFollwTypeEnum.GIVE, pageRequest);

		List<CouponGiveVo> voList = new ArrayList<>();

		List<Long> couponIdList = new ArrayList<>();

		page.getContent().forEach(record -> {

			CouponGiveVo vo = new CouponGiveVo();
			vo.setCouponFollowId(record.getId());
			vo.setCode(record.getCouponCode());
			vo.setGiveToPersonName(record.getGiveToPersonName());
			vo.setGiveDateTime(record.getCreateDateTime());

			couponIdList.add(record.getCouponId());

			voList.add(vo);
		});

		List<Coupon> list = couponRepository.findByIdIn(couponIdList);

		for (Coupon coupon : list) {
			for (CouponGiveVo vo : voList) {
				if (vo.getCode().equals(coupon.getCode())) {
					vo.setCode(coupon.getCode());
					vo.setName(coupon.getName());
					vo.setCouponTypeName(coupon.getCouponType().getName());
					vo.setStatusName("已转赠");
					vo.setStatus("GIVE");

					break;
				}
			}
		}
		return voList;

	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param memberId
	 * @param status
	 * @return
	 */
	public List<CouponVo> queryList(Long memberId, CouponStatusEnum status, Integer pageNo, Integer pageSize) {
		if (status == null) {
			throw new IllegalArgumentException("status不能为空");
		}

		PageRequest pageRequest = validateAndFetchPageRequestOrderByAsc(pageNo, pageSize, "endDateTime");

		List<CouponVo> voList = new ArrayList<>();

		Page<Coupon> page = couponRepository.findByOwnMemberIdAndStatus(memberId, status, pageRequest);

		page.getContent().stream().forEach(coupon -> {
			CouponVo vo = new CouponVo();

			vo.setCode(coupon.getCode());
			vo.setName(coupon.getName());
			vo.setBeginDateTime(coupon.getBeginDateTime());
			vo.setEndDateTime(coupon.getEndDateTime());
			vo.setUseDateTime(coupon.getUseDateTime());
			vo.setStatus(coupon.getStatus().toString());
			vo.setStatusName(coupon.getStatus().getName());
			vo.setFormatDateTime(DateUtil.formatLocalDateTime(coupon.getBeginDateTime(), DateUtil.DATEFORMAT_DATE10)
					+ "-" + DateUtil.formatLocalDateTime(coupon.getEndDateTime(), DateUtil.DATEFORMAT_DATE10));
			vo.setCouponTypeName(coupon.getCouponType().getName());

			long days = Duration.between(LocalDateTime.now(), coupon.getEndDateTime()).toDays();
			if (days <= 2) {
				vo.setDay(days);
			}

			voList.add(vo);
		});

		return voList;
	}

	public void add(Long modelId) {
		Template couponModel = templateRepository.findOne(modelId);

		for (int i = 0; i <= 50; i++) {

			Coupon coupon = new Coupon();
			coupon.setTemplateId(modelId);
			coupon.setBeginDateTime(couponModel.getBeginDateTime());
			coupon.setEndDateTime(couponModel.getEndDateTime());
			coupon.setName(couponModel.getName());
			coupon.setCode(CodeUtil.couponCode());
			coupon.setCouponType(couponModel.getCouponType());
			coupon.setOwnMemberId(7L);
			coupon.setFetchMemberId(7L);
			coupon.setStatus(CouponStatusEnum.NO_USED);
			coupon.setFetchDateTime(LocalDateTime.now());

			couponRepository.save(coupon);
		}
	}

	/**
	 * 卡券转赠操作
	 * 
	 * @param memberId
	 * @param couponCode
	 * @param smsCode
	 * @param giveMobile
	 */
	public void giveCoupon(Long memberId, String couponCode, String smsCode, String giveMobile) {
		if (StringUtils.isEmpty(smsCode)) {
			throw new IllegalArgumentException("验证码不能为空");
		}

		if (StringUtils.isEmpty(couponCode)) {
			throw new IllegalArgumentException("优惠券code不能为空");
		}

		if (StringUtils.isEmpty(giveMobile)) {
			throw new IllegalArgumentException("赠送人手机号不能为空");
		}

		if (!VerifyUtil.isMobile(giveMobile)) {
			throw new IllegalArgumentException("赠送人手机格式不正确");
		}

		try {
			Member member = memberRepository.findOne(memberId);

			String verifyCode = (String) redisTemplate.opsForValue()
					.get(member.getMobile() + "_" + OperateTypeEnum.GIVE_COUPON.toString());

			if (!Utils.checkSmsCode(smsCode, verifyCode)) {
				throw new IllegalArgumentException("手机验证码不正确");
			}

			Coupon coupon = couponRepository.findByCode(couponCode);

			if (coupon == null) {
				throw new IllegalStateException("找不到对应的券");
			}

			if (!coupon.getOwnMemberId().equals(member.getId())) {
				throw new IllegalStateException("卡券不属于当前用户");
			}

			if (coupon.getStatus() != CouponStatusEnum.NO_USED) {
				throw new IllegalStateException("不是未使用的券,不能执行赠送操作");
			}

			if (coupon.getEndDateTime().compareTo(LocalDateTime.now()) < 0) {
				throw new IllegalStateException("卡券已过期,不能执行赠送操作");
			}

			Member giveToMember = memberRepository.findByMobile(giveMobile);

			if (giveToMember == null) {
				throw new IllegalStateException("找不到赠送的用户");
			}

			coupon.setOwnMemberId(giveToMember.getId());
			coupon.setGiveDateTime(LocalDateTime.now());
			coupon.setUpdateDateTime(LocalDateTime.now());

			couponRepository.save(coupon);

			// 保存赠送流水操作
			CouponFollowRecord followRecord = new CouponFollowRecord();
			followRecord.setCouponId(coupon.getId());
			followRecord.setCouponCode(coupon.getCode());
			followRecord.setFollwType(CouponFollwTypeEnum.GIVE);
			followRecord.setMemberId(memberId);
			followRecord.setPersonName(member.getNickname());
			followRecord.setGiveToMemberId(giveToMember.getId());
			followRecord.setGiveToPersonName(giveToMember.getNickname());

			couponFollowRecordRepository.save(followRecord);

			Wallet giveToWallet = walletRepository.findByMemberId(giveToMember.getId());

			if (giveToWallet != null) {
				giveToWallet.setCouponCount(giveToWallet.getCouponCount() + 1);
				giveToWallet.setUpdateDateTime(LocalDateTime.now());

				walletRepository.save(giveToWallet);
			}

			Wallet wallet = walletRepository.findByMemberId(member.getId());

			if (wallet != null) {
				wallet.setCouponCount(wallet.getCouponCount() - 1);
				wallet.setUpdateDateTime(LocalDateTime.now());

				walletRepository.save(wallet);
			}

		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("赠送优惠券出错", e);
		}
	}

	public List<Coupon> queryOverdueList() {
		return couponRepository.findByEndDateTimeLessThanAndStatus(LocalDateTime.now(), CouponStatusEnum.NO_USED);
	}

	public void updateOverdueStatus(Coupon coupon) {
		try {
			coupon.setStatus(CouponStatusEnum.ALREADY_OVERDUE);
			coupon.setUpdateDateTime(LocalDateTime.now());

			couponRepository.save(coupon);
		} catch (Exception e) {
			throw new BizException("修改优惠券状态出错了", e);
		}
	}

	public void addWallet(Member member) {

		Wallet wallet = walletRepository.findByMemberId(member.getId());
		try {
			if (wallet == null) {

				Wallet wallet1 = new Wallet();

				wallet1.setCreateDateTime(LocalDateTime.now());
				wallet1.setMemberCode(member.getCode());
				wallet1.setMemberId(member.getId());
				wallet1.setScore(0L);
				wallet1.setCouponCount(0);

				walletRepository.save(wallet1);

			}
		} catch (Exception e) {
			throw new BizException("修改优惠券状态出错了", e);
		}

	}

	/**
	 * 
	 * @param couponCode
	 * @return
	 */
	public Boolean checkCouponStatus(String couponCode) {

		Coupon coupon = couponRepository.findByCode(couponCode);

		if (coupon == null) {
			throw new IllegalArgumentException("找不到对应的优惠券");
		}

		if (coupon.getStatus() == CouponStatusEnum.NO_USED) {
			return true;
		}

		return false;

	}

	/**
	 * 
	 * @param memberId
	 * @param contractNo
	 * @param couponCode
	 */
	public void useCoupon(Long memberId, String contractNo, String couponCode) {

		try {

			String scity = RequestContextHolder.getCityCode();

			ProtocolVo protocolVo = protocolServiceClient.findByContractNo(scity, contractNo);

			if (protocolVo == null) {
				throw new IllegalArgumentException("找不到对应的合同");
			}

			Coupon coupon = couponRepository.findByOwnMemberIdAndCode(memberId, couponCode);

			if (coupon == null) {
				throw new IllegalArgumentException("找不到对应的券");
			}

			if (coupon.getStatus() == CouponStatusEnum.ALREADY_USED) {
				throw new IllegalArgumentException("该优惠券已经使用过了");
			}

			if (coupon.getStatus() == CouponStatusEnum.ALREADY_OVERDUE) {
				throw new IllegalArgumentException("该优惠券过期了,不能使用");
			}

			// 保存流水记录
			CouponFollowRecord record = new CouponFollowRecord();

			record.setCouponId(coupon.getId());
			record.setCouponCode(coupon.getCode());
			record.setFollwType(CouponFollwTypeEnum.CONTRACT_USED);
			record.setCreateDateTime(LocalDateTime.now());
			couponFollowRecordRepository.save(record);

			// 保存使用记录
			CouponUsedRecord couponUsedRecord = new CouponUsedRecord();

			couponUsedRecord.setContractNo(protocolVo.getContractNo());
			couponUsedRecord.setCouponId(coupon.getId());
			couponUsedRecord.setCouponCode(coupon.getCode());
			couponUsedRecord.setCouponFollowId(record.getId());
			couponUsedRecord.setCreateDateTime(LocalDateTime.now());

			couponUsedRecordRepository.save(couponUsedRecord);

			// 修改卡券状态
			coupon.setStatus(CouponStatusEnum.ALREADY_USED);
			coupon.setUseDateTime(LocalDateTime.now());
			coupon.setUpdateDateTime(LocalDateTime.now());

			couponRepository.save(coupon);

		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("使用优惠券出错", e);
		}

	}
}