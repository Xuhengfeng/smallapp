package com.ztj.dichan.cust.appapi.vo.trend;

import java.io.Serializable;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value = "趋势图统计Vo")
@Data
@EqualsAndHashCode(callSuper = false)
public class TrendDetailVo implements Serializable{
	private static final long serialVersionUID = 1L;

	/**
	 * 标题
	 */
	@ApiModelProperty(value="标题")
	private String title;

	/**
	 * 年份
	 */
	@ApiModelProperty(value="年份")
	private Integer year;

	/**
	 * 月份
	 */
	@ApiModelProperty(value="月份")
	private Integer month;

	/**
	 * 成交价
	 */
	@ApiModelProperty(value="成交价")
	private Double avgPrice;
	
	/**
	 * 市场均价
	 */
	@ApiModelProperty(value="市场价")
	private Double marketPrice;
	

	/**
	 * 套数
	 */
	@ApiModelProperty(value="套数")
	private Integer suiteCount;


}
