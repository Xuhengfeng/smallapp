/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.activity;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author sily
 *
 */
@ApiModel(value = "优惠券详情")
@Data
@EqualsAndHashCode(callSuper = true)
public class CouponDetailVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "券名称")
	private String name;

	@ApiModelProperty(value = "券编号")
	private String code;

	@ApiModelProperty(value = "有效期")
	private String vaildDateTime;

	@ApiModelProperty(value = "图片链接")
	private String imageUrl;

	@ApiModelProperty(value = "卡券状态")
	private String status;
	
	@ApiModelProperty(value = "状态的中文描述")
	protected String statusName;

	@ApiModelProperty(value = "文本内容")
	private String content;
	
	@ApiModelProperty(value = "优惠券类型 :DY_COUPON==抵扣券,ZK_COUPON==折扣券")
	private String  couponTypeName;

}
