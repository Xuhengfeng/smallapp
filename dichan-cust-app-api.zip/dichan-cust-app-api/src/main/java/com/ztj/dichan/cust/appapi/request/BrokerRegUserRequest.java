/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "经纪人即时通信账号注册请求对象")
@Data
@EqualsAndHashCode(callSuper = true)
public class BrokerRegUserRequest extends BaseApiRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5362981406498074911L;
	
	@ApiModelProperty(value = "经纪人即时通信账号", required = true)
	private String chatUsername;

}
