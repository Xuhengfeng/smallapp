package com.ztj.dichan.cust.appapi.exception;


public class ResourceNotFoundException extends AbstractException {

	private static final long serialVersionUID = -6070313566028666378L;

	public ResourceNotFoundException() {
        super("404", "未找到相应的资源信息");
    }
	
	public ResourceNotFoundException(String message) {
        super("404", message);
    }
	public ResourceNotFoundException(String errCode, String message) {
        super(errCode, message);
    }
}
