package com.ztj.dichan.cust.appapi.vo;


import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value = "数据字典信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class DictionaryVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	public DictionaryVo() {
		
	}
	
	public DictionaryVo(String name,String value) {
		this.name = name;
		this.value = value;
	}
	
	
	/**
	 * 值
	 */
	@ApiModelProperty(value = "值")
	private String value;

	/**
	 * 名字
	 */
	@ApiModelProperty(value = "显示名称")
	private String name;
	
	
	
	
}
