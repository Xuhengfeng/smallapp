package com.ztj.dichan.cust.appapi.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.service.component.CacheComponent;
import com.ztj.dichan.cust.appapi.vo.DefaultCityVo;
import com.ztj.dichan.cust.appapi.vo.DictionaryVo;
import com.ztj.dichan.cust.core.entity.Dictionary;
import com.ztj.dichan.cust.core.enums.DicType;
import com.ztj.dichan.cust.core.repository.DictionaryRepository;

/**
 * 
 * @author lbs
 *
 */
@Service
public class DictionaryService extends BaseAppService {
	private static final String DEFAULT_CITY = "default";
	
	@Resource
	private CacheComponent cacheComponent;
	
	@Resource
	private DictionaryRepository dictionaryRepository;
	
	/**
	 * 获取单个数据字典类型信息列表
	 * 
	 * @param dicType
	 * @return
	 */
	public List<DictionaryVo> queryDictionaryList(DicType dicType) {
		
		List<Dictionary> dictionarys = dictionaryRepository.queryDictionaryList(dicType);
		
		if (dictionarys == null || dictionarys.isEmpty()) {
			return new ArrayList<DictionaryVo>(0);
		}
		
		List<DictionaryVo> dictionaryVos = dictionarys.stream().map(dictionary -> {
	            return new DictionaryVo(dictionary.getName(),dictionary.getValue());
	        }).collect(Collectors.toList());
		 
		return dictionaryVos;
	}
	
	/**
	 * 获取多个数据字典类型信息列表
	 * 
	 * @param dicTypes
	 * @return
	 */
	public Map<String,List<DictionaryVo>> queryDictionaryList(DicType[] dicTypes) {
		
		if (dicTypes == null || dicTypes.length <= 0) {
			return new HashMap<String,List<DictionaryVo>>(0);
		}
		List<Dictionary> dictionarys = dictionaryRepository.queryDictionaryList(dicTypes);
		if (dictionarys == null || dictionarys.isEmpty()) {
			return new HashMap<String,List<DictionaryVo>>(0);
		}
		Map<String,List<DictionaryVo>> tempMap = new HashMap<String,List<DictionaryVo>>(dicTypes.length); 
		List<DictionaryVo> dictionaryVos = null;
		for (Dictionary dictionary : dictionarys) {
			dictionaryVos = tempMap.get(dictionary.getDicType().toString());
			if (dictionaryVos != null) {
				dictionaryVos.add(new DictionaryVo(dictionary.getName(),dictionary.getValue()));
			} else {
				dictionaryVos = new ArrayList<DictionaryVo>();
				dictionaryVos.add(new DictionaryVo(dictionary.getName(),dictionary.getValue()));
				tempMap.put(dictionary.getDicType().toString(), dictionaryVos);
			}
		}
		return tempMap;
	}
	
	
	/**
	 * 获取单个数据字典类型信息列表--过滤城市
	 * 
	 * @param dicType
	 * @return
	 */
	public List<DictionaryVo> queryDictionaryCityList(DicType dicType,String cityCode) {
		
		
		
		List<Dictionary> dictionarys = dictionaryRepository.queryDictionaryList(dicType,cityCode);
		
		if (dictionarys == null || dictionarys.isEmpty()) {
			dictionarys = dictionaryRepository.queryDictionaryList(dicType,DEFAULT_CITY);
		}
		
		List<DictionaryVo> dictionaryVos = dictionarys.stream().map(dictionary -> {
	            return new DictionaryVo(dictionary.getName(),dictionary.getValue());
	        }).collect(Collectors.toList());
		 
		return dictionaryVos;
	}
	
	/**
	 * 获取地市信息列表
	 * @return
	 */
	public List<DictionaryVo> queryCityList() {
		
		List<Dictionary> dictionarys = dictionaryRepository.queryCityList(DicType.CITY);
		
		if (dictionarys == null || dictionarys.isEmpty()) {
			return new ArrayList<DictionaryVo>(0);
		}
		
		List<DictionaryVo> dictionaryVos = dictionarys.stream().map(dictionary -> {
	            return new DictionaryVo(dictionary.getName(),dictionary.getValue());
	        }).collect(Collectors.toList());
		 
		return dictionaryVos;
	}
	
	public DefaultCityVo getDefaultCity() {
		
		List<Dictionary> dictionarys = dictionaryRepository.queryCityList(DicType.DEFAULT_CITY);
		
		if (dictionarys == null || dictionarys.isEmpty()) {
			return null;
		}
		Dictionary dictionary = dictionarys.get(0);
		DefaultCityVo defaultCityVo = new DefaultCityVo();
		defaultCityVo.setName(dictionary.getName());
		String value = dictionary.getValue();
		if (!StringUtils.isEmpty(value)) {
			String[] values = value.split(",");
			defaultCityVo.setValue(values[0]);
			if (values.length >= 3) {
				defaultCityVo.setPx(new BigDecimal(values[1]));
				defaultCityVo.setPy(new BigDecimal(values[2]));
			}
		}
	
		return defaultCityVo;
	}
	
	/**
	 * 获取投诉电话
	 * @return
	 */
	public String getComplaintPhone() {
		return this.getDictionaryValue(DicType.COMPLAINT_PHONE);
	}
	
	/**
	 * 获取经纪人默认电话
	 * @return
	 */
	public String getBrokerDefaultPhone() {
		return this.getDictionaryValue(DicType.BROKER_DEFAULT_PHONE);
	}
	
	public String getDictionaryValue(DicType type) {
		
		List<Dictionary> dictionarys = dictionaryRepository.queryDictionaryList(type);
		
		if (dictionarys == null || dictionarys.isEmpty()) {
			return null;
		}
		return dictionarys.get(0).getValue();
	}
	
	public String getDictionaryValue(DicType type,String cityCode) {
		
		List<Dictionary> dictionarys = dictionaryRepository.queryDictionaryList(type,cityCode);
		
		if (dictionarys == null || dictionarys.isEmpty()) {
			return null;
		}
		return dictionarys.get(0).getValue();
	}
	
	
	public boolean checkDictionaryExist(DicType type,String value) {
		if (StringUtils.isEmpty(value)) {
			return false;
		}
		List<Dictionary> dictionarys = dictionaryRepository.queryDictionaryList(type);
		
		if (dictionarys == null || dictionarys.isEmpty()) {
			return false;
		}
		boolean flag = false;
		for (Dictionary dictionary : dictionarys) {
			if (value.equals(dictionary.getValue())) {
				flag = true;
				break;
			}
		}
		
		return flag;
	}
	
	public void initCityNameMap() {
		logger.info("初始化城市缓存.....");
		
		List<Dictionary> dictionarys = dictionaryRepository.queryCityList(DicType.CITY);
		
		if (dictionarys != null) {
			dictionarys.forEach(dictionary -> {
				cacheComponent.addCity(dictionary.getValue(), dictionary.getName());
			});
		}
		
		logger.info("城市缓存结束!!");
	}
	
	public void initDicMap() {
		
		/*logger.info("初始化数据字典缓存.....");
		List<Dictionary> dictionarys = dictionaryRepository.queryDictionaryList(DicType.AGENT_BIZ_TYPE);
		if (dictionarys != null) {
			dictionarys.forEach(dictionary -> {
				SysCache.addCache(dictionary.getValue(), dictionary.getName());
				
			});
		}
		logger.info("数据字典缓存结束!!");*/
	}
	
}
