package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.RentHouseCollectionService;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseCollectionVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author sily
 *
 */
@Api(value = "租房收藏", description = "租房收藏相关接口")
@RestController
@RequestMapping(value = "/rentHCollection")
public class RentHouseCollectionRest extends BaseCustRest {

	@Resource
	private RentHouseCollectionService rentHouseCollectionService;
	
	@ApiOperation(value = "租房收藏列表", response = RentHouseCollectionVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType = "query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	@GetMapping(value = "/collectionList")
	public RestResult<List<RentHouseCollectionVo>> queryCollectionList(@RequestParam(name="pageNo", required = true)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		
		List<RentHouseCollectionVo> voList = rentHouseCollectionService.queryList(getCurrentMemberId(), pageNo, pageSize);

		return RestResult.success(voList);

	}
	
	@ApiOperation(value = "租房收藏")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "sdid", value = "租房源sdid,必填", dataType = "Long", paramType = "path", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true)})
	@PostMapping(value = "/add/{scity}/{sdid}")
	public RestResult<String> rentHouseCollection(@PathVariable("sdid")Long sdid,@PathVariable("scity")String scity) {
		
		rentHouseCollectionService.add(getCurrentMemberId(), sdid, scity);
		
		
		return RestResult.success("操作成功了");

	}
	
	@ApiOperation(value = "租房取消收藏")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "sdid", value = "租房源sdid,必填", dataType = "Long", paramType = "path", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true)})
	@PostMapping(value = "/cancel/{scity}/{sdid}")
	public RestResult<String> cancelRentHouseCollection(@PathVariable("sdid")Long sdid,@PathVariable("scity")String scity) {
		
		rentHouseCollectionService.cancelCollection(getCurrentMemberId(), sdid, scity);
		
		
		return RestResult.success("操作成功了");

	}
	

}
