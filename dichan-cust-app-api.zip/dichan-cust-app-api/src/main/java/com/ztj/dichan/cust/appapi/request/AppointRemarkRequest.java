/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "用户填写备注请求参数",description="用户填写备注请求参数")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointRemarkRequest extends BaseApiRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9080893070311285671L;

	@ApiModelProperty(value = "看房源记录id，必填",required=true)
	private Long id;
	
	@ApiModelProperty(value = "备注信息",required=false)
	private String memberRemark;
	
	@ApiModelProperty(value = "用户看房备注标签,多个使用英文逗号隔开")
	private String remarkTag;
}
