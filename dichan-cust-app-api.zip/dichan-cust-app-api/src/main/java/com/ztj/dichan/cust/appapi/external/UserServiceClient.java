package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import com.ztj.dichan.cust.rule.bean.SysLoginBean;

/**
 * @author sily
 *
 */
@FeignClient(name = "userServiceClient", url = "${cust.service.url}", fallback = UserServiceClient.class)
public interface UserServiceClient {

	
	@PostMapping(value = "/user/cityList")
	public List<SysLoginBean> cityList();
	
}