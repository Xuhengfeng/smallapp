package com.ztj.dichan.cust.appapi.rest;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.ShareRelationService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author sily
 */
@Api(value = "分享记录相关接口", description = "分享记录相关接口")
@RestController
@RequestMapping(value = "/share")
public class ShareRelationRest extends BaseCustRest {

	@Resource
	private ShareRelationService shareRelationService;

	@ApiOperation(value = "获取分享code")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "id", value = "会员id", dataType = "Long", paramType = "query"),
			@ApiImplicitParam(name = "url", value = "分享链接", dataType = "String", paramType = "query"),
			@ApiImplicitParam(name = "code", value = "分享code", dataType = "string", paramType = "query") })
	@PostMapping(value = "/fetchCode")
	public RestResult<String> add(Long id, String url, String code) {
		String code1 = shareRelationService.fetchShareCode(id, url, code);

		return RestResult.success(code1);

	}

	@ApiOperation(value = "增加阅读量")
	@ApiImplicitParams({ @ApiImplicitParam(name = "code", value = "分享code", dataType = "string", paramType = "query") })
	@PostMapping(value = "/add")
	public RestResult addReadNumber(String code) {
		shareRelationService.toAddReadNumber(code);

		return RestResult.success("加入成功");
	}
}