/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.request.ShopRequest;
import com.ztj.dichan.cust.rule.response.NearbyBrokerVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;
import com.ztj.dichan.cust.rule.response.shop.ShopVo;

/**
 * @author lbs
 *
 */
public class ShopServiceClientFallBack implements ShopServiceClient {

	@Override
	public List<ShopVo> queryShops(ShopRequest shopRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CountVo queryShopsCount(ShopRequest shopRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<NearbyBrokerVo> queryNearbyBroker(ShopRequest shopRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}


	

	
}
