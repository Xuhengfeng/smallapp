package com.ztj.dichan.cust.appapi.vo;

import java.util.ArrayList;
import java.util.List;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.appapi.vo.infocontent.InfoContentVo;
import com.ztj.dichan.cust.rule.response.building.HotBuildingVo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author test01
 */
@ApiModel(value = "首页一次性返回的数据")
@Data
@EqualsAndHashCode(callSuper = true)
public class HomeDataVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "首页热门资讯列表")
	private List<InfoContentVo> hotInfoContentVoList = new ArrayList<>();

	@ApiModelProperty(value = "房源成交量统计")
	private StatisticsInfoVo statisticsInfoVo = new StatisticsInfoVo();

	@ApiModelProperty(value = "热门小区列表")
	private List<HotBuildingVo> hotBuildingVolist  = new ArrayList<>();

	@ApiModelProperty(value = "首页新房推荐列表")
	private List<InfoContentVo> newInfoContentVoList  = new ArrayList<>();
}
