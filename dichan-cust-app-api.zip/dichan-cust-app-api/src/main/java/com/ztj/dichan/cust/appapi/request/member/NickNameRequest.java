/**
 * 
 */
package com.ztj.dichan.cust.appapi.request.member;


import com.ztj.dichan.cust.appapi.request.BaseApiRequest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author liuweichen
 *
 */
@ApiModel(value = "修改用户名")
@Data
@EqualsAndHashCode(callSuper = true)
public class NickNameRequest extends BaseApiRequest{
	private static final long serialVersionUID = 1L;
	
	
	@ApiModelProperty(value = "签名数据，必填")
	private String nickname;

}
