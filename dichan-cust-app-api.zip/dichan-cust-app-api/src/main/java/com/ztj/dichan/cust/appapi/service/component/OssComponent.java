package com.ztj.dichan.cust.appapi.service.component;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.model.OSSObject;
import com.ztj.common.util.Verify;

/**
 * 图片上传
 * 
 * @author HHF
 */
@Component
public class OssComponent extends BaseAppComponent	 {
	private OSSClient ossClient = null;
	
	@PostConstruct
	public void init() {
		ossClient = new OSSClient(systemConstant.getOssEndpoint(), systemConstant.getOssAccessKeyId(),
				systemConstant.getOssAccessKeySecret());
	}

	/**
	 * 获取图片的后缀名,即文件类型
	 * 
	 * @param base64Image
	 * @return
	 */
	public String fetchImageType(String base64Image) {
		int imageTypeBeginIndex = base64Image.indexOf("image/");
		int imageTypeEndIndex = base64Image.indexOf(";");

		return "." + base64Image.substring(imageTypeBeginIndex + 6, imageTypeEndIndex);
	}

	/**
	 * 
	 * @param key
	 * @param file
	 */
	public void uploadPicture(String key, MultipartFile file) {
		if (Verify.isPicture(getFileExt(file.getOriginalFilename()))) {
			throw new IllegalArgumentException("不正确的图片格式");
		}

		InputStream inputStream = null;

		try {
			inputStream = file.getInputStream();

			ossClient.putObject(systemConstant.getOssBucket(), key, inputStream);
		} catch (Exception e) {
			throw new RuntimeException("上传图片异常", e);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					logger.error("关闭文件流出错" + e.getMessage());
				}
			}
		}
	}

	/**
	 * 
	 * @param key
	 * @param base64Image
	 */
	public void uploadPicture(String key, String base64Image) {
		InputStream inputStream = null;

		try {
			int contentIndex = base64Image.indexOf("base64,");

			if (contentIndex == -1) {
				throw new IllegalStateException("图片格式不正确");
			}

			String imageContent = base64Image.substring(contentIndex + 7);

			if (contentIndex != -1) {
				imageContent = base64Image.substring(contentIndex + 7);
			} else {
				imageContent = base64Image;
			}

			byte[] datas = Base64.decodeBase64(imageContent);

			inputStream = new ByteArrayInputStream(datas);

			ossClient.putObject(systemConstant.getOssBucket(), key, inputStream);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					logger.error("关闭文件流出错" + e.getMessage());
				}
			}
		}
	}
	
	
	public void uploadPicture(String key,String base64Image,String catalog) {
		
		InputStream inputStream = null;

		try {
			int contentIndex = base64Image.indexOf("base64,");

			if (contentIndex == -1) {
				throw new IllegalStateException("图片格式不正确");
			}

			String imageContent = base64Image.substring(contentIndex + 7);

			if (contentIndex != -1) {
				imageContent = base64Image.substring(contentIndex + 7);
			} else {
				imageContent = base64Image;
			}

			byte[] datas = Base64.decodeBase64(imageContent);

			inputStream = new ByteArrayInputStream(datas);

			ossClient.putObject(systemConstant.getOssBucket(), catalog + key, inputStream);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					logger.error("关闭文件流出错" + e.getMessage());
				}
			}
		}
	}
	
	
	public String upload(String base64Image) {
		InputStream inputStream = null;
		try {

			int imageTypeBeginIndex = base64Image.indexOf("image/");
			int imageTypeEndIndex = base64Image.indexOf(";");

			String imageType = base64Image.substring(imageTypeBeginIndex + 6, imageTypeEndIndex);

			int contentIndex = base64Image.indexOf("base64,");

			String imageContent = base64Image.substring(contentIndex + 7);

			if (contentIndex != -1) {
				imageContent = base64Image.substring(contentIndex + 7);
			} else {
				imageContent = base64Image;
			}

			byte[] datas = Base64.decodeBase64(imageContent);

			inputStream = new ByteArrayInputStream(datas);

			return uploadPicture(inputStream, "jpg");
		} catch (Exception e) {
			throw new RuntimeException("上传图片异常", e);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					logger.error("上传文件到OSS时关闭文件流异常" + e.getMessage());
				}
			}
		}
	}
	
	
	/**
	 * 
	 * @param inputStream
	 *            文件流 接口不会关闭，调用方管理关闭
	 * @param extension
	 *            文件扩展名
	 * @return 文件访问链接 （如果是存储到私有区域的 访问有超时时间 为 5分钟，）
	 */
	private String uploadPicture(InputStream inputStream, String extension) {
		String key = generateKey(extension);

		ossClient.putObject(systemConstant.getOssBucket(), key, inputStream);

		return key;
	}
	
	/**
	 * 生成文件的key
	 * 
	 * @param extension
	 * @return
	 */
	private String generateKey(String extension) {
		return UUID.randomUUID().toString().replaceAll("-", "") + extension;
	}

	/**
	 * 
	 * @param key
	 * @param inputStream
	 */
	public void uploadPicture(String key, InputStream inputStream) {
		ossClient.putObject(systemConstant.getOssBucket(), key, inputStream);
	}

	/**
	 * 获得文件扩展名
	 * 
	 * @param fileName
	 *            文件名称
	 * @return
	 * @throws Exception
	 */
	private String getFileExt(String fileName) {
		// 获得文件扩展名
		String fileExt = null;
		if (fileName != null && fileName.lastIndexOf(".") != -1) {
			fileExt = fileName.substring(fileName.lastIndexOf(".") + 1);
		}
		return fileExt;
	}

	public BufferedInputStream downloadImage(String filePath) {
		OSSObject ossObject = ossClient.getObject(systemConstant.getOssBucket(), filePath);
		BufferedInputStream reader = new BufferedInputStream(ossObject.getObjectContent());
		return reader;
		
	}

	@PreDestroy
	public void destory() {
		ossClient.shutdown();
	}
}