/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.ztj.common.util.ShopUtil;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.request.BrokerRequest;
import com.ztj.dichan.cust.appapi.service.component.DownloadImageComponent;
import com.ztj.dichan.cust.appapi.service.component.OssComponent;
import com.ztj.dichan.cust.core.constant.OssConstant;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.repository.BrokerCollectionRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.BrokerHouseRequest;
import com.ztj.dichan.cust.rule.request.EmplClientRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * @author lbs
 *
 */
@Service
@Transactional
public class BrokerService extends BaseAppService {

	@Resource
	private BrokerServiceClient brokerServiceClient;

	@Resource
	private BrokerCollectionRepository brokerCollectionRepository;

	@Resource
	private DownloadImageComponent downloadImageComponent;

	public List<BrokerVo> queryBrokers(BrokerRequest brokerRequest) {
		EmplClientRequest emplClientRequest = new EmplClientRequest();
		emplClientRequest.setAreaId(brokerRequest.getAreaId());
		emplClientRequest.setDistrictId(brokerRequest.getDistrictId());
		List<Long> positiIds = new ArrayList<Long>();
		/*
		 * if (brokerRequest.getPositiId() == null || brokerRequest.getPositiId() <=0 )
		 * { positiIds.add(Long.valueOf(114));//区域经理
		 * positiIds.add(Long.valueOf(4));//置业顾问
		 * positiIds.add(Long.valueOf(16));//商业置业顾问
		 * positiIds.add(Long.valueOf(134));//高级置业顾问 } else {
		 * positiIds.add(brokerRequest.getPositiId()); }
		 */

		if (brokerRequest.getPositiId() != null && brokerRequest.getPositiId() > 0) {
			positiIds.add(brokerRequest.getPositiId());
		}

		emplClientRequest.setPositiIds(positiIds);
		emplClientRequest.setSortMode(brokerRequest.getSortMode());
		emplClientRequest.setScity(brokerRequest.getScity());
		emplClientRequest.setKeyword(brokerRequest.getKeyword());
		emplClientRequest.setPageNo(brokerRequest.getPageNo());
		emplClientRequest.setPageSize(brokerRequest.getPageSize());

		String scity = this.getScityNew(emplClientRequest);

		List<BrokerVo> brokerList = brokerServiceClient.queryBrokers(emplClientRequest, scity);
		if (brokerList == null) {
			return new ArrayList<>(0);
		}
		brokerList.forEach(brokerVo -> {
			brokerVo.setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), brokerVo.getPhoto(), scity,
					brokerVo.getId()) + OssConstant.CONSTRAINT_GUDING_150);
			/*
			 * if ("1".equals(brokerVo.getPhoto())) {
			 * brokerVo.setPhoto(systemConstant.getOssCdnUrl()+PhotoUtil.getCity(
			 * brokerRequest.getScity()) + "/Empl/PIC/" + brokerVo.getId() + "/"+
			 * brokerVo.getId() + ".jpg"); }
			 */
			// brokerVo.setDeptName(ShopUtil.updateName(brokerVo.getDeptName()));
		});
		return brokerList;
	}

	public CountVo queryBrokerCount(BrokerRequest brokerRequest) {
		EmplClientRequest emplClientRequest = new EmplClientRequest();
		emplClientRequest.setAreaId(brokerRequest.getAreaId());
		emplClientRequest.setDistrictId(brokerRequest.getDistrictId());
		List<Long> positiIds = new ArrayList<Long>();

		if (brokerRequest.getPositiId() != null && brokerRequest.getPositiId() > 0) {
			positiIds.add(brokerRequest.getPositiId());
		}

		emplClientRequest.setPositiIds(positiIds);
		emplClientRequest.setSortMode(brokerRequest.getSortMode());
		emplClientRequest.setScity(brokerRequest.getScity());
		emplClientRequest.setKeyword(brokerRequest.getKeyword());

		String scity = this.getScityNew(emplClientRequest);

		CountVo countVo = brokerServiceClient.queryBrokerCount(emplClientRequest, scity);
		return countVo;
	}

	public List<BrokerVo> queryHouseBrokers(BrokerHouseRequest request) {

		String scity = RequestContextHolder.getCityCode();

		List<BrokerVo> brokerList = brokerServiceClient.queryHouseBrokers(request, scity);
		if (brokerList == null) {
			return new ArrayList<>(0);
		}
		brokerList.forEach(brokerVo -> {
			brokerVo.setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), brokerVo.getPhoto(), scity,
					brokerVo.getId()));
			/*
			 * if ("1".equals(brokerVo.getPhoto())) {
			 * brokerVo.setPhoto(systemConstant.getOssCdnUrl() + scity + "/Empl/PIC/" +
			 * brokerVo.getId() + "/"+ brokerVo.getId() + ".jpg"); }
			 */
			// brokerVo.setDeptName(ShopUtil.updateName(brokerVo.getDeptName()));
		});
		return brokerList;
	}

	public BrokerDetailVo queryBroker(String scity, Integer id, Long memberId) {

		BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(scity, id);
		if (brokerDetailVo != null) {
			Long count = brokerCollectionRepository.countByBrokerIdAndBrokerScity(Long.valueOf(brokerDetailVo.getId()),
					scity);
			brokerDetailVo.setByCollectNum(count.intValue());// 被收藏数
			if (memberId != null && memberId > 0) {
				Long count2 = brokerCollectionRepository.countByMemberIdAndBrokerIdAndBrokerScity(memberId,
						Long.valueOf(brokerDetailVo.getId()), scity);
				brokerDetailVo.setIsCollect(count2 > 0 ? true : false);
			} else {
				brokerDetailVo.setIsCollect(false);
			}
			brokerDetailVo.setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), brokerDetailVo.getPhoto(),
					scity, brokerDetailVo.getId()));
			/*
			 * if ("1".equals(brokerDetailVo.getPhoto())) {
			 * brokerDetailVo.setPhoto(systemConstant.getOssCdnUrl() +
			 * brokerDetailVo.getScity() + "/Empl/PIC/" + brokerDetailVo.getId() + "/"+
			 * brokerDetailVo.getId() + ".jpg"); }
			 */

			// brokerDetailVo.setDeptName(ShopUtil.updateName(brokerDetailVo.getDeptName()));
		}

		return brokerDetailVo;
	}

	public List<RentHouseVo> queryBrokerRentHouseList(String scity, Integer empId, Integer pageNo, Integer pageSize) {
		List<RentHouseVo> rentHouseList = brokerServiceClient.queryBrokerRentHouseList(scity, empId, pageNo, pageSize);
		if (rentHouseList == null) {
			return new ArrayList<>(0);
		}
		rentHouseList.forEach(rentHouseVo -> {
			List<String> photoList = PhotoUtil.converPhoto(systemConstant.getOssCdnUrl(), rentHouseVo.getHousePic(),
					scity, String.valueOf(rentHouseVo.getId()));

			if (photoList != null && !photoList.isEmpty()) {
				rentHouseVo.setHousePic(photoList.get(0));
			} else {
				rentHouseVo.setHousePic(null);
			}

		});
		return rentHouseList;
	}

	public List<HouseVo> queryBrokerHouseList(String scity, Integer empId, Integer pageNo, Integer pageSize) {
		List<HouseVo> houseList = brokerServiceClient.queryBrokerHouseList(scity, empId, pageNo, pageSize);
		if (houseList == null) {
			return new ArrayList<>(0);
		}
		houseList.forEach(houseVo -> {
			List<String> photoList = PhotoUtil.converPhoto(systemConstant.getOssCdnUrl(), houseVo.getHousePic(), scity,
					String.valueOf(houseVo.getId()));

			if (photoList != null && !photoList.isEmpty()) {
				houseVo.setHousePic(photoList.get(0));
			} else {
				houseVo.setHousePic(null);
			}

		});
		return houseList;
	}

	/**
	 * 下载经纪人头像
	 * 
	 * @param username
	 * @param response
	 */
	public void downloadHeadImage(String username, HttpServletResponse response) {

		// long start = System.currentTimeMillis();

		if (StringUtils.isEmpty(username)) {
			downloadImageComponent.handleImage("default_head_image.png", response);
			return;
		}
		String[] strs = username.split("_");
		if (strs.length != 3) {
			downloadImageComponent.handleImage("default_head_image.png", response);
			return;
		}
		try {

			String city = PhotoUtil.getCity(strs[0]);
			StringBuffer filePath = new StringBuffer();
			filePath.append(city).append("/Empl/PIC/");
			filePath.append(strs[1]).append("/").append(strs[1]).append(".jpg");
			downloadImageComponent.handleImage(filePath.toString(), response);
		} catch (Exception e) {
			downloadImageComponent.handleImage("default_head_image.png", response);
		}
		// System.out.println((System.currentTimeMillis() - start) + " 毫秒！");
	}

}
