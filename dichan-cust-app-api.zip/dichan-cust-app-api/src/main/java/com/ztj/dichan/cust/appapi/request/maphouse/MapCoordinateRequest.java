/**
 * 
 */
package com.ztj.dichan.cust.appapi.request.maphouse;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author lbs
 *
 */
@Data
public class MapCoordinateRequest implements Serializable {


	private static final long serialVersionUID = 5883653913677872751L;

	@ApiModelProperty(value = "城市编码,必填", required = true)
	protected String scity;
	
	@ApiModelProperty(value = "右上角X坐标",required=true)
	private Double x1;
	
	@ApiModelProperty(value = "左下角X坐标",required=true)
	private Double x2;
	
	@ApiModelProperty(value = "右上角角Y坐标",required=true)
	private Double y1;
	
	@ApiModelProperty(value = "左下角Y坐标",required=true)
	private Double y2;
	
	
	@ApiModelProperty(value = "查询等级(15以下=城区,15-17=片区,17以上=小区)",required=true)
	private Integer level;

}
