package com.ztj.dichan.cust.appapi.vo.house;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author lbs
 * 房源清单数量Vo
 *
 */
@ApiModel(value = "清单列表房源数量")
@Data
@EqualsAndHashCode(callSuper = true)
public class HouseDetailCountVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "对比清单列表房源数量")
	private Integer contrastCount;
	
	@ApiModelProperty(value = "约看清单列表房源数量")
	private Integer appointCount;
	
	
}
