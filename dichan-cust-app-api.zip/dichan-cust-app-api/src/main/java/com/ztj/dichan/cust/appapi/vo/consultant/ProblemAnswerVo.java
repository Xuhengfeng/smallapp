package com.ztj.dichan.cust.appapi.vo.consultant;

import com.ztj.dichan.cust.appapi.vo.BaseApiValueObject;
import com.ztj.dichan.cust.core.enums.WhetherAdoptEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author yincp
 *
 */
@ApiModel(value = "返回问题回答信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class ProblemAnswerVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "问题Id")
	private Long contProblemId;

	@ApiModelProperty(value = "顾问Id")
	private Long consultantId;

	@ApiModelProperty(value = "是否采纳")
	private WhetherAdoptEnum whetherAdopt;

	@ApiModelProperty(value = "回答时间")
	private String answerTime;

	
	@ApiModelProperty(value = "回答内容")
	private String answerContent;
	
	@ApiModelProperty(value = "顾问姓名")
	private String consultantName;
	
	@ApiModelProperty(value = "顾问头像")
	private String photo ;
	
	@ApiModelProperty(value = "顾问电话")
	private String phone ;
	
	@ApiModelProperty(value = "状态,0=用户未登陆，1=用户已登陆，2=用户已登陆并且是问题发起人")
	private String status;


}