/**
 * 
 */
package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.ShopService;
import com.ztj.dichan.cust.rule.request.ShopRequest;
import com.ztj.dichan.cust.rule.response.shop.CountVo;
import com.ztj.dichan.cust.rule.response.shop.ShopVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @author lbs
 *
 */
@Api(value = "门店信息",description="门店信息相关接口")
@RestController
@RequestMapping(value = "/shop")
public class ShopRest {

	@Resource
	private ShopService shopService;
	
	@ApiOperation(value="门店信息列表",response=ShopVo.class)
	@PostMapping(value = "/shops")
	public RestResult<List<ShopVo>> queryShops(@RequestBody ShopRequest shopRequest) {
		
		return RestResult.success(shopService.queryShops(shopRequest));
	
	}
	
	@ApiOperation(value="门店信息列表-总数量",response=CountVo.class)
	@PostMapping(value = "/shopsCount")
	public RestResult<CountVo> queryShopsCount(@RequestBody ShopRequest shopRequest) {
		
		return RestResult.success(shopService.queryShopsCount(shopRequest));
	
	}
	
	
}
