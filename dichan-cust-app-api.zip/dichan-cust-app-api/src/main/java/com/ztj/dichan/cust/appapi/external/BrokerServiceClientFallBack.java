/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.request.BrokerHouseRequest;
import com.ztj.dichan.cust.rule.request.EmplClientRequest;
import com.ztj.dichan.cust.rule.response.EmployeeDetailVo;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * @author lbs
 *
 */
public class BrokerServiceClientFallBack implements BrokerServiceClient {

	@Override
	public List<BrokerVo> queryBrokers(EmplClientRequest emplClientRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BrokerDetailVo queryBroker(String scity, Integer empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HouseVo> queryBrokerHouseList(String scity, Integer empId, Integer pageNo, Integer pageSize) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentHouseVo> queryBrokerRentHouseList(String scity, Integer empId, Integer pageNo, Integer pageSize) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CountVo queryBrokerCount(EmplClientRequest emplClientRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BrokerVo> queryHouseBrokers(BrokerHouseRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BrokerDetailVo queryBroker2(String scity, Integer empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeDetailVo getDetailInfo(String scity, Integer empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateEmployeeGrade(String scity, Integer empId, Double grade) {
		// TODO Auto-generated method stub
		
	}


	

}
