/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.vo.PlateVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.PlateManagers;
import com.ztj.dichan.cust.core.enums.PlateStatusEnum;
import com.ztj.dichan.cust.core.enums.PlateTypeEnum;
import com.ztj.dichan.cust.core.repository.PlateManagersRepository;

/**
 * @author lbs
 *
 */
@Service
public class PlateSerice extends BaseAppService {

	@Resource
	private PlateManagersRepository plateManagersRepository;
	
	public List<PlateVo> queryList(PlateTypeEnum type) {
		
		String scity = RequestContextHolder.getCityCode();
		
		List<PlateManagers> dataList = plateManagersRepository.findByTypeAndStatusAndCityCode(type, PlateStatusEnum.NORMAL,scity);
		if (dataList == null || dataList.isEmpty()) {
			 String defaultCity = "default";//如果地市没配置有则获取默认的配置
			 dataList = plateManagersRepository.findByTypeAndStatusAndCityCode(type, PlateStatusEnum.NORMAL,defaultCity);
		}
		return dataList.stream().map(plate->{
			PlateVo plateVo = new PlateVo();
			plateVo.setId(plate.getId());
			plateVo.setImageUrl(plate.getImageUrl());
			plateVo.setPhoneContUrl(plate.getPhoneContUrl());
			plateVo.setComputerContUrl(plate.getComputerContUrl());
			plateVo.setSubhead(plate.getSubhead());
			plateVo.setTitle(plate.getTitle());
			return plateVo;
		}).collect(Collectors.toList());
	}
	
	
}
