package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.ztj.dichan.cust.rule.request.buildnew.BuildRecmdRequest;
import com.ztj.dichan.cust.rule.request.buildnew.BuildRequest;
import com.ztj.dichan.cust.rule.request.buildnew.BuildingDyFhRequest;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.building.BuildingDzdyDetailVo;
import com.ztj.dichan.cust.rule.response.building.BuildingVo;
import com.ztj.dichan.cust.rule.response.building.DzDetailVo;
import com.ztj.dichan.cust.rule.response.building.HotBuildingVo;
import com.ztj.dichan.cust.rule.response.building.RentHouseVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * 
 * @author yincp
 */
@FeignClient(name = "bulidingServiceClient", url = "${cust.service.url}", fallback = HouseServiceClientFallBack.class)
public interface BuildingServiceClient {

	@PostMapping(value = "/build/buildList")
	public List<BuildingVo> buildList(@RequestBody BuildRequest buildRequest,
			@RequestHeader(value = "scity", required = true) String scity);

	@PostMapping(value = "/build/buildListCount")
	public CountVo buildListCount(@RequestBody BuildRequest buildRequest,
			@RequestHeader(value = "scity", required = true) String scity);

	@GetMapping(value = "/build/buildInfo")
	public BuildingDetailVo buildInfo(@RequestParam(name = "sdid", required = false) Long sdid,
			@RequestHeader(value = "scity", required = true) String scity);

	@GetMapping(value = "/build/secondHouseList")
	public List<SecondHouseVo> secondHouseList(@RequestHeader(value = "scity", required = true) String scity,
			@RequestParam(name = "sdid", required = false) Long sdid,
			@RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize);

	@GetMapping(value = "/build/rentHouseList")
	public List<RentHouseVo> rentHouseList(@RequestHeader(value = "scity", required = true) String scity,
			@RequestParam(name = "sdid", required = false) Long sdid,
			@RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize);

	@PostMapping(value = "/build/hotBuilding")
	public List<HotBuildingVo> hotBuilding(@RequestBody BuildRecmdRequest buildRecmdRequest,
			@RequestHeader(value = "scity", required = true) String scity);

	@GetMapping(value = "/build/building/dzdy/{sdid}")
	public BuildingDzdyDetailVo queryBuildingDzdyDetail(@PathVariable("sdid") Long sdid,
			@RequestHeader(value = "scity", required = true) String scity);

	@GetMapping(value = "/build/building/dz/{id}")
	public List<DzDetailVo> queryBuildingDz(@PathVariable("id") Integer id,
			@RequestHeader(value = "scity", required = true) String scity);

	@PostMapping(value = "/build/building/dyfh")
	public List<String> queryBuildingDyfh(@RequestBody BuildingDyFhRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
}