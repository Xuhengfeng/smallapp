package com.ztj.dichan.cust.appapi.jiguang;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 极光配置信息
 * @author lbs
 *
 */
@Component
public class JiguangConfig {

	@Value("${jiguang.appkey}")
	private String appkey;
	
	@Value("${jiguang.secret}")
	private String secret;
	
	@Value("${jiguang.brokerAppKey}")
	private String brokerAppKey;
	
	@Value("${jiguang.brokerSecret}")
	private String brokerSecret;

	public String getAppkey() {
		return appkey;
	}

	public String getSecret() {
		return secret;
	}

	public String getBrokerAppKey() {
		return brokerAppKey;
	}

	public String getBrokerSecret() {
		return brokerSecret;
	}
	
	
	
}
