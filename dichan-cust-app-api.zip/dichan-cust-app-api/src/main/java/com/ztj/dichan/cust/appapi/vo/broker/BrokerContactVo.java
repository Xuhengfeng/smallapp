/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.broker;


import com.ztj.dichan.cust.appapi.vo.BaseApiValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author yincp
 *
 */
@ApiModel(value = "我的-经纪人信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class BrokerContactVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 经纪人ID
	 */
	@ApiModelProperty(value = "经纪人ID")
	private Integer id; 

	/**
	 * 姓名
	 */
	@ApiModelProperty(value = "经纪人姓名")
	private String emplName;
	
	/**
	 * 经纪人账号
	 */
	@ApiModelProperty(value = "经纪人账号")
	private String emplAccNo;
	
	@ApiModelProperty(value = "性别")
	private String sex;
	
	/**
	 * 岗位名称
	 */
	@ApiModelProperty(value = "岗位名称")
	private String positionName;
	
	/**
	 * 门店
	 */
	@ApiModelProperty(value = "所在门店")
	private String deptName;
	
	/**
	 * 经纪人标签
	 */
	@ApiModelProperty(value = "经纪人标签")
	private String emplFlag;
	
	@ApiModelProperty(value = "评分")
	private Double grade;
	
	@ApiModelProperty(value = "照片")
	private String photo;
	
	private String emplStatus;
	
	@ApiModelProperty(value = "经纪人状态，0=正常，1=已离职")
	private Integer status;
	
	@ApiModelProperty(value = "经纪人聊天账号")
	private String chatUsername;
	
	public String getChatUsername() {
		return this.getScity() + "_" + this.getId() + "_" + this.getEmplAccNo();
	}
	
}
