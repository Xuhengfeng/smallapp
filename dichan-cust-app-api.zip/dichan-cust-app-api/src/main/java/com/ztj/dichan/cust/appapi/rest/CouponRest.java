package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.dichan.cust.appapi.service.CouponService;
import com.ztj.dichan.cust.appapi.vo.activity.CouponDetailVo;
import com.ztj.dichan.cust.appapi.vo.activity.CouponGiveVo;
import com.ztj.dichan.cust.appapi.vo.activity.CouponVo;
import com.ztj.dichan.cust.core.constant.RestResult;
import com.ztj.dichan.cust.core.enums.CouponStatusEnum;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author sily
 */
@Api(value = "优惠券相关接口", description = "优惠券相关接口")
@RestController
@RequestMapping(value = "/coupon")
public class CouponRest extends BaseCustRest {

	@Resource
	private CouponService couponService;

	@ApiOperation(value = "检查卡券的状态")
	@ApiImplicitParams(value = {
			
			@ApiImplicitParam(name = "couponCode", value = "优惠券编码", dataType = "String", paramType = "query", required = true) })
	@RequestMapping(value = "/checkStatus", method = { RequestMethod.POST })
	public RestResult checkCouponStatus(String couponCode) {
		Boolean vo = couponService.checkCouponStatus(couponCode);

		return RestResult.success(vo);
	}

	/**
	 * 
	 * @param houseCode
	 * @return
	 */
	@ApiOperation(value = "查看已兑换的卡券详细信息", response = CouponDetailVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "couponCode", value = "优惠券编码", dataType = "String", paramType = "query", required = true) })
	@RequestMapping(value = "/getCouponDetail", method = { RequestMethod.POST })
	public RestResult getCouponDetail(String couponCode) {
		CouponDetailVo vo = couponService.getDetailInfo(getCurrentMemberId(), couponCode);

		return RestResult.success(vo);
	}

	@ApiOperation(value = "查看我增送的卡券详细信息", response = CouponDetailVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "couponFollowId", value = "卡券记录id", dataType = "Long", paramType = "query", required = true) })
	@RequestMapping(value = "/getGiveCouponDetail", method = { RequestMethod.POST })
	public RestResult getCouponDetail(Long couponFollowId) {
		CouponDetailVo vo = couponService.getGiveDetailInfo(couponFollowId);

		return RestResult.success(vo);
	}

	@ApiOperation(value = "根据状态查看卡券列表", response = CouponVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "status", value = "优惠券状态{NO_USED:未使用,ALREADY_USED:已使用,ALREADY_OVERDUE:已过期}", dataType = "String", paramType = "query", required = true),
			@ApiImplicitParam(name = "pageNo", value = "需要显示的页数", dataType = "int", paramType = "query", required = true, example = "1"),
			@ApiImplicitParam(name = "pageSize", value = "每页显示的条数", dataType = "int", paramType = "query", example = "10") })
	@RequestMapping(value = "/queryList", method = { RequestMethod.POST })
	public RestResult queryList(CouponStatusEnum status, Integer pageNo, Integer pageSize) {
		List<CouponVo> voList = couponService.queryList(getCurrentMemberId(), status, pageNo, pageSize);

		return new RestResult(voList);
	}

	@ApiOperation(value = "查看我赠送的卡券列表", response = CouponGiveVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "需要显示的页数", dataType = "int", paramType = "query", required = true, example = "1"),
			@ApiImplicitParam(name = "pageSize", value = "每页显示的条数", dataType = "int", paramType = "query", example = "10") })
	@RequestMapping(value = "/queryGiveList", method = { RequestMethod.POST })
	public RestResult queryGiveList(Integer pageNo, Integer pageSize) {
		List<CouponGiveVo> voList = couponService.queryGiveList(getCurrentMemberId(), pageNo, pageSize);

		return new RestResult(voList);
	}

	@ApiOperation(value = "赠送卡券")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "couponCode", value = "优惠券code", dataType = "String", paramType = "query", required = true),
			@ApiImplicitParam(name = "smsCode", value = "手机验证码", dataType = "String", paramType = "query", required = true),
			@ApiImplicitParam(name = "giveMobile", value = "赠送人(得到卡券的人)手机号", dataType = "String", paramType = "query", required = true) })
	@RequestMapping(value = "/give", method = { RequestMethod.POST })
	public RestResult giveCoupon(String couponCode, String smsCode, String giveMobile) {
		RestResult result = new RestResult();

		couponService.giveCoupon(getCurrentMemberId(), couponCode, smsCode, giveMobile);

		return result;
	}

	@ApiOperation(value = "使用卡券")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市code", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "contractNo", value = "合同编号", dataType = "String", paramType = "query", required = true),
			@ApiImplicitParam(name = "couponCode", value = "优惠券code", dataType = "String", paramType = "query", required = true) })
	@RequestMapping(value = "/used", method = { RequestMethod.POST })
	public RestResult giveCoupon(String contractNo, String couponCode) {
		RestResult result = new RestResult();

		couponService.useCoupon(getCurrentMemberIdAllowNull(),contractNo, couponCode);
		return result;
	}

//	@ApiOperation(value = "插数据")
//	@RequestMapping(value = "/add", method = { RequestMethod.POST })
//	public RestResult add(Long templateId) {
//
//		RestResult result = new RestResult();
//
//		couponService.add(templateId);
//
//		return result;
//	}

//	@ApiOperation(value = "补用户钱包的数据")
//	@RequestMapping(value = "/addWallet", method = { RequestMethod.POST })
//	public RestResult addWallet() {
//		RestResult result = new RestResult();
//		try {
//			List<Member> list = memberService.queyList();
//
//			for (Member member : list) {
//				executor.submit(new Runnable() {
//					public void run() {
//						try {
//							couponService.addWallet(member);
//						} catch (Exception e) {
//							logger.error("补用户钱包的数据出错了", e);
//						}
//
//					}
//				});
//			}
//		} catch (Exception e) {
//			result.setStatus("500");
//			result.setMsg(e.getMessage());
//		}
//		return result;
//	}

}
