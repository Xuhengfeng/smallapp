package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.response.CityFilePathVo;

public class CityFilePathServiceClientFallBack implements CityFilePathServiceClient {

	@Override
	public List<CityFilePathVo> getCityFilePath() {
		// TODO Auto-generated method stub
		return null;
	}

}
