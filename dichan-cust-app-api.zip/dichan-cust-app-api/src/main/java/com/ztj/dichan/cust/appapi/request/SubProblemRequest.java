/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;

import java.math.BigDecimal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "提问/向他咨询请求参数")
@Data
@EqualsAndHashCode(callSuper = true)
public class SubProblemRequest extends BaseApiRequest {

	private static final long serialVersionUID = 3798151708396141025L;

	@ApiModelProperty(value = "问题标题",required=true)
	private String problemTitle;
	
	@ApiModelProperty(value = "问题描述",required=true)
	private String problemDescribe;

	@ApiModelProperty(value = "标签",required=true)
	private String label;
	
	@ApiModelProperty(value = "顾问Id(向他咨询时候必填)",required=false)
	private Long employeeId;
	
	
	@ApiModelProperty(hidden = true)
	private Long memberId;
	
	@ApiModelProperty(value = "会员name",required=true)
	private String memberName;
	
}
