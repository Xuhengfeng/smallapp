package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.request.contrast.ContrastRequest;
import com.ztj.dichan.cust.appapi.service.ContrastService;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.rule.response.house.HouseContrastDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseRecmdVo;
import com.ztj.dichan.cust.rule.response.house.RentHouseContrastDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseRecmdVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author yincp
 *
 */
@Api(value = "对比接口",description="房源对比相关接口")
@RestController
@RequestMapping(value = "/contrast")
public class ContrastRest extends BaseCustRest {

	@Resource
	private ContrastService contrastService;
	
	
	@ApiOperation(value = "加入对比列表")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true)})
	@PutMapping(value = "/joid")
	public RestResult joinContrast(@RequestBody ContrastRequest request) {
		request.setMemberId(getCurrentMemberId());
		contrastService.joinContrast(request);
		return RestResult.success("加入成功");

	}
	
	
	@ApiOperation(value = "取消对比")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "houseSdid", value = "房源sdid", dataType = "Long", paramType = "query", required = true)})
	@DeleteMapping(value = "/cancel")
	public RestResult cancelContrast(@RequestParam(name = "houseSdid", required = true) String houseSdid) {
		Long memberId = getCurrentMemberId();
		contrastService.cancelContrast(Long.parseLong(houseSdid),memberId);
		return RestResult.success("取消成功");

	}
	
	
	@ApiOperation(value = "二手房对比列表")
	@GetMapping(value = "/usedList")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true)})
	public RestResult<List<HouseRecmdVo>> usedContrastList() {
	    String cityCode = RequestContextHolder.getCityCode();
	    Long memberId =getCurrentMemberId();
		List<HouseRecmdVo> contrasList = contrastService.usedContrastList(cityCode, memberId);
		return RestResult.success(contrasList);

	}
	
	
	@ApiOperation(value = "租房对比列表")
	@GetMapping(value = "/rentList")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true)})
	public RestResult<List<RentHouseRecmdVo>> rentContrastList() {
	    String cityCode = RequestContextHolder.getCityCode();
	    Long memberId = getCurrentMemberId();
		List<RentHouseRecmdVo> contrasList = contrastService.rentContrastList(cityCode, memberId);
		return RestResult.success(contrasList);

	}
	
	
	
	@ApiOperation(value = "二手房对比")
	@GetMapping(value = "used-house")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "sdidStr", value = "房源sdid串,多个用-隔开", dataType = "String", paramType = "query", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "query", required = true)})
	public RestResult<List<HouseContrastDetailVo>> usedHouseContrast(@RequestParam(name = "scity", required = true) String scity,
			@RequestParam(name = "sdidStr", required = true) String sdidStr) {
		List<HouseContrastDetailVo> contrasList = contrastService.usedHouseContrast(scity,sdidStr);
		return RestResult.success(contrasList);

	}
	

	@ApiOperation(value = "租房对比")
	@GetMapping(value = "rent-house")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "sdidStr", value = "房源sdid串,多个用-隔开", dataType = "String", paramType = "query", required = true)})
	public RestResult<List<RentHouseContrastDetailVo>> rentHouseContrast(@RequestParam(name = "sdidStr", required = true) String sdidStr) {
		List<RentHouseContrastDetailVo> contrasList = contrastService.rentHouseContrast(sdidStr);
		return RestResult.success(contrasList);

	}


}
