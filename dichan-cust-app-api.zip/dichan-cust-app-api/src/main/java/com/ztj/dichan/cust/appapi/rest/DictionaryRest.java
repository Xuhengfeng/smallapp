/**
 * 
 */
package com.ztj.dichan.cust.appapi.rest;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.DictionaryService;
import com.ztj.dichan.cust.appapi.vo.DefaultCityVo;
import com.ztj.dichan.cust.appapi.vo.DictionaryVo;
import com.ztj.dichan.cust.core.enums.DicType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @author lbs
 *
 */
@Api(value = "数据字典",description="数据字典相关接口")
@RestController
@RequestMapping(value = "/dictionary")
public class DictionaryRest extends BaseCustRest {

	
	@Resource
	private DictionaryService dictionaryService;
	
	
	@ApiOperation(value="查询获取数据字典-单个",response=DictionaryVo.class)
	@ApiImplicitParams({
        @ApiImplicitParam(name = "dicType", value = "数据字典类型：\r\n"
        		+ "HOUSE_HUXING=房源户型;\r\n" + 
        		"SELL_PRICE=房源总售价(根据城市获取);\r\n" + 
        		"SELL_UNIT_PRICE=房源出售单价(根据城市获取);\r\n" + 
        		"HOUSE_RENTAL=房源租金(根据城市获取);\r\n" + 
        		"HOUSE_USE=房源用途;\r\n" + 
        		"HOUSE_AREA=房源面积;\r\n" + 
        		"HOUSE_TYPE=房源类型;\r\n" + 
        		"HOUSE_DECORATION=装修;\r\n" + 
        		"HOUSE_DIRECTION=朝向;\r\n" + 
        		"HOUSE_FEATURE=特色;\r\n" + 
        		"HOUSE_AGE=楼龄;\r\n" + 
        		"BROKER_DUTY=经纪人职务;\r\n" +
        		"USER_REMARK_TAG=用户看房备注标签;\r\n" +
        		"AGENT_BIZ_TYPE=代办业务类型;\r\n" +
        		"QUESTION_TAG=提问标签;\r\n" +
        		"APP_H5_URL=所有h5链接地址;\r\n" +
        		"BROKER_EVALUATE_TAG=经纪人评价标签", required = true, dataType = "String",paramType="path")})
	@GetMapping(value = "/{dicType}")
	public RestResult<List<DictionaryVo>> queryDictionary(@PathVariable("dicType")DicType dicType) {
		
		return RestResult.success(dictionaryService.queryDictionaryList(dicType));
	
	}
	
	@ApiOperation(value="查询获取数据字典-支持多个",response=DictionaryVo.class)
	@ApiImplicitParams({
        @ApiImplicitParam(name = "dicTypes", value = "数据字典类型数组,JSON格式:[\"HOUSE_HUXING\",\"HOUSE_USE\"]", 
        		required = true)})
	@PostMapping(value = "/dictionarys")
	public RestResult<Map<String,List<DictionaryVo>>> queryDictionarys(@RequestBody DicType[] dicTypes) {
		
		return RestResult.success(dictionaryService.queryDictionaryList(dicTypes));
	
	}
	
	
	@ApiOperation(value="查询获取数据字典-单个-过滤城市编码",response=DictionaryVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "dicType", value = "数据字典类型", required = true, dataType = "String", paramType="path"),
		@ApiImplicitParam(name = "scity", value = "城市编码", required = true, dataType = "String", paramType="path")})
	@GetMapping(value = "/{dicType}/{scity}")
	public RestResult<List<DictionaryVo>> queryDictionaryCity(@PathVariable("dicType")DicType dicType,@PathVariable("scity")String scity) {
		
		return RestResult.success(dictionaryService.queryDictionaryCityList(dicType,scity));
	}
	
	@ApiOperation(value="获取城市列表",response=DictionaryVo.class)
	@GetMapping(value = "/citys")
	public RestResult<List<DictionaryVo>> queryCitys() {
		
		return RestResult.success(dictionaryService.queryCityList());
	
	}
	
	@ApiOperation(value="获取默认城市",response=DefaultCityVo.class)
	@GetMapping(value = "/defaultCity")
	public RestResult<DefaultCityVo> getDefaultCity() {
		
		return RestResult.success(dictionaryService.getDefaultCity());
	
	}
	
	@ApiOperation(value="获取服务器当前时间戳（秒），如：1521704924636",notes="JSON格式 'data':{'currentDateTime':1521704924636}")
	@GetMapping(value = "/currentDateTime")
	public RestResult<Map<String,Long>> getCurrentDateTime() {
		Long currentDateTime =  LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();
		Map<String,Long> result = new HashMap<String,Long>();
		result.put("currentDateTime", currentDateTime);
		return RestResult.success(result);
	}
	
	@ApiOperation(value="刷新缓存")
	@GetMapping(value = "/refreshCache")
	public RestResult<String> refreshCityCache(@RequestParam(name="key")String key) {
		if ("liu123".equals(key)) {
			dictionaryService.initCityNameMap();
			dictionaryService.initDicMap();
			return RestResult.success("缓存已刷新!");
		} else {
			return RestResult.success("禁止操作!");
		}
	}
	
}
