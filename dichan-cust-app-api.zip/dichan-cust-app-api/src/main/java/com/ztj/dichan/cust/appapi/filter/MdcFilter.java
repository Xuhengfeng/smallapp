package com.ztj.dichan.cust.appapi.filter;

import java.io.IOException;
import java.util.Map;
import java.util.UUID;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.ztj.dichan.cust.core.constant.ParameterConstant;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.util.RequestUtil;

/**
 * 
 * @author test01
 */
@WebFilter(asyncSupported = true, filterName = "mdc", urlPatterns = "/*")
public class MdcFilter implements Filter {
	private static Logger logger = LoggerFactory.getLogger(MdcFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		logger.info("mdcFilter init success");
	}

	/**
	 * @param request
	 * @param response
	 * @param chain
	 * @throws IOException
	 * @throws ServletException
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		try {
			//获取请求uuid
			HttpServletRequest httpRequest = (HttpServletRequest) request;
			

			String requestUuid = httpRequest.getHeader("x-request-uuid");

			if (StringUtils.isEmpty(requestUuid)) {
				requestUuid = request.getParameter("request_uuid");
			}

			if (StringUtils.isEmpty(requestUuid)) {
				requestUuid = UUID.randomUUID().toString();
			}

			MDC.put("request_uuid", requestUuid);

			initRequestData(request, requestUuid);

			chain.doFilter(request, response);
		} finally {
			MDC.remove("request_uuid");
			MDC.remove("request_member_id");
			MDC.remove("request_city_code");

			RequestContextHolder.clear();
		}
	}

	@Override
	public void destroy() {
		logger.info("mdcFilter destroy success");
	}

	/**
	 * 
	 * @param request
	 * @param requestUuid
	 */
	private void initRequestData(ServletRequest request, String requestUuid) {
		RequestContextHolder.init();
		
		Map<String, Object> map = RequestContextHolder.get();

		if (map != null) {
			HttpServletRequest httpRequest = (HttpServletRequest) request;

			map.put(ParameterConstant.REQUEST_UUID, requestUuid);
			map.put(ParameterConstant.DEVICE_CODE, RequestUtil.getDeviceCode(httpRequest));
			map.put(ParameterConstant.TERMINAL_SOURCE, RequestUtil.getTerminalSource(httpRequest));
			map.put(ParameterConstant.NETWORK_TYPE, RequestUtil.getNetworkType(httpRequest));
			map.put(ParameterConstant.CLIENT_VERSION, RequestUtil.getClientVersion(httpRequest));
			map.put(ParameterConstant.CLIENT_IP, RequestUtil.getClientIp(httpRequest));
			map.put(ParameterConstant.CITY_CODE, RequestUtil.getCityCode(httpRequest));
		}
	}
}
