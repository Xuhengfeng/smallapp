package com.ztj.dichan.cust.appapi.service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.ztj.dichan.cust.appapi.util.HttpUtil;
import com.ztj.dichan.cust.core.constant.RedisConstant;

/**
 * 第三方登录
 * 
 * @author sily
 *
 */
@Service
public class ThirdLoginService extends BaseAppService {
	/**
	 * 用户向自己的服务器请求登录,登录方式为微信登录,附带上次登录返回的的access_token
	 * <p>
	 * 服务器收到用户的登录请求,向微信开放平台发送access_token是否有效
	 * <p>
	 * 正确的Json返回结果： { "errcode":0,"errmsg":"ok" }
	 * <p>
	 * 错误的Json返回示例: { "errcode":40003,"errmsg":"invalid openid" }
	 *
	 * @param openid
	 *            客户端收到的授权码
	 * @param accessToken
	 * @return
	 */
	public void validateWechatAccessToken(String openid, String accessToken) {
		String url = "https://api.weixin.qq.com/sns/auth";

		Map<String, String> paramMap = new HashMap<>();
		paramMap.put("openid", openid);
		paramMap.put("access_token", accessToken);

		String result = HttpUtil.doGet(url, paramMap);

		logger.info("返回的result=" + result);

		JSONObject object = JSONObject.parseObject(result);

		Integer errcode = object.getInteger("errcode");

		if (errcode != 0) {
			logger.warn("不正确的接口返回状态,result=" + result);

			throw new IllegalStateException("微信登录已经失效,请重新登录");
		}
	}
	
	public JSONObject checkWeixinSessionKey(String code) {
		
		try {
			if (StringUtils.isEmpty(systemConstant.getWeixinJscode2sessionUrl())) {
				logger.error("Weixin Jscode2session Url未配置");
				return null;
			}
			if (StringUtils.isEmpty(systemConstant.getWeixinAppid())) {
				logger.error("Weixin Appid 未配置");
				return null;
			}
			if (StringUtils.isEmpty(systemConstant.getWeixinSecret())) {
				logger.error("Weixin Secret 未配置");
				return null;
			}
			String url = systemConstant.getWeixinJscode2sessionUrl();
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("appid", systemConstant.getWeixinAppid());
			paramMap.put("secret", systemConstant.getWeixinSecret());//3258f8a5649ecdbfb3f1e3c43f5b2907
			paramMap.put("js_code", code);
			paramMap.put("grant_type", "authorization_code");

			String result = HttpUtil.doGet(url, paramMap);

			logger.info("返回的result=" + result);

			JSONObject object = JSONObject.parseObject(result);
			
			String openid = object.getString("openid");
			String sessionKey = object.getString("session_key");

			if (StringUtils.isEmpty(openid) 
					|| StringUtils.isEmpty(sessionKey)) {
				logger.warn("不正确的接口返回状态,result=" + result);
				return null;
			}
			return object;
		} catch (Exception e) {
			throw new IllegalStateException("微信code凭证校验失败！",e);
		}
		
		
	}
	
	public JSONObject checkWeixinAccessToken(String code) {
		
		try {
			if (StringUtils.isEmpty(systemConstant.getWeixinAccesstokenUrl())) {
				logger.error("Weixin gzh Accesstoken Url未配置");
				return null;
			}
			if (StringUtils.isEmpty(systemConstant.getWeixinGzhAppid())) {
				logger.error("Weixin gzh Appid 未配置");
				return null;
			}
			if (StringUtils.isEmpty(systemConstant.getWeixinGzhSecret())) {
				logger.error("Weixin gzh Secret 未配置");
				return null;
			}
			String url = systemConstant.getWeixinAccesstokenUrl();
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("appid", systemConstant.getWeixinGzhAppid());
			paramMap.put("secret", systemConstant.getWeixinGzhSecret());//3258f8a5649ecdbfb3f1e3c43f5b2907
			paramMap.put("code", code);
			paramMap.put("grant_type", "authorization_code");
			
			/*logger.info("appid=" + systemConstant.getWeixinGzhAppid());
			logger.info("secret=" + systemConstant.getWeixinGzhSecret());
			logger.info("code=" + code);
			logger.info("url=" + url);*/
			String result = HttpUtil.doGet(url, paramMap);

			logger.info("gzh获取AccessToken返回的result=" + result);

			JSONObject object = JSONObject.parseObject(result);

			String openid = object.getString("openid");
			String accesToken = object.getString("access_token");

			if (StringUtils.isEmpty(openid) 
					|| StringUtils.isEmpty(accesToken)) {
				logger.warn("gzh不正确的接口返回状态,code=" + code +",result=" + result);
				return null;
			}
			return object;
		} catch (Exception e) {
			throw new IllegalStateException("gzh微信code凭证校验失败！",e);
		}
		
		
	}
	
	public JSONObject getWeixinUserInfo(String accessToken,String openid) {
		
		if (StringUtils.isEmpty(systemConstant.getWeixinUserinfoUrl())) {
			logger.error("Weixin gzh Userinfo Url未配置");
			return null;
		}
		if (StringUtils.isEmpty(accessToken)) {
			logger.error("Weixin gzh accessToken 为空");
			return null;
		}
		if (StringUtils.isEmpty(openid)) {
			logger.error("Weixin gzh openid 为空");
			return null;
		}
		try {
			
			String url = systemConstant.getWeixinUserinfoUrl();
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("openid", openid);
			paramMap.put("access_token", accessToken);
			paramMap.put("lang", "zh_CN");
			
			String result = HttpUtil.doGet(url, paramMap);
			logger.info("gzh获取AccessToken返回的result=" + result);

			JSONObject object = JSONObject.parseObject(result);

			//String nickname = object.getString("nickname");
			//String accesToken = object.getString("sex");

			if (StringUtils.isEmpty(object.getString("openid"))) {
				logger.warn("gzh不正确的接口返回状态,result=" + result);
				return null;
			}
			
			return object;
			
		} catch (Exception e) {
			throw new IllegalStateException("公众号获取用户信息失败！",e);
		}
	}
	
	public String getGzhGeneralToken() {
		
		if (StringUtils.isEmpty(systemConstant.getWeixinTokenUrl())) {
			logger.error("Weixin gzh Token Url未配置");
			return null;
		}
		String token = null;
		try {
			token = (String) redisTemplate.opsForValue().get(RedisConstant.REDIS_WEIXIN_GENERAL_TOKEN);
		} catch (Exception e) {
			throw new IllegalStateException("从redis获取gzh token失败！",e);
		}
		
		if (!StringUtils.isEmpty(token)) {
			return token;
		}
		
		try {
			String url = systemConstant.getWeixinTokenUrl();
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("grant_type", "client_credential");
			paramMap.put("appid", systemConstant.getWeixinGzhAppid());
			paramMap.put("secret", systemConstant.getWeixinGzhSecret());
			
			String result = HttpUtil.doGet(url, paramMap);
			logger.info("gzh获取General Token返回的result=" + result);

			JSONObject object = JSONObject.parseObject(result);

			String accessToken =object.getString("access_token");
			
			if (StringUtils.isEmpty(accessToken)) {
				logger.warn("gzh General Token不正确的接口返回状态,result=" + result);
				return null;
			}
			try {
				redisTemplate.opsForValue().set(RedisConstant.REDIS_WEIXIN_GENERAL_TOKEN, accessToken, object.getLong("expires_in")-60, TimeUnit.SECONDS);
			} catch (Exception e) {
				logger.error("gzh General accessToken 放入redis出错", e);
			}
			return accessToken;
			
		} catch (Exception e) {
			throw new IllegalStateException("公众号获取General accessToken失败！",e);
		}
	}
	
	public String getJsapiTicket() {
		
		
		String ticket = null;
		try {
			ticket = (String) redisTemplate.opsForValue().get(RedisConstant.REDIS_WEIXIN_GZH_JSAPITICKET);
		} catch (Exception e) {
			throw new IllegalStateException("从redis获取gzh token失败！",e);
		}
		
		if (!StringUtils.isEmpty(ticket)) {
			return ticket;
		}
		
		if (StringUtils.isEmpty(systemConstant.getWeixinGetticketUrl())) {
			logger.error("Weixin gzh getticket Url未配置");
			return null;
		}
		
		String accessToken = getGzhGeneralToken();
		if (StringUtils.isEmpty(accessToken)) {
			logger.error("Weixin gzh accessToken 为空");
			return null;
		}
		try {
			String url = systemConstant.getWeixinGetticketUrl();
			Map<String, String> paramMap = new HashMap<>();
			paramMap.put("access_token", accessToken);
			paramMap.put("type", "jsapi");
			
			String result = HttpUtil.doGet(url, paramMap);
			logger.info("gzh获取JsapiTicket返回的result=" + result);

			JSONObject object = JSONObject.parseObject(result);
			ticket = object.getString("ticket");
			if (StringUtils.isEmpty(ticket) && "ok".equals(object.getString("errmsg"))) {
				logger.warn("gzh JsapiTicket不正确的接口返回状态,result=" + result);
				return null;
			}
			try {
				redisTemplate.opsForValue().set(RedisConstant.REDIS_WEIXIN_GZH_JSAPITICKET, ticket, object.getLong("expires_in")-60, TimeUnit.SECONDS);
			} catch (Exception e) {
				logger.error("微信公众号JsapiTicket 写入redis出错", e);
			}
			return ticket;
			
		} catch (Exception e) {
			throw new IllegalStateException("公众号获取用户信息失败！",e);
		}
	}

}
