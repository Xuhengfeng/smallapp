package com.ztj.dichan.cust.appapi.rest;

import java.net.URLDecoder;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.dichan.cust.appapi.jiguang.JiguangConfig;
import com.ztj.dichan.cust.appapi.request.WeixinRegRequest;
import com.ztj.dichan.cust.appapi.request.member.FetchSmsCodeRequest;
import com.ztj.dichan.cust.appapi.request.member.LoginRequest;
import com.ztj.dichan.cust.appapi.request.member.LoginSmsRequest;
import com.ztj.dichan.cust.appapi.request.member.NickNameRequest;
import com.ztj.dichan.cust.appapi.request.member.PasswordRequest;
import com.ztj.dichan.cust.appapi.request.member.RegisterRequest;
import com.ztj.dichan.cust.appapi.request.member.UpdateGenderRequest;
import com.ztj.dichan.cust.appapi.request.member.UpdateMobileRequest;
import com.ztj.dichan.cust.appapi.request.member.UpdatePasswordRequest;
import com.ztj.dichan.cust.appapi.service.MemberService;
import com.ztj.dichan.cust.appapi.service.component.OssComponent;
import com.ztj.dichan.cust.appapi.service.component.SmsComponent;
import com.ztj.dichan.cust.appapi.vo.MemberInviteVo;
import com.ztj.dichan.cust.appapi.vo.MemberMyInfoVo;
import com.ztj.dichan.cust.appapi.vo.MemberVo;
import com.ztj.dichan.cust.appapi.vo.WeixinSignatureVo;
import com.ztj.dichan.cust.appapi.vo.WeixinVo;
import com.ztj.dichan.cust.appapi.vo.WeixinVo2;
import com.ztj.dichan.cust.core.constant.RestResult;
import com.ztj.dichan.cust.rule.util.Utils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author test01
 */
@Api(value = "用户管理相关接口", description = "会员相关接口*")
@RestController
@RequestMapping(value = "/member")
public class MemberRest extends BaseCustRest {
	@Resource
	private MemberService memberService;

	@Resource
	private OssComponent ossSevice;

	@Resource
	private SmsComponent smsService;

	@Resource
	private JiguangConfig jiguangConfig;

	/**
	 * 
	 * @param mobile
	 * @param sign
	 * @param operateType
	 * @return
	 */
	@ApiOperation(value = "获取手机验证码")
	@RequestMapping(value = "/fetchSmsCode", method = { RequestMethod.POST })
	public RestResult fetchSmsCode(@RequestBody FetchSmsCodeRequest fetchSmsCodeRequest) {
		RestResult result = new RestResult();

		memberService.fetchSmsCode(fetchSmsCodeRequest.getMobile(), fetchSmsCodeRequest.getSign(),
				fetchSmsCodeRequest.getOperateType());
		
		return result;
	}

//	@ApiOperation(value = "补数据")
//	@RequestMapping(value = "/addData", method = { RequestMethod.POST })
//	public RestResult addData() {
//		RestResult result = new RestResult();
//		try {
//			memberService.addData();
//		} catch (Exception e) {
//			result.setStatus("500");
//			result.setMsg(e.getMessage());
//		}
//		return result;
//	}
//
//	@ApiOperation(value = "查询号码归属地")
//	@RequestMapping(value = "/mobileLocation", method = { RequestMethod.GET })
//	public RestResult mobileLocation(String mobile) {
//		RestResult result = new RestResult();
//		try {
//			String result1=memberService.getMobileLocation(mobile);
//			result.setData(result1);
//		} catch (Exception e) {
//			result.setStatus("500");
//			result.setMsg(e.getMessage());
//		}
//		return result;
//	}

	/**
	 * 
	 * @param mobile
	 * @param password
	 * @param confirmPassword
	 * @param smsCode
	 * @return
	 */
	@ApiOperation(value = "用戶注册")
	@RequestMapping(value = "/register", method = { RequestMethod.POST })
	public RestResult register(@RequestBody RegisterRequest registerRequest) {
		RestResult result = new RestResult();
		
		memberService.register(registerRequest);
		
		return result;
	}

	/**
	 * 
	 * @param mobile
	 * @param password
	 * @param deviceCode
	 * @return
	 */
	@ApiOperation(value = "用戶登录")
	@RequestMapping(value = "/login", method = { RequestMethod.POST })
	public RestResult login(@RequestBody LoginRequest loginRequest) {
		RestResult result = new RestResult();
		
		String uniqueCode = memberService.login(loginRequest.getMobile(), loginRequest.getPassword(),
				loginRequest.getDeviceCode());
		
		result.setData(uniqueCode);
		
		return result;
	}

	/**
	 * 
	 * @param mobile
	 * @param smsCode
	 * @param deviceCode
	 * @return
	 */
	@ApiOperation(value = "用戶验证码登录")
	@RequestMapping(value = "/smsCodelogin", method = { RequestMethod.POST })
	public RestResult smsCodelogin(@RequestBody LoginSmsRequest loginSmsRequest) {
		RestResult result = new RestResult();
		
		String code = memberService.smsCodeLogin(loginSmsRequest.getMobile(), loginSmsRequest.getDeviceCode(),
				loginSmsRequest.getSmsCode());
		
		result.setData(code);
		
		return result;
	}

	/**
	 * 
	 * @param openId
	 * @param accessToken
	 * @param refreshToken
	 * @param deviceCode
	 * @param nickname
	 * @param headImage
	 * @return
	 */
	@ApiOperation(value = "微信第三方登录")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "terminal-source", value = "终端来源标识", dataType = "String", paramType = "header", required = false),
			@ApiImplicitParam(name = "network-type", value = "网络类型标识", dataType = "String", paramType = "header", required = false),
			@ApiImplicitParam(name = "client-version", value = "客户端版本标识", dataType = "String", paramType = "header", required = false),
			@ApiImplicitParam(name = "device-code", value = "用戶終端设备标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "openId", value = "微信第三方登录返回的openid", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "unionId", value = "微信第三方登录返回的unionid", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "accessToken", value = "微信第三方登录返回的accessToken", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "refreshToken", value = "微信第三方登录返回的refreshToken", dataType = "String", paramType = "form", required = true),
			@ApiImplicitParam(name = "nickname", value = "用户昵称", dataType = "String", paramType = "form", required = false),
			@ApiImplicitParam(name = "sex", value = "用户性别", dataType = "String", paramType = "form", required = false),
			@ApiImplicitParam(name = "headImage", value = "用户邮箱链接地址", dataType = "String", paramType = "form", required = false) })
	@RequestMapping(value = "/loginByWechat", method = { RequestMethod.POST })
	public RestResult loginByWechat(String openId, String unionId, String accessToken, String refreshToken,
			String nickname, String sex, String headImage) {
		RestResult result = new RestResult();
	
		String uniqueCode = memberService.loginByWechat(openId, unionId, accessToken, refreshToken, nickname, sex,
				headImage, getDeviceCode());
		
		result.setData(uniqueCode);
		
		return result;
	}

	@ApiOperation(value = "微信授权注册--小程序", response = WeixinVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "terminal-source", value = "终端来源标识", dataType = "string", paramType = "header", required = false),
			@ApiImplicitParam(name = "network-type", value = "网络类型标识", dataType = "string", paramType = "header", required = false),
			@ApiImplicitParam(name = "client-version", value = "客户端版本标识", dataType = "string", paramType = "header", required = false),
			@ApiImplicitParam(name = "device-code", value = "用戶終端设备标识", dataType = "string", paramType = "header", required = false),
			@ApiImplicitParam(name = "code", value = "微信code", required = true, dataType = "string", paramType = "query") })
	@RequestMapping(value = "/authWeixin", method = { RequestMethod.GET })
	public RestResult authWeixin(@RequestParam(name = "code", required = false) String code) {
		RestResult result = new RestResult();

		WeixinVo vo = memberService.authWeixin(code);
		
		result.setData(vo);
		
		return result;
	}

	@ApiOperation(value = "微信授权注册")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "terminal-source", value = "终端来源标识", dataType = "String", paramType = "header", required = false),
			@ApiImplicitParam(name = "network-type", value = "网络类型标识", dataType = "String", paramType = "header", required = false),
			@ApiImplicitParam(name = "client-version", value = "客户端版本标识", dataType = "String", paramType = "header", required = false),
			@ApiImplicitParam(name = "device-code", value = "用戶終端设备标识", dataType = "String", paramType = "header", required = false) })
	@RequestMapping(value = "/registerWeixin", method = { RequestMethod.POST })
	public RestResult registerWeixin(@RequestBody WeixinRegRequest request) {
		RestResult result = new RestResult();

		memberService.registerWeixin(request);
		
		return result;
	}

	@ApiOperation(value = "微信手机号码和openid第三方登录")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "terminal-source", value = "终端来源标识", dataType = "string", paramType = "header", required = false),
			@ApiImplicitParam(name = "network-type", value = "网络类型标识", dataType = "string", paramType = "header", required = false),
			@ApiImplicitParam(name = "client-version", value = "客户端版本标识", dataType = "string", paramType = "header", required = false),
			@ApiImplicitParam(name = "device-code", value = "用戶終端设备标识", dataType = "string", paramType = "header", required = false),
			@ApiImplicitParam(name = "phone", value = "微信绑定的手机号", dataType = "string", paramType = "query", required = true),
			@ApiImplicitParam(name = "openid", value = "微信openid", dataType = "string", paramType = "query", required = true) })
	@RequestMapping(value = "/loginWeixin", method = { RequestMethod.GET })
	public RestResult loginWeixin(@RequestParam(name = "phone", required = true) String phone,
			@RequestParam(name = "openid", required = true) String openid) {
		RestResult result = new RestResult();

		String uniqueCode = memberService.loginWeixin(phone, openid);
		
		result.setData(uniqueCode);

		return result;
	}

	@ApiOperation(value = "微信认证--公众号", response = WeixinVo2.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "code", value = "微信code", required = true, dataType = "string", paramType = "query") })
	@RequestMapping(value = "/authWeixin2", method = { RequestMethod.GET })
	public RestResult authWeixin2(@RequestParam(name = "code", required = false) String code) {
		RestResult result = new RestResult();
		
		WeixinVo2 vo = memberService.authWeixin2(code);
		
		result.setData(vo);
		
		return result;
	}

	@ApiOperation(value = "微信注册--公众号")
	@RequestMapping(value = "/registerWeixin2", method = { RequestMethod.POST })
	public RestResult registerWeixin2(@RequestBody WeixinRegRequest request) {
		RestResult result = new RestResult();
		
		String code = memberService.registerWeixin2(request);
		
		result.setData(code);
		
		return result;
	}

	/**
	 * 
	 * @param mobile
	 * @param smsCode
	 * @param newPassword
	 * @return
	 */
	@ApiOperation(value = "验证码登陆 ，设置密码")
	@RequestMapping(value = "/resetPassword", method = { RequestMethod.POST })
	public RestResult resetPassword(@RequestBody PasswordRequest passwordRequest) {
		RestResult result = new RestResult();
		
		memberService.resetPassword(passwordRequest.getMobile(), passwordRequest.getSmsCode(),
				passwordRequest.getNewPassword(), passwordRequest.getConfirmPassword());
		
		return result;
	}

	@ApiOperation(value = "修改昵称")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/updateNickName", method = { RequestMethod.POST })
	public RestResult updateNickName(@RequestBody NickNameRequest nickNameRequest) {
		RestResult result = new RestResult();
		
		memberService.updateNickName(getCurrentMemberId(), nickNameRequest.getNickname());
		
		return result;
	}

	@ApiOperation(value = "修改性别")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/updateGender", method = { RequestMethod.POST })
	public RestResult updateGender(@RequestBody UpdateGenderRequest updateGenderRequest) {
		RestResult result = new RestResult();
		
		memberService.updateGender(getCurrentMemberId(), updateGenderRequest.getGender());
		
		return result;
	}

	@ApiOperation(value = "获取用户详细信息", response = MemberVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/getDetailInfo", method = { RequestMethod.POST })
	public RestResult getDetailInfo() {
		RestResult result = new RestResult();
	
		MemberVo vo = memberService.getDetailInfo(getCurrentMemberId());
		
		vo.setBrokerAppKey(jiguangConfig.getBrokerAppKey());
		
		result.setData(vo);
		
		return result;
	}

	/**
	 * 使用json格式接收数据,使用普通参数对方式提交时会出现post数据导致无法接收到数据的问题
	 * 
	 * @param map
	 * @return
	 */
	@ApiOperation(value = "修改头像")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "base64Image", value = "base64格式的图片编码", dataType = "String", paramType = "form", required = false) })
	@RequestMapping(value = "/updateHeadImage", method = { RequestMethod.POST })
	public RestResult updateHeadImage(@RequestBody Map<String, String> map) {
		RestResult result = new RestResult();
		
		String url = memberService.updateHeadImage(getCurrentMemberId(), map.get("base64Image"));
		
		result.setData(url);
		
		return result;
	}

	@ApiOperation(value = "退出登录")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/logout", method = { RequestMethod.POST })
	public RestResult logout() {
		RestResult result = new RestResult();
		
		memberService.logout(getCurrentMemberId());
		
		return result;
	}

	@ApiOperation(value = "修改密码")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/updatePassword", method = { RequestMethod.POST })
	public RestResult updatePassword(@RequestBody UpdatePasswordRequest updatePasswordRequest) {
		RestResult result = new RestResult();
		
		memberService.updatePassword(getCurrentMemberId(), updatePasswordRequest.getPassword(),
				updatePasswordRequest.getNewPassword(), updatePasswordRequest.getConfirmPassword());
		
		return result;
	}

	@ApiOperation(value = "更换手机号")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/updateMobile", method = { RequestMethod.POST })
	public RestResult updateMobile(@RequestBody UpdateMobileRequest updateMobileRequest) {
		RestResult result = new RestResult();
		Long memberId = getCurrentMemberId();
		/*
		 * try { memberService.updateMobile(memberId, updateMobileRequest.getMobile(),
		 * updateMobileRequest.getSmsCode()); } catch (Exception e) {
		 * result.setStatus("500"); result.setMsg(e.getMessage()); }
		 */
		// 目前系统大部分需要根据手机号来确定用户身份，暂时不允许修改手机号
		result.setStatus("500");
		result.setMsg("抱歉，暂时不允许修改手机号码");
		return result;
	}

	@ApiOperation(value = "获取会员用户信息", response = MemberMyInfoVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true) })
	@RequestMapping(value = "/myinfo", method = { RequestMethod.GET })
	public RestResult getMyInfo() {
		RestResult result = new RestResult();
		
		MemberMyInfoVo vo = memberService.getMemberMyInfo(getCurrentMemberId());
		
		if (vo != null) {
			vo.setBrokerAppKey(jiguangConfig.getBrokerAppKey());
		}
		
		result.setData(vo);
		
		return result;
	}

	@ApiOperation(value = "我邀请的用户")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "需要显示的页数", dataType = "int", paramType = "form", required = true, example = "1"),
			@ApiImplicitParam(name = "pageSize", value = "每页显示的条数", dataType = "int", paramType = "form", required = true, example = "10") })
	@RequestMapping(value = "/myInvite", method = { RequestMethod.POST })
	public RestResult myInvite(Integer pageNo, Integer pageSize) {
		List<MemberInviteVo> voList = memberService.myInvite(getCurrentMemberId(), pageNo, pageSize);

		return new RestResult(voList);
	}

	@ApiOperation(value = "邀请我的用户")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true), })
	@RequestMapping(value = "/InviteTome", method = { RequestMethod.POST })
	public RestResult InviteTome() {
		MemberInviteVo vo = memberService.InviteTome(getCurrentMemberId());

		return new RestResult(vo);
	}

	@ApiOperation(value = "获取二维码")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true), })
	@RequestMapping(value = "/fetchQRCodeUrl", method = { RequestMethod.POST })
	public RestResult fetchQRCodeUrl() {
		Map<String, String> map = memberService.fetchQrCodeUrl(getCurrentMemberId());
		
		return new RestResult(map);
	}

//	@ApiOperation(value = "补数据")
//	@RequestMapping(value = "/applyCodeUrl", method = { RequestMethod.POST })
//	public RestResult applyCodeUrl() {
//		RestResult result = new RestResult();
//		try {
//			List<Member> iterator = memberService.queryAll();
//
//			for (Member member : iterator) {
//				executor.submit(new Runnable() {
//					public void run() {
//						try {
//							memberService.applyQRCodeUrl(member);
//						} catch (Exception e) {
//							logger.error("applyQRCodeUrl出错了", e);
//						}
//
//					}
//				});
//			}
//		} catch (Exception e) {
//			result.setStatus("500");
//			result.setMsg(e.getMessage());
//		}
//		return result;
//	}

	@ApiOperation(value = "下载会员头像（仅限聊天界面使用）")
	@RequestMapping(value = "/headImage/{username}", method = RequestMethod.GET)
	@ApiImplicitParams({
			@ApiImplicitParam(name = "username", value = "会员聊天账号", required = true, dataType = "string", paramType = "path") })
	public void downloadHeadImage(@PathVariable("username") String username, HttpServletResponse response) {
		memberService.downloadHeadImage(username, response);
	}

	@ApiOperation(value = "获取微信公众号鉴权信息", response = WeixinSignatureVo.class)
	@PostMapping(value = "/weixin/signature")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "accessKey", value = "访问key,必填", dataType = "string", paramType = "header", required = true) })
	public RestResult getWeixinSignature(@RequestHeader("accessKey") String accessKey, @RequestBody String url) {
		RestResult result = new RestResult();
		if (!Utils.ACCESS_KEY.equals(accessKey)) {
			result.setStatus("403");
			result.setMsg("无权限访问");
			result.setData(null);
			return result;
		}
		result.setData(this.memberService.getWeixinSignature(url));
		return result;

	}

	@ApiOperation(value = "获取微信公众号鉴权信息", response = WeixinSignatureVo.class)
	@GetMapping(value = "/weixin/signature")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "accessKey", value = "访问key,必填", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "url", value = "分析URL地址", dataType = "string", paramType = "query", required = true) })
	public RestResult getWeixinSignature2(@RequestHeader("accessKey") String accessKey,
			@RequestParam(name = "url", required = true) String url) {
		logger.info("Signature url=" + url);
		try {
			url = URLDecoder.decode(url, "utf-8");
			logger.info("Signature Decoder url=" + url);
		} catch (Exception e) {
			logger.error("URL解码失败>>", e);
		}

		RestResult result = new RestResult();
		if (!Utils.ACCESS_KEY.equals(accessKey)) {
			result.setStatus("403");
			result.setMsg("无权限访问");
			result.setData(null);
			return result;
		}

		result.setData(this.memberService.getWeixinSignature(url));
		return result;
	}
}