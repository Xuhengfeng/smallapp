/**
 * 
 */
package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.InfoContentService;
import com.ztj.dichan.cust.appapi.vo.infocontent.ColumnesGuideVo;
import com.ztj.dichan.cust.appapi.vo.infocontent.ColumnesVo;
import com.ztj.dichan.cust.appapi.vo.infocontent.InfoContentDetailVo;
import com.ztj.dichan.cust.appapi.vo.infocontent.InfoContentVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @author lbs
 *
 */
@Api(value = "资讯内容接口",description="资讯内容相关接口")
@RestController
@RequestMapping(value = "/info")
public class InfoContentRest extends BaseCustRest {

	@Resource
	private InfoContentService infoContentService;
	

	@ApiOperation(value = "获取资讯内容信息列表", response = InfoContentVo.class)
	@GetMapping(value = "/query/{code}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "code", value = "栏目code，1001=首页热门推荐，1002=首页新盘推荐", dataType = "string", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query")})
	public RestResult<List<InfoContentVo>> getInfoContentList(@PathVariable("code") String code,
			@RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {

		List<InfoContentVo> voList = this.infoContentService.queryList(code, pageNo, pageSize);
		return RestResult.success(voList);

	}
	
	@ApiOperation(value = "获取资讯子栏目列表", response = InfoContentVo.class)
	@GetMapping(value = "/query/child/{code}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "code", value = " 父栏目code", dataType = "string", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query")})
	public RestResult<List<ColumnesVo>> getChildColumnList(@PathVariable("code") String code,
			@RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {

		List<ColumnesVo> voList = this.infoContentService.queryChildColumnList(code, pageNo, pageSize);
		return RestResult.success(voList);

	}
	
	
	
	
	@ApiOperation(value = "获取资讯内容详情", response = InfoContentDetailVo.class)
	@GetMapping(value = "/{id}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "id", value = "资讯内容Id", dataType = "string", paramType = "path", required = true)})
	public RestResult<InfoContentDetailVo> getInfoContentDetail(@PathVariable("id") Long id) {

		InfoContentDetailVo detailVo = this.infoContentService.getInfoContentDetail(id);
		return RestResult.success(detailVo);

	}
	
	
	@ApiOperation(value = "购房指南首页信息", response = ColumnesGuideVo.class)
	@GetMapping(value = "/purchase-guide/index")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true)})
	public RestResult<List<ColumnesGuideVo>> getPurchaseGuideIndex() {

		List<ColumnesGuideVo> voList = this.infoContentService.getPurchaseGuideIndex();
		return RestResult.success(voList);

	}
	
	
}
