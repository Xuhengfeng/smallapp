package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.common.constant.ReturnCode;
import com.ztj.common.exception.BizException;
import com.ztj.common.util.DateUtil;
import com.ztj.dichan.cust.appapi.easemob.external.EasemobUserServiceClient;
import com.ztj.dichan.cust.appapi.easemob.service.EasemobUserService;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.external.HouseSeeServiceClient;
import com.ztj.dichan.cust.appapi.external.HouseServiceClient;
import com.ztj.dichan.cust.appapi.external.RentHouseServiceClient;
import com.ztj.dichan.cust.appapi.request.HouseEntrustApplyCancelRequest;
import com.ztj.dichan.cust.appapi.request.HouseEntrustApplyRequest;
import com.ztj.dichan.cust.appapi.service.component.CacheComponent;
import com.ztj.dichan.cust.appapi.service.component.SmsComponent;
import com.ztj.dichan.cust.appapi.vo.ApplyHouseBrokerVo;
import com.ztj.dichan.cust.appapi.vo.HouseEntrustApplyDetailVo;
import com.ztj.dichan.cust.appapi.vo.HouseEntrustApplyVo;
import com.ztj.dichan.cust.appapi.vo.MemberVo;
import com.ztj.dichan.cust.appapi.vo.RentEntrustApplyDetailVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointDetailHouseVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointDetailRentHouseVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.BrokerCollection;
import com.ztj.dichan.cust.core.entity.BrokerContact;
import com.ztj.dichan.cust.core.entity.HouseEntrustApply;
import com.ztj.dichan.cust.core.enums.ApplicantTypeEnum;
import com.ztj.dichan.cust.core.enums.ApplicationStatusEnum;
import com.ztj.dichan.cust.core.enums.ApplicationTypeEnum;
import com.ztj.dichan.cust.core.repository.BrokerContactRepository;
import com.ztj.dichan.cust.core.repository.HouseCollectionRepository;
import com.ztj.dichan.cust.core.repository.HouseEntrustApplyRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.EntrustHouseRequest;
import com.ztj.dichan.cust.rule.request.EntrustRentRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeCountVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * 
 * @author liuweichen
 *
 */

@Service
@Transactional
public class HouseEntrustApplyService extends BaseAppService {
	
	@Resource
	private HouseEntrustApplyRepository houseEntrustApplyRepository;
	
	@Resource
	private BrokerServiceClient brokerServiceClient;
	
	@Resource
	private EasemobUserServiceClient easemobUserServiceClient;
	
	@Resource
	private EasemobUserService easemobUserService;
	
	@Resource
	private HouseSeeServiceClient houseSeeServiceClient;
	
	@Resource
	private HouseServiceClient houseServiceClient;
	
	@Resource
	private RentHouseServiceClient rentHouseServiceClient;
	
	@Resource
	private HouseCollectionRepository houseCollectionRepository;
	
	@Resource
	private MemberService memberService;
	
	@Resource
	private SmsComponent smsComponent;
	
	@Resource
	private CacheComponent cacheComponent;
	
	@Resource
	private BrokerContactRepository brokerContactRepository ;
	
	
	
	public void addHouseEntrustApply(Long memberId, ApplicationTypeEnum applicationType, HouseEntrustApplyRequest request) {
		
		BrokerDetailVo broker = null;
		try {
			if (request == null) {
				return;
			}
			String scity = RequestContextHolder.getCityCode();
			
			HouseEntrustApply houseEntrustApply = new HouseEntrustApply();
			houseEntrustApply.setAddress(request.getAddress());
			houseEntrustApply.setApplicationType(applicationType);
			houseEntrustApply.setLinkman(request.getLinkman());
			houseEntrustApply.setPhone(request.getPhone());
			houseEntrustApply.setMemberId(memberId);
			houseEntrustApply.setCityCode(request.getCityCode());
			houseEntrustApply.setBuildingName(request.getBuildingName());
			houseEntrustApply.setBuildingSdid(request.getBuildingSdid());
			houseEntrustApply.setBuildNum(request.getBuildNum());
			houseEntrustApply.setUnitNum(request.getUnitNum());
			houseEntrustApply.setRoomNum(request.getRoomNum());
			houseEntrustApply.setStatus(ApplicationStatusEnum.ZERO);
			houseEntrustApply.setCurrCityCode(scity);
			houseEntrustApply.setApplicationTime(LocalDateTime.now());
			houseEntrustApply.setUpdateDateTime(LocalDateTime.now());
			if (request.getApplicantType() == null) {
				houseEntrustApply.setApplicantType(ApplicantTypeEnum.OWNER);//默认业主
			} else {
				houseEntrustApply.setApplicantType(request.getApplicantType());
			}
			
			if (request.getBrokerId() == null || request.getBrokerId() <=0) {
				//这里需要随机取一个经纪人
			} else {
				broker = brokerServiceClient.queryBroker(request.getCityCode(), Integer.valueOf(request.getBrokerId()+""));
				if (broker == null) {
					throw new IllegalStateException("未找到相应的经纪人");
				}
				houseEntrustApply.setBrokerId(request.getBrokerId());
			}
			
			houseEntrustApplyRepository.save(houseEntrustApply);
			
			//发送短信通知经纪人
			JSONObject data = new JSONObject();
			data.put("phone", houseEntrustApply.getPhone());
			data.put("name", houseEntrustApply.getLinkman());
			this.smsComponent.sendApplyNotifiBroker(broker.getPhone(), data);
				
		} catch (Exception e) {
			throw new BizException("保存租售信息出错了", e);
		}
		
//	  去经纪人app上 通知经纪人，您有一条订单信息
		try {
			JSONObject req = new JSONObject();
			JSONObject msg = new JSONObject();
			JSONArray target = new JSONArray();
			JSONObject ext = new JSONObject();
			target.add(request.getCityCode()+"_"+request.getBrokerId()+"_"+broker.getEmplAccNo());
			//"target" : ["u1", "u2", "u3"],
			msg.put("type", "txt");
			msg.put("msg", "您有一条新的订单");
			ext.put("customType","2");
			req.put("target_type", "users");
			req.put("target", target);
			req.put("msg", msg);
			req.put("from", "系统消息");
			req.put("ext", ext);
			JSONObject obj = easemobUserServiceClient.sendMessage(easemobUserService.getToken(), req);
			
		} catch (Exception e) {
			throw new BizException("通知经纪人出错了", e);
		}
	}
	
	/**
	 * 房屋租售列表
	 * @param memberId
	 * @param applicationType
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	
	public List<HouseEntrustApplyVo>  houseEntrustApplyList(Long memberId, ApplicationTypeEnum applicationType, Integer pageNo,Integer pageSize) {
		try {
            Sort sort = new Sort(Sort.Direction.DESC, "createDateTime");
			if (pageSize == null || pageSize <= 0) {
				pageSize = 10;
			}
			PageRequest pageRequest = new PageRequest(pageNo - 1, pageSize, sort);
			List<HouseEntrustApply> list = houseEntrustApplyRepository.findByMemberIdAndApplicationType(memberId, applicationType, pageRequest);
			List<HouseEntrustApplyVo> voList = new ArrayList<>();
			for (HouseEntrustApply houseEntrustApply : list) {
				
				HouseEntrustApplyVo vo = new HouseEntrustApplyVo();
				BeanUtils.copyProperties(houseEntrustApply, vo);
				vo.setApplicationTime(DateUtil.formatLocalDateTime(houseEntrustApply.getApplicationTime(), DateUtil.DATEFORMAT_DATETIME16));
				vo.setCityName(cacheComponent.getCityName(vo.getCityCode()));
				
				voList.add(vo);
				
			}
			return voList;  
		} catch (Exception e) {
			throw new BizException(ReturnCode.REC_0.getCode(), e);		}
		
	}
	
	/**
	 * 获取出租申请详情
	 * @param memberId
	 * @param id
	 * @return
	 */
	public RentEntrustApplyDetailVo  getEntrustRentApplyDetail(Long memberId,Long id) {
		
		if (memberId == null || id == null) {
			return null;
		}
		HouseEntrustApply houseEntrustApply = houseEntrustApplyRepository.findByIdAndMemberId(id, memberId);
		if (houseEntrustApply == null) {
			return null;
		}
		RentEntrustApplyDetailVo vo = new RentEntrustApplyDetailVo();
		BeanUtils.copyProperties(houseEntrustApply, vo);
		vo.setApplicationTime(DateUtil.formatLocalDateTime(houseEntrustApply.getApplicationTime(), DateUtil.DATEFORMAT_DATETIME16));
		vo.setCityName(cacheComponent.getCityName(vo.getCityCode()));
		if (houseEntrustApply.getBrokerId() != null) {
			BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(houseEntrustApply.getCityCode(), houseEntrustApply.getBrokerId().intValue());
			if (brokerDetailVo != null) {
				ApplyHouseBrokerVo broker = new ApplyHouseBrokerVo();
				BeanUtils.copyProperties(brokerDetailVo, broker);
				broker.setStatus(Utils.checkBrokerStatus(brokerDetailVo.getEmplStatus()));
				if ("1".equals(brokerDetailVo.getPhoto())) {
					brokerDetailVo.setPhoto(systemConstant.getOssCdnUrl() + brokerDetailVo.getScity()
					+ "/Empl/PIC/" + brokerDetailVo.getId() + "/"+ brokerDetailVo.getId() + ".jpg");
				}
				vo.setBroker(broker);
			}
			
		}
		
		
		
		if (houseEntrustApply.getHouseSdid() != null 
				&& houseEntrustApply.getApplicationType() == ApplicationTypeEnum.RENT) {
			
			RentHouseDetailVo rentHouseDetailVo = rentHouseServiceClient.getDetailInfo(houseEntrustApply.getCityCode(), houseEntrustApply.getHouseSdid());
			if (rentHouseDetailVo != null) {
				AppointDetailRentHouseVo rentHouseVo = new AppointDetailRentHouseVo();
				BeanUtils.copyProperties(rentHouseDetailVo, rentHouseVo);
				
				rentHouseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), rentHouseVo.getHousePic(),
						rentHouseVo.getScity(), String.valueOf(rentHouseVo.getId())));
				
				rentHouseVo.setStatus(Utils.checkHouseStatus(rentHouseVo.getBuildStatus()));
				if (houseEntrustApply.getStatus() == ApplicationStatusEnum.CANCEL) {
					rentHouseVo.setStatus(2);
				}
				HouseSeeCountVo houseSeeCountVo = houseSeeServiceClient.queryCount(rentHouseVo.getScity(), rentHouseVo.getId());
				
				rentHouseVo.setDay7Num(houseSeeCountVo.getDay7Count());
				rentHouseVo.setDay30Num(houseSeeCountVo.getDay30Count());
				rentHouseVo.setTotalSeeNum(houseSeeCountVo.getTotalCount());
				Integer collectNum = houseCollectionRepository.countByHouseSdid(houseEntrustApply.getHouseSdid());
				rentHouseVo.setCollectNum(collectNum);
				if (!StringUtils.isEmpty(houseSeeCountVo.getRecentlySeeDate())) {
					rentHouseVo.setRecentlySee(houseSeeCountVo.getRecentlySeeDate().split(" ")[0].replace("-", "."));
				} else {
					rentHouseVo.setRecentlySee("");
				}
				
				vo.setHouse(rentHouseVo);
			}
			
			
		}
		return vo;
		
	}
	
	/**
	 * 获取卖房申请信息详情
	 * @param memberId
	 * @param id
	 * @return
	 */
	public HouseEntrustApplyDetailVo  getEntrustHouseApplyDetail(Long memberId,Long id) {
		
		if (memberId == null || id == null) {
			return null;
		}
		
		HouseEntrustApply houseEntrustApply = houseEntrustApplyRepository.findByIdAndMemberId(id, memberId);
		if (houseEntrustApply == null) {
			return null;
		}
		HouseEntrustApplyDetailVo vo = new HouseEntrustApplyDetailVo();
		BeanUtils.copyProperties(houseEntrustApply, vo);
		vo.setApplicationTime(DateUtil.formatLocalDateTime(houseEntrustApply.getApplicationTime(), DateUtil.DATEFORMAT_DATETIME16));
		vo.setCityName(cacheComponent.getCityName(vo.getCityCode()));
		if (houseEntrustApply.getBrokerId() != null) {
			BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(houseEntrustApply.getCityCode(), houseEntrustApply.getBrokerId().intValue());
			if (brokerDetailVo != null) {
				ApplyHouseBrokerVo broker = new ApplyHouseBrokerVo();
				BeanUtils.copyProperties(brokerDetailVo, broker);
				broker.setStatus(Utils.checkBrokerStatus(brokerDetailVo.getEmplStatus()));
				if ("1".equals(brokerDetailVo.getPhoto())) {
					brokerDetailVo.setPhoto(systemConstant.getOssCdnUrl() + brokerDetailVo.getScity()
					+ "/Empl/PIC/" + brokerDetailVo.getId() + "/"+ brokerDetailVo.getId() + ".jpg");
				}
				vo.setBroker(broker);
			}
			
		}
		
		if (houseEntrustApply.getHouseSdid() != null
				&& houseEntrustApply.getApplicationType() == ApplicationTypeEnum.SELL) {
			
			HouseDetailVo houseDetailVo = houseServiceClient.getDetailInfo(houseEntrustApply.getCityCode(), houseEntrustApply.getHouseSdid());
			if (houseDetailVo != null) {
				AppointDetailHouseVo houseVo = new AppointDetailHouseVo();
				BeanUtils.copyProperties(houseDetailVo, houseVo);
				
				houseVo.setBuiltArea(houseDetailVo.getBuiltArea());
				houseVo.setSalePrice(houseDetailVo.getSaleprice());
				houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseVo.getHousePic(),
						houseVo.getScity(), String.valueOf(houseVo.getId())));
				
				houseVo.setStatus(Utils.checkHouseStatus(houseVo.getBuildStatus()));
				
				if (houseEntrustApply.getStatus() == ApplicationStatusEnum.CANCEL) {
					houseVo.setStatus(2);
				}
				
				HouseSeeCountVo houseSeeCountVo = houseSeeServiceClient.queryCount(houseVo.getScity(), houseVo.getId());
				
				houseVo.setDay7Num(houseSeeCountVo.getDay7Count());
				houseVo.setDay30Num(houseSeeCountVo.getDay30Count());
				houseVo.setTotalSeeNum(houseSeeCountVo.getTotalCount());
				Integer collectNum = houseCollectionRepository.countByHouseSdid(houseEntrustApply.getHouseSdid());
				houseVo.setCollectNum(collectNum);
				if (!StringUtils.isEmpty(houseSeeCountVo.getRecentlySeeDate())) {
					houseVo.setRecentlySee(houseSeeCountVo.getRecentlySeeDate().split(" ")[0].replace("-", "."));
				} else {
					houseVo.setRecentlySee("");
				}
				
				vo.setHouse(houseVo);
			}
			
		}
		return vo;
	}
	
	/**
	 * 根据客户手机号码查找相关的二手房列表
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<HouseVo> queryEntrustHouseList(Long memberId, Integer pageNo,Integer pageSize) {
		
		MemberVo member = memberService.getDetailInfo(memberId);
		if (member == null || StringUtils.isEmpty(member.getMobile())) {
			return new ArrayList<HouseVo>(0);
		}
		String scity = RequestContextHolder.getCityCode();
		EntrustHouseRequest request = new EntrustHouseRequest();
		request.setScity(scity);
		request.setPageNo(pageNo);
		request.setPageSize(pageSize);
		request.setPhone(member.getMobile());
		List<HouseVo> houseList = houseServiceClient.queryEntrustHouseList(request, scity);
		if (houseList == null) {
			return new ArrayList<HouseVo>(0);
		}
		
		houseList.forEach(houseVo -> {
			houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseVo.getHousePic(),
					scity, String.valueOf(houseVo.getId())));
			houseVo.setStatus(Utils.checkHouseStatus(houseVo.getBuildStatus()));

		});
		return houseList;
	}
	
	/**
	 * 根据客户手机号码查找相关的出租房列表
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<RentHouseVo> queryEntrustRentHouseList(Long memberId, Integer pageNo,Integer pageSize) {
		
		MemberVo member = memberService.getDetailInfo(memberId);
		if (member == null || StringUtils.isEmpty(member.getMobile())) {
			return new ArrayList<RentHouseVo>(0);
		}
		String scity = RequestContextHolder.getCityCode();
		EntrustRentRequest request = new EntrustRentRequest();
		request.setScity(scity);
		request.setPageNo(pageNo);
		request.setPageSize(pageSize);
		request.setPhone(member.getMobile());
		List<RentHouseVo> houseList = rentHouseServiceClient.queryEntrustRentList(request, scity);
		if (houseList == null) {
			return new ArrayList<RentHouseVo>(0);
		}
		
		houseList.forEach(rentHouseVo -> {
			rentHouseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), rentHouseVo.getHousePic(),
					scity, String.valueOf(rentHouseVo.getId())));
			rentHouseVo.setStatus(Utils.checkHouseStatus(rentHouseVo.getBuildStatus()));

		});
		return houseList;
	}
	
	public void cancelEntrustHouseApply(Long memberId,HouseEntrustApplyCancelRequest request) {
		if (request.getId() == null || request.getId() <= 0) {
			throw new IllegalArgumentException("不存在委托申请记录");
		}
		HouseEntrustApply houseEntrustApply = this.houseEntrustApplyRepository.findOne(request.getId());
		if (houseEntrustApply == null) {
			throw new IllegalArgumentException("不存在委托申请记录");
		}
		if (houseEntrustApply.getMemberId() != memberId) {
			throw new IllegalArgumentException("无权限取消该委托申请记录");
		}
		houseEntrustApply.setStatus(ApplicationStatusEnum.CANCEL);
		houseEntrustApply.setCancelCause(request.getCancelCause());
		houseEntrustApply.setCancelTime(LocalDateTime.now());
		this.houseEntrustApplyRepository.save(houseEntrustApply);
		
	}
	
	public void savebrokerContact(Integer brokerId ,String scity,Long memberId ) {
		
		
		BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(scity, brokerId);
		
		if (brokerDetailVo == null) {
			throw new IllegalArgumentException("该经纪人不存在");
		}

		BrokerCollection brokerCollection = new BrokerCollection();

		brokerCollection.setBrokerScity(brokerDetailVo.getScity());
		brokerCollection.setBrokerId(Long.valueOf(brokerDetailVo.getId()));
		brokerCollection.setBrokerSdid(Long.valueOf(brokerDetailVo.getSdid()));
		
		BrokerContact entity = new BrokerContact();
		entity.setBrokerId(Long.parseLong(brokerId+""));
		entity.setBrokerScity(scity);
		entity.setBrokerSdid(Long.valueOf(brokerDetailVo.getSdid()));
		entity.setMemberId(memberId);
		entity.setCreateTime(LocalDateTime.now());
		brokerContactRepository.save(entity);
	}
	
}
