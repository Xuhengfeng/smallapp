package com.ztj.dichan.cust.appapi.service;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.dichan.cust.appapi.constant.SystemConstant;
import com.ztj.dichan.cust.appapi.request.BaseRequest;
import com.ztj.dichan.cust.appapi.service.component.CacheComponent;
import com.ztj.dichan.cust.core.constant.OtherConstant;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.service.BaseService;

/**
 * 
 * @author sily
 */
@Service
public class BaseAppService extends BaseService {
	protected ExecutorService executor = Executors.newScheduledThreadPool(Runtime.getRuntime().availableProcessors());

	@Resource
	protected SystemConstant systemConstant;

	@Resource
	protected RestTemplate restTemplate;

	@Resource
	protected RedisTemplate redisTemplate;
	
	@Resource
	protected CacheComponent cacheComponent;

	//public static Map<String, SysLoginBean> cityNamePyContext = new HashMap<>();

//	public static void initCityContext(List<SysLogin> list) {
//		if (list == null || list.size() == 0) {
//			return;
//		}
//		for (SysLogin login : list) {
//			cityNamePyContext.put(login.getCityNamePy(), login);
//		}
//	}

	public  String getCityNameByCityCode(String cityCode) {
//		SysLoginBean login = cityNamePyContext.get(cityCode);
//
//		if (login != null) {
//			return login.getCityNameCh();
//		}
//
//		return null;
		
		return cacheComponent.getCityNameByCityCode(cityCode);
	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 */
	protected void validatePageRequest(Integer pageNo, Integer pageSize) {
		if (pageNo == null || pageNo <= 0) {
			throw new IllegalArgumentException("pageNo必须大于等于1");
		}

		if (pageSize == null || pageSize <= 0) {
			throw new IllegalArgumentException("pageSize必须大于等于1");
		}

		if (pageSize > OtherConstant.DEFAULT_MAX_PAGE_SIZE) {
			throw new IllegalArgumentException("pageSize不能大于" + OtherConstant.DEFAULT_MAX_PAGE_SIZE);
		}
	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 */
	protected void validatePageRequestWithoutMaxCount(Integer pageNo, Integer pageSize) {
		if (pageNo == null || pageNo <= 0) {
			throw new IllegalArgumentException("pageNo必须大于等于1");
		}

		if (pageSize == null || pageSize <= 0) {
			throw new IllegalArgumentException("pageSize必须大于等于1");
		}
	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 */
	protected PageRequest validateAndFetchPageRequest(Integer pageNo, Integer pageSize) {
		validatePageRequest(pageNo, pageSize);

		PageRequest pageRequest = new PageRequest(pageNo - 1, pageSize, new Sort(Sort.Direction.DESC, "recmdTime"));

		return pageRequest;
	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 */
	protected PageRequest validateAndFetchPageRequest(Integer pageNo, Integer pageSize, String orderField) {
		validatePageRequest(pageNo, pageSize);

		PageRequest pageRequest = new PageRequest(pageNo - 1, pageSize, new Sort(Sort.Direction.DESC, orderField));

		return pageRequest;
	}

	/**
	 * 验证并获取PageRequest对象,不限制最大记录数
	 * 
	 * @param pageNo
	 * @param pageSize
	 */
	protected PageRequest validateAndFetchPageRequestWithoutMaxCount(Integer pageNo, Integer pageSize,
			String orderField) {
		validatePageRequestWithoutMaxCount(pageNo, pageSize);

		PageRequest pageRequest = new PageRequest(pageNo - 1, pageSize, new Sort(Sort.Direction.DESC, orderField));

		return pageRequest;
	}

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @param orderField
	 * @return
	 */
	protected PageRequest validateAndFetchPageRequestOrderByAsc(Integer pageNo, Integer pageSize, String orderField) {
		validatePageRequest(pageNo, pageSize);

		PageRequest pageRequest = new PageRequest(pageNo - 1, pageSize, new Sort(Sort.Direction.ASC, orderField));

		return pageRequest;
	}

	protected String getScity(BaseRequest baseRequest) {
		String scity = RequestContextHolder.getCityCode();
		if (StringUtils.isEmpty(scity)) {
			scity = baseRequest.getScity();
		}
		return scity;
	}
	
	protected String getScityNew(com.ztj.dichan.cust.rule.request.BaseRequest baseRequest) {
		String scity = RequestContextHolder.getCityCode();
		if (StringUtils.isEmpty(scity)) {
			scity = baseRequest.getScity();
		}
		return scity;
	}

	/**
	 * 
	 * @param mobile 查询手机号码归属地
	 * @return
	 */
	protected String getMobileLocation(String mobile) {

		HttpHeaders requestHeaders = new HttpHeaders();
		requestHeaders.add("Authorization", "APPCODE " + systemConstant.getAppcode());

		HttpEntity<String> requestEntity = new HttpEntity<>(null, requestHeaders);

		ResponseEntity<String> responseEntity = restTemplate.exchange(
				"https://jisushouji.market.alicloudapi.com/shouji/query?shouji=" + mobile, HttpMethod.GET,
				requestEntity, String.class);

		String result = responseEntity.getBody();

		JSONObject jsonObject = (JSONObject) JSON.parse(result);

		String status = jsonObject.getString("status");
		String msg = jsonObject.getString("msg");

		if (StringUtils.isEmpty(status)) {
			throw new IllegalStateException("调用接口出错了");
		}

		if (!status.equals("0")) {
			throw new IllegalStateException("调用接口出错了,msg=" + msg);
		}

		JSONObject resultJsonObject = jsonObject.getJSONObject("result");

		String city = resultJsonObject.getString("city");
		String province = resultJsonObject.getString("province");
		if (StringUtils.isEmpty(city)) {
			return province;
		}

		return city;
	}

	/**
	 * 
	 * @param mobile 验证是否是员工
	 */
	protected Map<String, String> queryIsEmployee(String mobile) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

		MultiValueMap<String, String> parameterMap = new LinkedMultiValueMap<String, String>();
		parameterMap.add("mobile", mobile);

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(parameterMap,
				headers);

		ResponseEntity<String> response = restTemplate.postForEntity(systemConstant.getGroupApiUrl() + "queryMobile",
				request, String.class);

		String resultStr = response.getBody();

		JSONArray jsonArray = JSONArray.parseArray(resultStr);

		if (jsonArray.size() == 0) {
			return null;
		}

		JSONObject cityObject = jsonArray.getJSONObject(0);

		String scity = cityObject.getString("scity");
		String phone = cityObject.getString("phone");

		Map<String, String> map = new HashMap<>();
		map.put("scity", scity);
		map.put("phone", phone);

		return map;
	}

}