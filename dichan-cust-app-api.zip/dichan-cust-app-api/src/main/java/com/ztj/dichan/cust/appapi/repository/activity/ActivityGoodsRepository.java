package com.ztj.dichan.cust.appapi.repository.activity;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.cust.core.entity.activity.ActivityGoods;

/**
 * 
 * @author sily
 */
@Repository
public interface ActivityGoodsRepository extends PagingAndSortingRepository<ActivityGoods, Long> {

	List<ActivityGoods> findByActivityId(Long activityId);
}