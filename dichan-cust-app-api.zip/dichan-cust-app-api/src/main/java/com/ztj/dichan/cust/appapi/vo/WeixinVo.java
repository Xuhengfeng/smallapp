/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value="微信认证信息VO--小程序")
@Data
@EqualsAndHashCode(callSuper=true)
public class WeixinVo extends BaseValueObject{
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "微信-用户唯一标识")
	private String openid;
	
	@ApiModelProperty(value = "微信-会话密钥")
	private String sessionKey;
	
	@ApiModelProperty(value = "微信-用户在开放平台的唯一标识符")
	private String unionid;
	
	@ApiModelProperty(value = "认证key")
	private String authKey;

}
