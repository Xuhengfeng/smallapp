package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.BuildingService;
import com.ztj.dichan.cust.rule.request.buildnew.BuildRequest;
import com.ztj.dichan.cust.rule.request.buildnew.BuildingDyFhRequest;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.building.BuildingVo;
import com.ztj.dichan.cust.rule.response.building.DzDetailVo;
import com.ztj.dichan.cust.rule.response.building.HotBuildingVo;
import com.ztj.dichan.cust.rule.response.building.RentHouseVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author yincp
 */
@Api(value = "小区相关接口", description = "小区相关接口")
@RestController
@RequestMapping(value = "/build")
public class BuildingRest extends BaseCustRest {

	@Resource
	private BuildingService buildingService;

	@ApiOperation(value = "查询小区列表(搜索)", response = BuildingVo.class)
	@PostMapping(value = "/buildList")
	public RestResult<List<BuildingVo>> queryList(@RequestBody BuildRequest buildRequest) {
		List<BuildingVo> voList = buildingService.buildList(buildRequest);

		return RestResult.success(voList);
	}

	@ApiOperation(value = "查询小区列表(搜索)-总数量", response = BuildingVo.class)
	@PostMapping(value = "/buildListCount")
	public RestResult<CountVo> queryListCount(@RequestBody BuildRequest buildRequest) {
		CountVo countVo = buildingService.buildListCount(buildRequest);
		
		return RestResult.success(countVo);
	}

	@ApiOperation(value = "获取小区详情", response = BuildingDetailVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "sdid", value = "小区sdid", dataType = "long", paramType = "path", required = true) })
	@GetMapping(value = "/buildInfo/{scity}/{sdid}")
	public RestResult<BuildingDetailVo> getDetailInFo(@PathVariable("scity") String scity,
			@PathVariable("sdid") Long sdid) {
		BuildingDetailVo detailVo = buildingService.buildInfo(sdid, scity, getCurrentMemberIdAllowNull());

		return RestResult.success(detailVo);
	}

	@ApiOperation(value = "二手房列表", response = SecondHouseVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "sdid", value = "小区sdid", dataType = "long", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	@GetMapping(value = "/secondHouseList/{scity}/{sdid}")
	public RestResult<List<SecondHouseVo>> secondHouseList(@PathVariable("sdid") Long sdid,
			@PathVariable("scity") String scity, @RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {
		List<SecondHouseVo> recmdVoList = buildingService.secondHouseList(sdid, scity, pageNo, pageSize);
		
		return RestResult.success(recmdVoList);
	}

	@ApiOperation(value = "租房列表", response = RentHouseVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "sdid", value = "小区sdid", dataType = "long", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	@GetMapping(value = "/rentHouseList/{scity}/{sdid}")
	public RestResult<List<RentHouseVo>> rentHouseList(@PathVariable("sdid") Long sdid,
			@PathVariable("scity") String scity, @RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {
		List<RentHouseVo> recmdVoList = buildingService.rentHouseList(sdid, scity, pageNo, pageSize);

		return RestResult.success(recmdVoList);
	}

	@ApiOperation(value = "同小区二手房", response = SecondHouseVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "sdid", value = "小区sdid", dataType = "long", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	@GetMapping(value = "/same-used/{scity}/{sdid}")
	public RestResult<List<SecondHouseVo>> sameUsedHousing(@PathVariable("sdid") Long sdid,
			@PathVariable("scity") String scity, @RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {
		List<SecondHouseVo> recmdVoList = buildingService.secondHouseList(sdid, scity, pageNo, pageSize);
		
		return RestResult.success(recmdVoList);
	}

	@ApiOperation(value = "同小区租房", response = RentHouseVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "sdid", value = "小区sdid", dataType = "long", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	@GetMapping(value = "/same-rent/{scity}/{sdid}")
	public RestResult<List<RentHouseVo>> sameRentHousing(@PathVariable("sdid") Long sdid,
			@PathVariable("scity") String scity, @RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {
		List<RentHouseVo> recmdVoList = buildingService.rentHouseList(sdid, scity, pageNo, pageSize);

		return RestResult.success(recmdVoList);
	}

	@ApiOperation(value = "热门小区", response = HotBuildingVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	@GetMapping(value = "/hotBuilding/{scity}")
	public RestResult<List<HotBuildingVo>> hotBuilding(@PathVariable("scity") String scity,
			@RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {
		List<HotBuildingVo> hotList = buildingService.hotBuilding(scity, pageNo, pageSize);

		return RestResult.success(hotList);
	}

	/**
	 * 根据小区sdid获取小区详细
	 * 
	 * @param sdid
	 * @return
	 */
//	@ApiOperation(value = "获取小区-栋座-单元信息", response = BuildingDzdyDetailVo.class)
//	@ApiImplicitParams(value = {
//			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
//			@ApiImplicitParam(name = "sdid", value = "小区sdid", required = true, dataType = "int", paramType="path")})
//	@GetMapping(value = "/building/dzdy/{sdid}")
//	public RestResult<BuildingDzdyDetailVo> queryBuildingDzdyDetail(@PathVariable("sdid") Long sdid) {
//		
//		BuildingDzdyDetailVo vo = this.buildingService.queryBuildingDzdyDetail(sdid);
//		return RestResult.success(vo);
//
//	}

	@ApiOperation(value = "获取栋座列表", response = DzDetailVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码，必填", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "id", value = "小区id，必填", required = true, dataType = "int", paramType = "path"),
			@ApiImplicitParam(name = "pageNo", value = "当前页码，必填", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	@GetMapping(value = "/building/dz/{id}")
	public RestResult<List<DzDetailVo>> queryBuildingDz(@PathVariable("id") Integer id) {
		List<DzDetailVo> voList = this.buildingService.queryBuildingDz(id);
		
		return RestResult.success(voList);
	}

	/**
	 * 获取单元或房号信息列表,根据是否存在单元名称为依据
	 * 
	 * @param request
	 * @return
	 */
	@ApiOperation(value = "获取单元或房号列表")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true) })
	@PostMapping(value = "/building/dyfh")
	public RestResult<List<String>> queryBuildingDyFh(@RequestBody BuildingDyFhRequest request) {
		List<String> voList = this.buildingService.queryBuildingDyFh(request);

		return RestResult.success(voList);
	}
}