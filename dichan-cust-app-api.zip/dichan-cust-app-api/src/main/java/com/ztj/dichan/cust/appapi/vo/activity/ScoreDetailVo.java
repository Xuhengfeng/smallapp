package com.ztj.dichan.cust.appapi.vo.activity;

import java.util.ArrayList;
import java.util.List;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value = "积分明细")
@Data
@EqualsAndHashCode(callSuper = true)
public class ScoreDetailVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "当前剩余的积分")
	private Long currentScore;
	
	@ApiModelProperty(value = "当前年份")
	private Integer year;

	/**
	 * 流水列表
	 */
	@ApiModelProperty(value = "积分流水列表")
	private List<ScoreFollowRecordVo> recordVoList = new ArrayList<>();
}
