package com.ztj.dichan.cust.appapi.vo.consultant;

import com.ztj.dichan.cust.appapi.vo.BaseApiValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author yincp
 *
 */
@ApiModel(value = "返回问题简要信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class AnswerVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "问题Id")
	private Long contProblemId;

	@ApiModelProperty(value = "问题标题")
	private String problemTitle;

	

}