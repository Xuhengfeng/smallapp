/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ztj.dichan.cust.rule.request.EntrustRentRequest;
import com.ztj.dichan.cust.rule.request.RentHouseRequest;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.request.contract.HouseContrastRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRecmdRequest;
import com.ztj.dichan.cust.rule.response.house.RentHouseContrastDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseRecmdVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;



/**
 * @author sily
 *
 */
@FeignClient(name = "rentHouseServiceClient", url= "${cust.service.url}", fallback = HouseServiceClientFallBack.class)
public interface RentHouseServiceClient {

	@RequestMapping(method = RequestMethod.POST, value = "/rentHouse/queryList")
	public List<RentHouseVo> queryList(@RequestBody RentHouseRequest rentHouseRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@RequestMapping(method = RequestMethod.POST, value = "/rentHouse/queryListCount")
	public CountVo queryListCount(RentHouseRequest rentHouseRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@GetMapping(value = "/rentHouse/getDetailInfo")
	public RentHouseDetailVo getDetailInfo(@RequestHeader(value = "scity", required = true) String scity,
			@RequestParam(name="sdid", required = true) Long sdid);
	
	@RequestMapping(method = RequestMethod.POST, value = "/rentHouse/queryRecmdList")
	public List<RentHouseRecmdVo> queryRecmdList(HouseRecmdRequest houseRecmdRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@PostMapping(value = "/rentHouse/rimHousing")
	public List<RentHouseVo> rimHousing(RimHouseRequest rimHouseRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	@PostMapping(value = "/house/houseContrast")
	public List<RentHouseContrastDetailVo> houseContrast(HouseContrastRequest contrastRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@PostMapping(value = "/rentHouse/entrustRentList")
	public List<RentHouseVo> queryEntrustRentList(@RequestBody EntrustRentRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	
}
