package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.core.enums.GenderEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author sily
 */
@ApiModel(value = "会员信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class MemberVo extends BaseValueObject {
	
	private static final long serialVersionUID = 1L;

	/**
	 * 昵称
	 */
	@ApiModelProperty(value = "昵称")
	private String nickname;

	/**
	 * 性别
	 */
	@ApiModelProperty(value = "性别标识")
	private GenderEnum gender;

	/**
	 * 用户编码
	 */
	@ApiModelProperty(value = "用户编码")
	private String code;

	/**
	 * 头像链接地址
	 */
	@ApiModelProperty(value = "头像链接地址")
	private String headImage;
	
	/**
	 * 手机号
	 */
	@ApiModelProperty(value = "手机号码")
	private String mobile;
	
	@ApiModelProperty(value = "聊天账户")
	private String easemobUsername;
	
	@ApiModelProperty(value = "聊天密码")
	private String easemobPassword;
	
	@ApiModelProperty(value = "经纪人聊天appKey")
	private String brokerAppKey;
	
}
