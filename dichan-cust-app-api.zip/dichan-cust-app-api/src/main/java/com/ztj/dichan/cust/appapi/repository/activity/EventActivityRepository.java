package com.ztj.dichan.cust.appapi.repository.activity;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.cust.core.entity.activity.EventActivity;
import com.ztj.dichan.cust.core.enums.EventEnum;

/**
 * 
 * @author sily
 */
@Repository
public interface EventActivityRepository extends PagingAndSortingRepository<EventActivity, Long> {
	
	List<EventActivity> findByEvent(EventEnum event);
}