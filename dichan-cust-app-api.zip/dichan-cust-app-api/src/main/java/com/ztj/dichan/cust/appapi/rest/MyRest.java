package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.BrokerCollectionService;
import com.ztj.dichan.cust.appapi.service.BrokerEvaluateService;
import com.ztj.dichan.cust.appapi.service.ConsultantService;
import com.ztj.dichan.cust.appapi.service.MyService;
import com.ztj.dichan.cust.appapi.service.ScoreService;
import com.ztj.dichan.cust.appapi.vo.broker.BrokerContactVo;
import com.ztj.dichan.cust.appapi.vo.consultant.MyConsultVo;
import com.ztj.dichan.cust.appapi.vo.my.CommentVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author yincp
 */
@Api(value = "我的相关接口", description = "我的相关接口*")
@RestController
@RequestMapping(value = "/my")
public class MyRest extends BaseCustRest {
	@Resource
	private MyService myService;

	@Resource
	private BrokerCollectionService brokerCollectionService;
	
	@Resource
	private BrokerEvaluateService brokerEvaluateService;
	
	@Resource
	private ConsultantService consultantService;
	
	@Resource
	private ScoreService scoreService;
	
	
	@ApiOperation(value="查询我的评论",response=CommentVo.class)
	@GetMapping(value = "/comment")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query")})
	public RestResult<List<CommentVo>> queryBrokerEvaluates(@RequestParam(name="pageNo", required = true)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
			Long memberId =getCurrentMemberId();
			List<CommentVo> result =  myService.queryMyComment(memberId, pageNo, pageSize);
		return RestResult.success(result);
	
	}
	
	
	
	@ApiOperation(value = "我的经纪人列表", response = BrokerContactVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType = "query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	@GetMapping(value = "/collectionList")
	public RestResult<List<BrokerContactVo>> queryCollectionList(@RequestParam(name="pageNo", required = true)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		List<BrokerContactVo> voList = myService.queryList(getCurrentMemberId(), pageNo, pageSize);
		return RestResult.success(voList);
	}
	
	
	@ApiOperation(value = "我的咨询", response = MyConsultVo.class)
	@GetMapping(value = "/my_problem")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query")})
	public RestResult<List<MyConsultVo>> myProblem(@RequestParam(name="pageNo", required = true)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		    Long memberId =getCurrentMemberId();
		    List<MyConsultVo>  result = consultantService.myProblem(memberId, pageNo, pageSize);
		return RestResult.success(result);
	}
}