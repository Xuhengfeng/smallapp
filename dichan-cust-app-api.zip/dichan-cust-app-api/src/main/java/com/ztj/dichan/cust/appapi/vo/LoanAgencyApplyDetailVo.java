/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointDetailHouseVo;
import com.ztj.dichan.cust.core.enums.AgencyApplicantTypeEnum;
import com.ztj.dichan.cust.core.enums.ApplicationStatusEnum;
import com.ztj.dichan.cust.core.enums.LoanTypeEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "贷款申请信息详情")
@Data
@EqualsAndHashCode(callSuper= true)
public class LoanAgencyApplyDetailVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	/**
	 * 二手房委托申请id
	 */
	@ApiModelProperty(value = "贷款代办申请id")
	private Long id;

	/**
	 * 联系人名字
	 */
	@ApiModelProperty(value = "名字")
	private String name;



	/**
	 *城市
	 */
	@ApiModelProperty(value = "城市")
	private String cityCode;
	
	@ApiModelProperty(value = "城市名称")
	private String cityName;

	/**
	 *地址
	 */
	@ApiModelProperty(value = "地址")
	private String address;
	
	/**
	 * 电话
	 */
	@ApiModelProperty(value = "电话")
	private String phone;
	
	/**
	 * 小区名字
	 */
	@ApiModelProperty(value = "小区名字")
	private String buildingName;
	
	@ApiModelProperty(value = "栋号")
	private String buildNum;
	
	@ApiModelProperty(value = "单元号")
	private String unitNum;
	
	@ApiModelProperty(value = "房号")
	private String roomNum;
	
	/**
	 * 申请时间
	 */
	@ApiModelProperty(value = "申请时间")
	private String applicationTime;
	
	@ApiModelProperty(value = "代办类型(LONA=贷款,TRANSFER=过户,DETENTION=解押,DUTIABLE=报税,CONTRACT=签合同,OTHER=其他综合)")
	@Enumerated(EnumType.STRING)
	private LoanTypeEnum loanAgencyType;
	
	@ApiModelProperty(value = "代办业务类型名称")
	private String loanAgencyTypeName;
	
	/**
	 *状态 
	 */
	@ApiModelProperty(value = "审核状态")
	@Enumerated(EnumType.STRING)
	private ApplicationStatusEnum status;
	
	/**
	 * 会员ID
	 */
	@ApiModelProperty(value = "会员id")
	private Long memberId;
	
	/**
	 * 经纪人ID
	 */
	@ApiModelProperty(value = "经纪人id")
	private Long brokerId;
	
	@ApiModelProperty(value = "申请人类型[卖方=SELLER,买方=PURCHASER,推荐人=RECMD_MAN]")
	private AgencyApplicantTypeEnum applicantType;
	
	
	@ApiModelProperty(value = "所属经纪人")
	private ApplyHouseBrokerVo broker;
		
	@ApiModelProperty(value = "二手房源信息")
	private AppointDetailHouseVo house;
}
