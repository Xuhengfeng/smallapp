package com.ztj.dichan.cust.appapi.jiguang.external;

import com.alibaba.fastjson.JSONArray;

public class JiguangServiceClientFallBack implements JiguangServiceClient {

	
	
	@Override
	public JSONArray regUser(JSONArray request, String token) {
		// TODO Auto-generated method stub
		return null;
	}

}
