package com.ztj.dichan.cust.appapi.handler;

import java.nio.file.AccessDeniedException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ztj.common.constant.ReturnCode;
import com.ztj.common.exception.BizException;
import com.ztj.common.exception.NoLoginException;
import com.ztj.common.exception.ValidateException;
import com.ztj.dichan.cust.appapi.exception.ResourceNotFoundException;
import com.ztj.dichan.cust.appapi.exception.UserDefinedException;
import com.ztj.dichan.cust.core.constant.RestResult;

/**
 * 如果DefaultExceptionHandler和RestExceptionHandler设置同样的@Order(Ordered.HIGHEST_PRECEDENCE),DefaultExceptionHandler的优先级更高
 * 
 * @author test01
 */
@ControllerAdvice
public class DefaultExceptionHandler {
	private static Logger logger = LoggerFactory.getLogger(DefaultExceptionHandler.class);

	private static final String REC_NOLONGIN_400 = "400";

	/**
	 * 
	 * @param e
	 * @return
	 */
	@ResponseBody
	@ExceptionHandler(value = Exception.class)
	@ResponseStatus(HttpStatus.OK)
	public RestResult handleException(Exception e) {
		RestResult result = RestResult.success();

		if (e instanceof IllegalArgumentException || e instanceof IllegalStateException) {
			result.setStatus(ReturnCode.REC_2.getCode());
			result.setMsg(e.getMessage());
		} else if (e instanceof ValidateException) {
			ValidateException validateException = (ValidateException) e;

			result.setStatus(validateException.getErrorCode());
			result.setMsg(validateException.getErrorMsg());
		} else if (e instanceof NoLoginException) {
			logger.warn("用户未登陆无权限访问!!");
			
			result.setStatus(REC_NOLONGIN_400);
			result.setMsg(e.getMessage());
		} else if (e instanceof AccessDeniedException) {
			result.setStatus(ReturnCode.REC_NEGATIVE_1.getCode());
			result.setMsg("禁止访问");
		} else if (e instanceof ResourceNotFoundException) {
			ResourceNotFoundException resourceNotFound = (ResourceNotFoundException) e;

			result.setStatus(resourceNotFound.getErrCode());
			result.setMsg(resourceNotFound.getMessage());
		} else if (e instanceof UserDefinedException) {
			UserDefinedException resourceNotFound = (UserDefinedException) e;

			result.setStatus(resourceNotFound.getErrorCode());
			result.setMsg(resourceNotFound.getMessage());
		} else if (e instanceof BizException) {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		} else {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		}
		
		if (e instanceof NoLoginException) {
			logger.warn("用户未登陆无权限访问!!");
		} else {
			logger.error("请求出错了", e);
		}

		return result;
	}
}