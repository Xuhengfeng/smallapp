/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author yincp
 *
 */
@ApiModel(value = "取消贷款申请参数",description="取消贷款申请参数")
@Data
@EqualsAndHashCode(callSuper = true)
public class LoanAgencyApplyCancelRequest extends BaseApiRequest {
	
	private static final long serialVersionUID = -4768385584042114126L;

	@ApiModelProperty(value = "委托申请Id，必填",required=true)
	private Long id;
	
	@ApiModelProperty(value = "取消原因",required=false)
	private String cancelCause; 
}
