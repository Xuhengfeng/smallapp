package com.ztj.dichan.cust.appapi.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BaseTask {
	protected Logger logger = LoggerFactory.getLogger(getClass());
}
