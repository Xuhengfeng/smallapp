package com.ztj.dichan.cust.appapi.service.component;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

@Component
public class DownloadImageComponent extends BaseAppComponent {

	@Resource
	private OssComponent ossComponent;

	public void handleImage(String filePath, HttpServletResponse response) {
		logger.info("下载图片时传入的filePath={}", filePath);

		byte[] buffer = new byte[1024];
		BufferedInputStream bis = null;
		try {

			bis = this.ossComponent.downloadImage(filePath);
			OutputStream os = response.getOutputStream();
			int i = bis.read(buffer);
			while (i != -1) {
				os.write(buffer, 0, i);
				i = bis.read(buffer);
			}
		} catch (Exception e) {
			throw new RuntimeException("下载图片失败,filePath=" + filePath, e);
		} finally {

			if (bis != null) {
				try {
					bis.close();
				} catch (IOException e) {
					logger.error("BufferedInputStream 关闭失败>>>", e);
				}
			}
		}
	}
}
