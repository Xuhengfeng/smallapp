/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import com.ztj.dichan.cust.rule.response.EmployeeDetailVo;

/**
 * @author sily
 *
 */
public class EmployeeServiceClientFallBack implements EmployeeServiceClient {

	@Override
	public EmployeeDetailVo queryBroker(String scity, Integer empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeDetailVo queryEmployee(String scity, String emplName) {
		// TODO Auto-generated method stub
		return null;
	}

	


}