package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.request.SubProblemRequest;
import com.ztj.dichan.cust.appapi.service.ConsultantService;
import com.ztj.dichan.cust.appapi.vo.consultant.ConcernConsultVo;
import com.ztj.dichan.cust.appapi.vo.consultant.ConsultantInfoVo;
import com.ztj.dichan.cust.appapi.vo.consultant.ConsultantVo;
import com.ztj.dichan.cust.appapi.vo.consultant.HotConsultVo;
import com.ztj.dichan.cust.appapi.vo.consultant.MyConsultVo;
import com.ztj.dichan.cust.appapi.vo.consultant.ProblemInfoVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author yincp
 *
 */
@Api(value = "咨询接口",description="咨询接口")
@RestController
@RequestMapping(value = "/consultant")
public class ConsultantRest extends BaseCustRest {

	@Resource
	private ConsultantService consultantService;


	@ApiOperation(value = "顾问推荐列表", response = ConsultantVo.class)
	@GetMapping(value = "/remd")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true)})
	public RestResult<List<ConsultantVo>> remdList() {
		 List<ConsultantVo> list = consultantService.recommendConsultant();
		return RestResult.success(list);

	}
	
	
	@ApiOperation(value = "顾问列表", response = ConsultantVo.class)
	@GetMapping(value = "/list")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true)})
	public RestResult<List<ConsultantVo>> consultantList() {

		List<ConsultantVo> list = consultantService.consultantList();

		return RestResult.success(list);
 
	}
	
	@ApiOperation(value = "热门咨询列表", response = HotConsultVo.class)
	@GetMapping(value = "/hot")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true)})
	public RestResult<List<HotConsultVo>> hotConsultList() {
		 List<HotConsultVo> list = consultantService.hotConsultList();
		return RestResult.success(list);
	}
	
	
	@ApiOperation(value = "提问/向他咨询", response = String.class)
	@PostMapping(value = "/sub_problem")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true)})
	public RestResult<String> submitProblem(@RequestBody SubProblemRequest request ) {
		 Long memberId =getCurrentMemberId();
		 request.setMemberId(memberId);
		 consultantService.submitProblem(request);
		return RestResult.success(" 操作成功了");
	}
	
	
	@ApiOperation(value = "我的提问", response = MyConsultVo.class)
	@GetMapping(value = "/my_problem")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query")})
	public RestResult<List<MyConsultVo>> myProblem(@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		    Long memberId =getCurrentMemberId();
		    List<MyConsultVo>  result = consultantService.myProblem(memberId, pageNo, pageSize);
		return RestResult.success(result);
	}
	
	
	@ApiOperation(value = "我关注的问题", response = ConcernConsultVo.class)
	@GetMapping(value = "/my_concern")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true)})
	public RestResult<List<ConcernConsultVo>> myConcern() {
		    Long memberId =getCurrentMemberId();
		    List<ConcernConsultVo>  result = consultantService.myConcern(memberId);
		return RestResult.success(result);
	}
	
	
	@ApiOperation(value = "关注/取消关注", response = ConcernConsultVo.class)
	@PutMapping(value = "/concern")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "contProblemId", value = "问题Id", dataType = "string", paramType = "query", required = true),
			@ApiImplicitParam(name = "state", value = "状态：关注 concern,取消关注 cancel", dataType = "string", paramType = "query", required = true)})
	public RestResult<String> concernOrCancel(@RequestParam(name = "contProblemId", required = true) Long contProblemId,@RequestParam(name = "state", required = true) String state ) {
		    Long memberId =getCurrentMemberId();
		    consultantService.concernOrCancel(memberId,contProblemId,state );
		return RestResult.success("操作成功了");
	}
	
	@ApiOperation(value = "采纳", response = ConcernConsultVo.class)
	@PutMapping(value = "/adopt")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true)})
	public RestResult<String> adopt(@RequestParam(name = "contProblemId", required = true) Long contProblemId,@RequestParam(name = "problemAnswerId", required = true) Long problemAnswerId ) {
		    consultantService.adopt(problemAnswerId);
		return RestResult.success("操作成功了");
	}
	
	
	
	@ApiOperation(value = "顾问详情", response = ConsultantInfoVo.class)
	@GetMapping(value = "/info")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true)})
	public RestResult<ConsultantInfoVo> consultantInfo(@RequestParam(name = "employeeId", required = true) Long employeeId ) {
		ConsultantInfoVo  result = consultantService.consultantInfo(employeeId);
		return  RestResult.success(result);
	}
	
	
	
	
	@ApiOperation(value = "问题详情", response = ProblemInfoVo.class)
	@GetMapping(value = "/problem_info")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true)})
	public RestResult<ProblemInfoVo> problemInfo(@RequestParam(name = "contProblemId", required = true) Long contProblemId ) {
		Long memberId = getCurrentMemberIdAllowNull();
		ProblemInfoVo result = consultantService.problemInfo(memberId,contProblemId);
		return RestResult.success(result);
	}
	
	
	
}
