package com.ztj.dichan.cust.appapi.service.component;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.ztj.dichan.cust.appapi.constant.SystemConstant;

/**
 * 
 * @author sily
 */
@Component
public class BaseAppComponent {
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	protected SystemConstant systemConstant;

	@Resource
	protected RedisTemplate redisTemplate;
}