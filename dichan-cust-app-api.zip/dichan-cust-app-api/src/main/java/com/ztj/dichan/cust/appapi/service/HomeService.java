package com.ztj.dichan.cust.appapi.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.vo.HomeDataVo;
import com.ztj.dichan.cust.appapi.vo.StatisticsInfoVo;
import com.ztj.dichan.cust.appapi.vo.infocontent.InfoContentVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.rule.response.building.HotBuildingVo;

/**
 * 
 * @author test01
 */
@Service
public class HomeService extends BaseAppService {

	@Resource
	private InfoContentService infoContentService;

	@Resource
	private StatisticalService statisticalService;

	@Resource
	private BuildingService buildingService;

	/**
	 * 
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public HomeDataVo fetchHomeData(Integer pageNo, Integer pageSize) {
		String scity = RequestContextHolder.getCityCode();

		validatePageRequest(pageNo, pageSize);

		// 首页热门推荐
		List<InfoContentVo> hotInfoContentVoList = infoContentService.queryList("1001", pageNo, pageSize);

		// 房源成交量
		StatisticsInfoVo statisticsInfoVo = statisticalService.querCurrentMonthStatistics(scity);

		// 热门小区
		List<HotBuildingVo> hotBuildingVolist = buildingService.hotBuilding(scity, pageNo, pageSize);

		// 首页新房推荐
		List<InfoContentVo> newInfoContentVoList = infoContentService.queryList("1002", pageNo, pageSize);

		HomeDataVo homeDataVo = new HomeDataVo();
		homeDataVo.setHotInfoContentVoList(hotInfoContentVoList);
		homeDataVo.setStatisticsInfoVo(statisticsInfoVo);
		homeDataVo.setHotBuildingVolist(hotBuildingVolist);
		homeDataVo.setNewInfoContentVoList(newInfoContentVoList);

		return homeDataVo;
	}
}