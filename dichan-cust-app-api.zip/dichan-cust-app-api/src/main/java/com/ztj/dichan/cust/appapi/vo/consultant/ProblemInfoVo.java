package com.ztj.dichan.cust.appapi.vo.consultant;


import java.util.List;

import com.ztj.dichan.cust.appapi.vo.BaseApiValueObject;
import com.ztj.dichan.cust.core.enums.ConcernStatusEnum;
import com.ztj.dichan.cust.core.enums.WhetherAdoptEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author yincp
 *
 */
@ApiModel(value = "问题详情")
@Data
@EqualsAndHashCode(callSuper = true)
public class ProblemInfoVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "问题Id")
	private Long contProblemId;

	@ApiModelProperty(value = "问题标题")
	private String problemTitle;
	
	@ApiModelProperty(value = "问题描述")
	private String  problemDescribe;

	@ApiModelProperty(value = "提问标签")
	private String label;
	
	@ApiModelProperty(value = "分类名称")
	private String classifyName;
	
	@ApiModelProperty(value = "会员Id")
	private Long memberId;

	@ApiModelProperty(value = "会员名称")
	private String memberName;
	
	@ApiModelProperty(value = "回答数量")
	private Long answerNum;
	
	@ApiModelProperty(value = "发布时间")
	private String pubTime;
	
	@ApiModelProperty(value = "关注状态，YES=已关注；NO=未关注")
	private ConcernStatusEnum concernStatus;
	
	@ApiModelProperty(value = "是否采纳，wase_yes=是；wase_no=否")
	private WhetherAdoptEnum whetherAdopt;
	
	
	private List<ProblemAnswerVo> problemAnswers;
	
}