/**
 * 
 */
package com.ztj.dichan.cust.appapi.request.member;

import com.ztj.dichan.cust.appapi.request.BaseApiRequest;
import com.ztj.dichan.cust.core.enums.GenderEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author liuweichen
 *
 */
@ApiModel(value = "更改性别")
@Data
@EqualsAndHashCode(callSuper = true)
public class UpdateGenderRequest extends BaseApiRequest {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "男或者女")
	private GenderEnum gender;

}
