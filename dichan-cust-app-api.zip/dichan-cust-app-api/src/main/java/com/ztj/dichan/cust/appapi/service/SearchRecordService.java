package com.ztj.dichan.cust.appapi.service;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.ztj.common.constant.ReturnCode;
import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.core.entity.SearchRecord;
import com.ztj.dichan.cust.core.enums.SearchType;
import com.ztj.dichan.cust.core.repository.SearchRecordRepository;

/**
 * 
 * @author liuweichen
 *
 */
@Service
@Transactional
public class SearchRecordService extends BaseAppService {
	
	
	@Resource
	private SearchRecordRepository searchRecordRepository;
	
	
	/**
	 * 获取搜索关键字记录列表
	 * @param memberId
	 * @param searchType
	 * @return
	 */
	
	public List<String> searchRecordList(Long memberId, SearchType searchType) {
		if (memberId == null || memberId.intValue() <= 0) {
			return new ArrayList<>(0);
		}
		List<SearchRecord> list = searchRecordRepository.findTop20ByMemberIdAndSearchTypeOrderBySearchTimeDesc(memberId, searchType);
		List<String> voList = new ArrayList<>();
		try {
			
			for (SearchRecord searchRecord : list){
				if (!voList.contains(searchRecord.getKeyword())) {
					voList.add(searchRecord.getKeyword());
				}
				if (voList.size() >= 10) {
					break;
				}
			}
			
			return voList;
			
		} catch (Exception e) {
			throw new BizException(ReturnCode.REC_0.getCode(), e);		
		}
		
		
	}
	
	/**
	 * 获取搜索关键字记录列表
	 * @param memberId
	 * @return
	 */
	
	public List<String> searchRecordList(Long memberId) {
		
		if (memberId == null || memberId <= 0) {
			return new ArrayList<String>(0);
		}
		List<SearchRecord> list = searchRecordRepository.findTop20ByMemberIdOrderBySearchTimeDesc(memberId);
		List<String> voList = new ArrayList<>();
		try {
			for (SearchRecord searchRecord : list){
				if (!voList.contains(searchRecord.getKeyword())) {
					voList.add(searchRecord.getKeyword());
				}
				if (voList.size() >= 10) {
					break;
				}
			}
			
			return voList;
			
		} catch (Exception e) {
			throw new BizException(ReturnCode.REC_0.getCode(), e);		
		}
		
		
	}
	
	
	public void saveSearchRecord(Long memberId,String keyword,SearchType searchType) {
		if (memberId == null || memberId <= 0) {
			return;
		}
		SearchRecord searchRecord = searchRecordRepository.findTop1ByMemberIdAndKeywordAndSearchType(memberId, keyword,searchType);
		
		if (searchRecord == null) {
			searchRecord = new SearchRecord();
			searchRecord.setKeyword(keyword);
			searchRecord.setMemberId(memberId);
			searchRecord.setSearchType(searchType);
			searchRecord.setSearchTime(LocalDateTime.now());
			searchRecord.setSearchNum(1);
		} else {
			searchRecord.setSearchNum(searchRecord.getSearchNum()+1);
			searchRecord.setSearchTime(LocalDateTime.now());
		}
		searchRecordRepository.save(searchRecord);
		
	}
	
	public String getSearchKeyword(Long memberId) {
		if (memberId == null || memberId <= 0) {
			return null;
		}
		SearchRecord searchRecord = searchRecordRepository.findTop1ByMemberIdOrderBySearchTimeDesc(memberId);
		
		if (searchRecord != null) {
			return searchRecord.getKeyword();
		}
		return null;
	}
	
	public void deleteAllSearchKeyword(Long memberId) {
		if (memberId == null || memberId <= 0) {
			return;
		}
		searchRecordRepository.deleteByMemberId(memberId);
	}
	
	public void deleteAllSearchKeyword(Long memberId,SearchType searchType) {
		if (memberId == null || memberId <= 0 || searchType == null) {
			return;
		}
		searchRecordRepository.deleteByMemberIdAndSearchType(memberId,searchType);
	}
	

}
 