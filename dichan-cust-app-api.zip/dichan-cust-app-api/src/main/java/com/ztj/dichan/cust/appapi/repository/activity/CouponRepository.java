package com.ztj.dichan.cust.appapi.repository.activity;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.cust.core.entity.activity.Coupon;
import com.ztj.dichan.cust.core.enums.CouponStatusEnum;

/**
 * 
 * @author sily
 */
@Repository
public interface CouponRepository extends PagingAndSortingRepository<Coupon, Long> {

	Coupon findByCode(String code);

	Coupon findByOwnMemberIdAndCode(Long ownMemberId, String code);

	List<Coupon> findByIdIn(List<Long> idList);

	List<Coupon> findByCodeIn(List<String> codeList);

	List<Coupon> findByEndDateTimeLessThanAndStatus(LocalDateTime endDateTime, CouponStatusEnum status);

	Page<Coupon> findByOwnMemberIdAndStatus(Long memberId, CouponStatusEnum status, Pageable pageable);

	@Query(value = "SELECT count(1) from coupon c WHERE c.end_date_time < now() + INTERVAL 2 DAY AND c.own_member_id=?", nativeQuery = true)
	Long countCoupon(Long memberId);
}