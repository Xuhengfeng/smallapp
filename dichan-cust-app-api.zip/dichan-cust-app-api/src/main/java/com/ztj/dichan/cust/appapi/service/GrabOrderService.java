package com.ztj.dichan.cust.appapi.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.appapi.easemob.EasemobConfig;
import com.ztj.dichan.cust.appapi.easemob.external.EasemobUserServiceClient;
import com.ztj.dichan.cust.appapi.easemob.service.EasemobUserService;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.external.BuildingServiceClient;
import com.ztj.dichan.cust.appapi.external.EmployeeServiceClient;
import com.ztj.dichan.cust.appapi.external.HouseServiceClient;
import com.ztj.dichan.cust.appapi.external.ShopServiceClient;
import com.ztj.dichan.cust.core.entity.AppointHouse;
import com.ztj.dichan.cust.core.entity.AppointHouseRecord;
import com.ztj.dichan.cust.core.entity.HouseEntrustApply;
import com.ztj.dichan.cust.core.entity.LoanAgencyApply;
import com.ztj.dichan.cust.core.entity.StatisticsInfo;
import com.ztj.dichan.cust.core.repository.AppointHouseRecordRepository;
import com.ztj.dichan.cust.core.repository.AppointHouseRepository;
import com.ztj.dichan.cust.core.repository.HouseEntrustApplyRepository;
import com.ztj.dichan.cust.core.repository.LoanAgencyApplyRepository;
import com.ztj.dichan.cust.core.repository.MemberRepository;
import com.ztj.dichan.cust.core.repository.StatisticsInfoRepository;
import com.ztj.dichan.cust.rule.request.ShopRequest;
import com.ztj.dichan.cust.rule.response.EmployeeDetailVo;
import com.ztj.dichan.cust.rule.response.NearbyBrokerVo;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;

/**
 * 
 * @author yincp
 */
@Service
@Transactional
public class GrabOrderService extends BaseAppService {

	@Resource
	private AppointHouseRepository houseRepository;

	@Resource
	private LoanAgencyApplyRepository loanAgencyApplyRepository;

	@Autowired
	private ShopServiceClient shopServiceClient;

	@Resource
	private BrokerServiceClient brokerServiceClient;

	@Resource
	private EmployeeServiceClient employeeServiceClient;

	@Resource
	private BuildingServiceClient buildingServiceClient;

	@Resource
	private EasemobUserServiceClient easemobUserServiceClient;

	@Resource
	private EasemobUserService easemobUserService;

	@Resource
	private MemberRepository memberRepository;

	@Resource
	private EasemobConfig easemobConfig;

	@Resource
	private HouseServiceClient houseServiceClient;

	@Resource
	private StatisticsInfoRepository statisticsInfoRepository;

	@Resource
	private HouseEntrustApplyRepository houseEntrustApplyRepository;

	@Resource
	private AppointHouseRecordRepository appointRepository;

	public void agencyTask() {
		try {
			PageRequest pageRequest = validateAndFetchPageRequestWithoutMaxCount(1, 100, "createDateTime");

			Page<LoanAgencyApply> result = loanAgencyApplyRepository.queryRobbings("notNull", pageRequest);

			// logger.info("超过20分钟为抢房源数量为{}",result.getTotalElements());

			result.getContent().stream().forEach(rb -> {
				sendMessage(rb.getCityCode(), Integer.parseInt(rb.getBrokerId() + ""), "你的订单因超时未处理，已流入抢单列表中！");

				loanAgencyApplyRepository.updateBroker(rb.getId());

				if (rb.getBuildingSdid() == null) {
					// logger.info("该代办事项单找不到小区id===={}",rb.getId());
					return;
				}

				BuildingDetailVo detailVo = buildingServiceClient.buildInfo(rb.getBuildingSdid(), rb.getCityCode());

				ShopRequest shopRequest = new ShopRequest();
				shopRequest.setPx(detailVo.getPx());
				shopRequest.setPy(detailVo.getPy());
				shopRequest.setScity(detailVo.getScity());

				// 查询经纪人经纬度附近的门店
				List<NearbyBrokerVo> nearbys = shopServiceClient.queryNearbyBroker(shopRequest, detailVo.getScity());

				StringBuffer depIds = new StringBuffer();

				if (nearbys != null && nearbys.size() > 0) {
					for (NearbyBrokerVo nb : nearbys) {
						Integer id = nb.getId();
						depIds.append(id + ",");

						sendMessage(detailVo.getScity(), nb.getEmplID(), "你有新的可抢房源");
					}

					String depId = depIds.substring(0, depIds.length() - 1).toString();

					loanAgencyApplyRepository.updateRobbingDeptId(depId, rb.getId());
				}
			});
		} catch (Exception e) {
			throw new BizException(e);
		}
	}

	public void appointTask() {
		try {
			PageRequest pageRequest = validateAndFetchPageRequestWithoutMaxCount(1, 100, "createDateTime");
			Page<AppointHouseRecord> result = appointRepository.queryRobbings("", "notNull", pageRequest);
			
			logger.info("超过20分钟为抢房源数量为{}", result.getTotalElements());
			
			result.getContent().stream().forEach(rb -> {
				sendMessage(rb.getScity(), Integer.parseInt(rb.getBrokerId() + ""), "你的订单因超时未处理，已流入抢单列表中！");
				
				appointRepository.updateBroker(rb.getId());
				
				List<AppointHouse> houses = houseRepository.findByRecordId(rb.getId());
				
				for (AppointHouse appointHouse : houses) {
					HouseDetailVo detailVo = houseServiceClient.getDetailInfo(appointHouse.getScity(),
							appointHouse.getHouseSdid());
					
					ShopRequest shopRequest = new ShopRequest();
					shopRequest.setPx(detailVo.getPx());
					shopRequest.setPy(detailVo.getPy());
					shopRequest.setScity(detailVo.getScity());

					// 查询经纪人经纬度附近的门店
					List<NearbyBrokerVo> nearbys = shopServiceClient.queryNearbyBroker(shopRequest,
							detailVo.getScity());
					
					StringBuffer depIds = new StringBuffer();
					if (nearbys != null && nearbys.size() > 0) {
						for (NearbyBrokerVo nb : nearbys) {
							Integer id = nb.getId();
							depIds.append(id + ",");
							// JpushUtil.sendToAll("有新的抢单", "有新的抢单列表", "点击", "");
							sendMessage(detailVo.getScity(), nb.getEmplID(), "你有新的可抢房源");
							
							logger.info("有{}条待抢房源", nearbys.size());
						}
						
						String depId = depIds.substring(0, depIds.length() - 1).toString();
						
						appointRepository.updateRobbingDeptId(depId, rb.getId());
					}
				}
			});
		} catch (Exception e) {
			throw new BizException(e);
		}
	}

	public void rentSellTask() {
		try {
			PageRequest pageRequest = validateAndFetchPageRequestWithoutMaxCount(1, 100, "createDateTime");
			
			Page<HouseEntrustApply> result = houseEntrustApplyRepository.queryRobbings("notNull", pageRequest);
			
			logger.info("超过20分钟为抢房源数量为{}", result.getTotalElements());
			
			result.getContent().stream().forEach(rb -> {
				sendMessage(rb.getCityCode(), Integer.parseInt(rb.getBrokerId() + ""), "你的订单因超时未处理，已流入抢单列表中！");
				
				houseEntrustApplyRepository.updateBroker(rb.getId());
				
				if (rb.getBuildingSdid() == null) {
					return;
				}

				BuildingDetailVo detailVo = buildingServiceClient.buildInfo(rb.getBuildingSdid(), rb.getCityCode());
				ShopRequest shopRequest = new ShopRequest();
				shopRequest.setPx(detailVo.getPx());
				shopRequest.setPy(detailVo.getPy());
				shopRequest.setScity(detailVo.getScity());

				// 查询经纪人经纬度附近的门店
				List<NearbyBrokerVo> nearbys = shopServiceClient.queryNearbyBroker(shopRequest, detailVo.getScity());

				logger.info("shopRequest====={},城市是{}", JSON.toJSONString(shopRequest), detailVo.getScity());

				StringBuilder depIds = new StringBuilder();

				if (nearbys != null && nearbys.size() > 0) {
					for (NearbyBrokerVo nb : nearbys) {
						Integer id = nb.getId();
						depIds.append(id + ",");
						// JpushUtil.sendToAll("有新的抢单", "有新的抢单列表", "点击", "");
						sendMessage(detailVo.getScity(), nb.getEmplID(), "你有新的可抢房源");
						
						logger.info("有{}条待抢房源", nearbys.size());
					}

					String depId = depIds.substring(0, depIds.length() - 1).toString();

					houseEntrustApplyRepository.updateRobbingDeptId(depId, rb.getId());
				}
			});
		} catch (Exception e) {
			throw new BizException(e);
		}
	}

	public void lastMonthHouse() {
		String result = houseServiceClient.lastMonth();

		JSONArray array = JSON.parseObject(result, JSONArray.class);

		if (array == null || array.isEmpty()) {
			logger.error("没有查询到上个月售出房源数据 === >> {}", result);
			return;
		}

		try {
			array.forEach(jsonObj -> {
				JSONObject resultJson = (JSONObject) jsonObj;
				StatisticsInfo statisticsInfo = null;
				Integer suiteCount = Integer.parseInt(String.valueOf(resultJson.get("suiteCount")));
				String cityCode = String.valueOf(resultJson.get("cityCode"));
				String cityName = String.valueOf(resultJson.get("cityName"));
				Double avgPrice = Double.parseDouble(String.valueOf(resultJson.get("avgPrice")));
				Integer year = Integer.parseInt(String.valueOf(resultJson.get("year")));
				Integer month = Integer.parseInt(String.valueOf(resultJson.get("month")));
				statisticsInfo = statisticsInfoRepository.findByCityCodeAndYearAndMonth(cityCode, year, month);

				if (statisticsInfo != null) {
					statisticsInfo.setSuiteCount(suiteCount);
					statisticsInfo.setAvgPrice(avgPrice);
				} else {
					statisticsInfo = new StatisticsInfo();
					statisticsInfo.setTitle(cityName);
					statisticsInfo.setSuiteCount(suiteCount);
					statisticsInfo.setCityCode(cityCode);
					statisticsInfo.setAvgPrice(avgPrice);
					statisticsInfo.setYear(year);
					statisticsInfo.setMonth(month);
				}

				statisticsInfoRepository.save(statisticsInfo);

				logger.info("保存{}{}月房源统计数据成功", cityCode, month);
			});
		} catch (Exception e) {
			throw new BizException(e);
		}

	}

	private void sendMessage(String scity, Integer emplId, String message) {
		String targetUserName = null;
		logger.info("城市是{},员工号是{}", scity, emplId);
		EmployeeDetailVo broker = brokerServiceClient.getDetailInfo(scity, emplId);
		if (broker == null) {
			logger.info("未找到相应的经纪人");
			return;
		}

		EmployeeDetailVo jituanBorker = employeeServiceClient.queryEmployee("jituan", broker.getEmplName());
		if (jituanBorker != null) {
			if (jituanBorker.getEmplAccNo().equals(broker.getEmplAccNo())) {
				targetUserName = "jituan" + "_" + jituanBorker.getId() + "_" + jituanBorker.getEmplAccNo();
			}
		}

		targetUserName = scity + "_" + emplId + "_" + broker.getEmplAccNo();

		try {
			JSONObject request = new JSONObject();
			JSONObject msg = new JSONObject();
			JSONObject name = new JSONObject();
			JSONArray target = new JSONArray();
			target.add(targetUserName);
			// "target" : ["u1", "u2", "u3"],
			msg.put("type", "txt");
			msg.put("msg", message);
			name.put("nickName", "系统消息");
			request.put("target_type", "users");
			request.put("target", target);
			request.put("msg", msg);
			request.put("from", "sys_admin");
			request.put("ext", name);
			
			easemobUserServiceClient.sendMessage(easemobUserService.getToken(), request);
		} catch (Exception e) {
			logger.error("发送消息出错了",e);
		}
	}
}