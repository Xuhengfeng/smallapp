package com.ztj.dichan.cust.appapi.service;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.util.PageUtil;
import com.ztj.dichan.cust.core.enums.InfoTypeEnum;
import com.ztj.dichan.cust.core.repository.InformationPubRepository;
import com.ztj.dichan.cust.core.vo.InformationVo;


/**
 * 
 * @author liuweichen
 *
 */
@Service
public class InformationPubService extends BaseAppService {
	
	@Resource
	private InformationPubRepository informationPubRepository;
	
	/**
	 * 资讯列表
	 * @param cityCode
	 * @param infoType
	 * @return
	 */
	
	public List<InformationVo>  querInformationPub(String cityCode, InfoTypeEnum infoType) {
		//这里暂时配置一样的
		cityCode = "beihai";
		return  informationPubRepository.queryInfoPubs(cityCode, infoType);
	}
	
	/**
	 * 资讯列表,分页
	 * @param cityCode
	 * @param infoType
	 * @return
	 */
	
	public List<InformationVo>  querInformationPub(String cityCode, InfoTypeEnum infoType,Integer pageNo,Integer pageSize) {
		//这里暂时配置一样的
		cityCode = "beihai";
		return  informationPubRepository.findAll(cityCode, infoType,PageUtil.createPage(pageNo, pageSize));
	}
}