package com.ztj.dichan.cust.appapi.config;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.ztj.dichan.cust.appapi.constant.SystemConstant;
import com.ztj.dichan.cust.appapi.interceptor.RequestInterceptor;
import com.ztj.dichan.cust.appapi.service.MemberNewService;

/**
 * 
 * @author sily
 */
@Configuration
public class WebAppConfigurer extends WebMvcConfigurerAdapter {

	@Resource
	private SystemConstant systemConstant;
	
	@Resource
	private MemberNewService memberNewService;
	
	/**
	 * 
	 * @param registry
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		super.addInterceptors(registry);

		List<String> swaggerList = new ArrayList<>();
		swaggerList.add("/swagger*/**");
		swaggerList.add("/v2/**");
		swaggerList.add("/webjars/**");
		
		List<String> list = new ArrayList<>();
		list.addAll(swaggerList);
		
		RequestInterceptor requestInterceptor = new RequestInterceptor(systemConstant, memberNewService);
		registry.addInterceptor(requestInterceptor).addPathPatterns("/**")
				.excludePathPatterns(list.toArray(new String[list.size()]));

		/*LoginInterceptor loginInterceptor = new LoginInterceptor();
		registry.addInterceptor(loginInterceptor).addPathPatterns("/**")
				.excludePathPatterns(list.toArray(new String[list.size()]));*/
	}

	/**
	 * 跨域配置
	 *
	 * @param registry
	 */
	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**").allowedHeaders("*").allowedMethods("*").allowedOrigins("*");
	}
}