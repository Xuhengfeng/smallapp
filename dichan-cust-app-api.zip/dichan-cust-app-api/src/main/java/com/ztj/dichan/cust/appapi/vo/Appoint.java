package com.ztj.dichan.cust.appapi.vo;

import java.time.LocalDateTime;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper=true)
public class Appoint extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 会员Id
	 */
	private Long memberId;

	/**
	 * 经纪人id
	 */
	private Integer brokerId;

	/**
	 * 经纪人Sdid
	 */
	private Long brokerSdId;

	/**
	 * 经纪人名称
	 */
	private String brokerName;

	/**
	 * 城市编码
	 */
	private String scity;


	/**
	 * 预约人姓名
	 */
	private String appointName;

	/**
	 * 预约人手机号
	 */
	private String appointMobile;


	/**
	 * 房源内容
	 */
	private String houseContent;

	/**
	 * 创建时间
	 */
	private LocalDateTime createDateTime;

 
	
}