package com.ztj.dichan.cust.appapi.repository.activity;

import java.time.LocalDateTime;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.cust.core.entity.activity.ScoreFollowRecord;

@Repository
public interface ScoreFollowRecordRepository extends PagingAndSortingRepository<ScoreFollowRecord, Long> {

	Page<ScoreFollowRecord> findByMemberId(Long memberId, Pageable pageable);
	
	@Query(value = "SELECT COUNT(*) from score_follow_record c WHERE create_date_time BETWEEN ?1 and ?2 and c.member_id=?3", nativeQuery = true)
	Long countScore(LocalDateTime beginDateTime, LocalDateTime enDateTime, Long memberId);
	
}
