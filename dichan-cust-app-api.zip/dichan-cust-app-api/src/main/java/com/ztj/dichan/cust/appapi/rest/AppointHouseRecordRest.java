package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.request.AppointHouseCancelRequest;
import com.ztj.dichan.cust.appapi.request.AppointHouseDetailRequest;
import com.ztj.dichan.cust.appapi.request.AppointHouseRequest;
import com.ztj.dichan.cust.appapi.request.AppointRemarkRequest;
import com.ztj.dichan.cust.appapi.service.AppointHouseRecordService;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseCompleteVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseDetailListVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseRecordDetailVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseRecordHouseVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseRecordVo;
import com.ztj.dichan.cust.appapi.vo.appoint.MemberRemarkDetail;
import com.ztj.dichan.cust.appapi.vo.appoint.ReadyHouseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author sily
 *
 */
@Api(value = "预约看房", description = "预约看房")
@RestController
@RequestMapping(value = "/appoint")
public class AppointHouseRecordRest extends BaseCustRest {

	@Resource
	private AppointHouseRecordService appointHouseRecordService;
	
	
	@ApiOperation(value = "加入待看列表")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true)})
	@RequestMapping(value = "/add", method = { RequestMethod.POST })
	public RestResult<String> addDetail(@RequestBody AppointHouseDetailRequest request) {
		//getCurrentMemberId()
		this.appointHouseRecordService.addAppointHouseDetail(getCurrentMemberId(), request);

		return RestResult.success("操作成功了");
	}
	
	@ApiOperation(value = "待看列表")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType="query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType="query")})
	@RequestMapping(value = "/detailLsit", method = { RequestMethod.GET })
	public RestResult<List<AppointHouseDetailListVo>> detailLsit(@RequestParam(name="pageNo", required = true)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		//getCurrentMemberId()
		List<AppointHouseDetailListVo> dataList = this.appointHouseRecordService.queryAppointHouseDetailList(getCurrentMemberId(), pageNo, pageSize);
		return RestResult.success(dataList);
	}
	
	@ApiOperation(value = "删除待看房源")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "id", value = "待看id", dataType = "int", paramType = "path", required = true)})
	@RequestMapping(value = "/delete/{id}", method = { RequestMethod.DELETE })
	public RestResult<String> deleteDetail(@PathVariable("id")Long id) {
		//getCurrentMemberId()
		this.appointHouseRecordService.deleteAppointHouseDetail(getCurrentMemberId(), id);

		return RestResult.success("操作成功了");
	}

	@ApiOperation(value = "提交预约看房")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true)})
	@PostMapping(value = "/house")
	public RestResult<String> appointHouse(@RequestBody AppointHouseRequest request) {
		
		appointHouseRecordService.appointHouse(getCurrentMemberId(),request);

		return RestResult.success("操作成功了");
	}
	
	@ApiOperation(value = "待看日程详情")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "id", value = "待看日程id", dataType = "int", paramType = "path", required = true)})
	@RequestMapping(value = "/readyDetail/{id}", method = { RequestMethod.GET })
	public RestResult<AppointHouseRecordDetailVo> queryReadyDetail(@PathVariable("id") Long id) {
		return RestResult.success(appointHouseRecordService.queryAppointDetail(getCurrentMemberId(), id));
	}

	@ApiOperation(value = "待看日程列表",response=AppointHouseRecordVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType="query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType="query")})
	@RequestMapping(value = "/readyList", method = { RequestMethod.GET })
	public RestResult<List<AppointHouseRecordVo>> queryReadyList(@RequestParam(name="pageNo", required = true)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {

		List<AppointHouseRecordVo> voList = appointHouseRecordService.queryReadyList(getCurrentMemberId(),pageNo, pageSize);

		return RestResult.success(voList);
	}
	
	
	@ApiOperation(value = "待看日程列表(含房源列表)",response=AppointHouseRecordHouseVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType="query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType="query")})
	@RequestMapping(value = "/readyHouseList", method = { RequestMethod.GET })
	public RestResult<List<AppointHouseRecordHouseVo>> queryReadyHouseList(@RequestParam(name="pageNo", required = true)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {

		List<AppointHouseRecordHouseVo> voList = appointHouseRecordService.queryReadyHouseList(getCurrentMemberId(),pageNo, pageSize);

		return RestResult.success(voList);
	}
	

	@ApiOperation(value = "已看记录列表",response=AppointHouseCompleteVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType="query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType="query")})
	@RequestMapping(value = "/complete", method = { RequestMethod.GET })
	public RestResult<List<AppointHouseCompleteVo>> queryCompileList(@RequestParam(name="pageNo", required = true)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		
		List<AppointHouseCompleteVo> voList = appointHouseRecordService.queryCompileList(getCurrentMemberId(),pageNo, pageSize);

		return RestResult.success(voList);
	}
	
	@ApiOperation(value = "取消预约")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true)})
	@PostMapping(value = "/cancel")
	public RestResult<String> cancelAppoint(@RequestBody AppointHouseCancelRequest request) {

		appointHouseRecordService.cancelAppoint(getCurrentMemberId(), request);

		return RestResult.success("操作成功了");
	}
	
	@ApiOperation(value = "用户填写看房备注")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true)})
	@PostMapping(value = "/fillMemberRemark")
	public RestResult<String> fillMemberRemark(@RequestBody AppointRemarkRequest request) {
		
		appointHouseRecordService.fillMemberRemark(getCurrentMemberId(),request);

		return RestResult.success("操作成功了");
	}
	
	@ApiOperation(value = "获取用户看房备注详情")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true),
		@ApiImplicitParam(name = "id", value = "约看房源记录id", dataType = "int", paramType = "path", required = true)})
	@RequestMapping(value = "/memberRemark/{id}", method = { RequestMethod.GET })
	public RestResult<MemberRemarkDetail> memberRemarkDetail(@PathVariable("id")Long id) {
		
		MemberRemarkDetail detail = this.appointHouseRecordService.memberRemarkDetail(getCurrentMemberId(),id);

		return RestResult.success(detail);
	}
	
	@ApiOperation(value = "待看房源列表",response=ReadyHouseVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "id", value = "待看日程id", required = true, dataType = "int", paramType = "path")})
	@RequestMapping(value = "/readyHouseList/{id}", method = { RequestMethod.GET })
	public RestResult<List<ReadyHouseVo>> readyHouseList(@PathVariable("id") Long id) {
		
		List<ReadyHouseVo> voList = appointHouseRecordService.queryReadyHouseList(getCurrentMemberId(),id);

		return RestResult.success(voList);
	}

}
