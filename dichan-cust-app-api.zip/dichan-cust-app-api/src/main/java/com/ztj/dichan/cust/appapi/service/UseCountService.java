package com.ztj.dichan.cust.appapi.service;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.common.exception.NoLoginException;
import com.ztj.dichan.cust.core.constant.RedisConstant;
import com.ztj.dichan.cust.core.entity.Member;
import com.ztj.dichan.cust.core.entity.UseCount;
import com.ztj.dichan.cust.core.repository.MemberRepository;
import com.ztj.dichan.cust.core.repository.UseCountRepository;

import net.sf.json.JSONObject;

/**
 * 
 * @author yincp
 */
@Service
@Transactional
public class UseCountService extends BaseAppService {

	@Resource
	private UseCountRepository useCountRepository;

	@Resource
	private MemberRepository memberRepository;

	public void toGet(String urls, Map<String, String> headerMap, Map<String, String> parameterMap) {
		executor.submit(new Runnable() {
			@Override
			public void run() {
				try {
					UseCount count = new UseCount();
					Long sdid = null;
					String url = urls.substring(0, getCharacterPosition(urls, 4));
					String modelName = null;
					String uniqueCode = headerMap.get("unique-code");
					String scity = headerMap.get("scity");
					if (url.equals("/custAppApi/member/logout")) {
						modelName = "退出登录";
					} else if (url.equals("/custAppApi/house/getDetailInFo/")) {
						scity = urls.substring(getCharacterPosition(urls, 5), getCharacterPosition(urls, 5));
						sdid = Long.parseLong(urls.substring(getCharacterPosition(urls, 6), urls.length()));
						modelName = "查看二手房详情";
					} else if (url.equals("/custAppApi/rentHouse/getDetailInFo")) {
						scity = urls.substring(getCharacterPosition(urls, 5), getCharacterPosition(urls, 5));
						sdid = Long.parseLong(urls.substring(getCharacterPosition(urls, 6), urls.length()));
						modelName = "查看租房详情";
					} else if (url.equals("/custAppApi/contrast/rentList")) {
						modelName = "租房对比";
					}

					else if (url.equals("/custAppApi/contrast/usedList")) {
						modelName = "二手房对比";
					}
					count.setHouseSdid(sdid);
					count.setScity(scity);
					count.setUrl(url);
					count.setModelName(modelName);
					count.setMemberId(getMemberId2(uniqueCode));

					useCountRepository.save(count);
				} catch (Exception e) {
					logger.error("保存用户行为数据出错了", e);
				}
			}
		});
	}

	public void toPost(String url, String text, String uniqueCode, String scity) {
		executor.submit(new Runnable() {
			@Override
			public void run() {
				try {
					UseCount count = new UseCount();
					String modelName = null;
					Long sdid = null;
					Integer brokerId = null;
					String mobile = null;
					boolean flag = false;

					if (url.equals("/custAppApi/member/login")) {
						JSONObject loginObj = JSONObject.fromObject(text);
						mobile = loginObj.getString("mobile");
						modelName = "登录";
						flag = true;
					} else if (url.equals("/custAppApi/member/fetchSmsCode")) {
						JSONObject loginObj = JSONObject.fromObject(text);
						mobile = loginObj.getString("mobile");
						modelName = "获取验证码";
						flag = true;
					} else if (url.equals("/custAppApi/appoint/house")) {
						JSONObject appointObj = JSONObject.fromObject(text);
						brokerId = appointObj.getInt("brokerId");
						mobile = appointObj.get("appointMobile").toString();
						String houseList = appointObj.getString("houseList");
						JSONObject houseListObj = JSONObject.fromObject(houseList);
						sdid = houseListObj.getLong("sdid");
						modelName = "提交预约看房";
						flag = true;
					} else if (url.equals("/custAppApi/appoint/cancel")) {
						modelName = "取消预约";
						flag = true;
					} else if (url.equals("/custAppApi/houseEntrustApply/sellHouse")) {
						JSONObject appointObj = JSONObject.fromObject(text);
						brokerId = appointObj.getInt("brokerId");
						mobile = appointObj.get("phone").toString();
						modelName = "我要卖房";
						flag = true;
					} else if (url.equals("/custAppApi/houseEntrustApply/sell/cancel")) {
						modelName = "取消卖房";
						flag = true;
					} else if (url.equals("/custAppApi/houseEntrustApply/rentHouse")) {
						JSONObject appointObj = JSONObject.fromObject(text);
						brokerId = appointObj.getInt("brokerId");
						mobile = appointObj.get("phone").toString();
						modelName = "我要出租";
						flag = true;
					} else if (url.equals("/custAppApi/houseEntrustApply/rent/cancel")) {
						modelName = "取消出租";
						flag = true;
					} else if (url.equals("custAppApi/houseCollection/add/{scity}/{sdid}")) {
						modelName = "二手房收藏";
						flag = true;
					} else if (url.equals("custAppApi/houseCollection/cancel/{scity}/{sdid}")) {
						modelName = "二手房取消收藏";
						flag = true;
					} else if (url.equals("/custAppApi/rentHCollection/add/{scity}/{sdid}")) {
						modelName = "租房收藏";
						flag = true;
					} else if (url.equals("/rentHCollection/cancel/{scity}/{sdid}")) {
						modelName = "租房取消收藏";
						flag = true;
					}
					count.setHouseSdid(sdid);
					count.setScity(scity);
					count.setBrokerId(brokerId);
					count.setMobile(mobile);
					count.setUrl(url);
					count.setModelName(modelName);
					if (flag) {
						count.setMemberId(getMemberId(mobile));

						useCountRepository.save(count);
					}
				} catch (Exception e) {
					logger.error("保存用户行为数据出错了", e);
				}
			}
		});
	}

	protected Long getMemberId(String mobile) {
		return memberRepository.findByMobile(mobile).getId();
	}

	public static int getCharacterPosition(String string, int index) {
		// 这里是获取"/"符号的位置
		Matcher slashMatcher = Pattern.compile("/").matcher(string);
		int mIdx = 0;
		while (slashMatcher.find()) {
			mIdx++;
			// 当"/"符号第三次出现的位置
			if (mIdx == index) {
				break;
			}
		}
		return slashMatcher.start();
	}

//	public List<String> getAllUrl() {
//		RequestMappingHandlerMapping mapping = applicationContext.getBean(RequestMappingHandlerMapping.class);
//		Map<RequestMappingInfo, HandlerMethod> map = mapping.getHandlerMethods();
//		List<String> urlList = new ArrayList<>();
//		for (RequestMappingInfo info : map.keySet()) {
//			Set<String> patterns = info.getPatternsCondition().getPatterns();
//			for (String url : patterns) {
//				if (!url.contains(url)) {
//				}
//				urlList.add(url);
//				System.out.println(url);
//			}
//		}
//		return urlList;
//	}

//	public void getUri(String uri) {
//		Map<String, String> urlMap = new HashMap<String, String>();
//		urlMap.put("登录", "/member/login");
//		urlMap.put("退出登录", "/member/logout");
//		urlMap.put("查看房源详情", "/house/getDetailInFo/{scity}/{sdid}");
//		urlMap.put("查看租房详情", "/rentHouse/getDetailInFo/{scity}/{sdid}");
//		urlMap.put("获取验证码", "/member/fetchSmsCode");
//		urlMap.put("提交预约看房", "/appoint/house");
//		urlMap.put("取消预约", "/appoint/cancel");
//		urlMap.put("我要卖房", "/houseEntrustApply/sellHouse");
//		urlMap.put("取消卖房", "/houseEntrustApply/sell/cancel");
//		urlMap.put("我要出租", "/houseEntrustApply/rentHouse");
//		urlMap.put("取消出租", "/houseEntrustApply/rent/cancel");
//		urlMap.put("二手房收藏", "/houseCollection/add/{scity}/{sdid}");
//		urlMap.put("二手房取消收藏", "/houseCollection/cancel/{scity}/{sdid}");
//		urlMap.put("租房收藏", "/rentHCollection/add/{scity}/{sdid}");
//		urlMap.put("租房取消收藏", "/rentHCollection/cancel/{scity}/{sdid}");
//		urlMap.put("租房对比", "/contrast/rent-house");
//		urlMap.put("二手房对比", "/contrast/used-house");
//	}

	/**
	 * @param uniqueCode
	 * @return
	 */
	public Long getMemberId2(String uniqueCode) {
		String memberId = null;

		try {
			memberId = (String) redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).get(uniqueCode);
		} catch (Exception e) {
			logger.error("从redis获取用户信息出错", e);
		}

		if (StringUtils.isEmpty(memberId)) {
			Member member = memberRepository.findByUniqueCode(uniqueCode);

			if (member == null) {
				throw new NoLoginException("用户未登录");
			}

			memberId = String.valueOf(member.getId());

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(uniqueCode,
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}
		}
		return Long.valueOf(memberId);
	}
}