/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.ztj.dichan.cust.rule.request.maphouse.MapAreaRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapDistrictRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapHousingRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapLocationRequest;
import com.ztj.dichan.cust.rule.response.maphouse.ArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.DistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.HousingDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentDistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentHousingDetailVo;



/**
 * @author sily
 *
 */
@FeignClient(name = "mapHouseServiceClient", url= "${cust.service.url}", fallback = HouseServiceClientFallBack.class)
public interface MapHouseServiceClient {

	@PostMapping(value = "/map-house/secondArea")
	public List<ArerDetailVo> secondArea(@RequestBody MapAreaRequest MapAreaRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	@PostMapping(value = "/map-house/secondDistrict")
	public List<DistrictDetailVo> secondDistrict(@RequestBody MapDistrictRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@PostMapping(value = "/map-house/secondHousing")
	public List<HousingDetailVo> secondHousing(@RequestBody MapHousingRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	
	@PostMapping(value = "/map-house/rentArea")
	public List<RentArerDetailVo> rentArea(@RequestBody MapAreaRequest MapAreaRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@PostMapping(value = "/map-house/rentDistrict")
	public List<RentDistrictDetailVo> rentDistrict(@RequestBody MapDistrictRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@PostMapping(value = "/map-house/rentHousing")
	public List<RentHousingDetailVo> rentHousing(@RequestBody MapHousingRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	
	


	
	@PostMapping(value = "/map-house/coordinate-usedDist")
	public List<DistrictDetailVo> coordinateUsedDist(@RequestBody MapLocationRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@PostMapping(value = "/map-house/coordinate-usedHousing")
	public List<HousingDetailVo> coordinateUsedHousing(@RequestBody MapLocationRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	

	
	@PostMapping(value = "/map-house/coordinate-rentDist")
	public List<RentDistrictDetailVo> coordinateRentDist(@RequestBody MapLocationRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@PostMapping(value = "/map-house/coordinate-rentHousing")
	public List<RentHousingDetailVo> coordinateRentHousing(@RequestBody MapLocationRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
}