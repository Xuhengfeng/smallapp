/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.appoint;

import java.math.BigDecimal;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "返回用户房源备注信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class MemberRemarkDetail extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	

	@ApiModelProperty(value = "看房源记录id")
	private Long id; 

	@ApiModelProperty(value = "用户看房备注内容")
	private String memberRemark;
	
	@ApiModelProperty(value = "用户看房备注时间")
	private String mRemarkDateTime;	
	
	@ApiModelProperty(value = "用户看房备注标签,多个使用英文逗号隔开")
	private String remarkTag;
	
	
}
