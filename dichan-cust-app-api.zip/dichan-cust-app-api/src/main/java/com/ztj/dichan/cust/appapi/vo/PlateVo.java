/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "版块信息VO")
@Data
@EqualsAndHashCode(callSuper = true)
public class PlateVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "版块id")
	private Long id;

	@ApiModelProperty(value = "标题")
	private String title;

	@ApiModelProperty(value = "副标题")
	private String subhead;

	@ApiModelProperty(value = "PC内容url")
	private String computerContUrl;

	@ApiModelProperty(value = "手机内容url")
	private String phoneContUrl;
	
	@ApiModelProperty(value = "图片url")
	private String imageUrl;
	
	

}
