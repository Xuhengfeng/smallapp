package com.ztj.dichan.cust.appapi.vo.activity;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class ExchangeVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "可以兑换的商品id")
	protected Long exchangeId;

	@ApiModelProperty(value = "商品兑换需要消耗的积分")
	protected Long score;
}
