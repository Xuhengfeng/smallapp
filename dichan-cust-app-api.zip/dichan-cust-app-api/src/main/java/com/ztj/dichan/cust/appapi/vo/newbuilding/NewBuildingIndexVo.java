package com.ztj.dichan.cust.appapi.vo.newbuilding;

import java.util.List;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value = "新房主页信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class NewBuildingIndexVo extends BaseValueObject {
	
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "城市名称")
	private String cityName;
	
	@ApiModelProperty(value = "城市编码")
	private String cityCode;
	
	@ApiModelProperty(value = "新盘信息列表")
	private List<NewBuildingVo> dataList;

}
