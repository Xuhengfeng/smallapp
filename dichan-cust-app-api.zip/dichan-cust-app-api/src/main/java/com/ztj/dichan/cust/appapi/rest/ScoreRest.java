package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.dichan.cust.appapi.service.CouponService;
import com.ztj.dichan.cust.appapi.service.ScoreService;
import com.ztj.dichan.cust.appapi.vo.activity.ExchangeVo;
import com.ztj.dichan.cust.appapi.vo.activity.GoodsDetailVo;
import com.ztj.dichan.cust.appapi.vo.activity.ScoreDetailVo;
import com.ztj.dichan.cust.appapi.vo.activity.ScoreFollowRecordVo;
import com.ztj.dichan.cust.core.constant.RestResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 积分接口
 * 
 * @author zhouqiao
 */
@Api(value = "积分相关接口", description = "积分的相关接口*")
@RestController
@RequestMapping(value = "/score")
public class ScoreRest extends BaseCustRest {
	@Resource
	private ScoreService scoreService;

	@Resource
	private CouponService couponService;

	@ApiOperation(value = "查看兑换商品的详细信息", response = GoodsDetailVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "exchangeId", value = "商品id", dataType = "int", paramType = "query", required = true, example = "1") })
	@RequestMapping(value = "/getGoodsDetail", method = { RequestMethod.POST })
	public RestResult getGoodsDetail(Long exchangeId) {
		GoodsDetailVo detailVo = scoreService.getGoodsDetail(getCurrentMemberIdAllowNull(), exchangeId);

		return RestResult.success(detailVo);
	}

	@ApiOperation(value = "查询积分可以兑换的商品列表", response = ExchangeVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "pageNo", value = "需要显示的页数", dataType = "int", paramType = "query", required = true, example = "1"),
			@ApiImplicitParam(name = "pageSize", value = "每页显示的条数", dataType = "int", paramType = "query", example = "10") })
	@RequestMapping(value = "/queryGoodsList", method = { RequestMethod.POST })
	public RestResult queryGoodsList(Integer pageNo, Integer pageSize) {
		List<ExchangeVo> result = scoreService.queryList(pageNo, pageSize);

		return RestResult.success(result);
	}

	@ApiOperation(value = "获取积分明细", response = ScoreFollowRecordVo.class)
	@PostMapping(value = "/detail")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	public RestResult getScoreDetails(Integer pageNo, Integer pageSize) {
		ScoreDetailVo result = scoreService.getScoreDetails(getCurrentMemberId(), pageNo, pageSize);

		return RestResult.success(result);
	}

	@ApiOperation(value = "积分转赠好友")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "score", value = "赠送积分值", dataType = "int", paramType = "query", required = true),
			@ApiImplicitParam(name = "smsCode", value = "验证码", dataType = "String", paramType = "query", required = true),
			@ApiImplicitParam(name = "giveMobile", value = "赠送人的手机号", dataType = "String", paramType = "query", required = true) })
	@RequestMapping(value = "/giveScore", method = { RequestMethod.POST })
	public RestResult giveScore(Long score, String smsCode, String giveMobile) {
		scoreService.giveScore(getCurrentMemberId(), score, smsCode, giveMobile);

		return RestResult.success();
	}

	@ApiOperation(value = "积分兑换礼品")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "exchangeId", value = "商品id", dataType = "int", paramType = "query", required = true),
			@ApiImplicitParam(name = "number", value = "商品数量", dataType = "int", paramType = "query", required = true),
			@ApiImplicitParam(name = "smsCode", value = "验证码", dataType = "String", paramType = "query", required = true) })
	@RequestMapping(value = "/exchange", method = { RequestMethod.POST })
	public RestResult exchange(Long exchangeId, Long number, String smsCode) {
		scoreService.scoreExchangeGift(getCurrentMemberId(), exchangeId, number, smsCode);

		return RestResult.success();
	}
}
