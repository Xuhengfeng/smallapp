/**
 * 
 */
package com.ztj.dichan.cust.appapi.request.member;

import com.ztj.dichan.cust.appapi.request.BaseApiRequest;
import com.ztj.dichan.cust.core.enums.OperateTypeEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author liuweichen
 *
 */
@ApiModel(value = "设置密码")
@Data
@EqualsAndHashCode(callSuper = true)
public class PasswordRequest extends BaseApiRequest{
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "用户手机号，必填")
	private  String mobile;
	
	@ApiModelProperty(value = "验证码")
	private  String smsCode;
	
	@ApiModelProperty(value = "新密码")
	private  String newPassword;
	
	@ApiModelProperty(value = "确认密码")
	private  String confirmPassword;

	

}
