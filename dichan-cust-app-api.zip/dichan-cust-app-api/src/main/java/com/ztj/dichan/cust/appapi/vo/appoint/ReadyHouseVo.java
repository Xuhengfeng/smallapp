/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.appoint;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "返回带看房源信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class ReadyHouseVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "房源标题")
	private String houseTitle;

	@ApiModelProperty(value = "区域")
	private String areaName;

	@ApiModelProperty(value = "片区")
	private String districtName;

	@ApiModelProperty(value = "房源标签")
	private String houseTag;

	@ApiModelProperty(value = "朝向")
	private String houseDirection;

	@ApiModelProperty(value = "房")
	private Integer roomsNum;

	@ApiModelProperty(value = "厅")
	private Integer livingRoomNum;

	@ApiModelProperty(value = "卫")
	private Integer washRoomNum;

	@ApiModelProperty(value = "户型")
	private String houseType;

	@ApiModelProperty(value = "建筑面积")
	private Integer builtArea;

	@ApiModelProperty(value = "房源特征")
	private String houseFeature;

	@ApiModelProperty(value = "售价")
	private Double saleTotal;

	@ApiModelProperty(value = "售单价")
	private Integer salePrice;

	@ApiModelProperty(value = "房源照片")
	private String housePic;
	
	@ApiModelProperty(value = "房源id")
	private Integer houseId;
	
	@ApiModelProperty(value = "房源sdid")
	private Long houseSdid;
	
	@ApiModelProperty(value = "房源城市编码")
	private String houseScity;
	
	@ApiModelProperty(value = "约看房源记录id")
	private Long id; 

	@ApiModelProperty(value = "房源状态，0=正常，1=已售")
	private Integer status; 
	
	@ApiModelProperty(value = "房源类别,ORIGINAL_HOUSE=原始房源;BROKER_HOUSE=经纪人推荐房源")
	private String type;

	public String getHouseType() {
	    return  String.format("%s房%s厅", roomsNum,livingRoomNum); 
	}
}
