/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ztj.dichan.cust.rule.response.house.HouseSeeCountVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeRecordVo;

/**
 * @author lbs
 * 
 *  房源带来记录
 *
 */
@FeignClient(name = "houseSeeServiceClient", url= "${cust.service.url}", fallback = HouseSeeServiceClientFallBack.class)
public interface HouseSeeServiceClient {

	@RequestMapping(method = RequestMethod.GET, value = "/dkinfo/list/{houseId}")
	public List<HouseSeeRecordVo> queryDkInfoList(@RequestHeader(value = "scity", required = true) String scity,
			@PathVariable("houseId") Integer houseId,
			@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize);
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/dkinfo/count/{houseId}")
	public HouseSeeCountVo queryCount(@RequestHeader(value = "scity", required = true) String scity,
			@PathVariable("houseId") Integer houseId);
	
}
