package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.HouseNewService;
import com.ztj.dichan.cust.appapi.service.HouseService;
import com.ztj.dichan.cust.appapi.vo.house.HouseDetailCountVo;
import com.ztj.dichan.cust.appapi.vo.house.HouseDetailDataVo;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseRecmdVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeRecordVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author sily
 *
 */
@Api(value = "二手房列表", description = "二手房相关接口")
@RestController
@RequestMapping(value = "/house")
public class HouseRest extends BaseCustRest {

	@Resource
	private HouseService houseService;

	@Resource
	private HouseNewService houseNewService;

	@ApiOperation(value = "查询二手房列表(搜索)", response = HouseVo.class)
	@PostMapping(value = "/query")
	public RestResult<List<HouseVo>> queryList(@RequestBody HouseRequest houseRequest) {
		List<HouseVo> voList = houseService.queryList(houseRequest, getCurrentMemberIdAllowNull());

		return RestResult.success(voList);
	}

	@ApiOperation(value = "查询二手房列表(搜索)-总数量", response = CountVo.class)
	@PostMapping(value = "/queryCount")
	public RestResult<CountVo> queryListCount(@RequestBody HouseRequest houseRequest) {
		CountVo count = houseService.queryListCount(houseRequest, getCurrentMemberIdAllowNull());

		return RestResult.success(count);
	}

	@ApiOperation(value = "首页猜你喜欢-二手房列表", response = HouseVo.class)
	@GetMapping(value = "/queryLike/{scity}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	public RestResult<List<HouseVo>> queryLikeList(@PathVariable("scity") String scity,
			@RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {
		List<HouseVo> voList = houseService.queryLikeList(scity, pageNo, pageSize, getCurrentMemberIdAllowNull());

		return RestResult.success(voList);
	}

	@ApiOperation(value = "查看二手房详情", response = HouseDetailVo.class)
	@GetMapping(value = "/getDetailInFo/{scity}/{sdid}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "sdid", value = "房源sdid", dataType = "int", paramType = "path", required = true) })
	public RestResult<HouseDetailVo> getDetailInFo(@PathVariable("scity") String scity,
			@PathVariable("sdid") Long sdid) {
		HouseDetailVo voList = houseService.getDetailInfo(scity, sdid, getCurrentMemberIdAllowNull());

		return RestResult.success(voList);
	}

	@ApiOperation(value = "二手房推荐", response = HouseRecmdVo.class)
	@GetMapping(value = "/recmdList/{scity}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true) })
	public RestResult<List<HouseRecmdVo>> queryRecmdList(@PathVariable("scity") String scity) {
		List<HouseRecmdVo> HouseRecmdVoList = houseService.queryRecmdList(scity);

		return RestResult.success(HouseRecmdVoList);
	}

	@ApiOperation(value = "二手房-周边房源", response = HouseVo.class)
	@PostMapping(value = "/rimHousing")
	public com.ztj.dichan.cust.core.constant.RestResult rimHousing(@RequestBody RimHouseRequest rimHouseRequest) {
		List<HouseVo> rimHousingList = houseService.rimHousing(rimHouseRequest);

		return com.ztj.dichan.cust.core.constant.RestResult.success(rimHousingList);
	}

	@ApiOperation(value = "获取二手房带看记录列表", response = HouseSeeRecordVo.class)
	@GetMapping(value = "/houseSee/{id}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "id", value = "房源id", dataType = "int", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query") })
	public RestResult<List<HouseSeeRecordVo>> getHouseSeeRecordList(@PathVariable("id") Integer id,
			@RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {
		List<HouseSeeRecordVo> voList = houseService.getHouseSeeRecordList(id, pageNo, pageSize);

		return RestResult.success(voList);
	}

	@ApiOperation(value = "房源清单列表数量统计", response = HouseDetailCountVo.class)
	@GetMapping(value = "/detailCount")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true) })
	public RestResult<HouseDetailCountVo> houseDetailCount() {
		return RestResult.success(houseService.getHouseDetailCount(getCurrentMemberIdAllowNull()));
	}

	@ApiOperation(value = "一次性获取房源详情等信息", response = HouseDetailDataVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识,未登录时为空", dataType = "string", paramType = "header", required = false),
			@ApiImplicitParam(name = "scity", value = "城市code", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "buildingSdid", value = "小区sdid", dataType = "long", paramType = "form", required = true),
			@ApiImplicitParam(name = "longitude", value = "当前坐标的经度值", dataType = "double", paramType = "form", required = true),
			@ApiImplicitParam(name = "latitude", value = "当前坐标的纬度值", dataType = "double", paramType = "form", required = true) })
	@RequestMapping(value = "/fetchDetailData", method = { RequestMethod.POST })
	public com.ztj.dichan.cust.core.constant.RestResult fetchDetailData(Long buildingSdid, Double longitude,
			Double latitude) {
		HouseDetailDataVo vo = houseNewService.fetchDetailData(getCurrentMemberIdAllowNull(), buildingSdid, longitude,
				latitude);

		return com.ztj.dichan.cust.core.constant.RestResult.success(vo);
	}
}