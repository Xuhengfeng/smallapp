/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.maphouse;

import java.math.BigDecimal;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "二手房-地图展示信息VO")
@Data
@EqualsAndHashCode(callSuper = true)
public class MapHouseDetailVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "Id")
	private Integer id;

	@ApiModelProperty(value = "名称")
	private String name;

	@ApiModelProperty(value = "平均售价")
	private Float avgPrice;

	@ApiModelProperty(value = "东经")
	private BigDecimal px;

	@ApiModelProperty(value = "西纬")
	private BigDecimal py;

	@ApiModelProperty(value = "平均售价显示格式")
	private String formatAvgPrice;
	
	
	public String getFormatAvgPrice() {
		BigDecimal decimal = new BigDecimal(avgPrice);
		if(avgPrice<10000F) {
			formatAvgPrice =  decimal.setScale(0,BigDecimal.ROUND_HALF_UP).toString();
		}else {
			Float f=(float) (avgPrice*0.0001);
			BigDecimal decimal2 = new BigDecimal(f);
			formatAvgPrice =  decimal2.setScale(2,BigDecimal.ROUND_HALF_UP)+"万";
		}
		return formatAvgPrice;
	}
	
}
