/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "取消预约看房参数",description="取消预约看房参数")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointHouseCancelRequest extends BaseApiRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7914712382397974332L;

	@ApiModelProperty(value = "预约看房记录id，必填",required=true)
	private Long id;
	
	@ApiModelProperty(value = "取消原因",required=false)
	private String cancelCause; 
}
