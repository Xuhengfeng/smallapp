/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.request.EntrustRentRequest;
import com.ztj.dichan.cust.rule.request.RentHouseRequest;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.request.contract.HouseContrastRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRecmdRequest;
import com.ztj.dichan.cust.rule.response.house.RentHouseContrastDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseRecmdVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * @author sily
 *
 */
public class RentHouseServiceClientFallBack implements RentHouseServiceClient {

	@Override
	public List<RentHouseVo> queryList(RentHouseRequest rentHouseRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CountVo queryListCount(RentHouseRequest rentHouseRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public RentHouseDetailVo getDetailInfo(String scity, Long sdid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentHouseRecmdVo> queryRecmdList(HouseRecmdRequest houseRecmdRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentHouseVo> rimHousing(RimHouseRequest rimHouseRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentHouseContrastDetailVo> houseContrast(HouseContrastRequest contrastRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentHouseVo> queryEntrustRentList(EntrustRentRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}



}
