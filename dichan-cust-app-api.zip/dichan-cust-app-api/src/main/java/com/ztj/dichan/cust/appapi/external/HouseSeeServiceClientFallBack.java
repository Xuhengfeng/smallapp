/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.response.house.HouseSeeCountVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeRecordVo;

/**
 * @author lbs
 *
 */
public class HouseSeeServiceClientFallBack implements HouseSeeServiceClient {

	@Override
	public List<HouseSeeRecordVo> queryDkInfoList(String scity, Integer houseId, Integer pageNo, Integer pageSize) {
		return null;
	}

	@Override
	public HouseSeeCountVo queryCount(String scity, Integer houseId) {
		// TODO Auto-generated method stub
		return null;
	}

}
