package com.ztj.dichan.cust.appapi.rest;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.dichan.cust.appapi.service.HomeService;
import com.ztj.dichan.cust.appapi.vo.HomeDataVo;
import com.ztj.dichan.cust.core.constant.RestResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author test01
 */
@Api(value = "首页一次性获取热门资讯、房源统计、热门小区、新房推荐等数据", description = "首页一次性获取热门资讯、房源统计、热门小区、新房推荐等数据")
@RestController
@RequestMapping(value = "/home")
public class HomeRest extends BaseCustRest {
	@Resource
	private HomeService homeService;

	@ApiOperation(value = "一次性获取热门资讯、房源统计、热门小区、新房推荐等数据", response = HomeDataVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市code", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", dataType = "int", paramType = "form", required = true),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", dataType = "int", paramType = "form", required = true) })
	@RequestMapping(value = "/fetchData", method = { RequestMethod.POST })
	public RestResult queryBrokerEvaluates(Integer pageNo, Integer pageSize) {
		HomeDataVo vo = homeService.fetchHomeData(pageNo, pageSize);

		return RestResult.success(vo);
	}
}