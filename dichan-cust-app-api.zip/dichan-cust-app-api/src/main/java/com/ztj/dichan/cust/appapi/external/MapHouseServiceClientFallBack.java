/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.request.maphouse.MapAreaRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapDistrictRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapHousingRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapLocationRequest;
import com.ztj.dichan.cust.rule.response.maphouse.ArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.DistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.HousingDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentDistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentHousingDetailVo;

/**
 * @author yincp
 *
 */
public class  MapHouseServiceClientFallBack implements MapHouseServiceClient {

	@Override
	public List<ArerDetailVo> secondArea(MapAreaRequest MapAreaRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DistrictDetailVo> secondDistrict(MapDistrictRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HousingDetailVo> secondHousing(MapHousingRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentArerDetailVo> rentArea(MapAreaRequest MapAreaRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentDistrictDetailVo> rentDistrict(MapDistrictRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentHousingDetailVo> rentHousing(MapHousingRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DistrictDetailVo> coordinateUsedDist(MapLocationRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HousingDetailVo> coordinateUsedHousing(MapLocationRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentDistrictDetailVo> coordinateRentDist(MapLocationRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentHousingDetailVo> coordinateRentHousing(MapLocationRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	

	

}