package com.ztj.dichan.cust.appapi.config;

import javax.annotation.Resource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ztj.dichan.cust.appapi.constant.SystemConstant;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 
 * @author sily
 */
@Configuration
@EnableSwagger2
public class SwaggerConfig {
	
	@Resource
	private SystemConstant systemConstant;

	@Bean
	public Docket createRestApi() {
		return new Docket(DocumentationType.SWAGGER_2).apiInfo(generateApiInfo()).enable(systemConstant.getIsEnableSwagger()).useDefaultResponseMessages(false)
				.select().apis(RequestHandlerSelectors.basePackage("com.ztj.dichan.cust")).build();
	}

	private ApiInfo generateApiInfo() {
		return new ApiInfoBuilder().title("地产系统").description("dichan-cust-app的API文档").version("1.0.0").build();
	}
}