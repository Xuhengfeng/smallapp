package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.dichan.cust.appapi.external.BrokerCollectionServiceClient;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.core.entity.BrokerCollection;
import com.ztj.dichan.cust.core.repository.BrokerCollectionRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.BrokerCollectionRequest;
import com.ztj.dichan.cust.rule.response.broker.BrokerCollectionVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * @author sily
 *
 */
@Service
@Transactional
public class BrokerCollectionService extends BaseAppService {

	@Resource
	private BrokerCollectionRepository brokerCollectionRepository;

	@Resource
	private BrokerCollectionServiceClient brokerCollectionServiceClient;
	
	@Resource
	private BrokerServiceClient brokerServiceClient;

	/**
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<BrokerCollectionVo> queryList(Long memberId, Integer pageNo, Integer pageSize) {
		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "collectDateTime");

		List<BrokerCollection> collectionList = brokerCollectionRepository.findByMemberId(memberId, pageRequest);
		if (collectionList == null || collectionList.isEmpty()) {
			return new ArrayList<BrokerCollectionVo>();
		}
		
		List<BrokerCollectionRequest> request = new ArrayList<>();

		collectionList.stream().forEach(collection -> {
			BrokerCollectionRequest vo = new BrokerCollectionRequest();
			vo.setSdid(collection.getBrokerSdid());
			vo.setScity(collection.getBrokerScity());

			request.add(vo);
		});

		List<BrokerCollectionVo> brokerVoList = brokerCollectionServiceClient.queryCollectionList(request);
		if (brokerVoList == null) {
			return new ArrayList<>(0);
		}
		brokerVoList.forEach(brokerVo -> {
			brokerVo.setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), brokerVo.getPhoto(), brokerVo.getScity(), brokerVo.getId()));
			brokerVo.setStatus(Utils.checkBrokerStatus(brokerVo.getEmplStatus()));
		});

		return brokerVoList;

	}
	
	/**
	 * 
	 * @param memberId
	 * @param sdid
	 * @param scity
	 */
	public void add(Long memberId, String scity,Integer id) {

		Long count = this.brokerCollectionRepository.countByMemberIdAndBrokerIdAndBrokerScity(memberId, Long.valueOf(id), scity);
		
		if (count > 0) {
			throw new IllegalArgumentException("该经纪人已在收藏列表中");
		}
		// 这里共用了dichan-cust-service工程里面的经纪人详情接口
		BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(scity, id);
		
		if (brokerDetailVo == null) {
			throw new IllegalArgumentException("该经纪人不存在");
		}

		BrokerCollection brokerCollection = new BrokerCollection();

		brokerCollection.setBrokerScity(brokerDetailVo.getScity());
		brokerCollection.setBrokerId(Long.valueOf(brokerDetailVo.getId()));
		brokerCollection.setBrokerSdid(Long.valueOf(brokerDetailVo.getSdid()));
		brokerCollection.setMemberId(memberId);
		brokerCollection.setCollectDateTime(LocalDateTime.now());

		brokerCollectionRepository.save(brokerCollection);
	}
	
	public void cancelCollection(Long memberId, String scity,Integer id) {
		BrokerCollection brokerCollection = brokerCollectionRepository.findByMemberIdAndBrokerIdAndBrokerScity(memberId, Long.valueOf(id), scity);
		
		if (brokerCollection != null) {
			brokerCollectionRepository.delete(brokerCollection);
		}
	}

}
