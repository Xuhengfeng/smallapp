package com.ztj.dichan.cust.appapi.vo.consultant;


import java.util.List;

import com.ztj.dichan.cust.appapi.vo.BaseApiValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author yincp
 *
 */
@ApiModel(value = "顾问详情")
@Data
@EqualsAndHashCode(callSuper = true)
public class ConsultantInfoVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "顾问Id")
	private Long employeeId;

	@ApiModelProperty(value = "顾问姓名")
	private String name;

	@ApiModelProperty(value = "顾问头像")
	private String  photo;

	@ApiModelProperty(value = "顾问标签")
	private String label;
	
	@ApiModelProperty(value = "顾问简介")
	private String summary;
	
	@ApiModelProperty(value = "被提问数")
	private Long problemNum;
	
	@ApiModelProperty(value = "回答数量")
	private Long answerNum;
	
	@ApiModelProperty(value = "回答问题列表")
	private List<AnswerVo> answerList;
	
	

}