package com.ztj.dichan.cust.appapi.request.contrast;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.ztj.dichan.cust.appapi.request.BaseApiRequest;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author yincp
 *
 */
@ApiModel(value = "房源对比请求参数")
@Data
@EqualsAndHashCode(callSuper = true)
public class ContrastRequest extends BaseApiRequest {

	

	private static final long serialVersionUID = -3939712683496166028L;

	@ApiModelProperty(value = "房源Id", dataType = "Long",required=true)
	private Long houseId;

	@ApiModelProperty(hidden = true)
	private Long memberId;

	@ApiModelProperty(value = "房源sdid(数据库唯一字段)", dataType = "Long",required=true)
	private Long houseSdid;
	
	

}
