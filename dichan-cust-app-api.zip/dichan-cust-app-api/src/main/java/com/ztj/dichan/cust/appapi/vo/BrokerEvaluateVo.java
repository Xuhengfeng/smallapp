/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 * 
 */
@ApiModel(value="经纪人评价列表VO")
@Data
@EqualsAndHashCode(callSuper=true)
public class BrokerEvaluateVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "会员头像URL")
	private String headUrl;
	
	@ApiModelProperty(value = "会员名称")
	private String memberName;
	
	@ApiModelProperty(value = "评价日期")
	private String evaluateDate;
	
	@ApiModelProperty(value = "评级")
	private Integer grade;
	
	@ApiModelProperty(value = "评价内容")
	private String content;
	
	@ApiModelProperty(value = "评价标签")
	private String tag;
	
}
