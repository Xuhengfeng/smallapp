/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ztj.dichan.cust.rule.request.HouseCollectionRequest;
import com.ztj.dichan.cust.rule.response.house.HouseCollectionVo;



/**
 * @author sily
 *
 */
@FeignClient(name = "houseCollectionServiceClient", url= "${cust.service.url}", fallback = HouseCollectionServiceClient.class)
public interface HouseCollectionServiceClient {
	
	@RequestMapping(method = RequestMethod.POST, value = "/house/collection")
	public List<HouseCollectionVo> queryCollectionList(List<HouseCollectionRequest> houseCollectionRequest);
	
}