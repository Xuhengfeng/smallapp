package com.ztj.dichan.cust.appapi.rest;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.request.DeviceRequest;
import com.ztj.dichan.cust.appapi.service.DeviceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author yincp
 */
@Api(value = "设备相关接口", description = "设备相关接口*")
@RestController
@RequestMapping(value = "/device")
public class DeviceInfoRest extends BaseCustRest {

	@Resource
	private DeviceService deviceService;

	

	@ApiOperation(value = "加入对比列表")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "header", required = true)})
	@PostMapping(value = "/add")
	public RestResult add(@RequestBody DeviceRequest request) {
		deviceService.add(request);
		return RestResult.success("加入成功");

	}
	
	
	
}