/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.infocontent;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.core.enums.InfoContentTypeEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "资讯内容详情信息VO")
@Data
@EqualsAndHashCode(callSuper = true)
public class InfoContentDetailVo  extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "资讯内容id")
	private Long id;
	
	@ApiModelProperty(value = "标题")
	private String title;

	@ApiModelProperty(value = "摘要")
	private String summary;

	@ApiModelProperty(value = "资讯内容的类型")
	private InfoContentTypeEnum type;

	@ApiModelProperty(value = "图片URL")
	private String imageUrl;
	
	@ApiModelProperty(value = "资讯内容")
	private String content;


	@ApiModelProperty(value = "发布时间")
	private Long publishDateTime;
	
	@ApiModelProperty(value = "发布人")
	private String publishPerson;

}
