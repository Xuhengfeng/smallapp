package com.ztj.dichan.cust.appapi.repository.activity;

import java.util.Collection;
import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.cust.core.entity.activity.Template;
import com.ztj.dichan.cust.core.enums.TemplateTypeEnum;

/**
 * 
 * @author sily
 */
@Repository
public interface TemplateRepository extends PagingAndSortingRepository<Template, Long> {

	List<Template> findByIdIn(Collection<Long> ids);
	
	@Deprecated
	Template findTop1ByType(TemplateTypeEnum type);
}