/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "加入清单表单数据",description="加入清单表单数据")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointHouseDetailRequest extends BaseApiRequest {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2299971907507210717L;
	
	@ApiModelProperty(value = "房源sdid，必填",required=true)
	private Long sdid;
}
