package com.ztj.dichan.cust.appapi.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ztj.dichan.cust.appapi.service.NewBuildingService;
import com.ztj.dichan.cust.appapi.vo.newbuilding.NewBuildingVo;

@Controller
@RequestMapping("/newBuild")
public class NewHouseController {

	@Resource
	private NewBuildingService newBuildingService;

	// 新房列表
	@RequestMapping("/newBuildList/{scity}/{pageNo}/{pageSize}")
	public String newhouse(Model model, @PathVariable("scity") String scity,
			@PathVariable("pageNo") Integer pageNo,@PathVariable("pageSize") Integer pageSize) {
		List<NewBuildingVo>  voList = this.newBuildingService.queryList(scity, pageNo, pageSize);
		model.addAttribute("newHouseList", voList);
		model.addAttribute("scity", scity);
		return "/newhouse";
	}

}
