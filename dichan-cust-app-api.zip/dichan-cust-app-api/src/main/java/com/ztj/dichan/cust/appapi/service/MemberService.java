package com.ztj.dichan.cust.appapi.service;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Base64Utils;

import com.alibaba.fastjson.JSONObject;
import com.google.zxing.WriterException;
import com.ztj.common.exception.BizException;
import com.ztj.common.exception.NoLoginException;
import com.ztj.common.util.DateUtil;
import com.ztj.dichan.cust.appapi.constant.SystemConstant;
import com.ztj.dichan.cust.appapi.easemob.service.EasemobUserService;
import com.ztj.dichan.cust.appapi.repository.activity.ActivityGoodsRepository;
import com.ztj.dichan.cust.appapi.repository.activity.ActivityRepository;
import com.ztj.dichan.cust.appapi.repository.activity.CouponFollowRecordRepository;
import com.ztj.dichan.cust.appapi.repository.activity.CouponRepository;
import com.ztj.dichan.cust.appapi.repository.activity.EventActivityRepository;
import com.ztj.dichan.cust.appapi.repository.activity.ScoreFollowRecordRepository;
import com.ztj.dichan.cust.appapi.repository.activity.TemplateRepository;
import com.ztj.dichan.cust.appapi.repository.activity.WalletRepository;
import com.ztj.dichan.cust.appapi.request.WeixinRegRequest;
import com.ztj.dichan.cust.appapi.request.member.RegisterRequest;
import com.ztj.dichan.cust.appapi.service.component.DownloadImageComponent;
import com.ztj.dichan.cust.appapi.service.component.OssComponent;
import com.ztj.dichan.cust.appapi.service.component.SmsComponent;
import com.ztj.dichan.cust.appapi.util.HanyuPinyinHelperUtil;
import com.ztj.dichan.cust.appapi.util.QrCodeUtil;
import com.ztj.dichan.cust.appapi.vo.EmployeeResponse;
import com.ztj.dichan.cust.appapi.vo.MemberInviteVo;
import com.ztj.dichan.cust.appapi.vo.MemberMyInfoVo;
import com.ztj.dichan.cust.appapi.vo.MemberVo;
import com.ztj.dichan.cust.appapi.vo.WeixinSignatureVo;
import com.ztj.dichan.cust.appapi.vo.WeixinVo;
import com.ztj.dichan.cust.appapi.vo.WeixinVo2;
import com.ztj.dichan.cust.core.constant.OssConstant;
import com.ztj.dichan.cust.core.constant.OtherConstant;
import com.ztj.dichan.cust.core.constant.RedisConstant;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.Member;
import com.ztj.dichan.cust.core.entity.activity.Activity;
import com.ztj.dichan.cust.core.entity.activity.ActivityGoods;
import com.ztj.dichan.cust.core.entity.activity.Coupon;
import com.ztj.dichan.cust.core.entity.activity.CouponFollowRecord;
import com.ztj.dichan.cust.core.entity.activity.EventActivity;
import com.ztj.dichan.cust.core.entity.activity.ScoreFollowRecord;
import com.ztj.dichan.cust.core.entity.activity.Template;
import com.ztj.dichan.cust.core.entity.activity.Wallet;
import com.ztj.dichan.cust.core.entity.record.MemberLoginRecord;
import com.ztj.dichan.cust.core.entity.record.SmsCodeRecord;
import com.ztj.dichan.cust.core.enums.CouponFollwTypeEnum;
import com.ztj.dichan.cust.core.enums.CouponStatusEnum;
import com.ztj.dichan.cust.core.enums.DicType;
import com.ztj.dichan.cust.core.enums.EventEnum;
import com.ztj.dichan.cust.core.enums.GenderEnum;
import com.ztj.dichan.cust.core.enums.GoodsTypeEnum;
import com.ztj.dichan.cust.core.enums.MemberStatusEnum;
import com.ztj.dichan.cust.core.enums.OperateTypeEnum;
import com.ztj.dichan.cust.core.enums.ScoreFollowTypeEnum;
import com.ztj.dichan.cust.core.repository.BrokerCollectionRepository;
import com.ztj.dichan.cust.core.repository.BuildCollectionRepository;
import com.ztj.dichan.cust.core.repository.HouseCollectionRepository;
import com.ztj.dichan.cust.core.repository.MemberRepository;
import com.ztj.dichan.cust.core.repository.RentHouseCollectionRepository;
import com.ztj.dichan.cust.core.repository.record.MemberLoginRecordRepository;
import com.ztj.dichan.cust.core.repository.record.SmsCodeRecordRepository;
import com.ztj.dichan.cust.core.util.CodeUtil;
import com.ztj.dichan.cust.core.util.VerifyUtil;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * 
 * @author sily
 */
@Service
@Transactional
public class MemberService extends BaseAppService {

	@Resource
	private ThirdLoginService thirdLoginService;

	@Resource
	private SmsComponent smsComponent;

	@Resource
	private OssComponent ossComponent;

	@Resource
	private MemberRepository memberRepository;

	@Resource
	private MemberLoginRecordRepository memberLoginRecordRepository;

	@Resource
	private SmsCodeRecordRepository smsCodeRecordRepository;

	@Resource
	private BrokerCollectionRepository brokerCollectionRepository;

	@Resource
	private BuildCollectionRepository buildCollectionRepository;

	@Resource
	private HouseCollectionRepository houseCollectionRepository;

	@Resource
	private RentHouseCollectionRepository rentHouseCollectionRepository;

	@Resource
	private WalletRepository walletRepository;

	@Resource
	private DictionaryService dictionaryService;

	@Resource
	private EasemobUserService easemobUserService;

	@Resource
	private DownloadImageComponent downloadImageComponent;

	@Resource
	private CouponRepository couponRepository;

	@Resource
	private ScoreFollowRecordRepository scoreFollowRecordRepository;

	@Resource
	private TemplateRepository templateRepository;

	@Resource
	private CouponFollowRecordRepository couponFollowRecordRepository;

	@Resource
	private EventActivityRepository eventActivityRepository;

	@Resource
	private ActivityRepository activityRepository;

	@Resource
	private ActivityGoodsRepository activityGoodsRepository;

	/**
	 * @param uniqueCode
	 * @return
	 */
	public Long getMemberId(String uniqueCode) {
		String memberId = null;

		try {
			memberId = (String) redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).get(uniqueCode);
		} catch (Exception e) {
			logger.error("从redis获取用户信息出错", e);
		}

		if (StringUtils.isEmpty(memberId)) {
			Member member = memberRepository.findByUniqueCode(uniqueCode);

			if (member == null) {
				throw new NoLoginException("用户未登录");
			}

			memberId = String.valueOf(member.getId());

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(uniqueCode,
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}
		}
		return Long.valueOf(memberId);
	}

	/**
	 * @param uniqueCode
	 * @return
	 */
	public Long getMemberIdAllowNull(String uniqueCode) {
		String memberId = null;

		try {
			memberId = (String) redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).get(uniqueCode);
		} catch (Exception e) {
			logger.error("从redis获取用户信息出错", e);
		}

		if (StringUtils.isEmpty(memberId)) {
			Member member = memberRepository.findByUniqueCode(uniqueCode);

			if (member == null) {
				return null;
			}

			memberId = String.valueOf(member.getId());

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(uniqueCode,
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}
		}

		return Long.valueOf(memberId);
	}

	/**
	 * 
	 * @param memberId
	 * @return
	 */
	public MemberVo getDetailInfo(Long memberId) {
		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return null;
		}
		MemberVo memberVo = new MemberVo();
		memberVo.setCode(member.getCode());
		memberVo.setNickname(member.getNickname());
		memberVo.setGender(member.getGender());
		memberVo.setMobile(member.getMobile());
		memberVo.setEasemobPassword(member.getEasemobPassword());
		memberVo.setEasemobUsername(member.getEasemobUsername());
		if (StringUtils.isNotEmpty(member.getHeadImage())) {
			if (member.getHeadImage().startsWith("http")) {
				memberVo.setHeadImage(member.getHeadImage());
			} else {
				memberVo.setHeadImage(
						systemConstant.getOssCdnUrl() + member.getHeadImage() + OssConstant.SUOFANG_YIBAN);
			}
		} else {
			memberVo.setHeadImage(
					systemConstant.getOssCdnUrl() + OtherConstant.DEFAULT_HEAD_IMAGE + OssConstant.SUOFANG_YIBAN);
		}

		if (StringUtils.isEmpty(member.getEasemobUsername()) || member.getEasemobUsername().indexOf("_") == -1) {
			synchJiguangAccount(member);
		}

		return memberVo;
	}

	/**
	 * 
	 * @param mobile
	 * @param sign
	 * @param operateType
	 */
	public void fetchSmsCode(String mobile, String sign, OperateTypeEnum operateType) {
		if (StringUtils.isEmpty(mobile)) {
			throw new IllegalArgumentException("手机号不能为空");
		}

		if (!VerifyUtil.isMobile(mobile)) {

			throw new IllegalArgumentException("不正确的手机格式");
		}

		if (StringUtils.isEmpty(sign)) {
			throw new IllegalArgumentException("签名不能为空");
		}

		if (operateType == null) {
			throw new IllegalArgumentException("操作类型不能为空");
		}

		if (!(operateType == OperateTypeEnum.REGISTER || operateType == OperateTypeEnum.RESET_PASSWORD
				|| operateType == OperateTypeEnum.UPDATE_MOBILE || operateType == OperateTypeEnum.LOGIN
				|| operateType == OperateTypeEnum.TRADE_PROGRESS || operateType == OperateTypeEnum.GIVE_COUPON
				|| operateType == OperateTypeEnum.GIVE_SCORE || operateType == OperateTypeEnum.SCORE_EXCHANGE_GIFT
				|| operateType == OperateTypeEnum.SCORE_EXCHANGE_COUPON)) {
			throw new IllegalArgumentException("不支持的操作类型");
		}

		Long count = memberRepository.countByMobile(mobile);

		if (count > 0) {
			if (operateType == OperateTypeEnum.UPDATE_MOBILE) {
				throw new IllegalArgumentException("该手机号已被注册,不能更换");
			} else if (operateType == OperateTypeEnum.REGISTER) {
				throw new IllegalStateException("该手机号已注册");
			}

		} else {
			if (operateType == OperateTypeEnum.LOGIN || operateType == OperateTypeEnum.RESET_PASSWORD) {
				throw new IllegalStateException("该手机号未注册");
			}
		}

		String requestStr = mobile + OtherConstant.FETCH_SMS_CODE_PRIVATE_KEY;

		String validateSignStr = DigestUtils.md5Hex(requestStr.toUpperCase());

		if (!validateSignStr.equals(sign)) {
			throw new IllegalArgumentException("非法的签名请求");
		}

		try {
			String key = mobile + "_" + operateType.toString();

			String smsCode = (String) redisTemplate.opsForValue().get(key);

			if (StringUtils.isEmpty(smsCode)) {
				smsCode = smsComponent.sendPhoneCode(mobile);

				SmsCodeRecord record = new SmsCodeRecord();
				record.setMobile(mobile);
				record.setSmsCode(smsCode);
				record.setOperateType(operateType);
				record.setTerminalSource(RequestContextHolder.getTerminalSource());
				record.setNetworkType(RequestContextHolder.getNetworkType());
				record.setClientVersion(RequestContextHolder.getClientVersion());
				record.setClientIp(RequestContextHolder.getClientIp());
				record.setCreateDateTime(LocalDateTime.now());

				smsCodeRecordRepository.save(record);

				redisTemplate.opsForValue().set(key, smsCode, 60, TimeUnit.SECONDS);
			} else {
				throw new IllegalStateException("1分钟内不能重复提交");
			}
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("短信发送失败,手机号[" + mobile + "]" + e);
		}
	}

	/**
	 * 用户注册
	 * 
	 * @param deviceCode
	 * @param mobile
	 * @param password
	 * @param confirmPassword
	 * @param smsCode
	 * @return
	 */
	public String register(RegisterRequest registerRequest) {
		if (registerRequest == null) {
			throw new IllegalArgumentException("无效参数");
		}
		if (StringUtils.isEmpty(registerRequest.getDeviceCode())) {
			throw new IllegalArgumentException("设备类型标识不能为空");
		}

		if (StringUtils.isEmpty(registerRequest.getMobile())) {
			throw new IllegalArgumentException("手机号不能为空");
		}

		if (!VerifyUtil.isMobile(registerRequest.getMobile())) {
			throw new IllegalArgumentException("不正确的手机格式");
		}

		if (StringUtils.isEmpty(registerRequest.getPassword())) {
			throw new IllegalArgumentException("登录密码不能为空");
		}
		if (registerRequest.getPassword().length() < 6 || registerRequest.getPassword().length() > 12) {
			throw new IllegalArgumentException("密码长度最短6位或最长12位");
		}

		if (StringUtils.isEmpty(registerRequest.getSmsCode())) {
			throw new IllegalArgumentException("验证码不能为空");
		}

		try {
			Long count = memberRepository.countByMobile(registerRequest.getMobile());

			if (count > 0) {
				throw new IllegalStateException("该手机号已注册");
			}

			String verifyCode = (String) redisTemplate.opsForValue()
					.get(registerRequest.getMobile() + "_" + OperateTypeEnum.REGISTER.toString());

			if (!Utils.checkSmsCode(registerRequest.getSmsCode(), verifyCode)) {
				throw new IllegalStateException("手机验证码不正确");
			}

			String currentDeviceCode = registerRequest.getDeviceCode();

			if (StringUtils.isEmpty(currentDeviceCode)) {
				currentDeviceCode = UUID.randomUUID().toString();
			}

			if (StringUtils.isNotEmpty(registerRequest.getRecommendPerson())) {
				Member recommendMember = memberRepository.findByCode(registerRequest.getRecommendPerson());

				if (recommendMember == null) {
					throw new IllegalStateException("找不到推荐人信息");
				}
			}

			// 保存用户数据
			Member member = new Member();
			member.setCode(CodeUtil.generateMemberCode());
			member.setMobile(registerRequest.getMobile());
			member.setClientVersion(RequestContextHolder.getClientVersion());
			member.setAppKey(UUID.randomUUID().toString());
			member.setAppSecret(UUID.randomUUID().toString());
			member.setDeviceCode(currentDeviceCode);
			member.setStatus(MemberStatusEnum.NORMAL);
			member.setCreateDateTime(LocalDateTime.now());
			member.setNickname(registerRequest.getMobile());
			member.setGender(GenderEnum.NULL);
			member.setRecommendPerson(registerRequest.getRecommendPerson());
			member.setUsername(registerRequest.getMobile());
			member.setPassword(DigestUtils.md5Hex(registerRequest.getPassword()).toUpperCase());

			String key = currentDeviceCode + "_" + member.getAppSecret() + "_" + member.getCreateDateTime().getNano();
			String uniqueCode = Base64Utils.encodeToString(key.getBytes());

			member.setUniqueCode(uniqueCode);

			memberRepository.save(member);

			// 保存用户钱包数据
			saveWalletInfo(member);

			// 保存用户登录数据
			saveLoginRecordInfo(member);

			// 在redis中存储uniqueCode和用户的绑定关系
			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(member.getUniqueCode(),
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}

			// 赠送优惠券
//			saveCoupon(member);

			// 同步环信用户
			synchEasemobData(member);

			// 生成推广二维码
			saveCodeImage(member);

			// 填充用户的城市信息
			fillScity(registerRequest, member);

			return uniqueCode;
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("用户注册出错", e);
		}
	}

	/**
	 * 用户登录
	 * 
	 * @param mobile
	 * @param password
	 * @param deviceCode
	 * @return
	 */
	public String login(String mobile, String password, String deviceCode) {
		if (StringUtils.isEmpty(mobile)) {
			throw new IllegalArgumentException("手机号不能为空");
		}

		if (!VerifyUtil.isMobile(mobile)) {
			throw new IllegalArgumentException("不正确的手机格式");
		}

		if (StringUtils.isEmpty(password)) {
			throw new IllegalArgumentException("密码不能为空");
		}

		try {
			Member member = memberRepository.findByMobileAndPassword(mobile,
					DigestUtils.md5Hex(password).toUpperCase());

			if (member == null) {
				throw new IllegalArgumentException("手机号或者密码不正确");
			}

			if (member.getStatus() == MemberStatusEnum.DISABLED) {
				throw new IllegalArgumentException("用户已被禁用,不能登录");
			}

			// 判断uniqueCode是否失效
			dealUniqueCodeInfo(deviceCode, member);

			memberRepository.save(member);

			// 保存登录记录
			saveLoginRecordInfo(member);

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(member.getUniqueCode(),
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}

			return member.getUniqueCode();
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("用户登录出错", e);
		}
	}

	/**
	 * 用户验证码登录
	 * 
	 * @param mobile
	 * @param password
	 * @param deviceCode
	 * @return
	 */
	public String smsCodeLogin(String mobile, String deviceCode, String smsCode) {
		if (StringUtils.isEmpty(mobile)) {
			throw new IllegalArgumentException("手机号不能为空");
		}

		if (!VerifyUtil.isMobile(mobile)) {
			throw new IllegalArgumentException("不正确的手机格式");
		}

		if (StringUtils.isEmpty(smsCode)) {
			throw new IllegalArgumentException("验证不能为空");
		}

		String verifyCode = (String) redisTemplate.opsForValue().get(mobile + "_" + OperateTypeEnum.LOGIN.toString());
		if (!Utils.checkSmsCode(smsCode, verifyCode)) {
			throw new IllegalStateException("手机验证码不正确");
		}

		try {
			Member member = memberRepository.findByMobile(mobile);

			if (member == null) {
				throw new IllegalArgumentException("手机号码未注册");
			}

			if (member.getStatus() == MemberStatusEnum.DISABLED) {
				throw new IllegalArgumentException("用户已被禁用,不能登录");
			}

			// 判断uniqueCode是否失效
			dealUniqueCodeInfo(deviceCode, member);

			memberRepository.save(member);

			// 保存登录记录
			saveLoginRecordInfo(member);

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(member.getUniqueCode(),
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}

			return member.getUniqueCode();
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("用户登录出错", e);
		}
	}

	/**
	 * 微信第三方登录
	 * 
	 * @param openId
	 * @param accessToken
	 * @param refreshToken
	 * @param nickname
	 * @param headImage
	 * @param deviceCode
	 * @return
	 */
	public String loginByWechat(String openId, String unionId, String accessToken, String refreshToken, String nickname,
			String sex, String headImage, String deviceCode) {
		if (StringUtils.isEmpty(openId)) {
			throw new IllegalArgumentException("微信openid不能为空");
		}

		if (StringUtils.isEmpty(accessToken)) {
			throw new IllegalArgumentException("微信accessToken不能为空");
		}

		if (StringUtils.isEmpty(refreshToken)) {
			throw new IllegalArgumentException("微信refreshToken不能为空");
		}

		try {
			thirdLoginService.validateWechatAccessToken(openId, accessToken);

			Member member = memberRepository.findByWechatOpenId(openId);

			if (member == null) {
				member = new Member();

				String currentDeviceCode = deviceCode;

				if (StringUtils.isEmpty(currentDeviceCode)) {
					currentDeviceCode = UUID.randomUUID().toString();
				}

				member.setCode("tg_" + System.nanoTime());
				member.setNickname(nickname);

				if (StringUtils.isNotEmpty(headImage)) {
					member.setHeadImage(headImage);
				} else {
					member.setHeadImage(OtherConstant.DEFAULT_HEAD_IMAGE);
				}

				if (StringUtils.isNotEmpty(sex)) {
					if (sex.equals("1")) {
						member.setGender(GenderEnum.MAN);
					} else {
						member.setGender(GenderEnum.WOMEN);
					}
				} else {
					member.setGender(GenderEnum.NULL);
				}

				member.setAppKey(UUID.randomUUID().toString());
				member.setAppSecret(UUID.randomUUID().toString());
				member.setDeviceCode(currentDeviceCode);
				member.setWechatOpenId(openId);
				member.setWechatUnionId(unionId);
				member.setStatus(MemberStatusEnum.NORMAL);
				member.setClientVersion(RequestContextHolder.getClientVersion());
				member.setCreateDateTime(LocalDateTime.now());

				String key = member.getDeviceCode() + "_" + member.getAppSecret() + "_"
						+ member.getCreateDateTime().getNano();
				String uniqueCode = Base64Utils.encodeToString(key.getBytes());

				member.setUniqueCode(uniqueCode);

				memberRepository.save(member);

				// 保存用户钱包数据
				saveWalletInfo(member);

				// 赠送优惠券
				// saveCoupon(member);

				// 保存推广二维码
				saveCodeImage(member);
			}

			// 保存登录记录
			saveLoginRecordInfo(member);

			// 在redis中存储uniqueCode和用户的绑定关系
			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(member.getUniqueCode(),
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}

			return member.getUniqueCode();
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("微信第三方登录出错", e);
		}
	}

	/**
	 * 微信code认证--小程序
	 * 
	 * @param request
	 */
	public WeixinVo authWeixin(String code) {

		if (StringUtils.isEmpty(code)) {
			throw new IllegalArgumentException("无效的参数！");
		}

		JSONObject obj = thirdLoginService.checkWeixinSessionKey(code);
		if (obj == null) {
			throw new IllegalArgumentException("注册授权失败！");
		}

		WeixinVo weixinVo = new WeixinVo();
		weixinVo.setOpenid(obj.getString("openid"));
		weixinVo.setSessionKey(obj.getString("session_key"));
		weixinVo.setUnionid(obj.getString("unionid"));

		long time = LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();

		String authKey = Base64Utils.encodeToString((DigestUtils.md5Hex(weixinVo.getOpenid()) + time).getBytes());
		try {
			// 5五分钟后失效
			redisTemplate.opsForValue().set(authKey, weixinVo.getOpenid(), 300, TimeUnit.SECONDS);
			// redisTemplate.boundHashOps(RedisConstant.REDIS_WEIXIN_AUTH_KEY).put(authKey,weixinVo.getOpenid());
		} catch (Exception e) {
			logger.error("把微信认证信息放入redis出错", e);
		}
		weixinVo.setAuthKey(authKey);
		return weixinVo;

	}

	/**
	 * 小程序微信注册--小程序
	 * 
	 * @param request
	 */
	public void registerWeixin(WeixinRegRequest request) {
		if (request == null) {
			throw new IllegalArgumentException("无效的参数！");
		}

		if (StringUtils.isEmpty(request.getOpenid())) {
			throw new IllegalArgumentException("微信openid为空！");
		}

		if (StringUtils.isEmpty(request.getPhone())) {
			throw new IllegalArgumentException("手机号码为空！");
		}

		if (StringUtils.isEmpty(request.getAuthKey())) {
			throw new IllegalArgumentException("认证key为空！");
		}

		/*
		 * String openid = thirdLoginService.checkWeixinSessionKey(request.getCode());
		 * if (openid == null) { throw new IllegalArgumentException("注册授权失败！"); }
		 */
		String openId = null;

		try {
			// openId = (String)
			// redisTemplate.boundHashOps(RedisConstant.REDIS_WEIXIN_AUTH_KEY).get(request.getAuthKey());
			openId = (String) redisTemplate.opsForValue().get(request.getAuthKey());
		} catch (Exception e) {
			logger.error("从redis获取用户信息出错", e);
		}

		if (!request.getOpenid().equals(openId)) {
			throw new IllegalArgumentException("认证失败，请检查认证key是否有效！");
		}

		try {
			Member member = memberRepository.findByWechatOpenId(request.getOpenid());

			if (member == null) {
				member = memberRepository.findByMobile(request.getPhone());
			}

			if (member == null) {
				member = new Member();

				String currentDeviceCode = RequestContextHolder.getDeviceCode();

				if (StringUtils.isEmpty(currentDeviceCode)) {
					currentDeviceCode = UUID.randomUUID().toString();
				}

				member.setCode("tg_" + System.nanoTime());
				member.setNickname(request.getNickname());

				if (StringUtils.isNotEmpty(request.getHeadImage())) {
					member.setHeadImage(request.getHeadImage());
				} else {
					member.setHeadImage(OtherConstant.DEFAULT_HEAD_IMAGE);
				}

				if (StringUtils.isNotEmpty(request.getSex())) {
					if (request.getSex().equals("1")) {
						member.setGender(GenderEnum.MAN);
					} else {
						member.setGender(GenderEnum.WOMEN);
					}
				} else {
					member.setGender(GenderEnum.NULL);
				}
				member.setAppKey(UUID.randomUUID().toString());
				member.setAppSecret(UUID.randomUUID().toString());
				member.setDeviceCode(currentDeviceCode);
				member.setWechatOpenId(request.getOpenid());
				member.setWechatUnionId("");
				member.setStatus(MemberStatusEnum.NORMAL);
				member.setClientVersion(RequestContextHolder.getClientVersion());
				member.setCreateDateTime(LocalDateTime.now());
				member.setMobile(request.getPhone());
				member.setUsername(request.getPhone());

				String key = member.getDeviceCode() + "_" + member.getAppSecret() + "_"
						+ member.getCreateDateTime().getNano();
				String uniqueCode = Base64Utils.encodeToString(key.getBytes());

				member.setUniqueCode(uniqueCode);

				memberRepository.save(member);

				// 生成推广二维码
				saveCodeImage(member);

				synchJiguangAccount(member);
			}
		} catch (Exception e) {
			throw new BizException("微信用户注册失败", e);
		}

		/*
		 * try { redisTemplate.boundHashOps(RedisConstant.REDIS_WEIXIN_AUTH_KEY).delete(
		 * request.getAuthKey()); } catch (Exception e) {
		 * logger.error("从redis中删除authKey出错", e); }
		 */
	}

	/**
	 * 微信code认证--公众号
	 * 
	 * @param request
	 */
	public WeixinVo2 authWeixin2(String code) {

		if (StringUtils.isEmpty(code)) {
			throw new IllegalArgumentException("无效的参数！");
		}

		JSONObject obj = thirdLoginService.checkWeixinAccessToken(code);
		if (obj == null) {
			throw new IllegalArgumentException("获取微信公众号AccessToken失败！");
		}

		String accessToken = obj.getString("access_token");
		String openid = obj.getString("openid");

		Member member = this.memberRepository.findByWechatOpenId(openid);
		WeixinVo2 weixinVo = new WeixinVo2();
		weixinVo.setOpenid(openid);
		if (member != null) {
			if (member.getStatus() == MemberStatusEnum.DISABLED) {
				throw new IllegalArgumentException("用户已被禁用,不能登录");
			}
			String deviceCode = "weixingzh";
			// 判断uniqueCode是否失效
			dealUniqueCodeInfo(deviceCode, member);

			memberRepository.save(member);

			// 保存登录记录
			saveLoginRecordInfo(member);

			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(member.getUniqueCode(),
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}
			weixinVo.setUniqueCode(member.getUniqueCode());
			weixinVo.setStatus(1);
			return weixinVo;
		}

		JSONObject userInfo = thirdLoginService.getWeixinUserInfo(accessToken, openid);
		if (userInfo == null) {
			throw new IllegalArgumentException("获取公众号微信用户信息失败！");
		}
		weixinVo.setStatus(2);
		weixinVo.setHeadImage(userInfo.getString("headimgurl"));
		weixinVo.setNickname(userInfo.getString("nickname"));
		weixinVo.setSex(userInfo.getString("sex"));
		long time = LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();

		String authKey = Base64Utils.encodeToString((DigestUtils.md5Hex(weixinVo.getOpenid()) + time).getBytes());
		try {
			// 5五分钟后失效
			redisTemplate.opsForValue().set(authKey, weixinVo.getOpenid(), 300, TimeUnit.SECONDS);
		} catch (Exception e) {
			logger.error("把微信公众号认证信息放入redis出错", e);
		}
		weixinVo.setAuthKey(authKey);
		return weixinVo;

	}

	/**
	 * 微信公众号注册--公众号
	 * 
	 * @param request
	 */
	public String registerWeixin2(WeixinRegRequest request) {
		if (request == null) {
			throw new IllegalArgumentException("无效的参数！");
		}

		if (StringUtils.isEmpty(request.getVerifyCode())) {
			throw new IllegalArgumentException("验证码为空！");
		}

		if (StringUtils.isEmpty(request.getOpenid())) {
			throw new IllegalArgumentException("微信openid为空！");
		}

		if (StringUtils.isEmpty(request.getPhone())) {
			throw new IllegalArgumentException("手机号码为空！");
		}

		if (StringUtils.isEmpty(request.getAuthKey())) {
			throw new IllegalArgumentException("认证key为空！");
		}

		String verifyCode = (String) redisTemplate.opsForValue()
				.get(request.getPhone() + "_" + OperateTypeEnum.REGISTER.toString());
		if (!Utils.checkSmsCode(request.getVerifyCode(), verifyCode)) {
			throw new IllegalStateException("手机验证码不正确");
		}

		String openId = null;
		try {
			openId = (String) redisTemplate.opsForValue().get(request.getAuthKey());
		} catch (Exception e) {
			logger.error("从redis获取用户信息出错", e);
		}

		if (!request.getOpenid().equals(openId)) {
			throw new IllegalArgumentException("gzh认证失败，请检查认证key是否有效！");
		}

		Member member = memberRepository.findByWechatOpenId(request.getOpenid());

		if (member == null) {
			member = memberRepository.findByMobile(request.getPhone());
		}

		try {
			if (member == null) {
				member = new Member();

				String currentDeviceCode = "weixingzh";

				member.setCode("tg_" + System.nanoTime());
				member.setNickname(request.getNickname());

				if (StringUtils.isNotEmpty(request.getHeadImage())) {
					member.setHeadImage(request.getHeadImage());
				} else {
					member.setHeadImage(systemConstant.getOssCdnUrl() + OtherConstant.DEFAULT_HEAD_IMAGE);
				}

				if (StringUtils.isNotEmpty(request.getSex())) {
					if (request.getSex().equals("1")) {
						member.setGender(GenderEnum.MAN);
					} else {
						member.setGender(GenderEnum.WOMEN);
					}
				} else {
					member.setGender(GenderEnum.NULL);
				}
				member.setAppKey(UUID.randomUUID().toString());
				member.setAppSecret(UUID.randomUUID().toString());
				member.setDeviceCode(currentDeviceCode);
				member.setWechatOpenId(request.getOpenid());
				member.setWechatUnionId("");
				member.setStatus(MemberStatusEnum.NORMAL);
				member.setClientVersion(RequestContextHolder.getClientVersion());
				member.setCreateDateTime(LocalDateTime.now());
				member.setMobile(request.getPhone());
				member.setUsername(request.getPhone());

				String key = member.getDeviceCode() + "_" + member.getAppSecret() + "_"
						+ member.getCreateDateTime().getNano();
				String uniqueCode = Base64Utils.encodeToString(key.getBytes());

				member.setUniqueCode(uniqueCode);

				memberRepository.save(member);

				// 保存用户钱包数据
				saveWalletInfo(member);

				// 赠送优惠券
				// saveCoupon(member);

				// 生成推广二维码
				saveCodeImage(member);

				// 同步极光账号
				synchJiguangAccount(member);
			} else {
				if (StringUtils.isEmpty(member.getUniqueCode())) {
					String key = member.getDeviceCode() + "_" + member.getAppSecret() + "_"
							+ member.getCreateDateTime().getNano();
					String uniqueCode = Base64Utils.encodeToString(key.getBytes());
					member.setUniqueCode(uniqueCode);
					memberRepository.save(member);
				}
			}

			// 保存登录记录
			saveLoginRecordInfo(member);

			// 在redis中存储uniqueCode和用户的绑定关系
			try {
				redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(member.getUniqueCode(),
						String.valueOf(member.getId()));
			} catch (Exception e) {
				logger.error("把用户信息放入redis出错", e);
			}

			return member.getUniqueCode();
		} catch (Exception e) {
			throw new BizException("公众号用户注册失败", e);
		}
	}

	public String loginWeixin(String phone, String openid) {

		if (StringUtils.isEmpty(phone)) {
			throw new IllegalArgumentException("微信绑定手机号为空！");
		}

		if (StringUtils.isEmpty(openid)) {
			throw new IllegalArgumentException("微信openid为空！");
		}

		Member member = memberRepository.findByWechatOpenId(openid);

		if (member == null) {
			member = memberRepository.findByMobile(phone);

			if (member == null) {
				throw new IllegalArgumentException("登陆失败，请检查手机号或openid是否正确");
			}

		} else {
			if (StringUtils.isEmpty(member.getMobile())) {
				try {
					member.setMobile(phone);
					member.setUsername(member.getMobile());
					memberRepository.save(member);
				} catch (Exception e) {
					logger.error("微信绑定手机号失败", e);
				}

			}
		}

		// 判断uniqueCode是否失效
		dealUniqueCodeInfo(RequestContextHolder.getDeviceCode(), member);

		// 保存登录记录
		saveLoginRecordInfo(member);

		// 在redis中存储uniqueCode和用户的绑定关系
		try {
			redisTemplate.boundHashOps(RedisConstant.REDIS_USER_UNIQUE_CODES).put(member.getUniqueCode(),
					String.valueOf(member.getId()));
		} catch (Exception e) {
			logger.error("把用户信息放入redis出错", e);
		}

		return member.getUniqueCode();
	}

	/**
	 * 修改昵称
	 * 
	 * @param memberId
	 * @param nickName
	 */
	public void updateNickName(Long memberId, String nickname) {
		if (StringUtils.isEmpty(nickname)) {
			throw new IllegalArgumentException("昵称不能为空");
		}

		try {

			Long count = memberRepository.countByNickname(nickname);

			if (count > 0) {
				throw new IllegalStateException("昵称已存在,请重新输入");
			}

			Member member = memberRepository.findOne(memberId);

			/*
			 * if (StringUtils.isNotEmpty(member.getNickname())) { throw new
			 * IllegalStateException("昵称只能设置一次"); }
			 */

			member.setNickname(nickname);
			member.setUpdateDateTime(LocalDateTime.now());

			memberRepository.save(member);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("修改用户昵称出错", e);
		}
	}

	/**
	 * 修改性别
	 * 
	 * @param MerberId
	 * @param gender
	 */
	public void updateGender(Long merberId, GenderEnum gender) {
		if (gender == null) {
			throw new IllegalArgumentException("性别不能为空");
		}

		if (gender == GenderEnum.NULL) {
			throw new IllegalArgumentException("性别只能是男或女");
		}

		try {
			Member member = memberRepository.findOne(merberId);

			member.setGender(gender);
			member.setUpdateDateTime(LocalDateTime.now());

			memberRepository.save(member);
		} catch (Exception e) {
			throw new BizException("修改用户性别出错", e);
		}

	}

	/**
	 * 修改头像
	 * 
	 * @param memberId
	 * @param base64Image
	 * @return
	 */
	public String updateHeadImage(Long memberId, String base64Image) {
		if (StringUtils.isEmpty(base64Image)) {
			throw new IllegalArgumentException("头像链接地址不能为空");
		}

		try {
			Member member = memberRepository.findOne(memberId);
			if (member == null) {
				throw new IllegalArgumentException("未知用户信息,memberId=" + memberId);
			}
			String imageType = ossComponent.fetchImageType(base64Image);
			String key = memberId + imageType;

			/*
			 * if (StringUtils.isEmpty(member.getHeadImage())) { String imageType =
			 * ossComponent.fetchImageType(base64Image); String imageName =
			 * UUID.randomUUID().toString().replaceAll("-", "");
			 * 
			 * key = imageName + imageType; } else {
			 * 
			 * if (member.getHeadImage().startsWith("http")) { key =
			 * UUID.randomUUID().toString().replaceAll("-", ""); } else { key =
			 * member.getHeadImage(); } }
			 */
			String catalog = SystemConstant.BUCKET + "head" + SystemConstant.SPRIT;
			member.setHeadImage(systemConstant.getOssCdnUrl() + catalog + key + OssConstant.SUOFANG_YIBAN + "&random="
					+ new Random().nextInt(10000000));
			member.setUpdateDateTime(LocalDateTime.now());

			memberRepository.save(member);

			// 上传图片到oss
			ossComponent.uploadPicture(key, base64Image, catalog);

			return member.getHeadImage();
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("修改头像出错", e);
		}
	}

	/**
	 * 重置密码
	 * 
	 * @param mobile
	 * @param smsCode
	 * @param newPassword
	 * @param confirmPassword
	 */
	public void resetPassword(String mobile, String smsCode, String newPassword, String confirmPassword) {
		if (StringUtils.isEmpty(mobile)) {
			throw new IllegalArgumentException("手机号不能为空");
		}

		if (!VerifyUtil.isMobile(mobile)) {
			throw new IllegalArgumentException("不正确的手机格式");
		}

		if (StringUtils.isEmpty(newPassword)) {
			throw new IllegalArgumentException("新密码不能为空");
		}

		if (!newPassword.equals(confirmPassword)) {
			throw new IllegalArgumentException("两次密码输入不一致");
		}

		String verifyCode = (String) redisTemplate.opsForValue()
				.get(mobile + "_" + OperateTypeEnum.RESET_PASSWORD.toString());

		if (!Utils.checkSmsCode(smsCode, verifyCode)) {
			throw new IllegalArgumentException("手机验证码不正确");
		}

		try {
			Member member = memberRepository.findByMobile(mobile);

			if (member == null) {
				throw new IllegalStateException("用户信息不存在");
			}

			member.setPassword(DigestUtils.md5Hex(newPassword).toUpperCase());
			member.setUpdateDateTime(LocalDateTime.now());

			memberRepository.save(member);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("用户重置密码出错", e);
		}
	}

	/**
	 * 退出登录
	 * 
	 * @param memberId
	 */
	public void logout(Long memberId) {
		if (memberId == null || memberId == 0) {
			throw new IllegalArgumentException("用户编号不能为空");
		}

		try {
			Member member = memberRepository.findOne(memberId);

			String oldUniqueCode = member.getUniqueCode();

			String key = UUID.randomUUID().toString() + "_" + member.getAppSecret() + "_"
					+ member.getCreateDateTime().getNano();
			String newUniqueCode = Base64Utils.encodeToString(key.getBytes());

			member.setUniqueCode(newUniqueCode);
			member.setUpdateDateTime(LocalDateTime.now());

			memberRepository.save(member);

			try {
				redisTemplate.boundHashOps(OtherConstant.REDIS_USER_UNIQUE_CODES).delete(oldUniqueCode);
			} catch (Exception e) {
				logger.error("从redis中删除旧的uniqueCode出错", e);
			}
		} catch (Exception e) {
			throw new BizException("用户注销出错", e);
		}
	}

	/**
	 * 修改密码
	 * 
	 * @param memberId
	 * @param password
	 * @param newPassword
	 * @param confirmPassword
	 */
	public void updatePassword(Long memberId, String password, String newPassword, String confirmPassword) {
		if (memberId == null || memberId == 0) {
			throw new IllegalArgumentException("用户编号不能为空");
		}

		if (StringUtils.isEmpty(password)) {
			throw new IllegalArgumentException("原密码不能为空");
		}

		if (StringUtils.isEmpty(newPassword)) {
			throw new IllegalArgumentException("新密码不能为空");
		}

		if (newPassword.length() > 12 && newPassword.length() < 6) {
			throw new IllegalArgumentException("请设置密码长度在6到12个字符");
		}

		if (!confirmPassword.equals(newPassword)) {
			throw new IllegalArgumentException("两次密码输入不一致");
		}

		try {

			Member member = memberRepository.findOne(memberId);

			member.setPassword(DigestUtils.md5Hex(newPassword).toUpperCase());
			member.setUpdateDateTime(LocalDateTime.now());

			memberRepository.save(member);
		} catch (Exception e) {
			throw new BizException("修改密码出错了", e);
		}
	}

	/**
	 * 更换手机号
	 * 
	 * @param memberId
	 * @param mobile
	 * @param smsCode
	 */
	public void updateMobile(Long memberId, String mobile, String smsCode) {
		if (memberId == null || memberId == 0) {
			throw new IllegalArgumentException("用户编号不能为空");
		}

		if (StringUtils.isEmpty(mobile)) {
			throw new IllegalArgumentException("手机号不能为空");
		}

		if (!VerifyUtil.isMobile(mobile)) {
			throw new IllegalArgumentException("不正确的手机格式");
		}

		if (StringUtils.isEmpty(smsCode)) {
			throw new IllegalArgumentException("验证码不能为空");
		}

		try {
			Long count = memberRepository.countByMobile(mobile);

			if (count > 0) {
				throw new IllegalArgumentException("该手机号已被注册");
			}

			String verifyCode = (String) redisTemplate.opsForValue()
					.get(mobile + "_" + OperateTypeEnum.UPDATE_MOBILE.toString());

			if (StringUtils.isEmpty(verifyCode) || !verifyCode.equals(smsCode)) {
				throw new IllegalArgumentException("手机验证码不正确");
			}

			Member member = memberRepository.findOne(memberId);

			member.setMobile(mobile);
			member.setUpdateDateTime(LocalDateTime.now());

			memberRepository.save(member);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("更换手机号出错了", e);
		}
	}

	/**
	 * app获取我的信息
	 * 
	 * @param memberId
	 * @return
	 */
	public MemberMyInfoVo getMemberMyInfo(Long memberId) {
		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return null;
		}
		MemberMyInfoVo vo = new MemberMyInfoVo();
		vo.setCode(member.getCode());
		vo.setId(member.getId());
		vo.setNickname(member.getNickname());
		if (member.getGender() != null) {
			vo.setGender(member.getGender().name());
		}
		vo.setMobile(member.getMobile());
		String custServerPhone = dictionaryService.getDictionaryValue(DicType.CUST_SERVER_PHONE);
		if (custServerPhone == null) {
			custServerPhone = "";
		}
		vo.setCustServerPhone(custServerPhone);

		if (StringUtils.isNotEmpty(member.getHeadImage())) {
			if (member.getHeadImage().startsWith("http")) {
				vo.setHeadImage(member.getHeadImage());
			} else {
				vo.setHeadImage(systemConstant.getOssCdnUrl() + member.getHeadImage() + OssConstant.SUOFANG_YIBAN);
			}
		} else {
			vo.setHeadImage(
					systemConstant.getOssCdnUrl() + OtherConstant.DEFAULT_HEAD_IMAGE + OssConstant.SUOFANG_YIBAN);
		}

		if (StringUtils.isEmpty(member.getEasemobUsername()) || member.getEasemobUsername().indexOf("_") == -1) {
			synchJiguangAccount(member);
		}

		vo.setEasemobPassword(member.getEasemobPassword());
		vo.setEasemobUsername(member.getEasemobUsername());

		// vo.setHeadImage(member.getHeadImage());

		Integer renHouseNum = rentHouseCollectionRepository.countByMemberId(memberId);
		Integer houseNum = houseCollectionRepository.countByMemberId(memberId);
		Integer buildNum = buildCollectionRepository.countByMemberId(memberId);
		Integer brokerNum = brokerCollectionRepository.countByMemberId(memberId);

		vo.setBrokerCollectCount(brokerNum);
		vo.setBuildCollectCount(buildNum);
		vo.setHouseCollectCount(houseNum);
		vo.setRentHouseCollectCount(renHouseNum);

		Wallet wallet = walletRepository.findByMemberId(member.getId());

		if (wallet != null) {
			vo.setScore(wallet.getScore());
			vo.setCouponCount(wallet.getCouponCount());
		}

		Long countCoupon = 0L;
		countCoupon = couponRepository.countCoupon(memberId);

		String datePrefix = DateUtil.formatLocalDate(LocalDate.now());
		String dateSubfix = " 00:00:00";
		LocalDateTime beginDateTime = DateUtil.toLocalDateTime(datePrefix + dateSubfix);
		LocalDateTime endDateTime = LocalDateTime.now();

		Long countScore = 0L;
		countScore = scoreFollowRecordRepository.countScore(beginDateTime, endDateTime, memberId);

		vo.setToDayScore(countScore);
		vo.setOverdueCoupon(countCoupon);

		return vo;

	}

	/**
	 * 
	 * @param deviceCode
	 * @param member
	 */
	private void dealUniqueCodeInfo(String deviceCode, Member member) {
		String currentDeviceCode = deviceCode;

		if (StringUtils.isEmpty(currentDeviceCode)) {
			currentDeviceCode = UUID.randomUUID().toString();
		}

		// 如果当前deviceCode和用户注册时或最近一次登录的device不同时,
		// 那么通过相同算法生成的uniqueCode也会不同,在安全级别较高时,可以执行相应的校验操作,这里暂时省略
		if (!currentDeviceCode.equals(member.getDeviceCode())) {
			logger.warn("用户[" + member.getId() + "]不在最近的设备登录,重新生成新的uniqueCode");

			// 重新设置deviceCode和
			String oldUniqueCode = member.getUniqueCode();
			String key = currentDeviceCode + "_" + member.getAppSecret() + "_" + member.getCreateDateTime().getNano();
			String newUniqueCode = Base64Utils.encodeToString(key.getBytes()).replaceAll("=", "A");

			member.setDeviceCode(currentDeviceCode);
			member.setUniqueCode(newUniqueCode);
			member.setUpdateDateTime(LocalDateTime.now());

			memberRepository.save(member);

			try {
				redisTemplate.boundHashOps(OtherConstant.REDIS_USER_UNIQUE_CODES).delete(oldUniqueCode);
			} catch (Exception e) {
				logger.error("从redis中删除旧的uniqueCode出错", e);
			}
		}
	}

	/**
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<MemberInviteVo> myInvite(Long memberId, Integer pageNo, Integer pageSize) {

		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createDateTime");

		Member member = memberRepository.findOne(memberId);

		List<MemberInviteVo> voList = new ArrayList<>();

		Page<Member> page = memberRepository.findByRecommendPerson(member.getCode(), pageRequest);

		if (page != null) {
			page.getContent().stream().forEach(member2 -> {
				MemberInviteVo vo = new MemberInviteVo();

				vo.setHeadImage(member2.getHeadImage());
				vo.setNickname(member2.getNickname());
				vo.setCreateDateTime(DateUtil.formatLocalDateTime(member2.getCreateDateTime()));

				voList.add(vo);

			});
		}

		return voList;

	}

	/**
	 * 
	 * @param memberId
	 * @return
	 */
	public MemberInviteVo InviteTome(Long memberId) {
		Member member = memberRepository.findOne(memberId);

		if (StringUtils.isNotEmpty(member.getRecommendPerson())) {
			Member recommendMember = memberRepository.findByCode(member.getRecommendPerson());

			if (recommendMember != null) {

				MemberInviteVo vo = new MemberInviteVo();

				vo.setHeadImage(recommendMember.getHeadImage());
				vo.setNickname(recommendMember.getNickname());
				vo.setCreateDateTime(DateUtil.formatLocalDateTime(recommendMember.getCreateDateTime()));

				return vo;
			}

		}

		return null;

	}

	/**
	 * 
	 * @param memberId
	 * @return
	 */
	public Map<String, String> fetchQrCodeUrl(Long memberId) {

		Map<String, String> map = new HashMap<>();
		Member member = memberRepository.findOne(memberId);

		String codeUrl = systemConstant.getOssCdnUrl() + member.getCodeImage();
		String nickname = member.getNickname();
		String headImage = member.getHeadImage();
		map.put("codeUrl", codeUrl);
		map.put("nickname", nickname);
		map.put("headImage", headImage);
		map.put("title", "邀请您体验世华易居APP");
		map.put("describe",
				"世华易居app是一款非常受欢迎的综合房产服务软件。世华易居app的主要服务是为有需要的用户提供房产租赁、购买等服务。新房和二手房世华易居app全都有，而且服务十分贴心，价格也很优惠！");
		map.put("shareImageUrl",
				"https://dichan-test.oss-cn-shenzhen.aliyuncs.com/dichan_cust/banner/017eecd4b1d848dda435534d361156b0.png");
		map.put("shareUrl", systemConstant.getH5Url() + "?name=" + member.getNickname() + "&code=" + member.getCode());

		return map;
	}
//
//	/**
//	 * 
//	 * @param memberId
//	 * @return
//	 */
//	public void applyQRCodeUrl(Member member) {
//
//		try {
//			saveCodeImage(member);
//		} catch (Exception e) {
//			throw new RuntimeException(e);
//		}
//	}
//
//	public List<Member> queryAll() {
//		return memberRepository.findByCodeImageIsNull();
//	}

	/**
	 * 下载会员头像
	 * 
	 * @param username
	 * @param response
	 */
	public void downloadHeadImage(String username, HttpServletResponse response) {

		// long start = System.currentTimeMillis();
		Member member = memberRepository.findByEasemobUsername(username);
		if (member == null || StringUtils.isEmpty(member.getHeadImage())
				|| member.getHeadImage().indexOf("http") == -1) {
			downloadImageComponent.handleImage("default_head_image.png", response);
			return;
		}
		URL url = null;
		byte[] buffer = new byte[1024];
		BufferedInputStream bis = null;
		InputStream is = null;
		try {
			url = new URL(member.getHeadImage());
			is = url.openStream();
			bis = new BufferedInputStream(is);
			OutputStream os = response.getOutputStream();
			int i = bis.read(buffer);
			while (i != -1) {
				os.write(buffer, 0, i);
				i = bis.read(buffer);
			}

		} catch (Exception e) {
			logger.error("会员下载图片失败,username=" + username + ",URL=" + member.getHeadImage() + " >>>>", e);
		} finally {
			if (bis != null) {
				try {
					bis.close();
				} catch (IOException e) {
					logger.error("BufferedInputStream 关闭失败>>>", e);
				}
			}
		}
		if (is != null) {
			try {
				is.close();
			} catch (IOException e) {
				logger.error("InputStream 关闭失败>>>", e);
			}
		}
	}

	/**
	 * 获取微信公众号分享签名
	 * 
	 * @return
	 */
	public WeixinSignatureVo getWeixinSignature(String url) {

		if (StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("url不能为空");
		}
		// jsapi_ticket=sM4AOVdWfPE4DxkXGEs8VMCPGGVi4C3VM0P37wVUCFvkVAy_90u5h9nbSlYy3-Sl-HhTdfl2fzFy1AOcHKP7qg&noncestr=Wm3WZYTPz0wzccnW&timestamp=1414587457&url=http://mp.weixin.qq.com?params=value
		WeixinSignatureVo weixinSignatureVo = new WeixinSignatureVo();
		String jsapi_ticket = thirdLoginService.getJsapiTicket();
		if (StringUtils.isEmpty(jsapi_ticket)) {
			throw new IllegalArgumentException("获取jsapi_ticket 失败！");
		}

		String nonceStr = UUID.randomUUID().toString().replaceAll("-", "");
		Long timestamp = System.currentTimeMillis() / 1000;
		String sha1 = "jsapi_ticket=" + jsapi_ticket + "&noncestr=" + nonceStr + "&timestamp=" + timestamp + "&url="
				+ url;
		logger.info("gzh-WeixinSignature-str=" + sha1);
		weixinSignatureVo.setNonceStr(nonceStr);
		weixinSignatureVo.setTimestamp(timestamp);
		weixinSignatureVo.setSignature(DigestUtils.sha1Hex(sha1));
		weixinSignatureVo.setAppId(systemConstant.getWeixinGzhAppid());
		logger.info("gzh-WeixinSignature=" + weixinSignatureVo.getSignature());
		return weixinSignatureVo;
	}

	public void fetchCitymessage() {
		try {

			List<Member> memberList = memberRepository.findByCityNameIsNull();

			List<String> mobileList = new ArrayList<>();

			for (Member member : memberList) {
				mobileList.add(member.getMobile());
			}

			String json = JSONObject.toJSONString(mobileList);

			// 通过restTemplate发送http请求,数据格式为json串,服务端通过request.getInputStream()或者@RequestBody接收数据
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.parseMediaType("application/json; charset=UTF-8"));
			headers.add("Accept", MediaType.APPLICATION_JSON.toString());

			HttpEntity<String> formEntity = new HttpEntity<>(json, headers);

			ResponseEntity<List<EmployeeResponse>> responseEntity = restTemplate.exchange(
					systemConstant.getGroupApiUrl() + "getMessage", HttpMethod.POST, formEntity,
					new ParameterizedTypeReference<List<EmployeeResponse>>() {
					});

			List<EmployeeResponse> employeeList = responseEntity.getBody();

			Map<String, EmployeeResponse> employeeMap = new HashMap<>();

			employeeList.forEach(employee -> {
				employeeMap.put(employee.getPhone(), employee);
			});

			CountDownLatch countDownLatch = new CountDownLatch(memberList.size());

			for (Member member : memberList) {
				executor.submit(new Runnable() {

					@Override
					public void run() {
						try {
							if (employeeMap.containsKey(member.getMobile())) {
								EmployeeResponse employee = employeeMap.get(member.getMobile());

								member.setIsEmployee(Boolean.TRUE);
								member.setScity(employee.getScity());
								member.setCityName(getCityNameByCityCode(employee.getScity()));
							} else {
								member.setIsEmployee(Boolean.FALSE);
								member.setCityName(getMobileLocation(member.getMobile()));
								member.setScity(
										HanyuPinyinHelperUtil.toHanyuPinyin(getMobileLocation(member.getMobile())));
							}

							member.setUpdateDateTime(LocalDateTime.now());

							memberRepository.save(member);
						} catch (Exception e) {
							logger.error("修改用户城市信息出错了", e);
						} finally {
							countDownLatch.countDown();
						}
					}
				});
			}

			try {
				countDownLatch.await();
			} catch (Exception e) {
				logger.error("countDownLatch阻塞等待出错了", e);
			}
		} catch (Exception e) {
			throw new RuntimeException("补充用户城市信息出错了", e);
		}
	}

//
//	public String getMobileLocation(String mobile) {
//
//		HttpHeaders requestHeaders = new HttpHeaders();
//		requestHeaders.add("Authorization", "APPCODE " + systemConstant.getAppcode());
//
//		HttpEntity<String> requestEntity = new HttpEntity<>(null, requestHeaders);
//
//		ResponseEntity<String> responseEntity = restTemplate.exchange(
//				"https://jisushouji.market.alicloudapi.com/shouji/query?shouji=" + mobile, HttpMethod.GET,
//				requestEntity, String.class);
//
//		String result = responseEntity.getBody();
//
//		JSONObject jsonObject = (JSONObject) JSON.parse(result);
//
//		String status = jsonObject.getString("status");
//		String msg = jsonObject.getString("msg");
//
//		if (StringUtils.isEmpty(status)) {
//			throw new IllegalStateException("调用接口出错了");
//		}
//
//		if (!status.equals("0")) {
//			throw new IllegalStateException("调用接口出错了,msg=" + msg);
//		}
//
//		JSONObject resultJsonObject = jsonObject.getJSONObject("result");
//
//		String city = resultJsonObject.getString("city");
//		String province = resultJsonObject.getString("province");
//		if (StringUtils.isEmpty(city)) {
//			return province;
//		}
//
//		return city;
//	}

	public List<Member> queyList() {
		return memberRepository.findTop1000By();
	}

	/**
	 * 
	 * @param member
	 */
	private void saveWalletInfo(Member member) {
		Wallet wallet = walletRepository.findByMemberId(member.getId());

		if (wallet == null) {
			wallet = new Wallet();

			wallet.setMemberId(member.getId());
			wallet.setMemberCode(member.getCode());
			wallet.setScore(0L);
			wallet.setCouponCount(0);
			wallet.setCreateDateTime(LocalDateTime.now());

			walletRepository.save(wallet);
		}
	}

	/**
	 * 
	 * @param member
	 */
	private void saveLoginRecordInfo(Member member) {
		MemberLoginRecord record = new MemberLoginRecord();
		record.setMemberId(member.getId());
		record.setMemberCode(member.getCode());
		record.setMobile(member.getMobile());
		record.setAppKey(member.getAppKey());
		record.setAppSecret(member.getAppSecret());
		record.setDeviceCode(member.getDeviceCode());
		record.setUniqueCode(member.getUniqueCode());
		record.setTerminalSource(RequestContextHolder.getTerminalSource());
		record.setNetworkType(RequestContextHolder.getNetworkType());
		record.setClientVersion(RequestContextHolder.getClientVersion());
		record.setClientIp(RequestContextHolder.getClientIp());
		record.setCreateDateTime(LocalDateTime.now());

		memberLoginRecordRepository.save(record);
	}

	/**
	 * 同步环信用户
	 * 
	 * @param member
	 */
	private void synchEasemobData(Member member) {
		try {
			member.setEasemobUsername(member.getId() + "_" + member.getMobile());
			member.setEasemobPassword(new Random().nextInt(100000000) + "");

			easemobUserService.regUser(member.getEasemobUsername(), member.getEasemobPassword(), member.getNickname());

			memberRepository.save(member);
		} catch (Exception e) {
			logger.error("会员注册,同步注册极光账号失败", e);
		}
	}

	/**
	 * 
	 * @param member
	 */
	private void synchJiguangAccount(Member member) {
		try {
			member.setEasemobUsername(member.getId() + "_" + member.getMobile());
			member.setEasemobPassword(new Random().nextInt(100000000) + "");

			easemobUserService.regUser(member.getEasemobUsername(), member.getEasemobPassword(), member.getNickname());

			memberRepository.save(member);
		} catch (Exception e) {
			logger.error("会员注册,同步注册极光账号失败", e);
		}
	}

	/**
	 * 注册赠送卡券或者积分
	 * 
	 * @param member
	 */
	private void saveCoupon(Member member) {
		try {
			List<EventActivity> eventActivityList = eventActivityRepository.findByEvent(EventEnum.REGISTER);

			if (eventActivityList == null || eventActivityList.isEmpty()) {
				logger.warn("没有发现配置的相关的活动");
				return;
			}

			Wallet wallet = walletRepository.findByMemberId(member.getId());

			for (EventActivity eventActivity : eventActivityList) {
				Activity activity = eventActivity.getActivity();

				List<ActivityGoods> activityGoodsList = activityGoodsRepository.findByActivityId(activity.getId());

				if (activityGoodsList == null || activityGoodsList.isEmpty()) {
					logger.warn("活动[code={}]没有配置对象的商品信息", activity.getCode());

					continue;
				}

				for (ActivityGoods activityGoods : activityGoodsList) {
					if (activityGoods.getGoodsType() == GoodsTypeEnum.COUPON) {
						
						for(long i=0;i<activityGoods.getNumber();i++) {
							Template template = templateRepository.findOne(activityGoods.getTemplateId());

							Coupon coupon = new Coupon();
							coupon.setActivityId(activity.getId());
							coupon.setTemplateId(template.getId());
							coupon.setOwnMemberId(member.getId());
							coupon.setFetchMemberId(member.getId());
							coupon.setCode(CodeUtil.couponCode());
							coupon.setName(template.getName());
							coupon.setCouponType(template.getCouponType());
							coupon.setStatus(CouponStatusEnum.NO_USED);
							coupon.setBeginDateTime(template.getBeginDateTime());
							coupon.setEndDateTime(template.getEndDateTime());
							coupon.setFetchDateTime(LocalDateTime.now());
							coupon.setCreateDateTime(LocalDateTime.now());

							couponRepository.save(coupon);

							// 保存卡券流水记录
							CouponFollowRecord couponFollowRecord = new CouponFollowRecord();
							couponFollowRecord.setCouponId(coupon.getId());
							couponFollowRecord.setCouponCode(coupon.getCode());
							couponFollowRecord.setFollwType(CouponFollwTypeEnum.REGISTER_RGIVE);
							couponFollowRecord.setMemberId(member.getId());
							couponFollowRecord.setPersonName(member.getNickname());
							couponFollowRecord.setCreateDateTime(LocalDateTime.now());

							couponFollowRecordRepository.save(couponFollowRecord);

							// 修改钱包状态
							wallet.setCouponCount(wallet.getCouponCount() + 1);
							wallet.setUpdateDateTime(LocalDateTime.now());

							walletRepository.save(wallet);
						}
					} else if (activityGoods.getGoodsType() == GoodsTypeEnum.SCORE) {
						ScoreFollowRecord record = new ScoreFollowRecord();
						record.setMemberId(member.getId());
						record.setMemberCode(member.getCode());
						record.setFollowType(ScoreFollowTypeEnum.REGISTER);
						record.setScore(activityGoods.getScore());
						record.setRemainingScore(wallet.getScore());
						record.setCreateDateTime(LocalDateTime.now());

						scoreFollowRecordRepository.save(record);

						// 修改钱包状态
						wallet.setScore(wallet.getScore() + activityGoods.getScore());
						wallet.setUpdateDateTime(LocalDateTime.now());

						walletRepository.save(wallet);
					}
				}
			}
		} catch (Exception e) {
			throw new BizException("注册赠送卡券或积分操作出错了", e);
		}
	}

	/**
	 * 
	 * @param member
	 * @throws WriterException
	 * @throws IOException
	 */
	private void saveCodeImage(Member member) throws WriterException, IOException {
		try {
			String base64Image = QrCodeUtil.writeToBase64(
					systemConstant.getH5Url() + "?name=" + member.getNickname() + "&code=" + member.getCode(),
					QrCodeUtil.width, QrCodeUtil.height);

			String catalog = SystemConstant.BUCKET + "code" + SystemConstant.SPRIT;
			String codeKey = Base64Utils.encodeToString(UUID.randomUUID().toString().getBytes()) + ".png";
			String key = catalog + codeKey;

			member.setCodeImage(key);

			memberRepository.save(member);

			ossComponent.uploadPicture(codeKey, base64Image, catalog);
		} catch (Exception e) {
			logger.error("生成用户二维码信息出错", e);
		}
	}

	/**
	 * 
	 * @param registerRequest
	 * @param member
	 */
	private void fillScity(RegisterRequest registerRequest, Member member) {
		try {
			Map<String, String> map = queryIsEmployee(registerRequest.getMobile());

			if (map == null) {
				// 查询手机号码归属地,把中文转为拼音
				member.setScity(HanyuPinyinHelperUtil.toHanyuPinyin(getMobileLocation(registerRequest.getMobile())));
				member.setCityName(getMobileLocation(registerRequest.getMobile()));
				member.setIsEmployee(Boolean.FALSE);
			} else {
				member.setScity(map.get("scity"));
				member.setCityName(getCityNameByCityCode(map.get("scity")));
				member.setIsEmployee(Boolean.TRUE);
			}

			memberRepository.save(member);
		} catch (Exception e) {
			logger.error("填充用户城市信息出错", e);
		}
	}
}