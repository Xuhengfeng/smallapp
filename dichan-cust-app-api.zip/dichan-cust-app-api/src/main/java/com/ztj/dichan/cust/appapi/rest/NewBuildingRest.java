/**
 * 
 */
package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.NewBuildingService;
import com.ztj.dichan.cust.appapi.vo.newbuilding.NewBuildingIndexVo;
import com.ztj.dichan.cust.appapi.vo.newbuilding.NewBuildingVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @author lbs
 *
 */
@Api(value = "新房接口",description="新房信息相关接口")
@RestController
@RequestMapping(value = "/newbuilding")
public class NewBuildingRest extends BaseCustRest {

	@Resource
	private NewBuildingService newBuildingService;
	
	@ApiOperation(value = "获取新房首页数据", response = NewBuildingIndexVo.class)
	@GetMapping(value = "/index")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true)})
	public RestResult<List<NewBuildingIndexVo>> queryIndex() {

		List<NewBuildingIndexVo> dataList = this.newBuildingService.queryNewBuildingIndex();
		return RestResult.success(dataList);

	}
	
	
	@ApiOperation(value = "获取城市新盘信息列表", response = NewBuildingVo.class)
	@GetMapping(value = "/query/{cityCode}")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "cityCode", value = "新盘城市编码", dataType = "string", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType = "query"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType = "query")})
	public RestResult<List<NewBuildingVo> > queryList(@PathVariable("cityCode") String cityCode,
			@RequestParam(name = "pageNo", required = false) Integer pageNo,
			@RequestParam(name = "pageSize", required = false) Integer pageSize) {

		List<NewBuildingVo>  voList = this.newBuildingService.queryList(cityCode, pageNo, pageSize);
		return RestResult.success(voList);

	}
	
	
	
}
