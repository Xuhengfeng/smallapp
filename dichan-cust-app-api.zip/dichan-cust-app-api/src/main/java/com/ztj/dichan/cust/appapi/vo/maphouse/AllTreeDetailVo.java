/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.maphouse;

import java.util.List;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.rule.response.maphouse.ArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentArerDetailVo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "地图找房数据")
@Data
@EqualsAndHashCode(callSuper = true)
public class AllTreeDetailVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "二手房-城区均价列表")
	private List<ArerDetailVo> usedAreaDetails;
	
	
	@ApiModelProperty(value = "租房-城区套数列表")
	private List<RentArerDetailVo> rentArerDetails;
	
	

}
