package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.request.maphouse.MapCoordinateRequest;
import com.ztj.dichan.cust.appapi.service.MapHouseService;
import com.ztj.dichan.cust.appapi.vo.maphouse.AllDetailVo;
import com.ztj.dichan.cust.appapi.vo.maphouse.AllTreeDetailVo;
import com.ztj.dichan.cust.rule.request.maphouse.MapAreaRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapDistrictRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapHousingRequest;
import com.ztj.dichan.cust.rule.response.maphouse.ArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.DistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.HousingDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentDistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentHousingDetailVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author yincp
 *
 */
@Api(value = "地图找房", description = "地图找房")
@RestController
@RequestMapping(value = "/map-house")
public class MapFindHouseRest extends BaseCustRest {

	@Resource
	private MapHouseService mapHouseService;


	@ApiOperation(value = "二手房-城区均价列表", response = ArerDetailVo.class)
	@PostMapping(value = "/secondArea")
	public RestResult<List<ArerDetailVo>> secondArea(@RequestBody MapAreaRequest request) {
		
		List<ArerDetailVo> voList = mapHouseService.secondArea(request);
		return RestResult.success(voList);
	}
	
	
	@ApiOperation(value = "二手房-片区均价列表", response = DistrictDetailVo.class)
	@PostMapping(value = "/secondDistrict")
	public RestResult<List<DistrictDetailVo>> secondDistrict(@RequestBody MapDistrictRequest request) {
		List<DistrictDetailVo> voList = mapHouseService.secondDistrict(request);
		return RestResult.success(voList);
		
	}
	
	@ApiOperation(value = "二手房-小区均价列表", response = HousingDetailVo.class)
	@PostMapping(value = "/secondHousing")
	public RestResult<List<HousingDetailVo>> secondHousing(@RequestBody MapHousingRequest request) {
		List<HousingDetailVo> voList = mapHouseService.secondHousing(request);
		return RestResult.success(voList);
		
	}
	
	
	
	@ApiOperation(value = "租房-城区套数列表", response = RentArerDetailVo.class)
	@PostMapping(value = "/rentArea")
	public RestResult<List<RentArerDetailVo>> rentArea(@RequestBody MapAreaRequest request) {
		List<RentArerDetailVo> voList = mapHouseService.rentArea(request);
		return RestResult.success(voList);

	}
	
	
	@ApiOperation(value = "租房-片区套数列表", response = RentDistrictDetailVo.class)
	@PostMapping(value = "/rentDistrict")
	public RestResult<List<RentDistrictDetailVo>> rentDistrict(@RequestBody MapDistrictRequest request) {
		List<RentDistrictDetailVo> voList = mapHouseService.rentDistrict(request);
		return RestResult.success(voList);
		
	}
	
	@ApiOperation(value = "租房-小区套数列表", response = RentHousingDetailVo.class)
	@PostMapping(value = "/rentHousing")
	public RestResult<List<RentHousingDetailVo>> rentHousing(@RequestBody MapHousingRequest request) {
		List<RentHousingDetailVo> voList = mapHouseService.rentHousing(request);
		return RestResult.success(voList);
		
	}
	
	
	
	@ApiOperation(value = "二手房和租房所有数据列表", response = AllDetailVo.class)
	@PostMapping(value = "/all")
	public RestResult<AllDetailVo> all(@RequestBody MapAreaRequest request) {
		
		return RestResult.success(mapHouseService.getAllDetail(request));
	}
	
	

	@ApiOperation(value = "二手房和租房所有数据树形列表", response = AllTreeDetailVo.class)
	@PostMapping(value = "/all-tree")
	public RestResult<AllTreeDetailVo> allTree(@RequestBody MapAreaRequest request) {
		
		return RestResult.success(mapHouseService.getAllTreeDetail(request));
	}
	/*
	@ApiOperation(value = "坐标找房", response = CoordinateDetailVo.class)
	@PostMapping(value = "/coordinate-house")
	public RestResult<CoordinateDetailVo> coordinateHouse(@RequestBody MapCoordinateRequest request) {
		return RestResult.success(mapHouseService.coordinateHouse(request));
	}*/
	
	@ApiOperation(value = "二手房-坐标找房")
	@PostMapping(value = "/coordinate/secondHouse")
	public RestResult<List<?>> secondHouse(@RequestBody MapCoordinateRequest request) {
		logger.info("二手房-坐标找房接口进来了============ycp,{}",JSON.toJSONString(request));
		return RestResult.success(mapHouseService.coordinateSecondHouseList(request));
	}
	
	@ApiOperation(value = "租房-坐标找房")
	@PostMapping(value = "/coordinate/rentHouse")
	public RestResult<List<?>> rentHouse(@RequestBody MapCoordinateRequest request) {
		return RestResult.success(mapHouseService.coordinateRentHouseList(request));
	}
	
	
}
