package com.ztj.dichan.cust.appapi.vo.house;

import java.util.ArrayList;
import java.util.List;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 一次性获取的房源关联小区、同小区房源等信息
 * 
 * @author test01
 */
@ApiModel(value = "一次性获取的房源关联小区、同小区房源等信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class HouseDetailDataVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "清单列表房源数量")
	private HouseDetailCountVo houseDetailCountVo;

	@ApiModelProperty(value = "小区详细信息")
	private BuildingDetailVo buildingDetailVo;

	@ApiModelProperty(value = "同小区二手房")
	private List<SecondHouseVo> secondHouseVoList = new ArrayList<>();

	@ApiModelProperty(value = "二手房-周边房源")
	private List<HouseVo> houseVoList = new ArrayList<>();
}
