/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.appoint;

import java.math.BigDecimal;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.rule.util.Utils;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 * 带看房源列表项VO
 */
@ApiModel(value = "返回带看房源信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class BringHouseVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "房源标题")
	private String houseTitle;
	
	@ApiModelProperty(value = "小区名称")
	private String buildName;

	@ApiModelProperty(value = "区域")
	private String areaName;

	@ApiModelProperty(value = "片区")
	private String districtName;

	@ApiModelProperty(value = "房源标签")
	private String houseTag;

	@ApiModelProperty(value = "朝向")
	private String houseDirection;

	@ApiModelProperty(value = "房")
	private Integer roomsNum;

	@ApiModelProperty(value = "厅")
	private Integer livingRoomNum;

	@ApiModelProperty(value = "卫")
	private Integer washRoomNum;

	@ApiModelProperty(value = "户型")
	private String houseType;

	@ApiModelProperty(value = "建筑面积")
	private Integer builtArea;

	@ApiModelProperty(value = "房源特征")
	private String houseFeature;

	@ApiModelProperty(value = "售价")
	private Double saleTotal;

	@ApiModelProperty(value = "售单价")
	private Integer salePrice;

	@ApiModelProperty(value = "房源照片")
	private String housePic;
	
	@ApiModelProperty(value = "所在楼层")
	private Integer floorNum;
	
	@ApiModelProperty(value = "总层数")
	private Integer totalFloorNum;
	
	@ApiModelProperty(value = "楼层")
	private String floor;
	
	@ApiModelProperty(value = "装修")
	private String houseDecoration;
	
	@ApiModelProperty(value = "建筑年代")
	private String buildAge;
	
	@ApiModelProperty(value = "房屋类型")
	private String houseForm;

	@ApiModelProperty(value = "带看次数")
	private Integer watchCount;
	
	
	
	@ApiModelProperty(value = "房源id")
	private Integer houseId;
	
	@ApiModelProperty(value = "房源sdid")
	private Long houseSdid;
	
	@ApiModelProperty(value = "房源城市编码")
	private String houseScity;
	
	@ApiModelProperty(value = "约看房源记录id")
	private Long id; 

	@ApiModelProperty(value = "用户看房备注内容")
	private String memberRemark;
	
	@ApiModelProperty(value = "用户看房备注时间")
	private String mRemarkDateTime;	
	
	@ApiModelProperty(value = "用户看房备注标签,多个使用英文逗号隔开")
	private String remarkTag;
	
	@ApiModelProperty(value = "房源类别,ORIGINAL_HOUSE=原始房源;BROKER_HOUSE=经纪人推荐房源")
	private String type;
	
	@ApiModelProperty(value = "房源状态，0=正常，1=已售")
	private Integer status;

	public String getHouseType() {
	    return  String.format("%s房%s厅", roomsNum,livingRoomNum); 
	}
	
	public String getFloor() {
		return Utils.formatFloor(floorNum, totalFloorNum);
	}
	
}
