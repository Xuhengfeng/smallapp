package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.AppointHouseReportService;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseReportVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author sily
 *
 */
@Api(value = "看房报告", description = "看房报告")
@RestController
@RequestMapping(value = "/report")
public class AppointHouseReportRest extends BaseCustRest {

	@Resource
	private AppointHouseReportService appointHouseReportService;

	@ApiOperation(value = "看房报告列表", response = AppointHouseReportVo.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "pageNo", value = "当前页码,必填", required = true, dataType = "int", paramType="query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType="query")})
	@RequestMapping(value = "/list", method = { RequestMethod.GET })
	public RestResult<List<AppointHouseReportVo>> queryReportList(@RequestParam(name="pageNo", required = true)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {

		List<AppointHouseReportVo> voList = appointHouseReportService.queryList(getCurrentMemberId(), pageNo, pageSize);

		return RestResult.success(voList);
	}

}
