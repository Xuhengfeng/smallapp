package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.InformationPubService;
import com.ztj.dichan.cust.core.enums.InfoTypeEnum;
import com.ztj.dichan.cust.core.vo.InformationVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author liuweichen
 *
 */
@Api(value = "banner接口",description="banner接口")
@RestController
@RequestMapping(value = "/information")
public class InformationPudRest extends BaseCustRest {
	
	@Resource
	private InformationPubService informationPubService;
	
	
	@ApiOperation(value = "获取已发布的资讯列表", response= InformationVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "infoType", 
			value = "资讯类型,INDEX_BANNER(首页banne r资讯),HOUSE_RENT_BANNER(租房banner资讯),HOUSE_USED_BANNER(二手房banner资讯),"
					+ "WILL_HOUSE_RENT_BANNER(我要出租banner),WILL_HOUSE_SELL_BANNER(我要卖房banner),NEW_BUILD_INDEX_BANNER(新盘首页banner),CONSULT_INDEX_BANNER(咨询首页banner)", 
			dataType = "string", paramType = "path", required = true)})
	@GetMapping("/pubs/{scity}/{infoType}")
	public RestResult<List<com.ztj.dichan.cust.core.vo.InformationVo>> queryList(@PathVariable("scity")String scity ,@PathVariable("infoType")InfoTypeEnum infoType) {
		
		
		return RestResult.success(informationPubService.querInformationPub(scity, infoType));
	}
	
	@ApiOperation(value = "获取已发布的资讯列表-分页", response= InformationVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "String", paramType = "path", required = true),
			@ApiImplicitParam(name = "infoType", 
			value = "资讯类型,INDEX_BANNER(首页banne r资讯),HOUSE_RENT_BANNER(租房banner资讯),HOUSE_USED_BANNER(二手房banner资讯),"
					+ "WILL_HOUSE_RENT_BANNER(我要出租banner),WILL_HOUSE_SELL_BANNER(我要卖房banner),NEW_BUILD_INDEX_BANNER(新盘首页banner),CONSULT_INDEX_BANNER(咨询首页banner)", 
			dataType = "string", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", dataType = "Integer", paramType = "path", required = true),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10条", dataType = "Integer", paramType = "path", required = true)})
	@GetMapping("/pubs/{scity}/{infoType}/{pageNo}/{pageSize}")
	public RestResult<List<InformationVo>> queryList(@PathVariable("scity")String scity ,@PathVariable("infoType")InfoTypeEnum infoType,
			@PathVariable("pageNo")Integer pageNo,@PathVariable("pageSize")Integer pageSize) {
		
		return RestResult.success(informationPubService.querInformationPub(scity, infoType,pageNo,pageSize));
	}

}
