/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.request.BuildCollectionRequest;
import com.ztj.dichan.cust.rule.response.building.BuildingCollectionVo;

/**
 * @author sily
 *
 */
public class BuildingCollectionServiceClientFallBack implements BuildingCollectionServiceClient {

	@Override
	public List<BuildingCollectionVo> queryCollectionList(List<BuildCollectionRequest> buildCollectionRequest) {
		// TODO Auto-generated method stub
		return null;
	}

}