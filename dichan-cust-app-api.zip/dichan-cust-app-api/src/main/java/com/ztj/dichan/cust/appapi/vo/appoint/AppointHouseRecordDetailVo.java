/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.appoint;


import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.core.enums.AppointHouseStatusEnum;
import com.ztj.dichan.cust.rule.response.HouseBrokerVo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "返回待看详情信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointHouseRecordDetailVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "预约时间")
	private String appointDate;

	@ApiModelProperty(value = "联系人名称")
	private String appointName;

	@ApiModelProperty(value = "联系人手机号")
	private String appointMobile;
	
	@ApiModelProperty(value = "安排看房时间")
	private String scheduleTime; 
	
	@ApiModelProperty(value = "处理安排日程时间")
	private String procScheduleTime; 
	
	@ApiModelProperty(value = "安排经纪人时间")
	private String assignBrokerTime; 
	
	@ApiModelProperty(value = "预约成功时间")
	private String createDateTime;

	@ApiModelProperty(value = "取消预约时间")
	private String cancelTime; 

	@ApiModelProperty(value = "看房套数")
	private Integer houseNum;
	
	@ApiModelProperty(value = "房源内容")
	private String houseContent;
	
	@ApiModelProperty(value = "状态，SUCCESS=预约成功；TO_ASSIGN_BROKER=已安排经纪人；TO_SCHEDULE=已安排日程；TO_CANCEL=已取消")
	private AppointHouseStatusEnum status;
	
	@ApiModelProperty(value = "当前处理步骤，SUCCESS=预约成功；TO_ASSIGN_BROKER=已安排经纪人；TO_SCHEDULE=已安排日程")
	private String procStep;
	
	@ApiModelProperty(value = "经纪人")
	private HouseBrokerVo broker;

}
