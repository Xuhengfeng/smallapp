/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.appoint;

import java.util.List;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.rule.response.HouseBrokerVo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 * 已看房记录VO
 */
@ApiModel(value = "返回已看房记录信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointHouseCompleteVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "看房记录id")
	private Long id;
	
	@ApiModelProperty(value = "房源内容")
	private String houseContent;

	@ApiModelProperty(value = "看房时间")
	private String scheduleTime;
	
	@ApiModelProperty(value = "是否已评价")
	private Boolean isEvaluate;
	
	@ApiModelProperty(value = "带看经纪人id")
	private Integer brokerId;
	
	@ApiModelProperty(value = "带看经纪人sdid")
	private Long brokerSdid;
	
	@ApiModelProperty(value = "带看经纪人名称")
	private String brokerName;
	
	@ApiModelProperty(value = "城市编码")
	private String scity;
	
	@ApiModelProperty(value = "投诉电话")
	private String complaintPhone;
	
	@ApiModelProperty(value = "经纪人")
	private HouseBrokerVo broker;
	
	@ApiModelProperty(value = "房源列表")
	private List<BringHouseVo> houseList;
	
	
}
