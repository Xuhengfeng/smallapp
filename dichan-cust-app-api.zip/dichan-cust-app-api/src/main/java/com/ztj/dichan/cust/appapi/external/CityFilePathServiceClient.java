package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.ztj.dichan.cust.rule.response.CityFilePathVo;

@FeignClient(name = "cityFilePathServiceClient", url= "${cust.service.url}", fallback = CityFilePathServiceClientFallBack.class)
public interface CityFilePathServiceClient {

	@GetMapping(value = "/cityFilePath/")
	public List<CityFilePathVo> getCityFilePath();
	
}
