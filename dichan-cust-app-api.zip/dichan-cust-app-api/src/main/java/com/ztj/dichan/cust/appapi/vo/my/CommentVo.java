/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.my;


import com.ztj.dichan.cust.appapi.vo.BaseApiValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author yincp
 *
 */
@ApiModel(value = "我的评论信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class CommentVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "会员名称")
	private String memberName;

	
	@ApiModelProperty(value = "经纪人ID")
	private Long brokerId; 

	
	@ApiModelProperty(value = "经纪人姓名")
	private String emplName;
	
	
	@ApiModelProperty(value = "经纪人账号")
	private String emplAccNo;

	
	
	@ApiModelProperty(value = "岗位名称")
	private String positionName;

	
	@ApiModelProperty(value = "评价标签")
	private String  tag;
	
	@ApiModelProperty(value = "评价内容")
	private String  content;
	
	
	@ApiModelProperty(value = "我的头像URL")
	private String headImage;
	
	@ApiModelProperty(value = "经纪人头像URL")
	private String brokerPhoto;
	
	@ApiModelProperty(value = "评论时间")
	private String commentTime;
	
	@ApiModelProperty(value = "评级")
	private Integer grade;
	
	
	
}
