package com.ztj.dichan.cust.appapi.vo.activity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author sily
 */
@ApiModel(value = "卡券详细信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class TemplateDetailVo extends GoodsDetailVo {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "模板名称")
	private String name;
	
	@ApiModelProperty(value = "兑换模板需要的积分数")
	private Long needScore;

	@ApiModelProperty(value = "当前用户拥有的积分数")
	private Long currentScore;
	
	@ApiModelProperty(value = "图片链接")
	private String imageUrl;

	@ApiModelProperty(value = "文本内容")
	private String content;
	
	
}
