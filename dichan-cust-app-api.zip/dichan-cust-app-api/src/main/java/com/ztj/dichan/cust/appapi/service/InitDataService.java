package com.ztj.dichan.cust.appapi.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.easemob.service.EasemobUserService;

@Service
public class InitDataService extends BaseAppService{

	@Resource
	private CityFilePathService cityFilePathService;
	
	@Resource
	private EasemobUserService easemobUserService;
	
	@Resource
	private DictionaryService dictionaryService;
	
	public void initData() {
		
		//初始化环信token
		try {
			easemobUserService.initToken();
			
		} catch (Exception e) {
			logger.error("",e);
		}
		//初始化各城市文件路径
		try {
			cityFilePathService.initCityFilePath();
		} catch (Exception e) {
			logger.error("",e);
		}
		
		//初始化城市编码和城市名称映射关系
		try {
			dictionaryService.initCityNameMap();
			dictionaryService.initDicMap();
		} catch (Exception e) {
			logger.error("",e);
		}
		
	}
}
