package com.ztj.dichan.cust.appapi.vo;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author liuweichen
 *
 */
@ApiModel(value = "资讯信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class InformationVo extends BaseValueObject{
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * 标题
	 */
	@ApiModelProperty(value = "标题")
	private String title;

	/**
	 * 简介
	 */
	@ApiModelProperty(value = "简介")
	private String summary;

	/**
	 * 内容URL
	 */
	@ApiModelProperty(value = "内容url")
	private String contentUrl;

	/**
	 * 主图片URL
	 */
	@ApiModelProperty(value = "主图片url")
	private String picUrl;
	
	/**
	 * 发布时间
	 */
	@ApiModelProperty(value = "发布时间")
	private Long pubTime;
	
	public InformationVo() {}

	public InformationVo(String title, String summary, String contentUrl, String picUrl, LocalDateTime pubTime) {
		super();
		this.title = title;
		this.summary = summary;
		this.contentUrl = contentUrl;
		this.picUrl = picUrl;
		if (pubTime != null) {
			this.pubTime = pubTime.toInstant(ZoneOffset.of("+8")).toEpochMilli();
		}
		
	}
    
	
	
	
}
