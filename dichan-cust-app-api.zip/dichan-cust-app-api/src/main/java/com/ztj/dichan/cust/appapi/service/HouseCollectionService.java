/**
 * 
 */
package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.appapi.external.HouseCollectionServiceClient;
import com.ztj.dichan.cust.appapi.external.HouseServiceClient;
import com.ztj.dichan.cust.core.constant.OtherConstant;
import com.ztj.dichan.cust.core.entity.HouseCollection;
import com.ztj.dichan.cust.core.repository.HouseCollectionRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.HouseCollectionRequest;
import com.ztj.dichan.cust.rule.response.house.HouseCollectionVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * @author sily
 *
 */
@Service
@Transactional
public class HouseCollectionService extends BaseAppService {

	@Resource
	private HouseCollectionRepository houseCollectionRepository;

	@Resource
	private HouseCollectionServiceClient houseCollectionServiceClient;

	@Resource
	private HouseServiceClient houseServiceClient;

	/**
	 * s
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<HouseCollectionVo> queryList(Long memberId, Integer pageNo, Integer pageSize) {

		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}
		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "collectDateTime");

		List<HouseCollection> collectionList = houseCollectionRepository.findByMemberId(memberId, pageRequest);

		if (collectionList == null || collectionList.isEmpty()) {
			return new ArrayList<HouseCollectionVo>(0);
		}

		List<HouseCollectionRequest> houseCollectionRequest = new ArrayList<>();

		collectionList.stream().forEach(collection -> {
			HouseCollectionRequest vo = new HouseCollectionRequest();
			vo.setSdid(collection.getHouseSdid());
			vo.setScity(collection.getHouseScity());

			houseCollectionRequest.add(vo);
		});

		List<HouseCollectionVo> houseVoList = houseCollectionServiceClient.queryCollectionList(houseCollectionRequest);
		if (houseVoList == null) {
			return new ArrayList<>(0);
		}
		houseVoList.forEach(collectionVo -> {
			collectionVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), collectionVo.getHousePic(),
					collectionVo.getScity(), String.valueOf(collectionVo.getId())));

			collectionVo.setStatus(Utils.checkHouseStatus(collectionVo.getBuildStatus()));
		});

		return houseVoList;

	}

	/**
	 * 
	 * @param memberId
	 * @param sdid
	 * @param scity
	 */
	public void add(Long memberId, Long sdid, String scity) {

		try {

			Long count = houseCollectionRepository.countByMemberIdAndHouseSdid(memberId, sdid);

			if (count >= 1) {
				throw new IllegalStateException();
			}

			// 这里共用了dichan-cust-service工程里面的二手房详情接口
			HouseDetailVo houseDetailVo = houseServiceClient.getDetailInfo(scity, sdid);

			if (houseDetailVo == null) {
				throw new IllegalStateException();
			}

			HouseCollection houseCollection = new HouseCollection();

			houseCollection.setHouseScity(houseDetailVo.getScity());
			houseCollection.setHouseSdid(Long.valueOf(houseDetailVo.getSdid()));
			houseCollection.setHouseId(Long.valueOf(houseDetailVo.getId()));
			houseCollection.setMemberId(memberId);
			houseCollection.setCollectDateTime(LocalDateTime.now());

			houseCollectionRepository.save(houseCollection);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("收藏二手房出错了",e);
		}
	}

	public void cancelCollection(Long memberId, Long sdid, String scity) {
		HouseCollection houseCollection = houseCollectionRepository.findByMemberIdAndHouseSdid(memberId, sdid);

		if (houseCollection != null) {
			houseCollectionRepository.delete(houseCollection);
		}
	}

}
