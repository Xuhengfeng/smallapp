package com.ztj.dichan.cust.appapi.request;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author yincp
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DeviceRequest extends BaseRequest {
	private static final long serialVersionUID = 1L;
	

	@ApiModelProperty(value = "手机的IMIE", dataType = "string", required = false)
	private String imie;
	
	@ApiModelProperty(value = "设备MAC地址", dataType = "string", required = false)
	private String mac;
	
	
	@ApiModelProperty(value = " 设备厂商", dataType = "string", required = false)
	private String manufacturer;
	
	
	@ApiModelProperty(value = "设备型号", dataType = "string", required = false)
	private String unitType;
	

	@ApiModelProperty(value = "设备OS版本号", dataType = "string", required = false)
	private String osVersion;

	@ApiModelProperty(value = "移动网络运营商名称", dataType = "string", required = false)
	private String mobileOperatorName;
	
	
	@ApiModelProperty(value = "移动终端类型", dataType = "string", required = false)
	private String mobileTerminalType;
	
	@ApiModelProperty(value = "网络类型 ", dataType = "string", required = false)
	private String networkType;
	
	
	@ApiModelProperty(value = "前App版本号", dataType = "string", required = false)
	private String beroreAppVersion;
	

	@ApiModelProperty(value = "手机分辨率", dataType = "string", required = false)
	private String resolution;
	
	
	@ApiModelProperty(value = "设备手机号码", dataType = "string", required = false)
	private String phone;


}
