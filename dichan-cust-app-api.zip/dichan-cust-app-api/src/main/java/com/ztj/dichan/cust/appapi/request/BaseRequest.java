package com.ztj.dichan.cust.appapi.request;

import java.io.Serializable;

import com.ztj.dichan.cust.core.constant.OtherConstant;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author test01
 */
public class BaseRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	/**
	 * 查询页码
	 */
	@ApiModelProperty(value = "查询页码,必填", required = true)
	protected Integer pageNo;
	/**
	 * 每页大小,默认10条
	 */
	@ApiModelProperty(value = "每页大小,默认10条", required = false)
	protected Integer pageSize = 10;

	@ApiModelProperty(value = "城市编码,必填", required = true)
	protected String scity;

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getScity() {
		return scity;
	}

	public void setScity(String scity) {
		this.scity = scity;
	}
	
	public static Integer valPageNoDef(Integer pageNo) {
		if (pageNo == null || pageNo <= 0) {
			pageNo = 1;
		}
		return pageNo;
	}
	
	public static Integer valPageSizeDef(Integer pageSize) {
		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}
		if (pageSize > OtherConstant.MAX_PAGE_SIZE) {
			throw new IllegalArgumentException("pageSize不能大于" + OtherConstant.MAX_PAGE_SIZE);
		}
		return pageSize;
	}
	
	public static Integer getMaxSize(Integer pageNo,Integer pageSize) {
		pageNo = valPageNoDef(pageNo);
		pageSize = valPageSizeDef(pageSize);
		
		return (pageNo-1) * pageSize;
	}


}