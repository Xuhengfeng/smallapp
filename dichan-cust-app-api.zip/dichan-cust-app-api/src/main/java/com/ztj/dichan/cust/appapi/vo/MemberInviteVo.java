package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author sily
 */
@ApiModel(value = "会员邀请信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class MemberInviteVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	/**
	 * 昵称
	 */
	@ApiModelProperty(value = "昵称")
	private String nickname;

	/**
	 * 头像链接地址
	 */
	@ApiModelProperty(value = "头像链接地址")
	private String headImage;

	/**
	 * 注册时间
	 */
	@ApiModelProperty(value = "注册时间")
	private String  createDateTime;

}
