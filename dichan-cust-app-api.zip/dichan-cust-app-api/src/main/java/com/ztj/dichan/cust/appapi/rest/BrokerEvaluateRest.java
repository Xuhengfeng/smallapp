/**
 * 
 */
package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.request.BrokerEvaluateRequest;
import com.ztj.dichan.cust.appapi.service.BrokerEvaluateService;
import com.ztj.dichan.cust.appapi.vo.BrokerEvaluateVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @author lbs
 *
 * 经纪人评价
 */
@Api(value = "经纪人评价",description="经纪人评价相关接口")
@RestController
@RequestMapping(value = "/brokerEval")
public class BrokerEvaluateRest extends BaseCustRest {

	@Resource
	private BrokerEvaluateService brokerEvaluateService;
	
	@ApiOperation(value = "用户提交经纪人评价")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "String", paramType = "header", required = true),
		@ApiImplicitParam(name = "scity", value = "城市编码,必填", dataType = "string", paramType = "header", required = true)})
	@PostMapping(value = "/fillBrokerEvaluate")
	public RestResult<String> fillBrokerEvaluate(@RequestBody BrokerEvaluateRequest request) {
		
		brokerEvaluateService.fillBrokerEvaluate(getCurrentMemberId(),request);

		return RestResult.success("操作成功了");
	}
	
	
	@ApiOperation(value="查询经纪人评价信息列表",response=BrokerEvaluateVo.class)
	@GetMapping(value = "/brokerEvaluates")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "brokerId", value = "经纪人id", required = true, dataType = "int", paramType="query"),
		@ApiImplicitParam(name = "pageNo", value = "当前页码", required = true, dataType = "int", paramType="query"),
		@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", required = false, dataType = "int", paramType="query")})
	public RestResult<List<BrokerEvaluateVo>> queryBrokerEvaluates(@RequestParam(name="brokerId", required = true)Long brokerId,
			@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="page   Size", required = false)Integer pageSize) {
		
		return RestResult.success(brokerEvaluateService.queryBrokerEvaluates(brokerId, pageNo, pageSize));
	
	}
}
