package com.ztj.dichan.cust.appapi.exception;

import com.ztj.common.exception.BaseRuntimeException;

public class UserDefinedException extends BaseRuntimeException {

	
	private static final long serialVersionUID = 7617173116979093382L;

	public UserDefinedException(String errCode, String message) {
        super(errCode, message);
    }
	
	public UserDefinedException(String errCode, String message, Throwable cause) {
        super(errCode, message,cause);
    }
}
