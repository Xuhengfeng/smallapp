/**
 * 
 */
package com.ztj.dichan.cust.appapi.util;

import org.springframework.data.domain.PageRequest;

import com.ztj.dichan.cust.core.constant.OtherConstant;

/**
 * @author lbs
 *
 */
public class PageUtil {

	public static PageRequest createPage(Integer pageNo,Integer pageSize) {
		if (pageSize == null || pageSize <= 0) {
			 pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		 }
		 if (pageNo == null || pageNo <= 0) {
			 pageNo = 0;
		 } else {
			 pageNo = pageNo - 1;
		 }
		 return new PageRequest(pageNo, pageSize);
	}
	
}
