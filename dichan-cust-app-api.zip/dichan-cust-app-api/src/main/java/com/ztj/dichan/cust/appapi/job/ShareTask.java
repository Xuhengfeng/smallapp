package com.ztj.dichan.cust.appapi.job;

import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.ztj.dichan.cust.appapi.service.ShareRelationService;

@Component
public class ShareTask extends BaseTask {
	private AtomicLong atomicLong = new AtomicLong(0);

	@Resource
	private ShareRelationService shareRelationService;

//	@Scheduled(cron="0/10 * *  * * ? ")
	public void lastMonthHouse() {
		long count = 0L;

		try {
			count = atomicLong.incrementAndGet();

			logger.info("shareTask组件执行开始,atomicLong=" + count);

			shareRelationService.updateCount();
		} catch (Exception e) {
			logger.error("分享增加阅读量任务执行出错", e);
		} finally {
			logger.info("shareTask组件执行结束,atomicLong=" + count);
		}
	}
}
