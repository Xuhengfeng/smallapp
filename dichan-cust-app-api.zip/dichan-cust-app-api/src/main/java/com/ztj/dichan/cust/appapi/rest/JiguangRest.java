package com.ztj.dichan.cust.appapi.rest;

import java.util.Random;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.jiguang.service.JiguangService;
import com.ztj.dichan.cust.appapi.request.BrokerRegUserRequest;
import com.ztj.dichan.cust.appapi.vo.jiguang.SignatureVo;
import com.ztj.dichan.cust.core.entity.Member;
import com.ztj.dichan.cust.core.repository.MemberRepository;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@Api(value = "极光相关接口", description = "极光相关接口")
@RestController
@RequestMapping(value = "/jiguang")
public class JiguangRest extends BaseCustRest {
	
	@Resource
	private JiguangService jiguangService;
	
	@Resource
	private MemberRepository memberRepository;

	@Value("${jiguang.appkey}")
	private String appkey;
	
	@Value("${jiguang.secret}")
	private String secret;
	
	@ApiOperation(value = "获取极光鉴权信息", response = SignatureVo.class)
	@GetMapping(value = "/signature")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true)})
	public RestResult<SignatureVo> getSignature() {
		getCurrentMemberId();
		String random_str = UUID.randomUUID().toString().replaceAll("-", "");
		String timestamp = System.currentTimeMillis()+"";
		String md5 = "appkey="+appkey+"&timestamp=" + timestamp + "&random_str="+random_str+"&key="+secret;
		SignatureVo signatureVo = new SignatureVo();
		signatureVo.setAppkey(appkey);
		signatureVo.setRandom_str(random_str);
		signatureVo.setTimestamp(timestamp);
		signatureVo.setSignature(DigestUtils.md5Hex(md5).toUpperCase());
		return RestResult.success(signatureVo);

	}
	
	@ApiOperation(value = "经纪人-用户注册")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "unique-code", value = "用戶token标识,必填", dataType = "string", paramType = "header", required = true)})
	@PostMapping(value = "/broker/reguser")
	public RestResult<String> regUser(@RequestBody BrokerRegUserRequest request) {
		getCurrentMemberId();
		jiguangService.brokerRegUser(request.getChatUsername());
		return RestResult.success("注册成功");

	}
	
	@ApiOperation(value = "绑定极光账号")
	@GetMapping(value = "/binding")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "username", value = "你的地产APP账号", dataType = "string", paramType = "query", required = true)})
	public RestResult<String> bindingUser(@RequestParam(name="username")String username) {
	
		Member member = memberRepository.findByMobile(username);
		if (member == null) {
			return RestResult.failed("您输入的账户不存在!");
		}
		try {
			String password = new Random().nextInt(100000000)+"";
			jiguangService.regUser2(member.getId() + "_" + member.getMobile(), password, member.getNickname());
			member.setEasemobPassword(password);
			member.setEasemobUsername(member.getId() + "_" + member.getMobile());
			memberRepository.save(member);
			return RestResult.success("绑定极光账号成功!!!");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return RestResult.success("绑定极光账号失败,请检测极光是否已存在相应的账户!");

	}
}
