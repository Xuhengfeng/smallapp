/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.activity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author sily
 */
@ApiModel(value = "卡券信息对象")
@Data
@EqualsAndHashCode(callSuper = true)
public class CouponVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "券编号")
	protected String code;

	@ApiModelProperty(value = "券名称")
	protected String name;

	@ApiModelProperty(value = "领取人名称")
	protected String fetchPersonName;

	@ApiModelProperty(value = "状态")
	protected String status;

	@ApiModelProperty(value = "状态的中文描述")
	protected String statusName;

	@ApiModelProperty(value = "卡券生效时间")
	@JsonFormat(pattern = "yyyy-MM-dd")
	protected LocalDateTime beginDateTime;

	@ApiModelProperty(value = "卡券失效时间")
	@JsonFormat(pattern = "yyyy-MM-dd")
	protected LocalDateTime endDateTime;

	@ApiModelProperty(value = "卡券领用时间")
	@JsonFormat(pattern = "yyyy-MM-dd")
	protected LocalDateTime fetchDateTime;

	@ApiModelProperty(value = "卡券使用时间")
	@JsonFormat(pattern = "yyyy-MM-dd")
	protected LocalDateTime useDateTime;

	@ApiModelProperty(value = "格式化时间")
	protected String formatDateTime;

	@ApiModelProperty(value = "优惠券类型 :DY_COUPON==抵扣券,ZK_COUPON==折扣券")
	private String couponTypeName;

	@ApiModelProperty(value = "多久过期")
	protected Long day;
}
