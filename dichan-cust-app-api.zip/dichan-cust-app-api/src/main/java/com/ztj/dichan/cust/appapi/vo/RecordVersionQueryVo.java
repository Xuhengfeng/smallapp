package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.core.enums.VersionTypeEnum;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author sily
 *
 */
@ApiModel(value = "版本参数")
@Data
@EqualsAndHashCode(callSuper = true)
public class RecordVersionQueryVo extends BaseValueObject {

	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "版本类型")
	private VersionTypeEnum versionType;
	

	@ApiModelProperty(value = "版本号")
	private String versionNo;

	@ApiModelProperty(value = "app编号")
	private String appCode;

}
