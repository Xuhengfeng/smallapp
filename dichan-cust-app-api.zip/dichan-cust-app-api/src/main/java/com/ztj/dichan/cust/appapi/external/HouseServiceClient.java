/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ztj.dichan.cust.rule.request.EntrustHouseRequest;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.request.TrendRequest;
import com.ztj.dichan.cust.rule.request.contract.HouseContrastRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRecmdRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.house.HouseContrastDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseRecmdVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;



/**
 * @author sily
 *
 */
@FeignClient(name = "houseServiceClient", url= "${cust.service.url}", fallback = HouseServiceClientFallBack.class)
public interface HouseServiceClient {

	@RequestMapping(method = RequestMethod.POST, value = "/house/queryList")
	public List<HouseVo> queryList(@RequestBody HouseRequest houseRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@RequestMapping(method = RequestMethod.POST, value = "/house/queryListCount")
	public CountVo queryListCount(@RequestBody HouseRequest houseRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@GetMapping(value = "/house/getDetailInfo")
	public HouseDetailVo getDetailInfo(@RequestHeader(value = "scity", required = true) String scity,
			@RequestParam(name="sdid", required = true) Long sdid);
	
	@RequestMapping(method = RequestMethod.POST, value = "/house/queryRecmdList")
	public List<HouseRecmdVo> queryRecmdList(@RequestBody HouseRecmdRequest houseRecmdRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	@PostMapping(value = "/house/rimHousing")
	public List<HouseVo> rimHousing(@RequestBody RimHouseRequest rimHouseRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	@PostMapping(value = "/house/housing60-days")
	public List<SecondHouseVo> housing60Days(@RequestBody TrendRequest trendRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@PostMapping(value = "/house/housing60-days-count")
	public CountVo housing60DaysCount(@RequestBody TrendRequest trendRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	@PostMapping(value = "/house/houseContrast")
	public List<HouseContrastDetailVo> houseContrast(@RequestBody HouseContrastRequest contrastRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	@GetMapping(value = "/house/lastMonth")
	public String lastMonth();
	
	
	@PostMapping(value = "/house/entrustHouseList")
	public List<HouseVo> queryEntrustHouseList(@RequestBody EntrustHouseRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	 

	
}