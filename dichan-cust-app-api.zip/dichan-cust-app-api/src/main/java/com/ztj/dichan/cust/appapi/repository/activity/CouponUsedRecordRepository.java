package com.ztj.dichan.cust.appapi.repository.activity;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.ztj.dichan.cust.core.entity.activity.CouponUsedRecord;

/**
 * 
 * @author sily
 */
@Repository
public interface CouponUsedRecordRepository extends PagingAndSortingRepository<CouponUsedRecord, Long> {

}