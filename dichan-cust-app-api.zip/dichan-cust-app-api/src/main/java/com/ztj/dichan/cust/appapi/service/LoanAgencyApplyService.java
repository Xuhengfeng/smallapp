package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.common.exception.BizException;
import com.ztj.common.util.DateUtil;
import com.ztj.dichan.cust.appapi.easemob.external.EasemobUserServiceClient;
import com.ztj.dichan.cust.appapi.easemob.service.EasemobUserService;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.external.HouseSeeServiceClient;
import com.ztj.dichan.cust.appapi.external.HouseServiceClient;
import com.ztj.dichan.cust.appapi.external.RentHouseServiceClient;
import com.ztj.dichan.cust.appapi.request.LoanAgencyApplyCancelRequest;
import com.ztj.dichan.cust.appapi.request.LoanAgencyApplyRequest;
import com.ztj.dichan.cust.appapi.service.component.CacheComponent;
import com.ztj.dichan.cust.appapi.service.component.SmsComponent;
import com.ztj.dichan.cust.appapi.vo.ApplyHouseBrokerVo;
import com.ztj.dichan.cust.appapi.vo.LoanAgencyApplyDetailVo;
import com.ztj.dichan.cust.appapi.vo.LoanAgencyApplyVo;
import com.ztj.dichan.cust.appapi.vo.MemberVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointDetailHouseVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.BrokerCollection;
import com.ztj.dichan.cust.core.entity.BrokerContact;
import com.ztj.dichan.cust.core.entity.LoanAgencyApply;
import com.ztj.dichan.cust.core.enums.AgencyApplicantTypeEnum;
import com.ztj.dichan.cust.core.enums.ApplicationStatusEnum;
import com.ztj.dichan.cust.core.enums.LoanTypeEnum;
import com.ztj.dichan.cust.core.repository.BrokerContactRepository;
import com.ztj.dichan.cust.core.repository.HouseCollectionRepository;
import com.ztj.dichan.cust.core.repository.LoanAgencyApplyRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.EntrustHouseRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeCountVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * 
 * @author liuweichen
 *
 */

@Service
@Transactional
public class LoanAgencyApplyService extends BaseAppService {

	@Resource
	private LoanAgencyApplyRepository loanAgencyApplyRepository;

	@Resource
	private BrokerServiceClient brokerServiceClient;

	@Resource
	private HouseSeeServiceClient houseSeeServiceClient;

	@Resource
	private HouseServiceClient houseServiceClient;

	@Resource
	private RentHouseServiceClient rentHouseServiceClient;

	@Resource
	private HouseCollectionRepository houseCollectionRepository;

	@Resource
	private MemberService memberService;

	@Resource
	private SmsComponent smsComponent;

	@Resource
	private CacheComponent cacheComponent;

	@Resource
	private BrokerContactRepository brokerContactRepository;
	
	@Resource
	private EasemobUserServiceClient easemobUserServiceClient;
	
	@Resource
	private EasemobUserService easemobUserService;

	public void addLoanAgencyApply(Long memberId, LoanAgencyApplyRequest request) {
		if (request == null || request.getLoanAgencyType() == null) {
			throw new IllegalStateException("业务类型不能为空！");
		}

		String scity = RequestContextHolder.getCityCode();
		
		BrokerDetailVo broker = null;
		
		try {
			LoanAgencyApply loanAgencyApply = new LoanAgencyApply();
			loanAgencyApply.setAddress(request.getAddress());
			loanAgencyApply.setApplicationType(request.getLoanAgencyType());
			loanAgencyApply.setName(request.getName());
			loanAgencyApply.setPhone(request.getPhone());
			loanAgencyApply.setMemberId(memberId);
			loanAgencyApply.setCityCode(request.getCityCode());
			loanAgencyApply.setBuildingName(request.getBuildingName());
			loanAgencyApply.setBuildingSdid(request.getBuildingSdid());
			loanAgencyApply.setBuildNum(request.getBuildNum());
			loanAgencyApply.setUnitNum(request.getUnitNum());
			loanAgencyApply.setRoomNum(request.getRoomNum());
			loanAgencyApply.setStatus(ApplicationStatusEnum.ZERO);
			loanAgencyApply.setCurrCityCode(scity);
			loanAgencyApply.setApplicationTime(LocalDateTime.now());

			if (request.getApplicantType() == null) {
				loanAgencyApply.setApplicantType(AgencyApplicantTypeEnum.PURCHASER);// 买方
			} else {
				loanAgencyApply.setApplicantType(request.getApplicantType());
			}

			if (request.getBrokerId() == null || request.getBrokerId() <= 0) {
				// 这里需要随机取一个经纪人
			} else {
				broker = brokerServiceClient.queryBroker(request.getCityCode(),
						Integer.valueOf(request.getBrokerId() + ""));
				if (broker == null) {
					throw new IllegalStateException("未找到相应的经纪人");
				}
				loanAgencyApply.setBrokerId(request.getBrokerId());
			}

			loanAgencyApplyRepository.save(loanAgencyApply);

			// 发送短信通知经纪人
			JSONObject data = new JSONObject();
			data.put("phone", loanAgencyApply.getPhone());
			data.put("name", loanAgencyApply.getName());
			this.smsComponent.sendApplyNotifiBroker(broker.getPhone(), data);

		} catch (Exception e) {
			throw new BizException("保存租售信息出错了", e);
		}
		
		
//		  去经纪人app上 通知经纪人，您有一条订单信息
		try {
			JSONObject req = new JSONObject();
			JSONObject msg = new JSONObject();
			JSONArray target = new JSONArray();
			JSONObject ext = new JSONObject();
			target.add(scity+"_"+request.getBrokerId()+"_"+broker.getEmplAccNo());
			//"target" : ["u1", "u2", "u3"],
			msg.put("type", "txt");
			msg.put("msg", "您有一条新的订单");
			ext.put("customType","2");
			req.put("target_type", "users");
			req.put("target", target);
			req.put("msg", msg);
			req.put("from", "系统消息");
			req.put("ext", ext);
			JSONObject obj = easemobUserServiceClient.sendMessage(easemobUserService.getToken(), req);
			
		} catch (Exception e) {
			throw new BizException("通知经纪人出错了", e);
		}
	}

	/**
	 * 房屋租售列表
	 * 
	 * @param memberId
	 * @param applicationType
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */

	public List<LoanAgencyApplyVo> loanAgencyApplyList(Long memberId, LoanTypeEnum applicationType, Integer pageNo,
			Integer pageSize) {
		Sort sort = new Sort(Sort.Direction.DESC, "applicationTime");
		if (pageSize == null || pageSize <= 0) {
			pageSize = 10;
		}

		PageRequest pageRequest = new PageRequest(pageNo - 1, pageSize, sort);

		List<LoanAgencyApply> list = new ArrayList<>();

		if (applicationType == null || applicationType.getCode().equals("")) {
			list = loanAgencyApplyRepository.findByMemberId(memberId, pageRequest);
		} else {
			list = loanAgencyApplyRepository.findByMemberIdAndApplicationType(memberId, applicationType, pageRequest);
		}

		List<LoanAgencyApplyVo> voList = new ArrayList<>();

		for (LoanAgencyApply loanAgencyApply : list) {

			LoanAgencyApplyVo vo = new LoanAgencyApplyVo();
			BeanUtils.copyProperties(loanAgencyApply, vo);
			vo.setApplicationTime(
					DateUtil.formatLocalDateTime(loanAgencyApply.getApplicationTime(), DateUtil.DATEFORMAT_DATETIME16));
			vo.setCityName(cacheComponent.getCityName(vo.getCityCode()));
			vo.setLoanAgencyType(loanAgencyApply.getApplicationType());
			vo.setLoanAgencyTypeName(loanAgencyApply.getApplicationType().getName());
			voList.add(vo);

		}

		return voList;
	}

	/**
	 * 获取卖房申请信息详情
	 * 
	 * @param memberId
	 * @param id
	 * @return
	 */
	public LoanAgencyApplyDetailVo getLoanAgencyApplyDetail(Long memberId, Long id) {

		if (memberId == null || id == null) {
			return null;
		}

		LoanAgencyApply loanAgencyApply = loanAgencyApplyRepository.findByIdAndMemberId(id, memberId);
		if (loanAgencyApply == null) {
			return null;
		}
		LoanAgencyApplyDetailVo vo = new LoanAgencyApplyDetailVo();
		BeanUtils.copyProperties(loanAgencyApply, vo);
		vo.setLoanAgencyType(loanAgencyApply.getApplicationType());
		vo.setApplicationTime(
				DateUtil.formatLocalDateTime(loanAgencyApply.getApplicationTime(), DateUtil.DATEFORMAT_DATETIME16));

		vo.setCityName(cacheComponent.getCityName(vo.getCityCode()));
		vo.setLoanAgencyTypeName(loanAgencyApply.getApplicationType().getName());

		if (loanAgencyApply.getBrokerId() != null) {
			BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(loanAgencyApply.getCityCode(),
					loanAgencyApply.getBrokerId().intValue());
			if (brokerDetailVo != null) {
				ApplyHouseBrokerVo broker = new ApplyHouseBrokerVo();
				BeanUtils.copyProperties(brokerDetailVo, broker);
				broker.setStatus(Utils.checkBrokerStatus(brokerDetailVo.getEmplStatus()));
				if ("1".equals(brokerDetailVo.getPhoto())) {
					brokerDetailVo.setPhoto(systemConstant.getOssCdnUrl() + brokerDetailVo.getScity() + "/Empl/PIC/"
							+ brokerDetailVo.getId() + "/" + brokerDetailVo.getId() + ".jpg");
				}
				vo.setBroker(broker);
			}

		}

		if (loanAgencyApply.getHouseSdid() != null && loanAgencyApply.getApplicationType() == LoanTypeEnum.LONA) {

			HouseDetailVo houseDetailVo = houseServiceClient.getDetailInfo(loanAgencyApply.getCityCode(),
					loanAgencyApply.getHouseSdid());
			if (houseDetailVo != null) {
				AppointDetailHouseVo houseVo = new AppointDetailHouseVo();
				BeanUtils.copyProperties(houseDetailVo, houseVo);

				houseVo.setBuiltArea(houseDetailVo.getBuiltArea());
				houseVo.setSalePrice(houseDetailVo.getSaleprice());
				houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseVo.getHousePic(),
						houseVo.getScity(), String.valueOf(houseVo.getId())));

				houseVo.setStatus(Utils.checkHouseStatus(houseVo.getBuildStatus()));

				if (loanAgencyApply.getStatus() == ApplicationStatusEnum.CANCEL) {
					houseVo.setStatus(2);
				}

				HouseSeeCountVo houseSeeCountVo = houseSeeServiceClient.queryCount(houseVo.getScity(), houseVo.getId());

				houseVo.setDay7Num(houseSeeCountVo.getDay7Count());
				houseVo.setDay30Num(houseSeeCountVo.getDay30Count());
				houseVo.setTotalSeeNum(houseSeeCountVo.getTotalCount());
				Integer collectNum = houseCollectionRepository.countByHouseSdid(loanAgencyApply.getHouseSdid());
				houseVo.setCollectNum(collectNum);
				if (!StringUtils.isEmpty(houseSeeCountVo.getRecentlySeeDate())) {
					houseVo.setRecentlySee(houseSeeCountVo.getRecentlySeeDate().split(" ")[0].replace("-", "."));
				} else {
					houseVo.setRecentlySee("");
				}

				vo.setHouse(houseVo);
			}

		}
		return vo;
	}

	/**
	 * 根据客户手机号码查找相关的二手房列表
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<HouseVo> queryLoanHouseList(Long memberId, Integer pageNo, Integer pageSize) {

		MemberVo member = memberService.getDetailInfo(memberId);
		if (member == null || StringUtils.isEmpty(member.getMobile())) {
			return new ArrayList<HouseVo>(0);
		}
		String scity = RequestContextHolder.getCityCode();
		EntrustHouseRequest request = new EntrustHouseRequest();
		request.setScity(scity);
		request.setPageNo(pageNo);
		request.setPageSize(pageSize);
		request.setPhone(member.getMobile());
		List<HouseVo> houseList = houseServiceClient.queryEntrustHouseList(request, scity);
		if (houseList == null) {
			return new ArrayList<HouseVo>(0);
		}

		houseList.forEach(houseVo -> {
			houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseVo.getHousePic(), scity,
					String.valueOf(houseVo.getId())));
			houseVo.setStatus(Utils.checkHouseStatus(houseVo.getBuildStatus()));

		});
		return houseList;
	}

	public void cancelLoanAgencyApply(Long memberId, LoanAgencyApplyCancelRequest request) {
		if (request.getId() == null || request.getId() <= 0) {
			throw new IllegalArgumentException("不存在委托申请记录");
		}
		LoanAgencyApply loanAgencyApply = this.loanAgencyApplyRepository.findOne(request.getId());
		if (loanAgencyApply == null) {
			throw new IllegalArgumentException("不存在贷款申请记录");
		}
		if (loanAgencyApply.getMemberId() != memberId) {
			throw new IllegalArgumentException("无权限取消该贷款申请记录");
		}
		loanAgencyApply.setStatus(ApplicationStatusEnum.CANCEL);
		loanAgencyApply.setCancelCause(request.getCancelCause());
		loanAgencyApply.setCancelTime(LocalDateTime.now());
		this.loanAgencyApplyRepository.save(loanAgencyApply);

	}

	/**
	 * 
	 * @param brokerId
	 * @param scity
	 * @param memberId
	 */
	public void savebrokerContact(Integer brokerId, String scity, Long memberId) {
		try {
			BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(scity, brokerId);

			if (brokerDetailVo == null) {
				throw new IllegalArgumentException("该经纪人不存在");
			}

			BrokerCollection brokerCollection = new BrokerCollection();

			brokerCollection.setBrokerScity(brokerDetailVo.getScity());
			brokerCollection.setBrokerId(Long.valueOf(brokerDetailVo.getId()));
			brokerCollection.setBrokerSdid(Long.valueOf(brokerDetailVo.getSdid()));

			BrokerContact entity = new BrokerContact();
			entity.setBrokerId(Long.parseLong(brokerId + ""));
			entity.setBrokerScity(scity);
			entity.setBrokerSdid(Long.valueOf(brokerDetailVo.getSdid()));
			entity.setMemberId(memberId);
			entity.setCreateTime(LocalDateTime.now());
			brokerContactRepository.save(entity);
		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("保存经纪人收藏信息出错" + e);
		}
	}
}
