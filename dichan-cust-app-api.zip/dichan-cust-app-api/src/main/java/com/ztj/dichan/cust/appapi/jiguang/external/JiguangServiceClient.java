package com.ztj.dichan.cust.appapi.jiguang.external;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSONArray;

/**
 * 极光IM相关接口
 * 
 * @author lbs
 *
 */
@FeignClient(name = "jiguangServiceClient", url= "${jiguang.api.url}", fallback = JiguangServiceClientFallBack.class)
public interface JiguangServiceClient {


	@RequestMapping(method = RequestMethod.POST, value = "/v1/users/")
	public JSONArray regUser(@RequestBody JSONArray request,
			@RequestHeader(value = "Authorization", required = true) String token);
}
