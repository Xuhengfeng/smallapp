package com.ztj.dichan.cust.appapi.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.druid.util.StringUtils;
import com.ztj.dichan.cust.appapi.external.MapHouseServiceClient;
import com.ztj.dichan.cust.appapi.request.maphouse.MapCoordinateRequest;
import com.ztj.dichan.cust.appapi.vo.maphouse.AllDetailVo;
import com.ztj.dichan.cust.appapi.vo.maphouse.AllTreeDetailVo;
import com.ztj.dichan.cust.appapi.vo.maphouse.CoordinateDetailVo;
import com.ztj.dichan.cust.appapi.vo.maphouse.MapHouseDetailVo;
import com.ztj.dichan.cust.appapi.vo.maphouse.MapRentHouseDetailVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.repository.HouseUsedRecmdRepository;
import com.ztj.dichan.cust.rule.request.maphouse.MapAreaRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapConditionRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapDistrictRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapHousingRequest;
import com.ztj.dichan.cust.rule.request.maphouse.MapLocationRequest;
import com.ztj.dichan.cust.rule.response.maphouse.ArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.DistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.HousingDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentArerDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentDistrictDetailVo;
import com.ztj.dichan.cust.rule.response.maphouse.RentHousingDetailVo;

/**
 * 
 * @author yincp
 */
@Service
@Transactional
public class MapHouseService extends BaseAppService {

	@Resource
	private MapHouseServiceClient mapHouseServiceClient;

	@Resource
	private HouseUsedRecmdRepository houseUsedRecmdRepository;

	public List<ArerDetailVo> secondArea(MapAreaRequest request) {
		String scity = this.getScity(request);
		List<ArerDetailVo> list = mapHouseServiceClient.secondArea(request,scity);
		return list;
	}
	
	public List<DistrictDetailVo> secondDistrict(MapDistrictRequest request) {
		String scity = this.getScity(request);
		List<DistrictDetailVo> list = mapHouseServiceClient.secondDistrict(request,scity);
		return list;
	}
	
	public List<HousingDetailVo> secondHousing(MapHousingRequest request) {
		String scity = this.getScity(request);
		List<HousingDetailVo> list = mapHouseServiceClient.secondHousing(request,scity);
		return list;
	}
	
	
	public List<RentArerDetailVo> rentArea(MapAreaRequest request) {
		String scity = this.getScity(request);
		List<RentArerDetailVo> list = mapHouseServiceClient.rentArea(request,scity);
		return list;
	}
	
	public List<RentDistrictDetailVo> rentDistrict(MapDistrictRequest request) {
		 String scity = this.getScity(request);
		 List<RentDistrictDetailVo> list = mapHouseServiceClient.rentDistrict(request,scity);
		return list;
	}
	
	public List<RentHousingDetailVo> rentHousing(MapHousingRequest request) {
		String scity = this.getScity(request);
		List<RentHousingDetailVo>  list = mapHouseServiceClient.rentHousing(request,scity);
		return list;
	}
	
	
	
	
	public CoordinateDetailVo coordinateHouse(MapCoordinateRequest request) {
		
		String scity = RequestContextHolder.getCityCode();
		CoordinateDetailVo cdVo  = new CoordinateDetailVo();
		
		Integer level = request.getLevel();
		Double x1 =  request.getX1();
		Double x2 =  request.getX2();
		Double y1 =  request.getY1();
		Double y2 =  request.getY2();
		
		if (x1 == null || x1 <= 0 || x2 == null || x2 <= 0 || 
				y1 == null || y1 <= 0 || y2 == null || y2 <= 0) {
			
		}
		
		
		MapLocationRequest locationRequest = new MapLocationRequest();
		locationRequest.setScity(request.getScity());
		locationRequest.setLeftX(x2);
		locationRequest.setRightX(x1);
		locationRequest.setTopY(y1);
		locationRequest.setBottomY(y2);
		
		
		MapAreaRequest areaRequest = new MapAreaRequest();
		areaRequest.setScity(request.getScity());
		if (StringUtils.isEmpty(scity)) {
			scity = request.getScity();
		}
		if(level==13) {
			List<ArerDetailVo> usedAreas =  mapHouseServiceClient.secondArea(areaRequest,scity);
			cdVo.setArerDetails(usedAreas);
		}else if(level==14) {
			List<RentArerDetailVo>  rentAreas = mapHouseServiceClient.rentArea(areaRequest,scity);
			cdVo.setRentArerDetails(rentAreas);
		}
		else if(level==15) {
			 List<DistrictDetailVo> uesdDists = mapHouseServiceClient.coordinateUsedDist(locationRequest,scity);
			 cdVo.setDistrictDetails(uesdDists);
		}else if(level==16) {
			List<RentDistrictDetailVo> rentDists = mapHouseServiceClient.coordinateRentDist(locationRequest,scity);
			cdVo.setRentDistrictDetails(rentDists);
		}
		else if(level==17) {
			List<HousingDetailVo> usedHous = mapHouseServiceClient.coordinateUsedHousing(locationRequest,scity);
			cdVo.setHousingDetails(usedHous);
		}else if(level==16) {
			List<RentHousingDetailVo>  rentHous = mapHouseServiceClient.coordinateRentHousing(locationRequest,scity);
			cdVo.setRentHousingDetails(rentHous);
			
		}
		return cdVo;
	}
	
	
	public List<?> coordinateSecondHouseList(MapCoordinateRequest request) {
		
		String scity = RequestContextHolder.getCityCode();
		
		if (StringUtils.isEmpty(scity)) {
			scity = request.getScity();
		}
		
		if (StringUtils.isEmpty(scity)) {
			return new ArrayList<>(0);
		}
		Integer level = request.getLevel();
		Double x1 =  request.getX1();
		Double x2 =  request.getX2();
		Double y1 =  request.getY1();
		Double y2 =  request.getY2();
		if(level > 15) {
			if (x1 == null || x1 <= 0 || x2 == null || x2 <= 0 || 
					y1 == null || y1 <= 0 || y2 == null || y2 <= 0) {
				return new ArrayList<>(0);
			}
		}
		
		
		MapLocationRequest locationRequest = new MapLocationRequest();
		locationRequest.setScity(request.getScity());
		locationRequest.setLeftX(x2);
		locationRequest.setRightX(x1);
		locationRequest.setTopY(y1);
		locationRequest.setBottomY(y2);
		
		
		MapAreaRequest areaRequest = new MapAreaRequest();
		areaRequest.setScity(scity);
		
		if(level < 15) {
			List<ArerDetailVo> usedAreas =  mapHouseServiceClient.secondArea(areaRequest,scity);
			if (usedAreas == null) {
				return new ArrayList<>(0);
			}
			return usedAreas.stream().map(vo->{
				MapHouseDetailVo mapVo = new MapHouseDetailVo();
				mapVo.setId(vo.getAreaId());
				mapVo.setName(vo.getAreaName());
				mapVo.setAvgPrice(vo.getAvgPrice());
				mapVo.setPx(vo.getPx());
				mapVo.setPy(vo.getPy());
				return mapVo;
			}).collect(Collectors.toList());
			
		} else if(level >= 15 && level < 17) {
			List<DistrictDetailVo> uesdDists = mapHouseServiceClient.coordinateUsedDist(locationRequest,scity);
			if (uesdDists == null) {
				return new ArrayList<>(0);
			}
			return uesdDists.stream().map(vo->{
				MapHouseDetailVo mapVo = new MapHouseDetailVo();
				mapVo.setId(vo.getDistrictId());
				mapVo.setName(vo.getDistrictName());
				mapVo.setAvgPrice(vo.getAvgPrice());
				mapVo.setPx(vo.getPx());
				mapVo.setPy(vo.getPy());
				return mapVo;
			}).collect(Collectors.toList());
		}
		else if(level >= 17) {
			List<HousingDetailVo> usedHous = mapHouseServiceClient.coordinateUsedHousing(locationRequest,scity);
			return usedHous;
		}
		return new ArrayList<>(0);
	}
	
	public List<?> coordinateRentHouseList(MapCoordinateRequest request) {
		
		String scity = RequestContextHolder.getCityCode();
		
		if (StringUtils.isEmpty(scity)) {
			scity = request.getScity();
		}
		if (StringUtils.isEmpty(scity)) {
			return new ArrayList<>(0);
		}
		
		Integer level = request.getLevel();
		Double x1 =  request.getX1();
		Double x2 =  request.getX2();
		Double y1 =  request.getY1();
		Double y2 =  request.getY2();
		if(level >= 15) {
			if (x1 == null || x1 <= 0 || x2 == null || x2 <= 0 || 
					y1 == null || y1 <= 0 || y2 == null || y2 <= 0) {
				return new ArrayList<>(0);
			}
		}
		
		
		MapLocationRequest locationRequest = new MapLocationRequest();
		locationRequest.setScity(request.getScity());
		locationRequest.setLeftX(x2);
		locationRequest.setRightX(x1);
		locationRequest.setTopY(y1);
		locationRequest.setBottomY(y2);
		
		
		MapAreaRequest areaRequest = new MapAreaRequest();
		areaRequest.setScity(scity);
		
		if(level < 15) {
			List<RentArerDetailVo> usedAreas =  mapHouseServiceClient.rentArea(areaRequest,scity);
			if (usedAreas == null) {
				return new ArrayList<>(0);
			}
			return usedAreas.stream().map(vo->{
				MapRentHouseDetailVo mapVo = new MapRentHouseDetailVo();
				mapVo.setId(vo.getAreaId());
				mapVo.setName(vo.getAreaName());
				mapVo.setRentCount(vo.getRentCount());
				mapVo.setPx(vo.getPx());
				mapVo.setPy(vo.getPy());
				return mapVo;
			}).collect(Collectors.toList());
			
		} else if(level >= 15 && level < 17) {
			List<RentDistrictDetailVo> uesdDists = mapHouseServiceClient.coordinateRentDist(locationRequest,scity);
			if (uesdDists == null) {
				return new ArrayList<>(0);
			}
			return uesdDists.stream().map(vo->{
				MapRentHouseDetailVo mapVo = new MapRentHouseDetailVo();
				mapVo.setId(vo.getDistrictId());
				mapVo.setName(vo.getDistrictName());
				mapVo.setRentCount(vo.getRentCount());
				mapVo.setPx(vo.getPx());
				mapVo.setPy(vo.getPy());
				return mapVo;
			}).collect(Collectors.toList());
		}
		else if(level >= 17) {
			List<RentHousingDetailVo> usedHous = mapHouseServiceClient.coordinateRentHousing(locationRequest,scity);
			if (usedHous == null) {
				return new ArrayList<>(0);
			}
			return usedHous;
		}
		return new ArrayList<>(0);
	}
	
	
	public AllDetailVo getAllDetail(MapAreaRequest request) {
		AllDetailVo vo = new AllDetailVo();
		MapDistrictRequest requestDistrict = new MapDistrictRequest();
		MapHousingRequest requestHousing = new MapHousingRequest();
		BeanUtils.copyProperties(request, requestDistrict);
		BeanUtils.copyProperties(request, requestHousing);
		String scity = this.getScity(request);
		vo.setArerDetails(mapHouseServiceClient.secondArea(request,scity));

		vo.setDistrictDetails(mapHouseServiceClient.secondDistrict(requestDistrict,scity));
		
		vo.setHousingDetails(mapHouseServiceClient.secondHousing(requestHousing,scity));
		
		vo.setRentArerDetails(mapHouseServiceClient.rentArea(request,scity));
		
		vo.setRentDistrictDetails(mapHouseServiceClient.rentDistrict(requestDistrict,scity));
		
		vo.setRentHousingDetails(mapHouseServiceClient.rentHousing(requestHousing,scity));
		
		return vo;
	}
	
	
	public AllTreeDetailVo getAllTreeDetail(MapAreaRequest request) {
		AllTreeDetailVo treeVo = new AllTreeDetailVo();
		String scity = this.getScity(request);
		 List<ArerDetailVo> usedAreaList =  mapHouseServiceClient.secondArea(request,scity);
		 for (ArerDetailVo arerDetailVo : usedAreaList) {
			 MapDistrictRequest usedDistrictRequest = new MapDistrictRequest();
			 usedDistrictRequest.setAreaId(arerDetailVo.getAreaId());
			 usedDistrictRequest.setScity(request.getScity());
			 List<DistrictDetailVo> usedDistrictList  = mapHouseServiceClient.secondDistrict(usedDistrictRequest,scity);
			 for (DistrictDetailVo districtDetailVo : usedDistrictList) {
				 MapHousingRequest usedHousingRequest = new MapHousingRequest(); 
				 usedHousingRequest.setDistrictId(districtDetailVo.getDistrictId());
				 usedHousingRequest.setAreaId(arerDetailVo.getAreaId());
				 usedHousingRequest.setScity(request.getScity());
				 List<HousingDetailVo> usedHousing =  mapHouseServiceClient.secondHousing(usedHousingRequest,scity);
				 districtDetailVo.setUsedHousingDetails(usedHousing);
			}
			 arerDetailVo.setUsedDistrictDetails(usedDistrictList);
		}
		 treeVo.setUsedAreaDetails(usedAreaList);
		 
		
		 List<RentArerDetailVo> rentAreaList = 	 mapHouseServiceClient.rentArea(request,scity);
		 for (RentArerDetailVo rentArerDetailVo : rentAreaList) {
			 MapDistrictRequest rentDistrictRequest = new MapDistrictRequest();
			 rentDistrictRequest.setAreaId(rentArerDetailVo.getAreaId());
			 rentDistrictRequest.setScity(request.getScity());
			 List<RentDistrictDetailVo> rentDistrictList  = mapHouseServiceClient.rentDistrict(rentDistrictRequest,scity);
			 for (RentDistrictDetailVo rentDistrictDetailVo : rentDistrictList) {
				 MapHousingRequest rentHousingRequest = new MapHousingRequest(); 
				 rentHousingRequest.setDistrictId(rentDistrictDetailVo.getDistrictId());
				 rentHousingRequest.setAreaId(rentArerDetailVo.getAreaId());
				 rentHousingRequest.setScity(request.getScity());
				 List<RentHousingDetailVo> rentHousing =  mapHouseServiceClient.rentHousing(rentHousingRequest,scity);
				 rentDistrictDetailVo.setRentHousingDetails(rentHousing);
			}
			 rentArerDetailVo.setRentDistrictDetails(rentDistrictList);
		 }
		 treeVo.setRentArerDetails(rentAreaList);
		return treeVo;
	}
	
	private String getScity(MapConditionRequest request) {
		String scity = RequestContextHolder.getCityCode();
		if (StringUtils.isEmpty(scity)) {
			scity = request.getScity();
		}
		return scity;
	}
	
}