package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value="微信认证信息VO")
@Data
@EqualsAndHashCode(callSuper=true)
public class WeixinVo2 extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "微信-用户唯一标识")
	private String openid;
	
	@ApiModelProperty(value = "认证key")
	private String authKey;
	
	@ApiModelProperty(value = "微信昵称")
	private String nickname;
	
	@ApiModelProperty(value = "性别")
	private String sex;
	
	@ApiModelProperty(value = "头像URL")
	private String headImage;
	
	@ApiModelProperty(value = "用戶token标识,登录不成功值为空")
	private String uniqueCode;
	
	@ApiModelProperty(value = "状态,1=登录成功,2=用户未注册")
	private Integer status;
	
}
