/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ztj.dichan.cust.rule.response.ProtocolVo;



/**
 * @author sily
 *
 */
@FeignClient(name = "protocolServiceClient", url= "${cust.service.url}", fallback = ProtocolVo.class)
public interface ProtocolServiceClient {
	
	@RequestMapping(method = RequestMethod.POST, value = "/protocol/findByNo")
	public ProtocolVo findByContractNo(@RequestHeader(value = "scity", required = true) String scity,
			@RequestParam("contractNo")String contractNo);
	
}