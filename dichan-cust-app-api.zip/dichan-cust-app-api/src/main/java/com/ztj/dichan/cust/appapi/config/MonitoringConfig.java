package com.ztj.dichan.cust.appapi.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/**
 * 监控加载配置,与swagger的配置可能会冲突,冲突时可以先关闭
 * 
 * @author test01
 */
@Configuration
//@ImportResource({ "classpath:monitoring-api.xml", "classpath:net/bull/javamelody/monitoring-spring-aspectj.xml" })
public class MonitoringConfig {

}