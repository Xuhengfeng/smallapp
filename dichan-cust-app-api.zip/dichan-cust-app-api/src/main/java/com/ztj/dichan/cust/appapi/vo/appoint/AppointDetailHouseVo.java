/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.appoint;

import com.ztj.dichan.cust.appapi.vo.BaseApiValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "卖房申请房源详情")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointDetailHouseVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "房源标题")
	private String houseTitle;

	@ApiModelProperty(value = "区域")
	private String areaName;

	@ApiModelProperty(value = "片区")
	private String districtName;

	@ApiModelProperty(value = "房源标签")
	private String houseTag;

	@ApiModelProperty(value = "朝向")
	private String houseDirection;

	@ApiModelProperty(value = "房")
	private Integer roomsNum;

	@ApiModelProperty(value = "厅")
	private Integer livingRoomNum;

	@ApiModelProperty(value = "卫")
	private Integer washRoomNum;

	@ApiModelProperty(value = "户型")
	private String houseType;

	@ApiModelProperty(value = "建筑面积")
	private Integer builtArea;

	@ApiModelProperty(value = "房源特征")
	private String houseFeature;

	@ApiModelProperty(value = "售价")
	private Integer saleTotal;

	@ApiModelProperty(value = "售单价")
	private Integer salePrice;

	@ApiModelProperty(value = "房源照片")
	private String housePic;
	
	@ApiModelProperty(value = "房源id")
	private Integer id;
	
	@ApiModelProperty(value = "房源状态，0=正常，1=已售，2=已失效，3=已停售")
	private Integer status;
	
	private String buildStatus;
	
	
	@ApiModelProperty(value = "近7日带看次数")
	private Integer day7Num;
	
	@ApiModelProperty(value = "近30日带看次数")
	private Integer day30Num;
	
	@ApiModelProperty(value = "总带看次数")
	private Integer totalSeeNum;
	
	@ApiModelProperty(value = "收藏房源(人)")
	private Integer collectNum;
	
	@ApiModelProperty(value = "最近带看日期")
	private String recentlySee;
	

	public String getHouseType() {
	    return  String.format("%s房%s厅", roomsNum,livingRoomNum); 
	}

}
