/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ztj.dichan.cust.rule.request.RentHouseCollectionRequest;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseCollectionVo;



/**
 * @author sily
 *
 */
@FeignClient(name = "RentHouseCollectionServiceClient", url= "${cust.service.url}", fallback = RentHouseCollectionServiceClient.class)
public interface RentHouseCollectionServiceClient {
	
	@RequestMapping(method = RequestMethod.POST, value = "/rentHouse/collection")
	public List<RentHouseCollectionVo> queryCollectionList(List<RentHouseCollectionRequest> rentHouseCollectionRequest);
	
}