package com.ztj.dichan.cust.appapi.job;

import java.util.concurrent.atomic.AtomicLong;

import javax.annotation.Resource;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.ztj.dichan.cust.appapi.service.GrabOrderService;

/**
 * 获取上个月售出房源数据定时任务
 * 
 * @author sily
 */
@Component
public class HouseTask extends BaseTask {
	private AtomicLong atomicLong = new AtomicLong(0);

	@Resource
	private GrabOrderService grabOrderService;

	@Scheduled(cron = "0 5 0 1 * ?") // 每月一号凌晨过5分执行
	public void agencyJob() {
		long count = 0L;
		
		try {
			count = atomicLong.incrementAndGet();

			logger.info("houseTask组件执行开始,atomicLong=" + count);

			grabOrderService.lastMonthHouse();
		} catch (Exception e) {
			logger.error("获取上月房源统计任务出错", e);
		} finally {
			logger.info("houseTask组件执行结束,atomicLong=" + count);
		}
	}
}
