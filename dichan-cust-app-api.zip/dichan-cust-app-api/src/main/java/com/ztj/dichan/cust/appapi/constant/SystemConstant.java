package com.ztj.dichan.cust.appapi.constant;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 
 * @author sily
 */
@Component
public class SystemConstant {
	public static final String BUCKET = "dichan_cust/";

	public static final String SPRIT = "/";

	@Value("${cust.service.url}")
	private String custServiceUrl;

	@Value("${h5.url}")
	private String h5Url;

	@Value("${appcode}")
	private String appcode;

	@Value("${group.api.url}")
	private String groupApiUrl;

//	@Value("${package.environment}")
//	private String packageEnvironment;

	@Value("${swagger.enable}")
	private Boolean isEnableSwagger;

	@Value("${request.log.enable}")
	private Boolean isEnableRequestLog;

	@Value("${dichan.oss.accessKeyId}")
	private String ossAccessKeyId;

	@Value("${dichan.oss.accessKeySecret}")
	private String ossAccessKeySecret;

	@Value("${dichan.oss.bucket}")
	private String ossBucket;
	
	@Value("${dichan.oss.endpoint}")
	private String ossEndpoint;

	@Value("${dichan.oss.cdnUrl}")
	private String ossCdnUrl;

	@Value("${dichan.sms.accessKeyId}")
	private String smsAccessKeyId;

	@Value("${dichan.sms.accessKeySecret}")
	private String smsAccessKeySecret;

	@Value("${dichan.sms.templateCode}")
	private String smsTemplateCode;

	@Value("${dichan.sms.appoint.templateCode}")
	private String appointSmsTemplateCode;

	@Value("${dichan.sms.apply.templateCode}")
	private String applySmsTemplateCode;

	@Value("${dichan.sms.switch}")
	private String smsSwitch;

	@Value("${dichan.sms.endpointName}")
	private String smsEndpointName;

	@Value("${dichan.sms.regionId}")
	private String smsRegionId;

	@Value("${dichan.sms.product}")
	private String smsProduct;

	@Value("${dichan.sms.domain}")
	private String smsDomain;

	@Value("${weixin.appid}")
	private String weixinAppid;

	@Value("${weixin.secret}")
	private String weixinSecret;

	@Value("${weixin.jscode2session.url}")
	private String weixinJscode2sessionUrl;

	@Value("${weixin.gzh.appid}")
	private String weixinGzhAppid;

	@Value("${weixin.gzh.secret}")
	private String weixinGzhSecret;

	@Value("${weixin.gzh.accesstoken.url}")
	private String weixinAccesstokenUrl;

	@Value("${weixin.gzh.userinfo.url}")
	private String weixinUserinfoUrl;

	@Value("${weixin.gzh.getticket.url}")
	private String weixinGetticketUrl;

	@Value("${weixin.gzh.token.url}")
	private String weixinTokenUrl;

//	public String getPackageEnvironment() {
//		return packageEnvironment;
//	}

	public Boolean getIsEnableSwagger() {
		return isEnableSwagger;
	}

	public Boolean getIsEnableRequestLog() {
		return isEnableRequestLog;
	}

	public String getOssAccessKeyId() {
		return ossAccessKeyId;
	}

	public String getOssAccessKeySecret() {
		return ossAccessKeySecret;
	}

	public String getOssEndpoint() {
		return ossEndpoint;
	}

	public String getOssBucket() {
		return ossBucket;
	}

	public String getOssCdnUrl() {
		return ossCdnUrl;
	}

	public String getSmsAccessKeyId() {
		return smsAccessKeyId;
	}

	public String getSmsAccessKeySecret() {
		return smsAccessKeySecret;
	}

	public String getSmsTemplateCode() {
		return smsTemplateCode;
	}

	public String getCustServiceUrl() {
		return custServiceUrl;
	}

	public String getAppointSmsTemplateCode() {
		return appointSmsTemplateCode;
	}

	public String getApplySmsTemplateCode() {
		return applySmsTemplateCode;
	}

	public String getWeixinAppid() {
		return weixinAppid;
	}

	public String getWeixinSecret() {
		return weixinSecret;
	}

	public String getWeixinJscode2sessionUrl() {
		return weixinJscode2sessionUrl;
	}

	public String getSmsSwitch() {
		return smsSwitch;
	}

	public String getSmsEndpointName() {
		return smsEndpointName;
	}

	public String getSmsRegionId() {
		return smsRegionId;
	}

	public String getSmsProduct() {
		return smsProduct;
	}

	public String getSmsDomain() {
		return smsDomain;
	}

	public String getWeixinGzhAppid() {
		return weixinGzhAppid;
	}

	public String getWeixinGzhSecret() {
		return weixinGzhSecret;
	}

	public String getWeixinAccesstokenUrl() {
		return weixinAccesstokenUrl;
	}

	public String getWeixinUserinfoUrl() {
		return weixinUserinfoUrl;
	}

	public String getWeixinGetticketUrl() {
		return weixinGetticketUrl;
	}

	public String getWeixinTokenUrl() {
		return weixinTokenUrl;
	}
	
	public String getGroupApiUrl() {
		return groupApiUrl;
	}

	public String getH5Url() {
		return h5Url;
	}

	public String getAppcode() {
		return appcode;
	}

}