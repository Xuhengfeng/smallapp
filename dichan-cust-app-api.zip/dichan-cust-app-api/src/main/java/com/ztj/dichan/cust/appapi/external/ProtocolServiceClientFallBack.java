/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.request.BrokerCollectionRequest;
import com.ztj.dichan.cust.rule.response.broker.BrokerCollectionVo;

/**
 * @author sily
 *
 */
public class ProtocolServiceClientFallBack implements BrokerCollectionServiceClient {

	@Override
	public List<BrokerCollectionVo> queryCollectionList(List<BrokerCollectionRequest> brokerCollectionRequest) {
		// TODO Auto-generated method stub
		return null;
	}

}