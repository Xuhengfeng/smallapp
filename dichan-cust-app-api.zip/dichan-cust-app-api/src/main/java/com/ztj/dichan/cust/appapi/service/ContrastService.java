package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.appapi.external.HouseServiceClient;
import com.ztj.dichan.cust.appapi.external.RentHouseServiceClient;
import com.ztj.dichan.cust.appapi.request.contrast.ContrastRequest;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.HouseContrast;
import com.ztj.dichan.cust.core.repository.HouseContrastRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.rule.request.contract.HouseContrastRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRecmdRequest;
import com.ztj.dichan.cust.rule.response.house.HouseContrastDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseRecmdVo;
import com.ztj.dichan.cust.rule.response.house.RentHouseContrastDetailVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseRecmdVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * 
 * @author yincp
 */
@Service
@Transactional
public class ContrastService extends BaseAppService {
	
	
	@Resource
	private HouseServiceClient houseServiceClient;
	
	@Resource
	private RentHouseServiceClient rentHouseServiceClient;
	
	
	@Resource
	private HouseContrastRepository houseContrastRepository;

	
	public void joinContrast(ContrastRequest request) {
		
		if (request == null || request.getMemberId() == null 
				|| request.getHouseSdid() == null) {
			throw new BizException("加入对比失败，缺少必须参数！");
		}
		
		String cityCode = RequestContextHolder.getCityCode();
		Long  memberId = request.getMemberId();
		Long  houseSdid = request.getHouseSdid();
		Long count= houseContrastRepository.countByMemberIdAndHouseSdid(memberId,houseSdid);
		if(count>0) {
			return;
		}
		HouseContrast contrast = new HouseContrast();
		contrast.setCreateTime(LocalDateTime.now());
		contrast.setHouseId(request.getHouseId());
		contrast.setHouseScity(cityCode);
		contrast.setHouseSdid(houseSdid);
		contrast.setMemberId(memberId);
		try {
			houseContrastRepository.save(contrast);
		} catch (Exception e) {
			throw new BizException("添加对比出错了");
		}
	}
	
	
	public void cancelContrast(Long houseSdid,Long memberId) {
		try {
			houseContrastRepository.deleteBySdid(houseSdid,memberId);
		} catch (Exception e) {
			throw new BizException("删除对比出错了");
		}
	}
	
	
	public List<HouseRecmdVo> usedContrastList (String scity,Long memberId){
		
		List<HouseContrast>  contrastList = houseContrastRepository.findByHouseScityAndMemberId(scity, memberId);
		if(contrastList.isEmpty() || contrastList.size() <1) {
			return new ArrayList<>();
		}
		List<Long> houseSdidList = new ArrayList<>();
		contrastList.stream().forEach(contrast -> {
			houseSdidList.add(contrast.getHouseSdid());
		});
		HouseRecmdRequest houseRecmdRequest = new HouseRecmdRequest();
		houseRecmdRequest.setSdidList(houseSdidList);
		houseRecmdRequest.setScity(scity);
		List<HouseRecmdVo> houseContrastList = houseServiceClient.queryRecmdList(houseRecmdRequest,houseRecmdRequest.getScity());
		houseContrastList.forEach(houseContrastVo -> {
			houseContrastVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseContrastVo.getHousePic(),
					scity, String.valueOf(houseContrastVo.getId())));
		
			houseContrastVo.setStatus(Utils.checkHouseStatus(houseContrastVo.getBuildStatus()));
			
		});
		return houseContrastList;
	}
	
	
	public List<RentHouseRecmdVo> rentContrastList (String scity,Long memberId){
		List<HouseContrast>  contrastList = houseContrastRepository.findByHouseScityAndMemberId(scity, memberId);
		if(contrastList.isEmpty() || contrastList.size() <1) {
			return new ArrayList<>();
		}
		List<Long> houseSdidList = new ArrayList<>();
		contrastList.stream().forEach(contrast -> {
			houseSdidList.add(contrast.getHouseSdid());
		});
		HouseRecmdRequest houseRecmdRequest = new HouseRecmdRequest();
		houseRecmdRequest.setSdidList(houseSdidList);
		houseRecmdRequest.setScity(scity);
		List<RentHouseRecmdVo> houseContrastList = rentHouseServiceClient.queryRecmdList(houseRecmdRequest,scity);
		houseContrastList.forEach(houseContrastVo -> {
			houseContrastVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseContrastVo.getHousePic(),
					scity, String.valueOf(houseContrastVo.getId())));
		});
		return houseContrastList;
	}
	
	
	
	public List<HouseContrastDetailVo> usedHouseContrast (String scity,String sdidStr){
		
		List<Long> sdidList = new LinkedList<Long>();
		String[] sdidArray = sdidStr.split("-");
		for (String sdid : sdidArray) {
			sdidList.add(Long.parseLong(sdid));
		}
		if (StringUtils.isEmpty(scity)) {
			scity = RequestContextHolder.getCityCode();
		}
		
		HouseContrastRequest request = new HouseContrastRequest();
		request.setScity(scity);
		request.setSdidList(sdidList);
		
		List<HouseContrastDetailVo>  houseList = houseServiceClient.houseContrast(request,request.getScity());
		for (HouseContrastDetailVo houseContrastDetailVo : houseList) {
			houseContrastDetailVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseContrastDetailVo.getHousePic(),
					scity, String.valueOf(houseContrastDetailVo.getId())));
			houseContrastDetailVo.setElevator("有");
		}
		return houseList;
	}
	
	public List<RentHouseContrastDetailVo> rentHouseContrast (String sdidStr){
		
		List<Long> sdidList = new LinkedList<Long>();
		String[] sdidArray = sdidStr.split("-");
		for (String sdid : sdidArray) {
			sdidList.add(Long.parseLong(sdid));
		}
		String cityCode = RequestContextHolder.getCityCode();
		HouseContrastRequest request = new HouseContrastRequest();
		request.setScity(cityCode);
		request.setSdidList(sdidList);
		
		List<RentHouseContrastDetailVo>  houseList = rentHouseServiceClient.houseContrast(request,cityCode);
		for (RentHouseContrastDetailVo houseContrastDetailVo : houseList) {
			houseContrastDetailVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), houseContrastDetailVo.getHousePic(),
					request.getScity(), String.valueOf(houseContrastDetailVo.getId())));
		}
		return houseList;
	}


}