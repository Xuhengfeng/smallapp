package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.common.exception.BizException;
import com.ztj.common.util.DateUtil;
import com.ztj.dichan.cust.appapi.easemob.EasemobConfig;
import com.ztj.dichan.cust.appapi.easemob.external.EasemobUserServiceClient;
import com.ztj.dichan.cust.appapi.easemob.service.EasemobUserService;
import com.ztj.dichan.cust.appapi.external.BrokerServiceClient;
import com.ztj.dichan.cust.appapi.external.HouseCollectionServiceClient;
import com.ztj.dichan.cust.appapi.external.HouseServiceClient;
import com.ztj.dichan.cust.appapi.request.AppointHouseCancelRequest;
import com.ztj.dichan.cust.appapi.request.AppointHouseDetailRequest;
import com.ztj.dichan.cust.appapi.request.AppointHouseRequest;
import com.ztj.dichan.cust.appapi.request.AppointHouseSdid;
import com.ztj.dichan.cust.appapi.request.AppointRemarkRequest;
import com.ztj.dichan.cust.appapi.service.component.SmsComponent;
import com.ztj.dichan.cust.appapi.util.JMessageUtil;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseCompleteVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseDetailListVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseRecordDetailVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseRecordHouseVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseRecordVo;
import com.ztj.dichan.cust.appapi.vo.appoint.BringHouseVo;
import com.ztj.dichan.cust.appapi.vo.appoint.MemberRemarkDetail;
import com.ztj.dichan.cust.appapi.vo.appoint.ReadyHouseVo;
import com.ztj.dichan.cust.core.constant.OtherConstant;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.entity.AppointHouse;
import com.ztj.dichan.cust.core.entity.AppointHouseDetail;
import com.ztj.dichan.cust.core.entity.AppointHouseRecord;
import com.ztj.dichan.cust.core.entity.BrokerCollection;
import com.ztj.dichan.cust.core.entity.BrokerContact;
import com.ztj.dichan.cust.core.enums.AppointHouseStatusEnum;
import com.ztj.dichan.cust.core.enums.AppointHouseTypeEnum;
import com.ztj.dichan.cust.core.enums.AppointRangeEnum;
import com.ztj.dichan.cust.core.repository.AppointHouseDetailRepository;
import com.ztj.dichan.cust.core.repository.AppointHouseRecordRepository;
import com.ztj.dichan.cust.core.repository.AppointHouseRepository;
import com.ztj.dichan.cust.core.repository.BrokerContactRepository;
import com.ztj.dichan.cust.core.repository.BrokerEvaluateRepository;
import com.ztj.dichan.cust.core.util.PhotoUtil;
import com.ztj.dichan.cust.core.util.VerifyUtil;
import com.ztj.dichan.cust.rule.request.HouseCollectionRequest;
import com.ztj.dichan.cust.rule.response.HouseBrokerVo;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseCollectionVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;
import com.ztj.dichan.cust.rule.util.Utils;

/**
 * @author sily
 *
 */
@Service
@Transactional
public class AppointHouseRecordService extends BaseAppService {

	@Resource
	private AppointHouseRecordRepository appointHouseRecordRepository;

	@Resource
	private HouseServiceClient houseServiceClient;

	@Resource
	private HouseCollectionServiceClient houseCollectionServiceClient;

	@Resource
	private AppointHouseDetailRepository appointHouseDetailRepository;

	@Resource
	private AppointHouseRepository appointHouseRepository;

	@Resource
	private BrokerServiceClient brokerServiceClient;
	
	@Resource
	private BrokerEvaluateRepository brokerEvaluateRepository;
	
	@Resource
	private DictionaryService dictionaryService;
	
	@Resource
	private SmsComponent smsComponent;
	
	@Resource
	private BrokerContactRepository brokerContactRepository ;
	
	@Resource
	private EasemobUserServiceClient easemobUserServiceClient;
	 
	@Resource
	private EasemobUserService easemobUserService;
	

	/**
	 * 加入清单
	 * 
	 * @param memberId
	 * @param request
	 */
	public void addAppointHouseDetail(Long memberId, AppointHouseDetailRequest request) {

		if (request.getSdid() == null || request.getSdid() <= 0) {
			throw new IllegalArgumentException("房源sdid不能为空");
		}
		String scity = RequestContextHolder.getCityCode();
		HouseDetailVo houseDetailVo = houseServiceClient.getDetailInfo(scity, request.getSdid());
		if (houseDetailVo == null) {
			throw new IllegalArgumentException("房源信息不存在");
		}
		Integer count = appointHouseDetailRepository.countByMemberIdAndHouseSdid(memberId,
				Long.valueOf(houseDetailVo.getSdid()));
		if (count > 0) {
			throw new IllegalArgumentException("该房源信息已存在预约清单中，不能重复加入");
		}
		AppointHouseDetail appointHouseDetail = new AppointHouseDetail();

		appointHouseDetail.setHouseId(Long.valueOf(houseDetailVo.getId()));
		appointHouseDetail.setHouseScity(houseDetailVo.getScity());
		appointHouseDetail.setHouseSdid(request.getSdid());
		appointHouseDetail.setCreateDateTime(LocalDateTime.now());
		appointHouseDetail.setMemberId(memberId);
		appointHouseDetail.setScity(scity);

		appointHouseDetailRepository.save(appointHouseDetail);
	}

	/**
	 * 查询获取待看房源列表
	 * 
	 * @param memberId
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<AppointHouseDetailListVo> queryAppointHouseDetailList(Long memberId, Integer pageNo, Integer pageSize) {

		if (pageNo == null || pageNo <= 0) {
			pageNo = 1;
		}
		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}
		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createDateTime");

		List<AppointHouseDetail> datalist = appointHouseDetailRepository.findByMemberId(memberId, pageRequest);

		if (datalist == null || datalist.isEmpty()) {
			return new ArrayList<AppointHouseDetailListVo>(0);
		}

		List<HouseCollectionRequest> houseCollectionRequest = new ArrayList<>();
		Map<String, Long> mapTemp = new HashMap<String, Long>();
		datalist.stream().forEach(houseDetail -> {
			HouseCollectionRequest vo = new HouseCollectionRequest();
			vo.setSdid(houseDetail.getHouseSdid());
			vo.setScity(houseDetail.getHouseScity());

			houseCollectionRequest.add(vo);
			mapTemp.put(houseDetail.getHouseSdid() + "", houseDetail.getId());
		});

		List<HouseCollectionVo> houseVoList = houseCollectionServiceClient.queryCollectionList(houseCollectionRequest);
		if (houseVoList == null) {
			return new ArrayList<>(0);
		}

		List<AppointHouseDetailListVo> voList = houseVoList.stream().map(record -> {
			AppointHouseDetailListVo vo = new AppointHouseDetailListVo();
			BeanUtils.copyProperties(record, vo);
			vo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), vo.getHousePic(), record.getScity(),
					String.valueOf(record.getId())));

			vo.setHouseId(record.getId());
			vo.setHouseScity(record.getScity());
			vo.setHouseSdid(record.getSdid() + "");
			vo.setId(mapTemp.get(vo.getHouseSdid()));
			
			
			vo.setStatus(Utils.checkHouseStatus(record.getBuildStatus()));
			
			return vo;

		}).collect(Collectors.toList());

		return voList;
	}

	/**
	 * 
	 * @param memberId
	 * @param request
	 */
	public void deleteAppointHouseDetail(Long memberId, Long id) {
		if (id == null || id <= 0) {
			throw new IllegalArgumentException("待看id为空");
		}
		if (memberId == null || memberId <= 0) {
			throw new IllegalArgumentException("无权限删除");
		}
		AppointHouseDetail appointHouseDetail = appointHouseDetailRepository.findOne(id);
		if (appointHouseDetail == null) {
			throw new IllegalArgumentException("待看记录不存在");
		}
		if (appointHouseDetail.getMemberId() == null) {
			throw new IllegalArgumentException("无权限删除");
		}
		logger.info("deleteAppointHouseDetail getMemberId()=" + appointHouseDetail.getMemberId() + ",memberId=" +memberId);
		if (appointHouseDetail.getMemberId() == null || appointHouseDetail.getMemberId().intValue() != memberId.intValue()) {
			throw new IllegalArgumentException("无权限删除");
		}
		appointHouseDetailRepository.delete(appointHouseDetail);
	}

	/**
	 * 提交预约保存
	 * @param memberId
	 * @param request
	 */
	public void appointHouse(Long memberId, AppointHouseRequest request) {

		List<AppointHouseSdid> houseList = request.getHouseList();
		if (houseList == null || houseList.isEmpty()) {
			throw new IllegalArgumentException("约看房源不能为空");
		}
		if (houseList.size() > 1) {
			String sctiy = houseList.get(0).getScity();
			if (StringUtils.isEmpty(sctiy)) {
				throw new IllegalArgumentException("约看房源城市编码为空");
			}
			houseList.forEach(house -> {
				if (!sctiy.equals(house.getScity())) {
					throw new IllegalArgumentException("约看房源城市编码不一致");
				}
			});
		}

		String scity = RequestContextHolder.getCityCode();

		if (StringUtils.isEmpty(request.getAppointName())) {
			throw new IllegalArgumentException("姓名不能为空");
		}

		if (StringUtils.isEmpty(request.getAppointMobile())) {
			throw new IllegalArgumentException("手机号不能为空");
		}

		if (!VerifyUtil.isMobile(request.getAppointMobile())) {
			throw new IllegalArgumentException("不正确的手机格式");
		}

		if (StringUtils.isEmpty(request.getAppointDate())) {
			throw new IllegalArgumentException("预约时间不能为空");
		}

		if (request.getAppointRange() == null) {
			throw new IllegalArgumentException("预约时段不能为空");
		}
		LocalDate appointDate = null;
		try {
			appointDate = toLocalDate(request.getAppointDate());
		} catch (Exception e) {
			throw new IllegalArgumentException("时间格式不正确");
		}

		if (request.getBrokerId() == null || request.getBrokerId() <= 0) {
			throw new IllegalArgumentException("经纪人不能为空");
		}

		LocalDateTime nowDateTime = LocalDateTime.now();

		LocalDate nowDate = LocalDate.now();
		if (appointDate.isBefore(nowDate)) {
			throw new IllegalStateException("预约时段不能小于当前时间");
		} else if (appointDate.isEqual(nowDate)) {
			String forenoonDateStr = DateUtil.formatLocalDateTime(nowDateTime, DateUtil.DATEFORMAT_DATE10)
					+ " 11:59:59";
			LocalDateTime forenoon = DateUtil.toLocalDateTime(forenoonDateStr);

			String afternoonDateStr = DateUtil.formatLocalDateTime(nowDateTime, DateUtil.DATEFORMAT_DATE10)
					+ " 13:59:59";
			LocalDateTime afternoon = DateUtil.toLocalDateTime(afternoonDateStr);

			String nightDateStr = DateUtil.formatLocalDateTime(nowDateTime, DateUtil.DATEFORMAT_DATE10) + " 17:59:59";
			LocalDateTime night = DateUtil.toLocalDateTime(nightDateStr);

			// 时间段为全天时不需要进行处理
			if (request.getAppointRange() == AppointRangeEnum.FORENOON) {
				if (nowDateTime.compareTo(forenoon) >= 0) {
					throw new IllegalStateException("当前时间段选择不正确");
				}
			} else if (request.getAppointRange() == AppointRangeEnum.AFTERNOON) {
				if (nowDateTime.compareTo(afternoon) >= 0) {
					throw new IllegalStateException("当前时间段选择不正确");
				}
			} else if (request.getAppointRange() == AppointRangeEnum.NIGHT) {
				if (nowDateTime.compareTo(night) >= 0) {
					throw new IllegalStateException("当前时间段选择不正确");
				}
			}
		}

		BrokerDetailVo broker = brokerServiceClient.queryBroker(scity, request.getBrokerId());
		
		if (broker == null) {
			throw new IllegalStateException("未找到相应的经纪人");
		}
		
		try {

			AppointHouseRecord appointRecord = new AppointHouseRecord();

			appointRecord.setMemberId(memberId);
			appointRecord.setAppointName(request.getAppointName());
			appointRecord.setAppointMobile(request.getAppointMobile());
			appointRecord.setAppointDate(appointDate);
			appointRecord.setAppointRange(request.getAppointRange());
			appointRecord.setStatus(AppointHouseStatusEnum.SUCCESS);
			appointRecord.setCreateDateTime(LocalDateTime.now());
			appointRecord.setBrokerId(broker.getId());
			appointRecord.setBrokerSdId(Long.valueOf(broker.getSdid()));
			appointRecord.setBrokerName(broker.getEmplName());
			appointRecord.setScity(scity);
			appointRecord.setProcStep(AppointHouseStatusEnum.SUCCESS.name());
			appointRecord.setHouseNum(houseList.size());
			
			appointHouseRecordRepository.save(appointRecord);
			
			StringBuffer houseContent = new StringBuffer("");
			houseList.forEach(house -> {

				HouseDetailVo houseDetailVo = houseServiceClient.getDetailInfo(house.getScity(), house.getSdid());
				if (houseDetailVo == null) {
					throw new IllegalArgumentException("没有找到相应的房源");
				}
				houseContent.append(houseDetailVo.getBuildName()).append("\\");
				AppointHouse appointHouse = new AppointHouse();
				appointHouse.setRecordId(appointRecord.getId());
				appointHouse.setHouseId(houseDetailVo.getId());
				appointHouse.setHouseSdid(Long.valueOf(houseDetailVo.getSdid()));
				appointHouse.setHouseScity(house.getScity());
				appointHouse.setMemberId(memberId);
				appointHouse.setType(AppointHouseTypeEnum.ORIGINAL_HOUSE);
				appointHouse.setCreateDateTime(LocalDateTime.now());
				appointHouse.setScity(scity);
				appointHouseRepository.save(appointHouse);
				appointHouseDetailRepository.deleteByMemberIdAndHouseSdid(memberId, house.getSdid());
			});

			appointRecord.setHouseContent(houseContent.toString().substring(0, houseContent.length() - 1));

			appointHouseRecordRepository.save(appointRecord);
			savebrokerContact(request.getBrokerId() ,scity, memberId );
			//发送短信通知经纪人
			JSONObject data = new JSONObject();
			data.put("phone", appointRecord.getAppointMobile());
			data.put("name", appointRecord.getAppointName());
			this.smsComponent.sendAppointNotifiBroker(broker.getPhone(), data);
			buildAndSend(broker.getId(), scity, appointRecord.getHouseContent()+",预约成功");

		} catch (IllegalArgumentException | IllegalStateException e) {
			throw e;
		} catch (Exception e) {
			throw new BizException("保存预约看房信息出错了", e);
		}
		
//		  去经纪人app上 通知经纪人，您有一条订单信息
		try {
			JSONObject req = new JSONObject();
			JSONObject msg = new JSONObject();
			JSONArray target = new JSONArray();
			JSONObject ext = new JSONObject();
			target.add(scity+"_"+request.getBrokerId()+"_"+broker.getEmplAccNo());
			//"target" : ["u1", "u2", "u3"],
			msg.put("type", "txt");
			msg.put("msg", "您有一条新的订单");
			ext.put("customType","2");
			req.put("target_type", "users");
			req.put("target", target);
			req.put("msg", msg);
			req.put("from", "系统消息");
			req.put("ext", ext);
			JSONObject obj = easemobUserServiceClient.sendMessage(easemobUserService.getToken(), req);
			
		} catch (Exception e) {
			throw new BizException("通知经纪人出错了", e);
		}
	}

	/**
	 * 获取待看详情信息
	 * 
	 * @param memberId
	 * @param id
	 */
	public AppointHouseRecordDetailVo queryAppointDetail(Long memberId, Long id) {
		if (memberId == null || id == null || id <= 0) {
			throw new IllegalStateException("待看记录ID不能为空");
		}
		AppointHouseRecord appointRecord = appointHouseRecordRepository.findOne(id);
		if (appointRecord == null) {
			throw new IllegalStateException("未找到相应的待看记录信息");
		}
		AppointHouseRecordDetailVo vo = new AppointHouseRecordDetailVo();
		vo.setHouseContent(appointRecord.getHouseContent());
		vo.setHouseNum(appointRecord.getHouseNum());
		vo.setAppointMobile(appointRecord.getAppointMobile());
		vo.setAppointName(appointRecord.getAppointName());
		vo.setStatus(appointRecord.getStatus());
		int currYear = LocalDateTime.now().getYear();
		vo.setCreateDateTime(formDate(currYear,appointRecord.getCreateDateTime()));

		vo.setAssignBrokerTime(formDate(currYear,appointRecord.getAssignBrokerTime()));
		vo.setProcScheduleTime(formDate(currYear,appointRecord.getProcScheduleTime()));
		vo.setCancelTime(formDate(currYear,appointRecord.getCancelTime()));
		vo.setScheduleTime(formDate(currYear,appointRecord.getScheduleTime()));
		String appointDate = "";
		if (currYear !=  appointRecord.getAppointDate().getYear()) {
			appointDate = appointRecord.getAppointDate().format(DateTimeFormatter.ofPattern("MM月dd日"));
		} else {
			appointDate = appointRecord.getAppointDate().format(DateTimeFormatter.ofPattern("yyyy年MM月dd日"));
		}
		
		appointDate += " " + appointRecord.getAppointRange().getName();
		vo.setAppointDate(appointDate);
		
		vo.setProcStep(appointRecord.getProcStep());

		BrokerDetailVo broker = brokerServiceClient.queryBroker(appointRecord.getScity(), appointRecord.getBrokerId());
		if (broker != null) {
			HouseBrokerVo brokerVo = new HouseBrokerVo();
			brokerVo.setEmplAccNo(broker.getEmplAccNo());
			brokerVo.setEmplFlag(broker.getEmplFlag());
			brokerVo.setEmplName(broker.getEmplName());
			brokerVo.setId(broker.getId());
			brokerVo.setPhone(broker.getPhone());
			brokerVo.setScity(broker.getScity());
			brokerVo.setSdid(broker.getSdid());
			brokerVo.setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), broker.getPhoto(),
					broker.getScity(), broker.getId()));
			brokerVo.setDeptName(broker.getDeptName());
			brokerVo.setPositionName(broker.getPositionName());
			vo.setBroker(brokerVo);
		}

		return vo;
	}

	/**
	 * 取消约看房
	 * 
	 * @param memberId
	 * @param request
	 */
	public void cancelAppoint(Long memberId, AppointHouseCancelRequest request) {

		if (memberId == null || request.getId() == null || request.getId() <= 0) {
			throw new IllegalStateException("预约ID不能为空");
		}
		if (StringUtils.isEmpty(request.getCancelCause())) {
			throw new IllegalStateException("取消原因不能为空!");
		}
		AppointHouseRecord appointRecord = appointHouseRecordRepository.findOne(request.getId());

		if (appointRecord == null) {
			throw new IllegalStateException("不存在预约记录");
		}
		if (appointRecord.getStatus() == AppointHouseStatusEnum.TO_COMPLETE) {
			throw new IllegalStateException("已看房完成，无法取消");
		}
		appointRecord.setStatus(AppointHouseStatusEnum.TO_CANCEL);
		appointRecord.setCancelTime(LocalDateTime.now());
		appointRecord.setCancelCause(request.getCancelCause());

		appointHouseRecordRepository.save(appointRecord);

	}

	public void fillMemberRemark(Long memberId, AppointRemarkRequest request) {

		if (request == null || request.getId() == null) {
			throw new IllegalStateException("约看房源记录id不能为空");
		}
		AppointHouse appointHouse = appointHouseRepository.findOne(request.getId());

		if (appointHouse == null) {
			throw new IllegalStateException("不存在约看房源记录");
		}
		if (memberId != appointHouse.getMemberId()) {
			throw new IllegalStateException("无权限填写备注");
		}
		AppointHouseRecord appointRecord = appointHouseRecordRepository.findOne(appointHouse.getRecordId());
		if (appointRecord == null) {
			throw new IllegalStateException("不存在约看记录");
		}
		if (appointRecord.getStatus() != AppointHouseStatusEnum.TO_COMPLETE) {
			throw new IllegalStateException("该约看房源记录还未看房完成，无法填写用户备注");
		}
		appointHouse.setMemberRemark(request.getMemberRemark());
		appointHouse.setMRemarkDateTime(LocalDateTime.now());
		appointHouse.setRemarkTag(request.getRemarkTag());

		appointHouseRecordRepository.save(appointRecord);

	}
	
	/**
	 * 获取用户备注详情
	 * @param id
	 */
	public MemberRemarkDetail memberRemarkDetail(Long memberId, Long id) {
		if (id == null || id <= 0) {
			throw new IllegalArgumentException("约看房源记录id为空");
		}
		AppointHouse appointHouse = appointHouseRepository.findOne(id);
		if (appointHouse == null) {
			throw new IllegalArgumentException("约看房源记录不存在");
		}
		if (appointHouse.getMemberId() != memberId) {
			throw new IllegalArgumentException("约看房源记录不存在");
		}
		int currYear = LocalDateTime.now().getYear();
		MemberRemarkDetail detail = new MemberRemarkDetail();
		detail.setId(appointHouse.getId());
		detail.setMemberRemark(appointHouse.getMemberRemark());
		detail.setMRemarkDateTime(this.formDate(currYear, appointHouse.getMRemarkDateTime()));
		detail.setRemarkTag(appointHouse.getRemarkTag());
		return detail;
	}

	/**
	 * 获取待看日程列表
	 * @param status
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<AppointHouseRecordVo> queryReadyList(Long memberId, Integer pageNo, Integer pageSize) {

		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}

		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createDateTime");

		List<AppointHouseStatusEnum> statusEnums = new ArrayList<>();
		statusEnums.add(AppointHouseStatusEnum.SUCCESS);
		statusEnums.add(AppointHouseStatusEnum.TO_ASSIGN_BROKER);
		statusEnums.add(AppointHouseStatusEnum.TO_SCHEDULE);
		statusEnums.add(AppointHouseStatusEnum.TO_CANCEL);
		List<AppointHouseRecord> dataList = appointHouseRecordRepository.findByMemberIdAndStatusIn(memberId,
				statusEnums, pageRequest);

		if (dataList == null) {
			return new ArrayList<AppointHouseRecordVo>(0);
		}
		
		int currYear = LocalDateTime.now().getYear();
		
		List<AppointHouseRecordVo> voList = dataList.stream().map(record -> {
			AppointHouseRecordVo vo = new AppointHouseRecordVo();
			vo.setHouseContent(record.getHouseContent());
			vo.setHouseNum(record.getHouseNum());

			if (record.getStatus() == AppointHouseStatusEnum.TO_CANCEL) {
				vo.setStatus(2);// 已取消
			} else if (record.getStatus() == AppointHouseStatusEnum.TO_SCHEDULE) {
				vo.setStatus(1);// 预约成功
			} else if (record.getStatus() != AppointHouseStatusEnum.TO_COMPLETE) {
				vo.setStatus(0);// 确认中
			}
			
			String appointDate = "";
			if (currYear !=  record.getAppointDate().getYear()) {
				appointDate = record.getAppointDate().format(DateTimeFormatter.ofPattern("MM月dd日"));
			} else {
				appointDate = record.getAppointDate().format(DateTimeFormatter.ofPattern("yyyy年MM月dd日"));
			}
			appointDate += " " + record.getAppointRange().getName();
			vo.setAppointDate(appointDate);
			vo.setId(record.getId());
			if (record.getBrokerId() != null && record.getBrokerId() > 0) {
				
				BrokerDetailVo broker = brokerServiceClient.queryBroker(record.getScity(), record.getBrokerId());
				if (broker != null) {
					HouseBrokerVo brokerVo = new HouseBrokerVo();
					brokerVo.setEmplAccNo(broker.getEmplAccNo());
					brokerVo.setEmplFlag(broker.getEmplFlag());
					brokerVo.setEmplName(broker.getEmplName());
					brokerVo.setId(broker.getId());
					brokerVo.setPhone(broker.getPhone());
					brokerVo.setScity(broker.getScity());
					brokerVo.setSdid(broker.getSdid());
					brokerVo.setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), broker.getPhoto(),
							broker.getScity(), broker.getId()));
					brokerVo.setDeptName(broker.getDeptName());
					brokerVo.setPositionName(broker.getPositionName());
					vo.setBroker(brokerVo);
				}
				
			}

			return vo;

		}).collect(Collectors.toList());

		return voList;
		// return handleAppointHouseRecord(list);

	}
	
	/**
	 * 获取待看日程列表--含房源列表
	 * @param status
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<AppointHouseRecordHouseVo> queryReadyHouseList(Long memberId, Integer pageNo, Integer pageSize) {

		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}

		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createDateTime");

		List<AppointHouseStatusEnum> statusEnums = new ArrayList<>();
		statusEnums.add(AppointHouseStatusEnum.SUCCESS);
		statusEnums.add(AppointHouseStatusEnum.TO_ASSIGN_BROKER);
		statusEnums.add(AppointHouseStatusEnum.TO_SCHEDULE);
		statusEnums.add(AppointHouseStatusEnum.TO_CANCEL);
		List<AppointHouseRecord> dataList = appointHouseRecordRepository.findByMemberIdAndStatusIn(memberId,
				statusEnums, pageRequest);

		if (dataList == null) {
			return new ArrayList<AppointHouseRecordHouseVo>(0);
		}
		
		int currYear = LocalDateTime.now().getYear();
		
		List<AppointHouseRecordHouseVo> voList = dataList.stream().map(record -> {
			AppointHouseRecordHouseVo vo = new AppointHouseRecordHouseVo();
			vo.setHouseContent(record.getHouseContent());
			vo.setHouseNum(record.getHouseNum());

			if (record.getStatus() == AppointHouseStatusEnum.TO_CANCEL) {
				vo.setStatus(2);// 已取消
			} else if (record.getStatus() == AppointHouseStatusEnum.TO_SCHEDULE) {
				vo.setStatus(1);// 预约成功
			} else if (record.getStatus() != AppointHouseStatusEnum.TO_COMPLETE) {
				vo.setStatus(0);// 确认中
			}
			
			String appointDate = "";
			if (currYear !=  record.getAppointDate().getYear()) {
				appointDate = record.getAppointDate().format(DateTimeFormatter.ofPattern("MM月dd日"));
			} else {
				appointDate = record.getAppointDate().format(DateTimeFormatter.ofPattern("yyyy年MM月dd日"));
			}
			appointDate += " " + record.getAppointRange().getName();
			vo.setAppointDate(appointDate);
			vo.setId(record.getId());
			
			if (record.getBrokerId() != null && record.getBrokerId() > 0) {
				BrokerDetailVo broker = brokerServiceClient.queryBroker(record.getScity(), record.getBrokerId());
				if (broker != null) {
					HouseBrokerVo brokerVo = new HouseBrokerVo();
					brokerVo.setEmplAccNo(broker.getEmplAccNo());
					brokerVo.setEmplFlag(broker.getEmplFlag());
					brokerVo.setEmplName(broker.getEmplName());
					brokerVo.setId(broker.getId());
					brokerVo.setPhone(broker.getPhone());
					brokerVo.setScity(broker.getScity());
					brokerVo.setSdid(broker.getSdid());
					brokerVo.setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), broker.getPhoto(),
							broker.getScity(), broker.getId()));
					brokerVo.setDeptName(broker.getDeptName());
					brokerVo.setPositionName(broker.getPositionName());
					vo.setBroker(brokerVo);
				}
			}
			
			vo.setHouseList(this.getHouseList2(record.getId()));

			return vo;

		}).collect(Collectors.toList());

		return voList;
		// return handleAppointHouseRecord(list);

	}
	
	private List<HouseVo> getHouseList2(Long id) {
		
		List<AppointHouse> appointHouseList = appointHouseRepository.findByRecordId(id);
		if (appointHouseList == null) {
			return new ArrayList<HouseVo>(0);
		}
		List<HouseCollectionRequest> request = appointHouseList.stream().map(appoint -> {
			HouseCollectionRequest collRequest = new HouseCollectionRequest();
			collRequest.setScity(appoint.getHouseScity()); 
			collRequest.setSdid(appoint.getHouseSdid());
			return collRequest;
		}).collect(Collectors.toList());
		
		List<HouseCollectionVo> houseVoList = houseCollectionServiceClient.queryCollectionList(request);
		if (houseVoList == null) {
			return new ArrayList<HouseVo>(0);
		}
		
		List<HouseVo> readyHouseList = houseVoList.stream().map(house -> {
			HouseVo houseVo = new HouseVo();
			BeanUtils.copyProperties(house, houseVo);
			houseVo.setSdid(house.getSdid());
			houseVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), house.getHousePic(),
					house.getScity(), String.valueOf(house.getId())));
			
			houseVo.setStatus(Utils.checkHouseStatus(house.getBuildStatus()));
			
			return houseVo;
		}).collect(Collectors.toList());
		
		return readyHouseList;
		
	}
	
	/**
	 * 约看房源列表
	 * @param memberId
	 * @param id 约看房源记录ID
	 * @return
	 */
	public List<ReadyHouseVo> queryReadyHouseList(Long memberId, Long id) {

		
		List<AppointHouse> appointHouseList = appointHouseRepository.findByRecordId(id);
		if (appointHouseList == null) {
			return new ArrayList<ReadyHouseVo>(0);
		}
		Map<String,AppointHouse> appointHouseMap = new HashMap<String,AppointHouse>(appointHouseList.size());
		List<HouseCollectionRequest> request = appointHouseList.stream().map(appoint -> {
			HouseCollectionRequest collRequest = new HouseCollectionRequest();
			collRequest.setScity(appoint.getHouseScity()); 
			collRequest.setSdid(appoint.getHouseSdid());
			appointHouseMap.put(appoint.getHouseSdid()+"", appoint);
			return collRequest;
		}).collect(Collectors.toList());
		
		List<HouseCollectionVo> houseVoList = houseCollectionServiceClient.queryCollectionList(request);
		if (houseVoList == null) {
			return new ArrayList<ReadyHouseVo>(0);
		}
		
		List<ReadyHouseVo> readyHouseList = houseVoList.stream().map(house -> {
			ReadyHouseVo ready = new ReadyHouseVo();
			BeanUtils.copyProperties(house, ready);
			ready.setHouseSdid(Long.valueOf(house.getSdid()));
			ready.setHouseId(house.getId());
			ready.setHouseScity(house.getScity());
			ready.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), house.getHousePic(),
					house.getScity(), String.valueOf(house.getId())));
			
			ready.setStatus(Utils.checkHouseStatus(house.getBuildStatus()));
			
			AppointHouse appointHouse = appointHouseMap.get(house.getSdid()+"");
			if (appointHouse != null) {
				ready.setId(appointHouse.getId());
				ready.setType(appointHouse.getType().name());
			}
			
			return ready;
		}).collect(Collectors.toList());
		
		
		return readyHouseList;
	}

	/**
	 * 已看记录列表
	 * @param status
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	public List<AppointHouseCompleteVo> queryCompileList(Long memberId, Integer pageNo, Integer pageSize) {

		if (pageSize == null || pageSize <= 0) {
			pageSize = OtherConstant.DEFAULT_MAX_PAGE_SIZE;
		}

		PageRequest pageRequest = validateAndFetchPageRequest(pageNo, pageSize, "createDateTime");

		List<AppointHouseRecord> dataList = appointHouseRecordRepository.findByMemberIdAndStatus(memberId,
				AppointHouseStatusEnum.TO_COMPLETE, pageRequest);
		
		if (dataList == null) {
			return new ArrayList<AppointHouseCompleteVo>(0);
		}
		String complaintPhone = dictionaryService.getComplaintPhone();
		int currYear = LocalDateTime.now().getYear();
		List<AppointHouseCompleteVo> voList = dataList.stream().map(record -> {
			AppointHouseCompleteVo vo = new AppointHouseCompleteVo();
			vo.setBrokerId(record.getBrokerId());
			vo.setBrokerName(record.getBrokerName());
			vo.setBrokerSdid(record.getBrokerSdId());
			vo.setScity(record.getScity());
			vo.setId(record.getId());
			vo.setComplaintPhone(complaintPhone);
			vo.setHouseContent(record.getHouseContent());
			if (record.getScheduleTime() != null) {
				String scheduleTime = "";
				if (currYear !=  record.getScheduleTime().getYear()) {
					scheduleTime = record.getScheduleTime().format(DateTimeFormatter.ofPattern("MM月dd日  HH:mm"));
				} else {
					scheduleTime = record.getScheduleTime().format(DateTimeFormatter.ofPattern("yyyy年MM月dd日  HH:mm"));
				}
				vo.setScheduleTime(scheduleTime);
			} else {
				vo.setScheduleTime("");
			}
			if (record.getBrokerId() != null && record.getBrokerId() > 0) {
				BrokerDetailVo broker = brokerServiceClient.queryBroker(record.getScity(), record.getBrokerId());
				if (broker != null) {
					HouseBrokerVo brokerVo = new HouseBrokerVo();
					brokerVo.setEmplAccNo(broker.getEmplAccNo());
					brokerVo.setEmplFlag(broker.getEmplFlag());
					brokerVo.setEmplName(broker.getEmplName());
					brokerVo.setId(broker.getId());
					brokerVo.setPhone(broker.getPhone());
					brokerVo.setScity(broker.getScity());
					brokerVo.setSdid(broker.getSdid());
					brokerVo.setPhoto(PhotoUtil.getBrokerPhoto(systemConstant.getOssCdnUrl(), broker.getPhoto(),
							broker.getScity(), broker.getId()));
					brokerVo.setDeptName(broker.getDeptName());
					brokerVo.setPositionName(broker.getPositionName());
					vo.setBroker(brokerVo);
				}
			}

			Integer count = brokerEvaluateRepository.countByAppHouseRecId(record.getId());
			vo.setIsEvaluate(count > 0?true:false);
			
			vo.setHouseList(this.getHouseList(record.getId()));
			
			return vo;
		}).collect(Collectors.toList());
		
		return voList;
	}
	
	
	private List<BringHouseVo> getHouseList(Long id) {
		
		if (id == null) {
			return new ArrayList<BringHouseVo>(0);
		}
		List<AppointHouse> appointHouseList = appointHouseRepository.findByRecordId(id);
		if (appointHouseList == null) {
			return new ArrayList<BringHouseVo>(0);
		}
		Map<String,AppointHouse> appointHouseMap = new HashMap<String,AppointHouse>(appointHouseList.size());
		List<HouseCollectionRequest> request = appointHouseList.stream().map(appoint -> {
			HouseCollectionRequest collRequest = new HouseCollectionRequest();
			collRequest.setScity(appoint.getHouseScity()); 
			collRequest.setSdid(appoint.getHouseSdid());
			appointHouseMap.put(appoint.getHouseSdid()+"", appoint);
			return collRequest;
		}).collect(Collectors.toList());
		List<HouseCollectionVo> houseVoList = houseCollectionServiceClient.queryCollectionList(request);
		if (houseVoList == null) {
			return new ArrayList<BringHouseVo>(0);
		}
		
		int currYear = LocalDateTime.now().getYear();
		List<BringHouseVo> bringHouselist = houseVoList.stream().map(house -> {
			BringHouseVo bring = new BringHouseVo();
			BeanUtils.copyProperties(house, bring);
			bring.setHouseSdid(Long.valueOf(house.getSdid()));
			bring.setHouseId(house.getId());
			bring.setHouseScity(house.getScity());
			bring.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(), house.getHousePic(),
					house.getScity(), String.valueOf(house.getId())));
			
			bring.setStatus(Utils.checkHouseStatus(house.getBuildStatus()));
			
			AppointHouse appointHouse = appointHouseMap.get(house.getSdid()+"");
			if (appointHouse != null) {
				bring.setMemberRemark(appointHouse.getMemberRemark());
				bring.setMRemarkDateTime(this.formDate(currYear, appointHouse.getMRemarkDateTime()));
				bring.setRemarkTag(appointHouse.getRemarkTag());
				bring.setId(appointHouse.getId());
				bring.setType(appointHouse.getType().name());
			}
			
			return bring;
		}).collect(Collectors.toList());
		
		return bringHouselist;
	}
	
	public void savebrokerContact(Integer brokerId ,String scity,Long memberId ) {
		
		if (brokerId == null || brokerId <= 0) {
			throw new IllegalArgumentException("该经纪人不存在");
		}
		BrokerDetailVo brokerDetailVo = brokerServiceClient.queryBroker(scity, brokerId);
		
		if (brokerDetailVo == null) {
			throw new IllegalArgumentException("该经纪人不存在");
		}

		BrokerCollection brokerCollection = new BrokerCollection();

		brokerCollection.setBrokerScity(brokerDetailVo.getScity());
		brokerCollection.setBrokerId(Long.valueOf(brokerDetailVo.getId()));
		brokerCollection.setBrokerSdid(Long.valueOf(brokerDetailVo.getSdid()));
		
		BrokerContact entity = new BrokerContact();
		entity.setBrokerId(Long.parseLong(brokerId+""));
		entity.setBrokerScity(scity);
		entity.setBrokerSdid(Long.valueOf(brokerDetailVo.getSdid()));
		entity.setMemberId(memberId);
		entity.setCreateTime(LocalDateTime.now());
		brokerContactRepository.save(entity);
	}

	/*
	 * private List<AppointHouseRecordVo>
	 * handleAppointHouseRecord(List<AppointHouseRecord> list) {
	 * 
	 * if (list == null || list.isEmpty()) { return new ArrayList<>(0); }
	 * 
	 * 
	 * List<HouseCollectionRequest> request = list.stream().map(appoint -> {
	 * HouseCollectionRequest vo = new HouseCollectionRequest();
	 * vo.setScity(appoint.getHouseScity()); vo.setSdid(appoint.getHouseSdid());
	 * 
	 * return vo;
	 * 
	 * }).collect(Collectors.toList());
	 * 
	 * // 这里公用了dichan-cust-service工程里的二手房收藏接口 List<HouseCollectionVo> houseVoList =
	 * houseCollectionServiceClient.queryCollectionList(request);
	 * 
	 * if (houseVoList == null || houseVoList.isEmpty()) { return new
	 * ArrayList<>(0); } Map<String,HouseCollectionVo> tempMap = new
	 * HashMap<String,HouseCollectionVo>(houseVoList.size());
	 * houseVoList.forEach(houseRecmdVo -> {
	 * 
	 * houseRecmdVo.setHousePic(PhotoUtil.getPhotoOne(systemConstant.getOssCdnUrl(),
	 * houseRecmdVo.getHousePic(), houseRecmdVo.getScity(),
	 * String.valueOf(houseRecmdVo.getId())));
	 * tempMap.put(houseRecmdVo.getSdid()+"", houseRecmdVo); });
	 * 
	 * 
	 * List<AppointHouseRecordVo> voList = list.stream().map(record -> {
	 * AppointHouseRecordVo appoinRecordVo = new AppointHouseRecordVo();
	 * HouseCollectionVo houseCollectionVo = tempMap.get(record.getHouseSdid()+"");
	 * if (houseCollectionVo != null) { BeanUtils.copyProperties(houseCollectionVo,
	 * appoinRecordVo);
	 * appoinRecordVo.setHouseSdid(String.valueOf(houseCollectionVo.getSdid()));
	 * appoinRecordVo.setHouseScity(houseCollectionVo.getScity());
	 * appoinRecordVo.setHouseId(houseCollectionVo.getId()); }
	 * appoinRecordVo.setAppointRange(record.getAppointRange().getName());
	 * appoinRecordVo.setAppointDate(DateUtil.formatLocalDate(record.getAppointDate(
	 * ))); appoinRecordVo.setId(record.getId());
	 * appoinRecordVo.setMemberRemark(record.getMemberRemark());
	 * appoinRecordVo.setStatus(record.getStatus());
	 * 
	 * 
	 * return appoinRecordVo;
	 * 
	 * }).collect(Collectors.toList());
	 * 
	 * return voList; }
	 */

	private LocalDate toLocalDate(String dateTime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DateUtil.DATEFORMAT_DATE10);

		return LocalDate.parse(dateTime, formatter);
	}
	
	
	private String formDate(int currYear,LocalDateTime dateTime) {
		
		if (dateTime == null) {
			return null;
		}
		if (currYear != dateTime.getYear()) {
			return dateTime.format(DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm"));
		} else {
			return dateTime.format(DateTimeFormatter.ofPattern("MM.dd HH:mm"));
		}
	}
	
	
	
	/**
	 * 组装targetUserName
	 * 城市编码（scity）+_+ 经纪人id（id）+_+ 经纪人账号（emplAccNo）
	 * 如：beihai_10_1094356
	 */
	private void buildAndSend(Integer emplId,String scity,String message) {
		
		BrokerDetailVo broker = brokerServiceClient.queryBroker(scity, emplId);
		if (broker == null) {
			logger.info("未找到相应的经纪人");
			return;
//			throw new IllegalStateException("未找到相应的经纪人");
		}
	
		String targetUserName = scity + "_" + emplId + "_" + broker.getEmplAccNo();
		
		JMessageUtil.SendSingleText(targetUserName, "im_jjr_admin", message);
		
	}
}
