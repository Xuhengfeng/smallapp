package com.ztj.dichan.cust.appapi.rest;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.ztj.common.exception.BizException;
import com.ztj.common.exception.NoLoginException;
import com.ztj.common.exception.ValidateException;
import com.ztj.dichan.cust.appapi.service.MemberService;
import com.ztj.dichan.cust.core.constant.HeaderConstant;
import com.ztj.dichan.cust.core.constant.ParameterConstant;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.core.constant.RestResult;
import com.ztj.dichan.cust.core.constant.ReturnCode;
import com.ztj.dichan.cust.core.enums.NetworkTypeEnum;
import com.ztj.dichan.cust.core.enums.TerminalSourceEnum;
import com.ztj.dichan.cust.core.rest.BaseRest;
import com.ztj.dichan.cust.core.util.RequestUtil;

/**
 * 
 * @author test01
 */
public class BaseCustRest extends BaseRest {
	@Autowired
	protected HttpServletRequest request;

	@Resource
	protected MemberService memberService;
	
	protected ScheduledExecutorService executor = Executors
			.newScheduledThreadPool(Runtime.getRuntime().availableProcessors());

	/**
	 * 初始化基本的认证用户数据
	 */
	protected void initAuthData() {
		Map<String, Object> map = RequestContextHolder.get();

		if (map != null) {
			map.put(ParameterConstant.CURRENT_AUTH_ID, getCurrentMemberId());
		}
	}

	/**
	 * 
	 * @return
	 */
	protected String getDeviceCode() {
		return RequestUtil.getDeviceCode(request);
	}

	/**
	 * 
	 * @return
	 */
	protected TerminalSourceEnum getTerminalSource() {
		return RequestUtil.getTerminalSource(request);
	}

	/**
	 * 
	 * @return
	 */
	protected NetworkTypeEnum getNetworkType() {
		return RequestUtil.getNetworkType(request);
	}

	/**
	 * 
	 * @return
	 */
	protected String getClientVersion() {
		return RequestUtil.getClientVersion(request);
	}

	/**
	 * 获取请求主机IP地址,如果通过代理进来，则透过防火墙获取真实IP地址
	 * 
	 * @return
	 */
	protected String getClientIp() {
		return RequestUtil.getClientIp(request);
	}

	/**
	 * 获取请求主机IP地址,如果通过代理进来，则透过防火墙获取真实IP地址
	 * 
	 * @return
	 */
	protected String getCityCode() {
		return RequestUtil.getCityCode(request);
	}

	/**
	 * 
	 * @return
	 */
	protected String getUniqueCode() {
		String uniqueCode = request.getHeader(HeaderConstant.UNIQUE_CODE);

		if (StringUtils.isEmpty(uniqueCode)) {
			uniqueCode = request.getParameter(ParameterConstant.UNIQUE_CODE);
		}

		if (StringUtils.isEmpty(uniqueCode)) {
			throw new NoLoginException();
		}

		return uniqueCode;
	}

	/**
	 * 
	 * @return
	 */
	protected Long getCurrentMemberId() {
		// 多重判断,兼容目前的接口调试
		String uniqueCode = request.getHeader(HeaderConstant.UNIQUE_CODE);

		if (StringUtils.isEmpty(uniqueCode)) {
			uniqueCode = request.getParameter(ParameterConstant.UNIQUE_CODE);
		}

		if (StringUtils.isEmpty(uniqueCode)) {
			throw new NoLoginException();
		}
		return memberService.getMemberId(uniqueCode);
	}

	/**
	 * 
	 * @return
	 */
	protected Long getCurrentMemberIdAllowNull() {
		// 多重判断,兼容目前的接口调试
		String uniqueCode = request.getHeader(HeaderConstant.UNIQUE_CODE);

		if (StringUtils.isEmpty(uniqueCode)) {
			uniqueCode = request.getParameter(ParameterConstant.UNIQUE_CODE);
		}
		if (StringUtils.isEmpty(uniqueCode)) {
			return null;
		}
		return memberService.getMemberIdAllowNull(uniqueCode);
	}

	/**
	 * @param request
	 * @return
	 * @throws IOException
	 */
	public String parseInputStream(HttpServletRequest request) throws IOException {
		return RequestUtil.parseInputStream(request);
	}

	/**
	 * @param successMsg
	 * @param result
	 */
	protected void buildSuccessResult(String successMsg, RestResult result) {
		result.setMsg(successMsg);
	}

	/**
	 * @param errorMsg
	 * @param result
	 */
	protected void buildFailureResult(String errorMsg, RestResult result) {
		result.setStatus(ReturnCode.REC_0.getCode());
		result.setMsg(errorMsg);
	}

	/**
	 * @param e
	 * @param result
	 */
	protected void buildFailureResult(Exception e, RestResult result) {
		initResult(e, result);
	}

	/**
	 * @param e
	 * @param result
	 */
	protected void logAndBuildFailureResult(Exception e, RestResult result) {
		logger.error("请求出错了", e);

		initResult(e, result);
	}

	private void initResult(Exception e, RestResult result) {
		if (e instanceof IllegalArgumentException || e instanceof IllegalStateException) {
			result.setStatus(ReturnCode.REC_2.getCode());
			result.setMsg(e.getMessage());
		} else if (e instanceof ValidateException) {
			result.setStatus(((ValidateException) e).getErrorCode());
			result.setMsg(e.getMessage());
		} else if (e instanceof NoLoginException) {
			result.setStatus(ReturnCode.REC_NEGATIVE_1.getCode());
			result.setMsg(e.getMessage());
		} else if (e instanceof BizException) {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		} else {
			result.setStatus(ReturnCode.REC_0.getCode());
			result.setMsg(ReturnCode.REC_0.getName());
		}
	}
	
}