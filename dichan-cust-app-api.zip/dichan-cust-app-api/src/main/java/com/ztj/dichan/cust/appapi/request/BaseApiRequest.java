/**
 * 
 */
package com.ztj.dichan.cust.appapi.request;

import java.io.Serializable;

/**
 * @author liuweichen
 *
 */
public class BaseApiRequest implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5637807611552755294L;

}
