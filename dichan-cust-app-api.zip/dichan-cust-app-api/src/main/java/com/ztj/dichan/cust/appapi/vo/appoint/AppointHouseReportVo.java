package com.ztj.dichan.cust.appapi.vo.appoint;


import javax.persistence.Lob;

import com.ztj.common.util.DateUtil;
import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.core.entity.AppointHouseReport;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author sily
 *
 */
@ApiModel(value = "返回看房报告信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointHouseReportVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	/**
	 * 报告的url
	 */
	@ApiModelProperty(value = "报告的url")
	private String reportUrl;

	/**
	 * 简介
	 */
	@ApiModelProperty(value = "简介")
	@Lob
	private String summary;

	/**
	 * 创建时间
	 */
	@ApiModelProperty(value = "创建时间")
	private String createDateTime;

	public static AppointHouseReportVo fromAppointHouseReport(AppointHouseReport report) {
		AppointHouseReportVo vo = new AppointHouseReportVo();
		vo.setReportUrl(report.getReportUrl());
		vo.setSummary(report.getSummary());
		vo.setCreateDateTime(DateUtil.formatLocalDateTime(report.getCreateDateTime(),DateUtil.DATEFORMAT_DATETIME16));

		return vo;
	}

}