package com.ztj.dichan.cust.appapi.interceptor;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.ztj.dichan.cust.appapi.constant.SystemConstant;
import com.ztj.dichan.cust.appapi.service.MemberNewService;
import com.ztj.dichan.cust.core.constant.HeaderConstant;
import com.ztj.dichan.cust.core.constant.ParameterConstant;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;

/**
 * 
 * @author test01
 */
public class RequestInterceptor extends HandlerInterceptorAdapter {
	private static Logger logger = LoggerFactory.getLogger(RequestInterceptor.class);

	private SystemConstant systemConstant;

	private MemberNewService memberNewService;

	public RequestInterceptor(SystemConstant systemConstant, MemberNewService memberNewService) {
		this.systemConstant = systemConstant;
		this.memberNewService = memberNewService;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		initMdcParamenter(request);

		if (logger.isDebugEnabled()) {
			StringBuilder headerSb = new StringBuilder();
			StringBuilder parameterSb = new StringBuilder();
			Map<String, String> headerMap = new HashMap<>();
			Map<String, String> parameterMap = new HashMap<>();
			String url = request.getRequestURI();

			StringBuilder sb = new StringBuilder();

			sb.append("\n请求的url：" + url);
			sb.append("\n");
			sb.append("\n请求头信息：");

			Enumeration<String> headerNames = request.getHeaderNames();
			while (headerNames != null && headerNames.hasMoreElements()) {
				String headerName = headerNames.nextElement();
				String headerValue = request.getHeader(headerName);

				headerSb.append("\n").append(headerName + ": " + headerValue);

				headerMap.put(headerName, headerValue);
			}

			sb.append(headerSb.toString());
			sb.append("\n");
			sb.append("\n请求参数信息：");

			Enumeration<String> parameterNames = request.getParameterNames();
			while (parameterNames != null && parameterNames.hasMoreElements()) {
				String parameterName = parameterNames.nextElement();
				String parameterValue = request.getParameter(parameterName);

				parameterSb.append("\n").append(parameterName + ": " + parameterValue);

				parameterMap.put(parameterName, parameterValue);
			}

			sb.append(parameterSb.toString());
			sb.append("\n");

			logger.debug(sb.toString());
		}

		// 保存请求日志
		if (systemConstant.getIsEnableRequestLog()) {
			// toAddRequestLog(request, url, headerMap, parameterMap);
		}

		return true;
	}

	/**
	 * 
	 * @param request
	 */
	private void initMdcParamenter(HttpServletRequest request) {
		Long memberId = getCurrentMemberIdAllowNull(request);
		String memberIdStr = memberId == null ? "" : memberId.toString();
		
		MDC.put("request_member_id", memberIdStr);
		
		String cityCode = RequestContextHolder.getCityCode();
		
		MDC.put("request_city_code", cityCode);
	}
	
	/**
	 * 
	 * @param request
	 * @return
	 */
	private Long getCurrentMemberIdAllowNull(HttpServletRequest request) {
		String uniqueCode = request.getHeader(HeaderConstant.UNIQUE_CODE);

		if (StringUtils.isEmpty(uniqueCode)) {
			uniqueCode = request.getParameter(ParameterConstant.UNIQUE_CODE);
		}
		
		if (StringUtils.isEmpty(uniqueCode)) {
			return null;
		}
		
		return memberNewService.getMemberIdAllowNull(uniqueCode);
	}
}