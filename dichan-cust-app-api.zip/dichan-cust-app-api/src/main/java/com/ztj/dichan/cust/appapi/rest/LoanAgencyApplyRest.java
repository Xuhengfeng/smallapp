package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.request.LoanAgencyApplyCancelRequest;
import com.ztj.dichan.cust.appapi.request.LoanAgencyApplyRequest;
import com.ztj.dichan.cust.appapi.service.LoanAgencyApplyService;
import com.ztj.dichan.cust.appapi.vo.LoanAgencyApplyDetailVo;
import com.ztj.dichan.cust.appapi.vo.LoanAgencyApplyVo;
import com.ztj.dichan.cust.core.enums.LoanTypeEnum;
import com.ztj.dichan.cust.rule.response.HouseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author yincp
 *
 */
@Api(value ="代办业务申请",description="代办业务申请相关接口")
@RestController
@RequestMapping(value = "/loanAgencyApplyRest")
public class LoanAgencyApplyRest extends BaseCustRest {
	
	@Resource
	private LoanAgencyApplyService loanAgencyApplyService;
	
	
	/**
	 * 代办业务申请
	 * @param request
	 * @return
	 */
	@ApiOperation(value = "我要代办业务申请")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true)})
	@RequestMapping(value = "/loanAgency", method = { RequestMethod.POST })
	public RestResult<?>  loanAgencyApply(@RequestBody LoanAgencyApplyRequest request) {
		loanAgencyApplyService.addLoanAgencyApply(getCurrentMemberId(),request);
		return RestResult.success();

	}
	

	
	/**
	 * 我的卖房申请列表
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	@ApiOperation(value = "我的代办业务申请列表", response = LoanAgencyApplyVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "loanAgencyType", value = "代办类型(LONA=贷款,TRANSFER=过户,DETENTION=解押,DUTIABLE=报税,CONTRACT=签合同,OTHER=其他综合)", dataType = "string", paramType = "query", required = false),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", dataType = "int", paramType = "query", required = true, example="1"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", dataType = "int", paramType = "query", required = false,example="10")})
	@RequestMapping(value = "/queryLoanApplyList", method = { RequestMethod.GET })
	public RestResult<List<LoanAgencyApplyVo>> querySellApplyList(@RequestParam(name="loanAgencyType", required = false)LoanTypeEnum loanAgencyType,@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		List<LoanAgencyApplyVo> list = loanAgencyApplyService.loanAgencyApplyList(getCurrentMemberId(), loanAgencyType, pageNo, pageSize);
		return RestResult.success(list);

	} 
	
	
	/**
	 * 获取我的代办业务申请详情
	 * @param id
	 * @return
	 */
	@ApiOperation(value = "获取我的代办业务申请详情", response = LoanAgencyApplyDetailVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "id", value = "申请Id", dataType = "int", paramType = "path", required = true)})
	@RequestMapping(value = "/loan/{id}", method = { RequestMethod.GET })
	public RestResult<LoanAgencyApplyDetailVo> getEntrustHouseApply(@PathVariable("id")Long id) {
		
		return RestResult.success(this.loanAgencyApplyService.getLoanAgencyApplyDetail(getCurrentMemberId(), id));

	}
	
	
	/**
	 * 代办业务房源列表
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	@ApiOperation(value = "代办业务房源列表", response = HouseVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", dataType = "int", paramType = "query", required = true, example="1"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", dataType = "int", paramType = "query", required = false,example="10")})
	@RequestMapping(value = "/queryLoanHouseList", method = { RequestMethod.GET })
	public RestResult<List<HouseVo>> querySellHouseList(@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		List<HouseVo> list = loanAgencyApplyService.queryLoanHouseList(getCurrentMemberId(), pageNo, pageSize);
		return RestResult.success(list);

	}
	
	
	/**
	 * 取消代办业务
	 * @param id
	 * @return
	 */
	@ApiOperation(value = "取消代办业务")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true)})
	@RequestMapping(value = "/loan/cancel", method = { RequestMethod.PUT })
	public RestResult<String> cancelEntrustHouseApply(@RequestBody LoanAgencyApplyCancelRequest request) {
		this.loanAgencyApplyService.cancelLoanAgencyApply(getCurrentMemberId(), request);
		return RestResult.success("操作成功！");

	}
	
	

}
