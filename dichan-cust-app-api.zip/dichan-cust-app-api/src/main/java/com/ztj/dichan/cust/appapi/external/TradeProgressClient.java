/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

import com.ztj.dichan.cust.rule.response.house.HouseTradeProgressVo;

/**
 * @author lbs
 *
 */
@FeignClient(name = "tradeProgressClient", url= "${cust.service.url}", fallback = HouseServiceClientFallBack.class)
public interface TradeProgressClient {

	 
	 @GetMapping(value = "/tradeProgress/query")
	 public List<HouseTradeProgressVo> queryTradeProgress(@RequestParam(name="phone", required = false) String phone,
				@RequestHeader(value = "scity", required = true) String scity);
	 
	 
}
