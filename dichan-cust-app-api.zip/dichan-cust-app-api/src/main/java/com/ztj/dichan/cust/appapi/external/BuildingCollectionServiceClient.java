/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ztj.dichan.cust.rule.request.BuildCollectionRequest;
import com.ztj.dichan.cust.rule.response.building.BuildingCollectionVo;



/**
 * @author sily
 *
 */
@FeignClient(name = "buildCollectionServiceClient", url= "${cust.service.url}", fallback = BuildingCollectionServiceClient.class)
public interface BuildingCollectionServiceClient {
	
	@RequestMapping(method = RequestMethod.POST, value = "/build/collection")
	public List<BuildingCollectionVo> queryCollectionList(List<BuildCollectionRequest> buildCollectionRequest);
	
}