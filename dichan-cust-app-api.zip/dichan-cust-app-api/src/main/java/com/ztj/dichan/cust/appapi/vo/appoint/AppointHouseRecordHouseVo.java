/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.appoint;

import java.util.List;

import com.ztj.common.vo.BaseValueObject;
import com.ztj.dichan.cust.rule.response.HouseBrokerVo;
import com.ztj.dichan.cust.rule.response.HouseVo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "返回待看列表信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppointHouseRecordHouseVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "预约看房id")
	private Long id;

	@ApiModelProperty(value = "预约时间")
	private String appointDate;

	@ApiModelProperty(value = "看房套数")
	private Integer houseNum;

	@ApiModelProperty(value = "房源内容")
	private String houseContent;

	@ApiModelProperty(value = "状态，0=确认中，1=预约成功，2=已取消")
	private Integer status;

	@ApiModelProperty(value = "经纪人")
	private HouseBrokerVo broker;
	
	@ApiModelProperty(value = "待看房源列表")
	private List<HouseVo> houseList;
	
	
}
