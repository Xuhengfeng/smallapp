/**
 * 
 */
package com.ztj.dichan.cust.appapi.vo.infocontent;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lbs
 *
 */
@ApiModel(value = "栏目信息VO")
@Data
@EqualsAndHashCode(callSuper = true)
public class ColumnesVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "城市编码")
	private String cityCode;

	/**
	 * 栏目名称
	 */
	@ApiModelProperty(value = "栏目名称")
	private String name;

	/**
	 * 栏目编码
	 */
	@ApiModelProperty(value = "栏目编码")
	private String code;

}
