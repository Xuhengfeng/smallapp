package com.ztj.dichan.cust.appapi.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.ztj.dichan.cust.appapi.vo.house.HouseDetailCountVo;
import com.ztj.dichan.cust.appapi.vo.house.HouseDetailDataVo;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;

/**
 * 
 * @author test01
 */
@Service
public class HouseNewService extends BaseAppService {

	@Resource
	private HouseService houseService;

	@Resource
	private BuildingService buildingService;

	/**
	 * 一次性获取房源详情等信息
	 * 
	 * @param memberId
	 * @param scity
	 * @param buildingSdid
	 * @param longitude
	 * @param latitude
	 * @return
	 */
	public HouseDetailDataVo fetchDetailData(Long memberId, Long buildingSdid, Double longitude, Double latitude) {
		String scity = RequestContextHolder.getCityCode();

		// 房源清单列表数量统计
		HouseDetailCountVo houseDetailCountVo = houseService.getHouseDetailCount(memberId);

		// 小区详情
		BuildingDetailVo buildingDetailVo = buildingService.buildInfo(buildingSdid, scity, memberId);

		// 同小区房源
		List<SecondHouseVo> secondHouseVoList = buildingService.secondHouseList(buildingSdid, scity, 1, 2);

		// 二手房周边房源
		RimHouseRequest rimHouseRequest = new RimHouseRequest();
		rimHouseRequest.setBuildSdid(buildingSdid);
		rimHouseRequest.setPx(longitude);
		rimHouseRequest.setPy(latitude);
		rimHouseRequest.setPageNo(1);
		rimHouseRequest.setPageSize(10);

		List<HouseVo> houseVoList = houseService.rimHousing(rimHouseRequest);

		HouseDetailDataVo vo = new HouseDetailDataVo();
		vo.setHouseDetailCountVo(houseDetailCountVo);
		vo.setBuildingDetailVo(buildingDetailVo);
		vo.setSecondHouseVoList(secondHouseVoList);
		vo.setHouseVoList(houseVoList);

		return vo;
	}
}