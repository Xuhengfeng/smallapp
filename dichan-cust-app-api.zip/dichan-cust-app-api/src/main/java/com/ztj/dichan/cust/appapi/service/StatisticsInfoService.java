package com.ztj.dichan.cust.appapi.service;
import java.time.LocalDateTime;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.alibaba.druid.util.StringUtils;
import com.ztj.dichan.cust.appapi.vo.StatisticsInfoVo;
import com.ztj.dichan.cust.core.entity.StatisticsInfo;
import com.ztj.dichan.cust.core.repository.StatisticsInfoRepository;


/**
 * 
 * @author liuweichen
 *
 */
@Service
public class StatisticsInfoService extends BaseAppService {
	
	@Resource
	private StatisticsInfoRepository statisticsInfoRepository;
	
	
	/**
	 * 房价统计
	 * @param city_id
	 * @param month
	 * @return
	 */
	public StatisticsInfoVo querCurrentMonthStatistics(String cityCode) {
		
		
		LocalDateTime now = LocalDateTime.now();
		Integer year = now.getYear();
		Integer month = now.getMonthValue();
		
		StatisticsInfoVo vo = new StatisticsInfoVo();
		if (StringUtils.isEmpty(cityCode)) {
			vo.setAvgPrice(0.0);
			vo.setMonth(month);
			vo.setSuiteCount(0);
			return vo;
		}
		
		StatisticsInfo info = statisticsInfoRepository.findByCityCodeAndYearAndMonth(cityCode,year,month);
		
		if (info == null) {
			vo.setAvgPrice(0.0);
			vo.setMonth(month);
			vo.setSuiteCount(0);
			return vo;
		}
		vo.setAvgPrice(info.getAvgPrice() == null? 0:info.getAvgPrice());
		vo.setMonth(info.getMonth());
		vo.setSuiteCount(info.getSuiteCount() == null? 0:info.getSuiteCount());
		return vo;
		
	}

}
