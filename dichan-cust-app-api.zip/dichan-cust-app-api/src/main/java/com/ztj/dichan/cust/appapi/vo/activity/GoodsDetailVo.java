package com.ztj.dichan.cust.appapi.vo.activity;

import com.ztj.dichan.cust.appapi.vo.BaseApiValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 * @author sily
 */
@ApiModel(value = "商品详细信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class GoodsDetailVo extends BaseApiValueObject {
	private static final long serialVersionUID = 1L;
	
	
	@ApiModelProperty(value = "已兑换数量")
	private Long soldNumber;
	
	@ApiModelProperty(value = "详情id")
	private Long exchangeId;
	
}
