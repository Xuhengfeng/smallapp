package com.ztj.dichan.cust.appapi.interceptor;

import java.lang.reflect.Type;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.RequestBodyAdviceAdapter;

import com.google.gson.Gson;
import com.ztj.dichan.cust.appapi.constant.SystemConstant;
import com.ztj.dichan.cust.appapi.service.UseCountService;
import com.ztj.dichan.cust.core.constant.ParameterConstant;
import com.ztj.dichan.cust.core.constant.RequestContextHolder;

/**
 * 
 * @author test01
 */
@ControllerAdvice(basePackages = "com.ztj.dichan.cust.appapi.rest")
public class SystemRequestBodyAdvice extends RequestBodyAdviceAdapter {
	private static Logger logger = LoggerFactory.getLogger(SystemRequestBodyAdvice.class);
	
	
	private UseCountService useCountService;
	
	private SystemConstant systemConstant;
	
	public SystemRequestBodyAdvice(UseCountService useCountService,SystemConstant systemConstant) {
		this.useCountService = useCountService;
		this.systemConstant = systemConstant;
	}
	
	@Override
	public boolean supports(MethodParameter methodParameter, Type targetType,
			Class<? extends HttpMessageConverter<?>> converterType) {
		return true;
	}

	@Override
	public Object afterBodyRead(Object body, HttpInputMessage inputMessage, MethodParameter parameter, Type targetType,
			Class<? extends HttpMessageConverter<?>> converterType) {
		 Map<String, Object> map = RequestContextHolder.get();
		 
		 String uri =	(String) map.get(ParameterConstant.REQUEST_CONTENT);
		 String uniqueCode =  (String) map.get(ParameterConstant.UNIQUE_CODE);
		 String scity =  (String) map.get(ParameterConstant.CITY_CODE);
		
		if (logger.isDebugEnabled()) {
			StringBuilder sb = new StringBuilder();
			sb.append("\n" + new Gson().toJson(body));
			sb.append("\n");

			logger.debug("\n发送的请求信息={}", sb);
		}
		
		if (systemConstant.getIsEnableRequestLog()) {
			useCountService.toPost(uri, new Gson().toJson(body), uniqueCode, scity);
		}
		
		return body;
	}
	
	
}
