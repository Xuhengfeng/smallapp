package com.ztj.dichan.cust.appapi.vo;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author liuweichen
 */
@ApiModel(value="房源统计")
@Data
@EqualsAndHashCode(callSuper=true)
public class StatisticsInfoVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;

   /**
    * 均价
    */
	@ApiModelProperty(value="均价")
   private Double avgPrice;
	
   /**
    * 成交套数
    */
	@ApiModelProperty(value="成交套数")
   private int suiteCount;
   /**
    * 月份
    */
	@ApiModelProperty( value="月份")
   private Integer month;
	
}
