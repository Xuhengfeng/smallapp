
package com.ztj.dichan.cust.appapi.vo;

import java.util.List;
import java.util.Map;

import com.ztj.common.vo.BaseValueObject;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode(callSuper = true)
public class IndexCityVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	private List<Map<String, Object>> item;
	
	private String title;
}
