package com.ztj.dichan.cust.appapi.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public abstract class AbstractException extends RuntimeException {

	private static final long serialVersionUID = -6871301963969100391L;
	
	private String errCode;

    public AbstractException(String errCode, String message) {
        super(message);
        this.errCode = errCode;
    }
}
