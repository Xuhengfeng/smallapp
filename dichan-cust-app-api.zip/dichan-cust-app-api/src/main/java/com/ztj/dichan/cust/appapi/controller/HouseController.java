package com.ztj.dichan.cust.appapi.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.constant.SystemConstant;
import com.ztj.dichan.cust.appapi.rest.BaseCustRest;
import com.ztj.dichan.cust.appapi.service.AppointHouseRecordService;
import com.ztj.dichan.cust.appapi.service.BuildingService;
import com.ztj.dichan.cust.appapi.service.ContrastService;
import com.ztj.dichan.cust.appapi.service.DictionaryService;
import com.ztj.dichan.cust.appapi.service.HouseService;
import com.ztj.dichan.cust.appapi.util.HttpUtil;
import com.ztj.dichan.cust.appapi.vo.DictionaryVo;
import com.ztj.dichan.cust.appapi.vo.LoginInfoVo;
import com.ztj.dichan.cust.appapi.vo.appoint.AppointHouseRecordHouseVo;
import com.ztj.dichan.cust.core.enums.DicType;
import com.ztj.dichan.cust.core.enums.HouseTypeStatusEnum;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseRecmdVo;
import com.ztj.dichan.cust.rule.response.house.HouseSeeRecordVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseRecmdVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

@Controller
@RequestMapping(value = "/house_c")
public class HouseController  extends BaseCustRest  {
	
	
	@Resource
	private HouseService houseService;
	

	@Resource
	private BuildingService buildingService;
	
	@Resource
	private DictionaryService dictionaryService;
	
	@Resource
	protected SystemConstant systemConstant;
	
	@Resource
	private ContrastService contrastService;
	
	@Resource
	private AppointHouseRecordService appointHouseRecordService;

	// 二手房
	@RequestMapping("/twohouse")
	public String twoHouse(Model model, Integer roomsNum, Integer areaId, Integer districtId, Double minPrice,
			Double maxPrice, Double minBuildArea, Double maxBuildArea, String houseForm, String houseDecor,
			String houseDirec, String houseFeature, String useYear, String keyword, String scity, Integer pageNo,
			Integer pageSize) {
		
		if(scity.isEmpty()) {
			scity = "beihai";
		}
		HouseRequest request = new HouseRequest();
		request.setRoomsNum(roomsNum);
		request.setAreaId(areaId);
		request.setDistrictId(districtId);
		request.setMinPrice(minPrice);
		request.setMaxPrice(maxPrice);
		request.setMinBuildArea(minBuildArea);
		request.setMaxBuildArea(maxBuildArea);
		request.setHouseForm(houseForm);
		request.setHouseDecor(houseDecor);
		request.setHouseDirec(houseDirec);
		request.setHouseFeature(houseFeature);
		request.setUseYear(useYear);
		request.setKeyword(keyword);
		request.setScity(scity);
		request.setPageNo(pageNo);
		request.setPageSize(pageSize);

		DicType[] dicTypes = { DicType.SELL_PRICE, DicType.HOUSE_AREA, DicType.HOUSE_HUXING, DicType.HOUSE_DECORATION,
				DicType.HOUSE_AGE, DicType.HOUSE_DIRECTION, DicType.HOUSE_FEATURE };
		Map<String, List<DictionaryVo>> tags = dictionaryService.queryDictionaryList(dicTypes);

		String areas = HttpUtil.doGet(systemConstant.getCustServiceUrl() + "/area/areas/" + scity + "");
		JSONObject json = JSONObject.parseObject(areas);
		JSONArray areaJson = (JSONArray) json.get("data");

		List<HouseVo> list = houseService.queryList(request, getCurrentMemberIdAllowNull());
		
		
		CountVo countVo = houseService.queryListCount(request, getCurrentMemberIdAllowNull());
		
		model.addAttribute("houseList", list);
		model.addAttribute("tags", tags);
		model.addAttribute("areas", areaJson);
		model.addAttribute("countVo", countVo);
		model.addAttribute("scity", scity);
		
		logger.info(JSON.toJSONString(tags));
		logger.info(JSON.toJSONString(areaJson));
		return "/twohouse";
	}

	// 二手房详情
	@RequestMapping("/twohousedetail/{scity}/{sdid}")
	public String twohousedetail(Model model,@PathVariable("scity") String scity,@PathVariable("sdid") Long sdid) {
		HouseDetailVo info = houseService.getDetailInfo(scity, sdid,getCurrentMemberIdAllowNull());
		List<SecondHouseVo> recmdVoList = buildingService.secondHouseList(Long.parseLong(info.getBuildSdid()),scity,0,10);
		RimHouseRequest rimHouseRequest = new RimHouseRequest();
		rimHouseRequest.setBuildSdid(Long.parseLong(info.getBuildSdid()));
		rimHouseRequest.setScity(scity);
		rimHouseRequest.setPageSize(0);
		rimHouseRequest.setPageNo(10);
		rimHouseRequest.setPx(info.getPx().doubleValue());
		rimHouseRequest.setPy(info.getPy().doubleValue());
		List<HouseVo> rimHousingList = houseService.rimHousing(rimHouseRequest);
		
		BuildingDetailVo detailVo = buildingService.buildInfo(Long.parseLong(info.getBuildSdid()),scity,getCurrentMemberIdAllowNull());
		
		List<HouseSeeRecordVo> seeList = houseService.getHouseSeeRecordList(info.getId(), 1, 10,scity);
		
		model.addAttribute("info", info);
		model.addAttribute("buildDetailVo", detailVo);
		model.addAttribute("buildHouseList", recmdVoList);
		model.addAttribute("rimHousingList", rimHousingList);
		model.addAttribute("seeList", seeList);
		model.addAttribute("scity", scity);
		
		logger.info(JSON.toJSONString(info));
		logger.info(JSON.toJSONString(detailVo));
		logger.info(JSON.toJSONString(recmdVoList));
		logger.info(JSON.toJSONString(rimHousingList));
		logger.info(JSON.toJSONString(seeList));
		return "/twohousedetail";
	}
	


	@RequestMapping("/loginInfo")
	@ResponseBody
	public  RestResult<LoginInfoVo> userLoginInfo(String scity,Long sdid,HouseTypeStatusEnum houseType){
		
		LoginInfoVo infoVo = new LoginInfoVo();
		List<HouseVo> houseList = new ArrayList<HouseVo>();
		int count = 0;
		List<AppointHouseRecordHouseVo> voList = appointHouseRecordService.queryReadyHouseList(getCurrentMemberId(),1, 4);
		for (AppointHouseRecordHouseVo appointHouseRecordHouseVo : voList) {
			for (HouseVo house : appointHouseRecordHouseVo.getHouseList()) {
				houseList.add(house);
				count++;
				if(count>4) {
					break;
				}
			}
			if(count>4) {
				break;
			}
		}
		infoVo.setHouseList(houseList);
		if(houseType.equals(HouseTypeStatusEnum.HOUSE)) {
			List<HouseRecmdVo> contrasList = contrastService.usedContrastList(scity, getCurrentMemberId());
			infoVo.setContrasList(contrasList);
		}else {
			List<RentHouseRecmdVo> rentContrasList = contrastService.rentContrastList(scity, getCurrentMemberId());
			infoVo.setRentContrasList(rentContrasList);
		}
		HouseDetailVo info = houseService.getDetailInfo(scity, sdid,getCurrentMemberIdAllowNull());
		if(info!=null) {
			infoVo.setIsAppoint(info.getIsAppoint());
			infoVo.setIsCollect(info.getIsCollect());
			infoVo.setIsComparison(info.getIsComparison());
		}
		return RestResult.success(infoVo);
	}
	
	

}
