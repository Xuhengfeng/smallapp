/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ztj.dichan.cust.rule.request.ShopRequest;
import com.ztj.dichan.cust.rule.response.NearbyBrokerVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;
import com.ztj.dichan.cust.rule.response.shop.ShopVo;

/**
 * @author lbs
 *
 */
@FeignClient(name = "shopServiceClient", url= "${cust.service.url}", fallback = BrokerServiceClientFallBack.class)
public interface ShopServiceClient {

	@RequestMapping(method = RequestMethod.POST, value = "/department/departments")
	public List<ShopVo> queryShops(@RequestBody ShopRequest shopRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@RequestMapping(method = RequestMethod.POST, value = "/department/departmentsCount")
	public CountVo queryShopsCount(@RequestBody ShopRequest shopRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/department/nearbyBroker")
	public List<NearbyBrokerVo> queryNearbyBroker(@RequestBody ShopRequest shopRequest,
			@RequestHeader(value = "scity", required = true) String scity);
}
