/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ztj.dichan.cust.rule.request.BrokerHouseRequest;
import com.ztj.dichan.cust.rule.request.EmplClientRequest;
import com.ztj.dichan.cust.rule.response.EmployeeDetailVo;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerDetailVo;
import com.ztj.dichan.cust.rule.response.broker.BrokerVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * @author lbs
 *
 */
@FeignClient(name = "brokerServiceClient", url= "${cust.service.url}", fallback = BrokerServiceClientFallBack.class)
public interface BrokerServiceClient {
	
	@RequestMapping(method = RequestMethod.POST, value = "/employee/employees")
	public List<BrokerVo> queryBrokers(EmplClientRequest emplClientRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	@RequestMapping(method = RequestMethod.POST, value = "/employee/employeeCount")
	public CountVo queryBrokerCount(EmplClientRequest emplClientRequest,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/employee/house/employees")
	public List<BrokerVo> queryHouseBrokers(BrokerHouseRequest request,
			@RequestHeader(value = "scity", required = true) String scity);
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/employee/detail/{empId}")
	public BrokerDetailVo queryBroker(@RequestHeader(value = "scity", required = true) String scity,
			@PathVariable("empId")Integer empId);
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/employee/notdep/{empId}")
	public BrokerDetailVo queryBroker2(@RequestHeader(value = "scity", required = true) String scity,
			@PathVariable("empId")Integer empId);
	
	@RequestMapping(method = RequestMethod.GET, value = "/employee/houseList/{empId}")
	public List<HouseVo> queryBrokerHouseList(@RequestHeader(value = "scity", required = true) String scity,
			@PathVariable("empId")Integer empId,
			@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize);
	
	@RequestMapping(method = RequestMethod.GET, value = "/employee/rentHouseList/{empId}")
	public List<RentHouseVo> queryBrokerRentHouseList(@RequestHeader(value = "scity", required = true) String scity,
			@PathVariable("empId")Integer empId,
			@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize);
	
	
	@RequestMapping(method = RequestMethod.GET, value = "/employee/getDetailInfo")
	public EmployeeDetailVo getDetailInfo(@RequestHeader(value = "scity", required = true) String scity,
			@RequestParam("empId")Integer empId);
	
	@RequestMapping(method = RequestMethod.PUT, value = "/employee/grade/{empId}")
	public void updateEmployeeGrade(@RequestHeader(value = "scity", required = true) String scity,
			@PathVariable("empId")Integer empId,
			@RequestParam(name = "grade", required = true) Double grade);
}
