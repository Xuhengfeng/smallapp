package com.ztj.dichan.cust.appapi.rest;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.dichan.cust.appapi.service.RecordVersionService;
import com.ztj.dichan.cust.appapi.vo.RecordVersionQueryVo;
import com.ztj.dichan.cust.appapi.vo.RecordVersionVo;
import com.ztj.dichan.cust.core.constant.RestResult;
import com.ztj.dichan.cust.core.entity.RecordVersionOld;

//120.77.240.10/ztj-dichan/dichan-cust-app-api.git

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author sily
 *
 */
@Api(value = "版本记录管理", description = "版本记录管理")
@RestController
@RequestMapping(value = "/version")
public class RecordVersionRest extends BaseCustRest {

	@Resource
	private RecordVersionService recordVersionService;

	@ApiOperation(value = "版本更新", response = RecordVersionVo.class)
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	public RestResult query(@RequestBody RecordVersionQueryVo queryVo) {

		RecordVersionVo recordVersionVo = recordVersionService.queryList(queryVo);

		return new RestResult(recordVersionVo);
	}

	@ApiOperation(value = "旧的版本更新", response = RecordVersionOld.class)
	@RequestMapping(value = "/getOne", method = { RequestMethod.POST })
	public RestResult getOne(@RequestBody RecordVersionQueryVo parm) {

		return new RestResult(recordVersionService.getOne(parm));

	}
	
	@ApiOperation(value = "推广接口", response = RecordVersionVo.class)
	@RequestMapping(value = "/generalize", method = { RequestMethod.POST })
	public RestResult generalize() {

		return new RestResult(recordVersionService.generalize());

	}

}
