package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.request.HouseEntrustApplyCancelRequest;
import com.ztj.dichan.cust.appapi.request.HouseEntrustApplyRequest;
import com.ztj.dichan.cust.appapi.service.HouseEntrustApplyService;
import com.ztj.dichan.cust.appapi.vo.HouseEntrustApplyDetailVo;
import com.ztj.dichan.cust.appapi.vo.HouseEntrustApplyVo;
import com.ztj.dichan.cust.appapi.vo.RentEntrustApplyDetailVo;
import com.ztj.dichan.cust.core.enums.ApplicationTypeEnum;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.renthouse.RentHouseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author liuweichen
 *
 */
@Api(value ="租/售房源申请",description="租/售房申请源相关接口")
@RestController
@RequestMapping(value = "/houseEntrustApply")
public class HouseEntrustApplyRest extends BaseCustRest {
	
	@Resource
	private HouseEntrustApplyService houseEntrustApplyService;
	
	
	/**
	 * 售房源申请
	 * @param request
	 * @return
	 */
	@ApiOperation(value = "我要卖房申请")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true)})
	@RequestMapping(value = "/sellHouse", method = { RequestMethod.POST })
	public RestResult<?>  sellHouseEntrustApply(@RequestBody HouseEntrustApplyRequest request) {

		houseEntrustApplyService.addHouseEntrustApply(getCurrentMemberId(), ApplicationTypeEnum.SELL,request);

		return RestResult.success();

	}
	
	/**
	 * 出租房源申请
	 * @param request
	 * @return
	 */
	@ApiOperation(value = "我要出租申请")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true)})
	@RequestMapping(value = "/rentHouse", method = { RequestMethod.POST })
	public RestResult<?>  rentHouseEntrustApply(@RequestBody HouseEntrustApplyRequest request) {
		
		houseEntrustApplyService.addHouseEntrustApply(getCurrentMemberId(), ApplicationTypeEnum.RENT,request);

		return RestResult.success();
		

	}
	
	
	/**
	 * 我的卖房申请列表
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	@ApiOperation(value = "我的卖房申请列表", response = HouseEntrustApplyVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", dataType = "int", paramType = "query", required = true, example="1"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", dataType = "int", paramType = "query", required = false,example="10")})
	@RequestMapping(value = "/querySellApplyList", method = { RequestMethod.GET })
	public RestResult<List<HouseEntrustApplyVo>> querySellApplyList(@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		
		List<HouseEntrustApplyVo> list = houseEntrustApplyService.houseEntrustApplyList(getCurrentMemberId(), ApplicationTypeEnum.SELL, pageNo, pageSize);
		return RestResult.success(list);

	}
	
	/**
	 * 我的出租申请列表
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	@ApiOperation(value = "我的出租申请列表", response = HouseEntrustApplyVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", dataType = "int", paramType = "query", required = true, example="1"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", dataType = "int", paramType = "query", required = false,example="10")})
	@RequestMapping(value = "/queryRentApplyList", method = { RequestMethod.GET })
	public RestResult<List<HouseEntrustApplyVo>> queryRentApplyList(@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		
		List<HouseEntrustApplyVo> list = houseEntrustApplyService.houseEntrustApplyList(getCurrentMemberId(), ApplicationTypeEnum.RENT, pageNo, pageSize);
		return RestResult.success(list);

	}
	
	/**
	 * 获取我的出租申请详情
	 * @param id
	 * @return
	 */
	@ApiOperation(value = "获取我的出租申请详情", response = RentEntrustApplyDetailVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "id", value = "申请Id", dataType = "int", paramType = "path", required = true)})
	@RequestMapping(value = "/rent/{id}", method = { RequestMethod.GET })
	public RestResult<RentEntrustApplyDetailVo> getEntrustRentApply(@PathVariable("id")Long id) {
		
		return RestResult.success(this.houseEntrustApplyService.getEntrustRentApplyDetail(getCurrentMemberId(), id));

	}
	
	/**
	 * 获取我的卖房申请详情
	 * @param id
	 * @return
	 */
	@ApiOperation(value = "获取我的卖房申请详情", response = HouseEntrustApplyDetailVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "id", value = "申请Id", dataType = "int", paramType = "path", required = true)})
	@RequestMapping(value = "/sell/{id}", method = { RequestMethod.GET })
	public RestResult<HouseEntrustApplyDetailVo> getEntrustHouseApply(@PathVariable("id")Long id) {
		
		return RestResult.success(this.houseEntrustApplyService.getEntrustHouseApplyDetail(getCurrentMemberId(), id));

	}
	
	
	/**
	 * 委托出售房源列表
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	@ApiOperation(value = "委托二手房源列表", response = HouseVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", dataType = "int", paramType = "query", required = true, example="1"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", dataType = "int", paramType = "query", required = false,example="10")})
	@RequestMapping(value = "/querySellHouseList", method = { RequestMethod.GET })
	public RestResult<List<HouseVo>> querySellHouseList(@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		
		List<HouseVo> list = houseEntrustApplyService.queryEntrustHouseList(getCurrentMemberId(), pageNo, pageSize);
		return RestResult.success(list);

	}
	
	/**
	 * 委托出售房源列表
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	@ApiOperation(value = "委托出租房源列表", response = RentHouseVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "String", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "pageNo", value = "当前页码", dataType = "int", paramType = "query", required = true, example="1"),
			@ApiImplicitParam(name = "pageSize", value = "每页大小,默认10", dataType = "int", paramType = "query", required = false,example="10")})
	@RequestMapping(value = "/queryRentHouseList", method = { RequestMethod.GET })
	public RestResult<List<RentHouseVo>> queryRentHouseList(@RequestParam(name="pageNo", required = false)Integer pageNo,
			@RequestParam(name="pageSize", required = false)Integer pageSize) {
		
		List<RentHouseVo> list = houseEntrustApplyService.queryEntrustRentHouseList(getCurrentMemberId(), pageNo, pageSize);
		return RestResult.success(list);

	}
	
	/**
	 * 取消卖房委托
	 * @param id
	 * @return
	 */
	@ApiOperation(value = "取消卖房委托")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true)})
	@RequestMapping(value = "/sell/cancel", method = { RequestMethod.PUT })
	public RestResult<String> cancelEntrustHouseApply(@RequestBody HouseEntrustApplyCancelRequest request) {
		this.houseEntrustApplyService.cancelEntrustHouseApply(getCurrentMemberId(), request);
		return RestResult.success("操作成功！");

	}
	
	/**
	 * 取消出租委托
	 * @param id
	 * @return
	 */
	@ApiOperation(value = "取消出租委托")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "unique-code", value = "用戶token标识", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true)})
	@RequestMapping(value = "/rent/cancel", method = { RequestMethod.PUT })
	public RestResult<String> cancelEntrustRentHouseApply(@RequestBody HouseEntrustApplyCancelRequest request) {
		this.houseEntrustApplyService.cancelEntrustHouseApply(getCurrentMemberId(), request);
		return RestResult.success("操作成功！");

	}
	

}
