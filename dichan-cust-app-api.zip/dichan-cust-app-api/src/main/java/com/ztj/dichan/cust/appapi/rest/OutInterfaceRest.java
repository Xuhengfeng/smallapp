package com.ztj.dichan.cust.appapi.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * 
 * @author sily
 */
@Api(value = "外部调用接口")
@RestController
@RequestMapping(value = "/out")
public class OutInterfaceRest extends BaseCustRest {

	/**
	 * 
	 * @return
	 */
	@ApiOperation(value = "心跳测试")
	@RequestMapping(value = "/ack", method = { RequestMethod.GET, RequestMethod.POST })
	public RestResult<String> ack() {
		try {
			// do none
		} catch (Exception e) {
			logger.error("心跳检测出错了", e);
		}

		return RestResult.success("ack ok");
	}

}