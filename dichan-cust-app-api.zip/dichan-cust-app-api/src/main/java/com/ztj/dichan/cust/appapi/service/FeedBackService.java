package com.ztj.dichan.cust.appapi.service;

import java.time.LocalDateTime;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.ztj.common.exception.BizException;
import com.ztj.dichan.cust.core.entity.FeedBack;
import com.ztj.dichan.cust.core.repository.FeedBackRepository;

/**
 * 
 * @author liuweichen
 *
 */
@Service
@Transactional
public class FeedBackService extends BaseAppService	 {

	@Resource
	private FeedBackRepository feedBackRepository;

	public void addFeedBack(Long memberId, String content) {
		if (StringUtils.isEmpty(content)) {
			throw new IllegalArgumentException("内容不能为空");
		}

		try {
			FeedBack feedBack = new FeedBack();
			feedBack.setContent(content);
			feedBack.setMemberId(memberId);
			feedBack.setCreateDateTime(LocalDateTime.now());

			feedBackRepository.save(feedBack);
		} catch (Exception e) {
			throw new BizException("提交意见反馈信息出错了", e);
		}
	}
}
