package com.ztj.dichan.cust.appapi.vo.jiguang;

import com.ztj.common.vo.BaseValueObject;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

@ApiModel(value = "极光鉴权信息")
@Data
@EqualsAndHashCode(callSuper = true)
public class SignatureVo extends BaseValueObject {
	private static final long serialVersionUID = 1L;
	
	private String appkey;
	
	private String random_str;
	
	private String signature;
	
	private String timestamp;
	
	

}
