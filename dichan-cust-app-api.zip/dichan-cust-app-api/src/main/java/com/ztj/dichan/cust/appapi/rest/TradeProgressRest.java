/**
 * 
 */
package com.ztj.dichan.cust.appapi.rest;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ztj.common.constant.RestResult;
import com.ztj.dichan.cust.appapi.service.TradeProgressService;
import com.ztj.dichan.cust.core.rest.BaseRest;
import com.ztj.dichan.cust.rule.response.house.HouseTradeProgressVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @author lbs
 *
 */
@Api(value = "成交进度", description = "成交进度接口")
@RestController
@RequestMapping(value = "/tradeProgress")
public class TradeProgressRest extends BaseRest {

	@Resource
	private TradeProgressService tradeProgressService;
	
	
	/**
	 * 根据手机号码和验证码查询相关的房源成交进度列表
	 * 
	 * @param phone
	 * @return
	 */
	@ApiOperation(value = "查询成交进度状态列表", response = HouseTradeProgressVo.class)
	@ApiImplicitParams(value = {
			@ApiImplicitParam(name = "scity", value = "城市编码", dataType = "string", paramType = "header", required = true),
			@ApiImplicitParam(name = "phone", value = "手机号码", required = true, dataType = "string", paramType="query"),
			@ApiImplicitParam(name = "smsCode", value = "验证码", required = true, dataType = "string", paramType="query")})
	@GetMapping(value = "/query")
	public RestResult<List<HouseTradeProgressVo>> queryTradeProgress(@RequestParam(name = "phone", required = true) String phone,
			@RequestParam(name = "smsCode", required = true) String smsCode) {
		
		List<HouseTradeProgressVo> dataList = this.tradeProgressService.queryTradeProgress(phone,smsCode);
		
		return RestResult.success(dataList);
	}
	
}
