/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ztj.dichan.cust.rule.request.buildnew.BuildRecmdRequest;
import com.ztj.dichan.cust.rule.request.buildnew.BuildRequest;
import com.ztj.dichan.cust.rule.request.buildnew.BuildingDyFhRequest;
import com.ztj.dichan.cust.rule.response.building.BuildingDetailVo;
import com.ztj.dichan.cust.rule.response.building.BuildingDzdyDetailVo;
import com.ztj.dichan.cust.rule.response.building.BuildingVo;
import com.ztj.dichan.cust.rule.response.building.DzDetailVo;
import com.ztj.dichan.cust.rule.response.building.HotBuildingVo;
import com.ztj.dichan.cust.rule.response.building.RentHouseVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * @author yincp
 *
 */
public class BuildServiceClientFallBack implements BuildingServiceClient {
	
	
	protected Logger logger = LoggerFactory.getLogger(getClass());

	@Override
	public List<BuildingVo> buildList(BuildRequest buildRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BuildingDetailVo buildInfo(Long sdid, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SecondHouseVo> secondHouseList(String scity, Long sdid, Integer pageNo, Integer pageSize) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<RentHouseVo> rentHouseList(String scity, Long sdid, Integer pageNo, Integer pageSize) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HotBuildingVo> hotBuilding(BuildRecmdRequest buildRecmdRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CountVo buildListCount(BuildRequest buildRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BuildingDzdyDetailVo queryBuildingDzdyDetail(Long sdid, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> queryBuildingDyfh(BuildingDyFhRequest request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<DzDetailVo> queryBuildingDz(Integer id, String scity) {
		// TODO Auto-generated method stub
		return null;
	}



}
