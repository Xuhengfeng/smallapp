/**
 * 
 */
package com.ztj.dichan.cust.appapi.external;

import java.util.List;

import com.ztj.dichan.cust.rule.request.EntrustHouseRequest;
import com.ztj.dichan.cust.rule.request.RimHouseRequest;
import com.ztj.dichan.cust.rule.request.TrendRequest;
import com.ztj.dichan.cust.rule.request.contract.HouseContrastRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRecmdRequest;
import com.ztj.dichan.cust.rule.request.house.HouseRequest;
import com.ztj.dichan.cust.rule.response.HouseVo;
import com.ztj.dichan.cust.rule.response.building.SecondHouseVo;
import com.ztj.dichan.cust.rule.response.house.HouseContrastDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseDetailVo;
import com.ztj.dichan.cust.rule.response.house.HouseRecmdVo;
import com.ztj.dichan.cust.rule.response.shop.CountVo;

/**
 * @author sily
 *
 */
public class HouseServiceClientFallBack implements HouseServiceClient {

	@Override
	public List<HouseVo> queryList(HouseRequest houseRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CountVo queryListCount(HouseRequest houseRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HouseDetailVo getDetailInfo(String scity, Long sdid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HouseRecmdVo> queryRecmdList(HouseRecmdRequest houseRecmdRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HouseVo> rimHousing(RimHouseRequest rimHouseRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<SecondHouseVo> housing60Days(TrendRequest trendRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HouseContrastDetailVo> houseContrast(HouseContrastRequest contrastRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public CountVo housing60DaysCount(TrendRequest trendRequest, String scity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HouseVo> queryEntrustHouseList(EntrustHouseRequest Request, String scity) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String lastMonth() {
		// TODO Auto-generated method stub
		return null;
	}


	
}